<#
.SYNOPSIS
  READ-ONLY, NO PowerCLI NEEDED. For each vCenter, lists every ESXi host that runs Windows VMs (Ativa excluded) with its
  PHYSICAL socket and core counts, then totals per cluster and per vCenter. Changes nothing.
  Works in plain Windows PowerShell 5.1 on the jump server (uses the vCenter web service at https://<vcenter>/sdk).

.DESCRIPTION
  - Physical cores = sockets x cores per socket as each host reports them (hyper-threads NOT counted).
  - "Has Windows" = at least one non-template VM whose guest OS is Windows (use -PoweredOnOnly to count only powered-on VMs).
  - Ativa is excluded by matching -ExcludePattern (regex, default 'ativa') against datacenter, cluster and host name.
    Excluded hosts get their own CSV so you can confirm the match is right.
  - LicensableCores is INFORMATION ONLY (Windows Server per-core rule: 8 per processor, 16 per host minimum).
    Confirm the rule and any datacenter-edition / Software Assurance terms with your licensing owner.
  - Login is typed at the prompt; the password is only sent to the vCenter you name.

.EXAMPLE
  .\Get-VmwareHostCoresNoPowerCLI.ps1 -VCenter cul-vmvce01.incmp.com
  .\Get-VmwareHostCoresNoPowerCLI.ps1 -VCenter cul-vmvce01.incmp.com -PoweredOnOnly
#>
param(
    [string[]]$VCenter = @('cul-vmvce01.incmp.com'),
    [string]$ExcludePattern = 'ativa',
    [switch]$PoweredOnOnly,
    [string]$OutDir = 'C:\Temp\VmwareCores'
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ps7 = $PSVersionTable.PSVersion.Major -ge 7
$skip = @{}
if ($ps7) { $skip.SkipCertificateCheck = $true }
else {
    Add-Type -TypeDefinition 'using System.Net;using System.Security.Cryptography.X509Certificates;public class TrustAllHC:ICertificatePolicy{public bool CheckValidationResult(ServicePoint s,X509Certificate c,WebRequest r,int p){return true;}}' -ErrorAction SilentlyContinue
    [Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllHC
}
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -Force | Out-Null }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'

function Invoke-Soap([string]$Body) {
    $xml = '<?xml version="1.0" encoding="UTF-8"?><soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:vim="urn:vim25"><soapenv:Body>' + $Body + '</soapenv:Body></soapenv:Envelope>'
    try {
        $r = Invoke-WebRequest -Uri ("https://{0}/sdk" -f $script:vc) -Method Post -Body ([Text.Encoding]::UTF8.GetBytes($xml)) -ContentType 'text/xml; charset=utf-8' -Headers @{ SOAPAction = '"urn:vim25/6.7.3"' } -WebSession $script:sess -UseBasicParsing @skip
    }
    catch {
        $msg = $_.Exception.Message
        try {
            $sr = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())
            $t = $sr.ReadToEnd()
            if ($t -match '<faultstring>(.*?)</faultstring>') { $msg = $Matches[1] }
        } catch {}
        throw "vCenter error: $msg"
    }
    $d = New-Object System.Xml.XmlDocument
    $d.LoadXml($r.Content)
    return $d
}
function Get-Node($doc, [string]$name) { return $doc.SelectSingleNode("//*[local-name()='$name']") }
function New-View([string]$Type) {
    $d = Invoke-Soap ('<vim:CreateContainerView><vim:_this type="ViewManager">' + $script:sc.vm + '</vim:_this><vim:container type="Folder">' + $script:sc.root + '</vim:container><vim:type>' + $Type + '</vim:type><vim:recursive>true</vim:recursive></vim:CreateContainerView>')
    return (Get-Node $d 'returnval').InnerText
}
# Returns one hashtable per object: Id, Type, P (property name -> value; object references come back as "Type|id")
function Get-Props([string]$Type, [string[]]$Paths) {
    $view = New-View $Type
    $ps = ($Paths | ForEach-Object { '<vim:pathSet>' + $_ + '</vim:pathSet>' }) -join ''
    $body = '<vim:RetrievePropertiesEx><vim:_this type="PropertyCollector">' + $script:sc.pc + '</vim:_this><vim:specSet><vim:propSet><vim:type>' + $Type + '</vim:type>' + $ps + '</vim:propSet><vim:objectSet><vim:obj type="ContainerView">' + $view + '</vim:obj><vim:skip>true</vim:skip><vim:selectSet xsi:type="vim:TraversalSpec"><vim:name>tv</vim:name><vim:type>ContainerView</vim:type><vim:path>view</vim:path><vim:skip>false</vim:skip></vim:selectSet></vim:objectSet></vim:specSet><vim:options><vim:maxObjects>500</vim:maxObjects></vim:options></vim:RetrievePropertiesEx>'
    $out = New-Object System.Collections.Generic.List[object]
    $d = Invoke-Soap $body
    while ($true) {
        foreach ($o in $d.SelectNodes("//*[local-name()='objects']")) {
            $ob = $o.SelectSingleNode("*[local-name()='obj']")
            $h = @{ Id = $ob.InnerText; Type = $ob.GetAttribute('type'); P = @{} }
            foreach ($pn in $o.SelectNodes("*[local-name()='propSet']")) {
                $n = $pn.SelectSingleNode("*[local-name()='name']").InnerText
                $v = $pn.SelectSingleNode("*[local-name()='val']")
                $t = $v.GetAttribute('type')
                $h.P[$n] = if ($t) { $t + '|' + $v.InnerText } else { $v.InnerText }
            }
            $out.Add($h)
        }
        $tok = Get-Node $d 'token'
        if (-not $tok -or -not $tok.InnerText) { break }
        $d = Invoke-Soap ('<vim:ContinueRetrievePropertiesEx><vim:_this type="PropertyCollector">' + $script:sc.pc + '</vim:_this><vim:token>' + $tok.InnerText + '</vim:token></vim:ContinueRetrievePropertiesEx>')
    }
    return $out.ToArray()
}

$all = New-Object System.Collections.Generic.List[object]
foreach ($vc in $VCenter) {
    Write-Host "`n=== $vc ===" -ForegroundColor Cyan
    $cred = Get-Credential -Message "Login for $vc (read-only is fine)"
    $script:vc = $vc
    $script:sess = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    try {
        $d = Invoke-Soap '<vim:RetrieveServiceContent><vim:_this type="ServiceInstance">ServiceInstance</vim:_this></vim:RetrieveServiceContent>'
        $script:sc = @{
            root = (Get-Node $d 'rootFolder').InnerText
            pc   = (Get-Node $d 'propertyCollector').InnerText
            vm   = (Get-Node $d 'viewManager').InnerText
            sm   = (Get-Node $d 'sessionManager').InnerText
        }
        $u = [Security.SecurityElement]::Escape($cred.UserName)
        $p = [Security.SecurityElement]::Escape($cred.GetNetworkCredential().Password)
        $null = Invoke-Soap ('<vim:Login><vim:_this type="SessionManager">' + $script:sc.sm + '</vim:_this><vim:userName>' + $u + '</vim:userName><vim:password>' + $p + '</vim:password></vim:Login>')
        $u = $null; $p = $null
    }
    catch { Write-Warning "Could not connect/log in to $vc : $($_.Exception.Message)"; continue }
    try {
        Write-Host 'Reading datacenters, clusters and hosts...' -ForegroundColor DarkGray
        # name + parent for everything above a host, so each host can be placed in a cluster and datacenter
        $ents = @{}
        foreach ($t in 'Folder', 'Datacenter', 'ComputeResource') {
            foreach ($e in (Get-Props $t @('name', 'parent'))) { $ents[$e.Id] = $e }
        }
        $hosts = Get-Props 'HostSystem' @('name', 'parent', 'summary.hardware.model', 'summary.hardware.cpuModel', 'summary.hardware.numCpuPkgs', 'summary.hardware.numCpuCores', 'summary.hardware.numCpuThreads', 'runtime.connectionState', 'summary.config.product.fullName')
        Write-Host ("Reading VMs (this can take a minute)...") -ForegroundColor DarkGray
        $vms = Get-Props 'VirtualMachine' @('name', 'runtime.host', 'runtime.powerState', 'config.template', 'config.guestId', 'config.guestFullName')
        $byHost = @{}
        foreach ($v in $vms) {
            $vp = $v.P
            if ($vp['config.template'] -eq 'true' -or -not $vp['runtime.host']) { continue }
            $hid = ($vp['runtime.host'] -split '\|')[1]
            $isWin = ("$($vp['config.guestId'])" -match '^windows') -or ("$($vp['config.guestFullName'])" -match 'Windows')
            if (-not $byHost.ContainsKey($hid)) { $byHost[$hid] = @{ WinTotal = 0; WinOn = 0; Other = 0 } }
            if ($isWin) {
                $byHost[$hid].WinTotal++
                if ($vp['runtime.powerState'] -eq 'poweredOn') { $byHost[$hid].WinOn++ }
            } else { $byHost[$hid].Other++ }
        }
        foreach ($h in ($hosts | Sort-Object { $_.P['name'] })) {
            $hp = $h.P
            # walk up from the host's parent to find the cluster and the datacenter
            $cluster = ''; $dcName = ''
            $cur = $hp['parent']
            $first = $true
            for ($i = 0; $i -lt 12 -and $cur; $i++) {
                $type, $id = $cur -split '\|'
                $e = $ents[$id]
                if ($first -and $type -eq 'ClusterComputeResource' -and $e) { $cluster = $e.P['name'] }
                $first = $false
                if ($type -eq 'Datacenter') { if ($e) { $dcName = $e.P['name'] }; break }
                $cur = if ($e) { $e.P['parent'] } else { $null }
            }
            $sockets = [int]$hp['summary.hardware.numCpuPkgs']
            $cores = [int]$hp['summary.hardware.numCpuCores']
            $threads = [int]$hp['summary.hardware.numCpuThreads']
            $perSocket = if ($sockets) { [int]($cores / $sockets) } else { 0 }
            $c = $byHost[$h.Id]
            $winTotal = if ($c) { $c.WinTotal } else { 0 }
            $winOn = if ($c) { $c.WinOn } else { 0 }
            $other = if ($c) { $c.Other } else { 0 }
            $hasWin = if ($PoweredOnOnly) { $winOn -gt 0 } else { $winTotal -gt 0 }
            $isAtiva = ("$dcName|$cluster|$($hp['name'])" -match $ExcludePattern)
            $status = if ($isAtiva) { 'EXCLUDED (Ativa)' } elseif (-not $hasWin) { 'No Windows VMs' } else { 'INCLUDED' }
            $lic = if ($sockets) { [math]::Max(16, $sockets * [math]::Max(8, $perSocket)) } else { 0 }
            $all.Add([pscustomobject]@{
                vCenter = $vc; Datacenter = $dcName; Cluster = $cluster; Host = $hp['name']
                Status = $status; State = $hp['runtime.connectionState']
                Model = $hp['summary.hardware.model']; CpuModel = ($hp['summary.hardware.cpuModel'] -replace '\s+', ' ')
                Sockets = $sockets; CoresPerSocket = $perSocket; PhysicalCores = $cores; Threads = $threads
                LicensableCores = $lic
                WindowsVMs = $winTotal; WindowsVMsPoweredOn = $winOn; OtherVMs = $other
                ESXi = $hp['summary.config.product.fullName']
            })
        }
        Write-Host ("Read {0} host(s) and {1} VM(s)." -f @($hosts).Count, @($vms).Count) -ForegroundColor DarkGray
    }
    catch { Write-Warning "Read failed on $vc : $($_.Exception.Message)" }
    finally { try { $null = Invoke-Soap ('<vim:Logout><vim:_this type="SessionManager">' + $script:sc.sm + '</vim:_this></vim:Logout>') } catch {} }
}

if (-not $all.Count) { throw 'No hosts were read. Check the errors above.' }
$f1 = Join-Path $OutDir "VmwareHostCores_All_$stamp.csv"
$f2 = Join-Path $OutDir "VmwareHostCores_Included_$stamp.csv"
$f3 = Join-Path $OutDir "VmwareHostCores_ExcludedAtiva_$stamp.csv"
$f4 = Join-Path $OutDir "VmwareHostCores_ByCluster_$stamp.csv"
$inc = @($all | Where-Object Status -eq 'INCLUDED')
$all | Export-Csv -NoTypeInformation -Path $f1
$inc | Export-Csv -NoTypeInformation -Path $f2
@($all | Where-Object Status -like 'EXCLUDED*') | Export-Csv -NoTypeInformation -Path $f3
$byCluster = $inc | Group-Object vCenter, Datacenter, Cluster | ForEach-Object {
    $g = $_.Group
    [pscustomobject]@{
        vCenter = $g[0].vCenter; Datacenter = $g[0].Datacenter; Cluster = $g[0].Cluster; Hosts = $g.Count
        Sockets = ($g | Measure-Object Sockets -Sum).Sum
        PhysicalCores = ($g | Measure-Object PhysicalCores -Sum).Sum
        LicensableCores = ($g | Measure-Object LicensableCores -Sum).Sum
        WindowsVMs = ($g | Measure-Object WindowsVMs -Sum).Sum
    }
} | Sort-Object vCenter, Datacenter, Cluster
$byCluster | Export-Csv -NoTypeInformation -Path $f4

Write-Host "`nPer cluster (hosts with Windows VMs, Ativa excluded):" -ForegroundColor Cyan
$byCluster | Format-Table vCenter, Cluster, Hosts, Sockets, PhysicalCores, LicensableCores, WindowsVMs -AutoSize
Write-Host 'Per vCenter:' -ForegroundColor Cyan
$inc | Group-Object vCenter | ForEach-Object {
    $g = $_.Group
    [pscustomobject]@{
        vCenter = $_.Name; Hosts = $g.Count
        Sockets = ($g | Measure-Object Sockets -Sum).Sum
        PhysicalCores = ($g | Measure-Object PhysicalCores -Sum).Sum
        LicensableCores = ($g | Measure-Object LicensableCores -Sum).Sum
    }
} | Format-Table -AutoSize
$ex = @($all | Where-Object Status -like 'EXCLUDED*'); $nw = @($all | Where-Object Status -eq 'No Windows VMs')
Write-Host ("Excluded as Ativa: {0} host(s). Hosts with no Windows VMs: {1}. Hosts not connected: {2}." -f $ex.Count, $nw.Count, @($all | Where-Object { $_.State -ne 'connected' }).Count) -ForegroundColor Yellow
Write-Host "Check which clusters were treated as Ativa: $f3" -ForegroundColor Yellow
Write-Host "`nFiles:`n  $f2`n  $f4`n  $f1`n  $f3" -ForegroundColor Green
