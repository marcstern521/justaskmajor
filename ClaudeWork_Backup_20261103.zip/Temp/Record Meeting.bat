@echo off
title Meeting Recorder
echo === Meeting Recorder ===
set "NAME="
set /p "NAME=Meeting name (e.g. aws-call, or just press Enter): "
if "%NAME%"=="" set "NAME=meeting"
python "%USERPROFILE%\MeetingRecorder\record_meeting.py" "%NAME%"
echo.
pause
