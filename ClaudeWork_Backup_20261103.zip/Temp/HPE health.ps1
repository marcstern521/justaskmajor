﻿# Search for the config file with that custom format
Get-ChildItem "$env:USERPROFILE" -Recurse -Depth 4 -ErrorAction SilentlyContinue | 
  Where-Object { $_.Name -match "config" -and $_.Extension -notmatch "\.log|\.bak" } |
  Select-Object FullName, LastWriteTime

# Also check appdata
Get-ChildItem "$env:APPDATA" -Recurse -Depth 3 -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -match "config" } |
  Select-Object FullName, LastWriteTime