﻿<#
.SYNOPSIS
  Term-user status check + INCMP cleanup (SCTASK0156751 - Bolivia, 177 users).

.DESCRIPTION
  DEFAULT = READ-ONLY. Checks every user in the list against:
    in.lab, inucn.com, incmp.com (AD), AWS IAM (per SSO profile), Pleasant Password (dal-insys01 / lax-ininf01)
  and writes a CSV report + console summary of what is still outstanding.

  -CleanupIncmp  : for users that EXIST in INCMP -> remove from groups, disable, move to Terminated Users OU,
                   (optional) delete profile/home folders, (optional) delete AD account.
                   Honors -WhatIf / -Confirm. Writes AuthLite_ToDelete.csv for the Token Manager step.

  Matches on: sAMAccountName, mail, UPN prefix, and INCMP style  first.last-######
  Anything unreachable from your laptop shows UNREACHABLE (not "clean") - never read that as OK.

.EXAMPLE
  # 1) check only
  .\Check-TermUsers.ps1 -InputFile C:\Temp\bolivia_177.txt

.EXAMPLE
  # 2) dry-run INCMP cleanup
  .\Check-TermUsers.ps1 -InputFile C:\Temp\bolivia_177.txt -CleanupIncmp -WhatIf

.EXAMPLE
  # 3) real INCMP cleanup incl. profile folders and AD delete
  .\Check-TermUsers.ps1 -InputFile C:\Temp\bolivia_177.txt -CleanupIncmp -RemoveProfileFolders -DeleteAccount -IncmpCredential (Get-Credential)

.NOTES
  InputFile: one user per line (email, username, or "first.last"); .csv with a column named
  Email / UserName / SamAccountName / Name also works.
  Requires: RSAT ActiveDirectory module. AWS CLI v2 only if -AwsProfiles is used.
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)] [string]$InputFile,
    [string]$OutDir = 'C:\Temp\TermCheck',
    [string]$Ticket = 'SCTASK0156751',

    # AD domains / servers (domain DNS name is used as -Server)
    [string]$LabDomain   = 'in.lab',
    [string]$InucnDomain = 'inucn.com',
    [string]$IncmpDomain = 'incmp.com',
    [pscredential]$LabCredential,
    [pscredential]$InucnCredential,
    [pscredential]$IncmpCredential,
    [switch]$UseCurrentLogonForInucn,
    [string[]]$OnlyDomains = @('in.lab','inucn','incmp'),   # e.g. -OnlyDomains incmp when running on a host inside FedRAMP
    [switch]$UseCurrentLogon,           # use the logged-on account for every domain, no prompts   # skip the INUCN prompt if your laptop logon already works there

    # AWS: SSO profile names (e.g. ic-prod, ic-dev, uk-sov). Run `aws sso login --profile X` first.
    [string[]]$AwsProfiles = @(),

    # Pleasant Password servers (REST). Needs a PP admin login.
    [string[]]$PleasantServers = @('dal-insys01.inucn.com:10001', 'lax-ininf01.inucn.com:10001'),
    [pscredential]$PleasantCredential,
    [switch]$SkipPleasant,

    # INCMP cleanup
    [switch]$CleanupIncmp,
    [switch]$RemoveProfileFolders,
    [switch]$DeleteAccount,
    [string]$ApprovedList,   # CSV with column SamAccountName (trim Candidates_*.csv after review). REQUIRED for -CleanupIncmp
    [string]$TerminatedOuName = 'Terminated Users',
    [string]$TerminatedOuDN   # exact DN of the target OU/container, e.g. 'OU=Terminated Users,DC=incmp,DC=com'
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir -WhatIf:$false | Out-Null }
$stamp   = Get-Date -Format 'yyyyMMdd_HHmmss'
$report  = Join-Path $OutDir "TermCheck_$stamp.csv"
$actions = Join-Path $OutDir "IncmpCleanup_$stamp.csv"
$authCsv = Join-Path $OutDir "AuthLite_ToDelete_$stamp.csv"

Import-Module ActiveDirectory -ErrorAction Stop

# ---------- load input ----------
# Preferred: CSV with EmployeeNumber,Name (made from the Bolivia sheet). Also accepts plain list of emails/usernames.
function Strip-Accents([string]$t) {
    $n = $t.Normalize([Text.NormalizationForm]::FormD)
    (-join ($n.ToCharArray() | Where-Object { [Globalization.CharUnicodeInfo]::GetUnicodeCategory($_) -ne 'NonSpacingMark' })).Normalize([Text.NormalizationForm]::FormC)
}
function New-Key([string]$Emp, [string]$Name, [string]$Email) {
    $clean = (Strip-Accents $Name) -replace "[^A-Za-z\- ']", ' ' -replace '\s+', ' '
    $t = @($clean.Trim().ToLower().Split(' ') | Where-Object { $_ })
    $cands = New-Object System.Collections.Generic.List[string]
    if ($Email) { $cands.Add(($Email.Split('@')[0]).ToLower()) }
    if ($t.Count -ge 2) {
        $f = $t[0]
        foreach ($l in @($t[-1], $(if ($t.Count -ge 3) { $t[-2] }), $(if ($t.Count -ge 3) { $t[1] })) | Where-Object { $_ }) {
            $c = "$f.$l"; if (-not $cands.Contains($c)) { $cands.Add($c) }
        }
    } elseif ($t.Count -eq 1 -and -not $Email) { $cands.Add($t[0]) }
    [pscustomobject]@{ Raw = $(if ($Name) { $Name } else { $Email }); Emp = $Emp; Name = $Name; Email = $Email; Cands = @($cands) }
}
function Get-InputUsers([string]$Path) {
    if ($Path -match '\.csv$') {
        $rows = Import-Csv $Path
        $h = $rows[0].PSObject.Properties.Name
        $empCol  = $h | Where-Object { $_ -match 'employee.*(number|id)|^emp' } | Select-Object -First 1
        $nameCol = $h | Where-Object { $_ -match '^name$|employee.?name|full.?name|display' } | Select-Object -First 1
        $mailCol = $h | Where-Object { $_ -match 'mail' } | Select-Object -First 1
        $samCol  = $h | Where-Object { $_ -match 'sam|user.?name' } | Select-Object -First 1
        foreach ($r in $rows) {
            $name = if ($nameCol) { "$($r.$nameCol)".Trim() } else { '' }
            $mail = if ($mailCol) { "$($r.$mailCol)".Trim() } else { '' }
            if (-not $mail -and $samCol) { $name = if ($name) { $name } else { "$($r.$samCol)" }; $mail = '' }
            $k = New-Key $(if ($empCol) { "$($r.$empCol)".Trim() } else { '' }) $name $mail
            if ($samCol -and $r.$samCol) { $k.Cands = @($k.Cands) + "$($r.$samCol)".Trim().ToLower() }
            $k
        }
    } else {
        foreach ($line in (Get-Content $Path | ForEach-Object { "$_".Trim() } | Where-Object { $_ })) {
            if ($line -match '@') { New-Key '' '' $line }
            else { $k = New-Key '' '' ''; $k.Raw = $line; $k.Cands = @($line.ToLower()); $k }
        }
    }
}
$users = @(Get-InputUsers $InputFile)
Write-Host "Loaded $($users.Count) users from $InputFile" -ForegroundColor Cyan
function Esc([string]$s) { $s -replace '\\','\5c' -replace '\*','\2a' -replace '\(','\28' -replace '\)','\29' }

# ---------- AD lookup ----------
$adProps = 'DisplayName','Enabled','mail','DistinguishedName','MemberOf','profilePath','homeDirectory','LastLogonDate','Description'
function Find-AdUser($key, [string]$Domain, [pscredential]$Cred) {
    $parts = @()
    if ($key.Emp) {
        $e = Esc $key.Emp
        $parts += "(sAMAccountName=*-$e)", "(employeeID=$e)", "(employeeNumber=$e)"
    }
    foreach ($c in $key.Cands) {
        $l = Esc $c
        $parts += "(sAMAccountName=$l)", "(sAMAccountName=$l-*)", "(userPrincipalName=$l@*)", "(mail=$l@*)"
    }
    if ($key.Name) { $n = Esc $key.Name; $parts += "(displayName=$n)", "(cn=$n)" }
    if (-not $parts) { return @() }
    $p = @{ LDAPFilter = "(&(objectCategory=person)(objectClass=user)(|$($parts -join '')))"; Server = $Domain; Properties = $adProps }
    if ($Cred) { $p.Credential = $Cred }
    for ($try = 1; $try -le 4; $try++) {
        try { return @(Get-ADUser @p) }
        catch {
            if ($try -eq 4 -or $_.Exception.Message -notmatch 'contact the server|timed out|unavailable|connection|forcibly') { throw }
            Start-Sleep -Seconds (3 * $try)   # transient drop (VPN/ADWS) - retry
        }
    }
}
function Test-Dom([string]$Domain, [pscredential]$Cred) {
    try {
        $p = @{ Server = $Domain }; if ($Cred) { $p.Credential = $Cred }
        $null = Get-ADDomain @p; $true
    } catch { Write-Warning "Cannot reach $Domain from this machine: $($_.Exception.Message)"; $false }
}
# Prompt for any domain credential not supplied (laptop is Autopilot/UCN - don't assume Kerberos reaches the others).
# Use your admin account for each, e.g. INUCN\youradmin, IN.LAB\youradmin, INCMP\youradmin
if ($OnlyDomains -contains 'inucn' -and -not $UseCurrentLogon -and -not $InucnCredential -and -not $UseCurrentLogonForInucn) { $InucnCredential = Get-Credential -Message "INUCN admin ($InucnDomain)" }
if ($OnlyDomains -contains 'in.lab' -and -not $UseCurrentLogon -and -not $LabCredential)   { $LabCredential   = Get-Credential -Message "IN.LAB admin ($LabDomain)" }
if ($OnlyDomains -contains 'incmp' -and -not $UseCurrentLogon -and -not $IncmpCredential) { $IncmpCredential = Get-Credential -Message "INCMP admin ($IncmpDomain) - FedRAMP/MFA, may not be reachable from here" }

$domains = [ordered]@{
    'in.lab' = @{ Dom = $LabDomain;   Cred = $LabCredential;   Up = $false }
    'inucn'  = @{ Dom = $InucnDomain; Cred = $InucnCredential; Up = $false }
    'incmp'  = @{ Dom = $IncmpDomain; Cred = $IncmpCredential; Up = $false }
}
foreach ($k in @($domains.Keys)) { if ($OnlyDomains -notcontains $k) { $domains.Remove($k) } }
foreach ($k in $domains.Keys) { $domains[$k].Up = Test-Dom $domains[$k].Dom $domains[$k].Cred }

# ---------- AWS ----------
$awsOk = @{}
foreach ($p in $AwsProfiles) {
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    & aws sts get-caller-identity --profile $p 2>&1 | Out-Null
    $awsOk[$p] = ($LASTEXITCODE -eq 0); $ErrorActionPreference = $eap
    if (-not $awsOk[$p]) { Write-Warning "AWS profile $p not logged in (aws sso login --profile $p)" }
}
function Find-AwsUser($key, [string]$Profile) {
    $hits = @()
    $cands = @($key.Cands); if ($key.Email) { $cands += $key.Email }
    foreach ($c in $cands) {
        $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
        $out = (& aws iam get-user --user-name $c --profile $Profile 2>&1 | Out-String)
        $rc = $LASTEXITCODE; $ErrorActionPreference = $eap
        if ($rc -eq 0) { $hits += $c }
        elseif ($out -notmatch 'NoSuchEntity') { return 'ERROR' }
    }
    if ($hits) { "FOUND($($hits -join ','))" } else { 'NotFound' }
}

# ---------- Pleasant Password ----------
$ppUsers = @{}   # server -> list of user objects, or $null if unreachable
if (-not $SkipPleasant) {
    if (-not $PleasantCredential) { $PleasantCredential = Get-Credential -Message 'Pleasant Password admin login (or Cancel to skip)' }
    foreach ($srv in $PleasantServers) {
        try {
            if ($PSVersionTable.PSVersion.Major -lt 6) {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            }
            $body = @{ grant_type = 'password'; username = $PleasantCredential.UserName; password = $PleasantCredential.GetNetworkCredential().Password }
            $tok  = Invoke-RestMethod -Method Post -Uri "https://$srv/OAuth2/Token" -Body $body
            $hdr  = @{ Authorization = "Bearer $($tok.access_token)" }
            $ppUsers[$srv] = @(Invoke-RestMethod -Uri "https://$srv/api/v5/rest/users" -Headers $hdr)
            Write-Host "Pleasant $srv : $($ppUsers[$srv].Count) users loaded" -ForegroundColor DarkGray
        } catch {
            Write-Warning "Pleasant $srv unreachable/auth failed: $($_.Exception.Message)"
            $ppUsers[$srv] = $null
        }
    }
}
function Find-PleasantUser($key, [string]$Srv) {
    if ($null -eq $ppUsers[$Srv]) { return 'UNREACHABLE' }
    $m = $ppUsers[$Srv] | Where-Object {
        ($_.Username -and (@($key.Cands) -contains "$($_.Username)".ToLower())) -or
        ($_.Email -and $key.Email -and $_.Email -eq $key.Email)
    }
    if ($m) { 'FOUND' } else { 'NotFound' }
}

# ---------- check loop ----------
function Fmt-Ad($hits, $up) {
    if (-not $up) { return 'UNREACHABLE' }
    if (-not $hits) { return 'NotFound' }
    ($hits | ForEach-Object { "$($_.SamAccountName) [$($_.DisplayName)]:" + $(if ($_.Enabled) { 'ENABLED' } else { 'disabled' }) }) -join ' | '
}
$results = New-Object System.Collections.Generic.List[object]
$incmpHits = New-Object System.Collections.Generic.List[object]
$cands = New-Object System.Collections.Generic.List[object]
$candCsv = Join-Path $OutDir "Candidates_$stamp.csv"
$i = 0
foreach ($key in $users) {
    $i++; Write-Progress -Activity 'Checking users' -Status "$($key.Raw) ($i/$($users.Count))" -PercentComplete (100 * $i / $users.Count)
    $row = [ordered]@{ Input = $key.Raw; EmpNo = $key.Emp }
    foreach ($k in $domains.Keys) {
        $hits = $null
        if ($domains[$k].Up) {
            try { $hits = Find-AdUser $key $domains[$k].Dom $domains[$k].Cred } catch { $hits = $null; $row[$k] = "ERROR: $($_.Exception.Message)"; continue }
        }
        $row[$k] = Fmt-Ad $hits $domains[$k].Up
        foreach ($h in @($hits)) { if ($h) { $cands.Add([pscustomobject]@{ InputName = $key.Raw; Domain = $k; SamAccountName = $h.SamAccountName; DisplayName = $h.DisplayName; Enabled = $h.Enabled; Mail = $h.mail; LastLogon = $h.LastLogonDate; DN = $h.DistinguishedName }) } }
        if ($k -eq 'incmp' -and $hits) { $hits | ForEach-Object { $incmpHits.Add($_) } }
    }
    foreach ($p in $AwsProfiles) {
        $row["aws:$p"] = if ($awsOk[$p]) { Find-AwsUser $key $p } else { 'UNREACHABLE' }
    }
    if (-not $SkipPleasant) { foreach ($s in $PleasantServers) { $row["pp:$($s.Split('.')[0])"] = Find-PleasantUser $key $s } }
    $results.Add([pscustomobject]$row)
}
Write-Progress -Activity 'Checking users' -Completed
$results | Export-Csv $report -NoTypeInformation -WhatIf:$false
$cands | Export-Csv $candCsv -NoTypeInformation -WhatIf:$false
Write-Host "Candidates (REVIEW name matches!): $candCsv" -ForegroundColor Yellow
Write-Host "`nReport: $report" -ForegroundColor Green

# ---------- summary ----------
$cols = $results[0].PSObject.Properties.Name | Where-Object { $_ -notin 'Input','EmpNo' }
$sum = foreach ($c in $cols) {
    $v = $results.$c
    [pscustomobject]@{
        Check       = $c
        ENABLED_or_FOUND = @($v | Where-Object { $_ -match 'ENABLED|FOUND\(|^FOUND$' }).Count
        Disabled    = @($v | Where-Object { $_ -match ':disabled' -and $_ -notmatch 'ENABLED' }).Count
        NotFound    = @($v | Where-Object { $_ -eq 'NotFound' }).Count
        Unreachable = @($v | Where-Object { $_ -match 'UNREACHABLE|ERROR' }).Count
    }
}
$sum | Format-Table -AutoSize
$outstanding = $results | Where-Object { ($_.PSObject.Properties | Where-Object { $_.Name -notin 'Input','EmpNo' -and "$($_.Value)" -match 'ENABLED|FOUND\(|^FOUND$' }) }
Write-Host "Users with something still active/present: $(@($outstanding).Count) of $($users.Count)" -ForegroundColor Yellow
$outstanding | Select-Object -First 25 | Format-Table -AutoSize -Wrap

# ---------- INCMP cleanup ----------
if ($CleanupIncmp) {
    if (-not $domains['incmp'].Up) { throw 'INCMP not reachable from this machine - run this from a host that can reach it (FedRAMP/MFA).' }
    if (-not $incmpHits.Count) { Write-Host 'No INCMP accounts found - nothing to clean.' -ForegroundColor Green; return }
    if (-not $ApprovedList) { throw "Pass -ApprovedList <csv with column SamAccountName> (name-only matching is fuzzy - review Candidates_*.csv first)." }
    if (-not (Test-Path -LiteralPath $ApprovedList)) { throw "Approved list not found on THIS machine: $ApprovedList  (copy it here first)." }
    $approved = @(Import-Csv $ApprovedList | ForEach-Object { "$($_.SamAccountName)".ToLower() })
    $incmpHits = @($incmpHits | Where-Object { $sm = $_.SamAccountName.ToLower(); ($approved -contains $sm) -or (@($approved | Where-Object { $sm -like "$_-*" }).Count -gt 0) })
    Write-Host "Approved INCMP accounts to clean: $($incmpHits.Count)" -ForegroundColor Cyan
    if (-not $incmpHits.Count) { return }
    $inc = $domains['incmp']
    $base = @{ Server = $inc.Dom }; if ($inc.Cred) { $base.Credential = $inc.Cred }
    if ($TerminatedOuDN) {
        $termOu = Get-ADObject @base -Identity $TerminatedOuDN
    } else {
        $termOu = Get-ADObject @base -Filter "Name -eq '$TerminatedOuName'" | Where-Object ObjectClass -in 'organizationalUnit','container' | Select-Object -First 1
    }
    if (-not $termOu) { throw "Terminated target not found in $($inc.Dom). Pass -TerminatedOuDN '<exact DN>' (or -TerminatedOuName)." }
    Write-Host "Terminated OU: $($termOu.DistinguishedName)" -ForegroundColor Cyan

    $log = New-Object System.Collections.Generic.List[object]
    foreach ($u in ($incmpHits | Sort-Object DistinguishedName -Unique)) {
        $sam = $u.SamAccountName
        $note = @()
        try {
            # 1) groups
            $groups = @($u.MemberOf)
            foreach ($g in $groups) {
                if ($PSCmdlet.ShouldProcess($sam, "Remove from group $g")) {
                    Remove-ADGroupMember @base -Identity $g -Members $u.DistinguishedName -Confirm:$false
                }
            }
            $note += "groups removed: $($groups.Count)"
            # 2) disable + tag
            if ($PSCmdlet.ShouldProcess($sam, 'Disable account')) {
                Set-ADUser @base -Identity $u.DistinguishedName -Enabled $false -Description "TERM $Ticket $(Get-Date -f yyyy-MM-dd)"
            }
            # 3) profile / home folders
            foreach ($path in @($u.profilePath, $u.homeDirectory) | Where-Object { $_ }) {
                if (Test-Path -LiteralPath $path) {
                    if ($RemoveProfileFolders) {
                        if ($PSCmdlet.ShouldProcess($sam, "Delete folder $path")) { Remove-Item -LiteralPath $path -Recurse -Force; $note += "deleted $path" }
                    } else { $note += "FOLDER EXISTS (use -RemoveProfileFolders): $path" }
                } else { $note += "folder not present: $path" }
            }
            # 4) move to Terminated Users
            if ($PSCmdlet.ShouldProcess($sam, "Move to $($termOu.DistinguishedName)")) {
                Move-ADObject @base -Identity $u.DistinguishedName -TargetPath $termOu.DistinguishedName
            }
            # 5) optional delete (re-resolve DN after the move)
            if ($DeleteAccount) {
                if ($PSCmdlet.ShouldProcess($sam, 'DELETE AD account')) {
                    $cur = Get-ADUser @base -Filter "SamAccountName -eq '$sam'"
                    if ($cur) { Remove-ADUser @base -Identity $cur.DistinguishedName -Confirm:$false; $note += 'AD account deleted' }
                }
            }
            $log.Add([pscustomobject]@{ User = $sam; Result = 'OK'; Detail = ($note -join '; ') })
        } catch {
            $log.Add([pscustomobject]@{ User = $sam; Result = 'FAILED'; Detail = $_.Exception.Message })
            Write-Warning "$sam : $($_.Exception.Message)"
        }
    }
    $log | Export-Csv $actions -NoTypeInformation -WhatIf:$false
    $incmpHits | Select-Object SamAccountName, mail |
        Sort-Object SamAccountName -Unique | Export-Csv $authCsv -NoTypeInformation -WhatIf:$false
    $log | Format-Table -AutoSize -Wrap
    Write-Host "Cleanup log : $actions" -ForegroundColor Green
    Write-Host "AuthLite    : $authCsv  <- delete these tokens in AuthLite Token Manager on cva-indco01 (select user > Delete Keys). Not scripted." -ForegroundColor Yellow
}
else {
    if ($incmpHits.Count) {
        $incmpHits | Select-Object SamAccountName, mail | Sort-Object SamAccountName -Unique | Export-Csv $authCsv -NoTypeInformation -WhatIf:$false
        Write-Host "INCMP accounts found: $($incmpHits.Count). AuthLite list: $authCsv" -ForegroundColor Yellow
    }
}