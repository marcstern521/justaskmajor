#Requires -Version 7.0
<#
.SYNOPSIS
    Weekly HPE OneView Health Check - dal-inovd01.inucn.com
.DESCRIPTION
    Connects to HPE OneView via REST API using PowerShell 7 (TLS 1.3 support).
    Checks server hardware, enclosures, Synergy frames, interconnects, and
    active alerts. Exits 0 (all healthy) or 1 (issues found).
.PARAMETER Credential
    PSCredential for OneView (INUCN AD account). Prompts if omitted.
.PARAMETER OutputPath
    Optional path to write the report as a .txt file.
.EXAMPLE
    pwsh .\Invoke-OneViewHealthCheck.ps1
.EXAMPLE
    pwsh .\Invoke-OneViewHealthCheck.ps1 -OutputPath C:\temp\oneview.txt
#>

[CmdletBinding()]
param(
    [Parameter()]
    [PSCredential]$Credential,

    [Parameter()]
    [string]$OutputPath
)

Set-StrictMode -Off
$ErrorActionPreference = 'Stop'

$OneViewHost = 'https://dal-inovd01.inucn.com'
$IRM = @{ SkipCertificateCheck = $true; ContentType = 'application/json' }

# -- CREDENTIALS ---------------------------------------------------------------
if (-not $Credential) {
    $Credential = Get-Credential -Message 'HPE OneView - INUCN AD credentials (domain\username)'
}

$userName = $Credential.UserName
$domain   = 'inucn'
if ($userName -match '^(.+)\\(.+)$') {
    $domain   = $Matches[1]
    $userName = $Matches[2]
}

# -- HELPERS -------------------------------------------------------------------
$script:AuthToken  = $null
$script:ApiVersion = 300   # fallback; auto-detected below

function Invoke-OV {
    param([string]$Method, [string]$Path, [hashtable]$Body = $null)
    $headers = @{ 'X-API-Version' = $script:ApiVersion }
    if ($script:AuthToken) { $headers['Auth'] = $script:AuthToken }
    $splat = @{
        Uri                 = "$OneViewHost$Path"
        Method              = $Method
        Headers             = $headers
        SkipCertificateCheck = $true
    }
    if ($Body) {
        $splat['Body']        = ($Body | ConvertTo-Json -Depth 10)
        $splat['ContentType'] = 'application/json'
    }
    return Invoke-RestMethod @splat
}

function Get-Icon {
    param([string]$Status)
    switch -Regex ($Status.ToLower()) {
        'ok|normal|online|active|enabled|healthy'  { return '[OK]'   }
        'warning|degraded|attention|minor'          { return '[WARN]' }
        'critical|error|fail|offline|unknown'       { return '[FAIL]' }
        default                                     { return '[INFO]' }
    }
}

# -- REPORT SETUP --------------------------------------------------------------
$lines      = [System.Collections.Generic.List[string]]::new()
$issueCount = 0
$timestamp  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

$lines.Add('=' * 70)
$lines.Add('  HPE ONEVIEW WEEKLY HEALTH CHECK')
$lines.Add("  Run    : $timestamp")
$lines.Add("  Target : $OneViewHost")
$lines.Add('  Scope  : Server Hardware | Enclosures | Synergy Frames | Alerts')
$lines.Add('=' * 70)

try {
    # -- AUTO-DETECT API VERSION -----------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Connecting')
    $verResp = Invoke-RestMethod -Uri "$OneViewHost/rest/version" -Method GET `
                   -SkipCertificateCheck -ContentType 'application/json'
    $script:ApiVersion = $verResp.currentVersion
    $lines.Add("|  [OK] OneView reachable - API version: $($script:ApiVersion)")

    # -- AUTHENTICATE ----------------------------------------------------------
    $authResp = Invoke-OV -Method POST -Path '/rest/login-sessions' -Body @{
        userName        = $userName
        password        = $Credential.GetNetworkCredential().Password
        authLoginDomain = $domain
    }
    $script:AuthToken = $authResp.sessionID
    $lines.Add("|  [OK] Authenticated as $($Credential.UserName)")

    # -- ACTIVE ALERTS ---------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Active Alerts')
    try {
        $alertsResp = Invoke-OV -Method GET -Path "/rest/alerts?filter=alertState='Active'&count=100&sort=created:desc"
        $alerts   = $alertsResp.members
        $critical = @($alerts | Where-Object { $_.severity -eq 'Critical' })
        $warning  = @($alerts | Where-Object { $_.severity -eq 'Warning'  })

        $aIcon = if ($critical.Count -gt 0) { $issueCount++; '[FAIL]' }
                 elseif ($warning.Count -gt 0) { $issueCount++; '[WARN]' }
                 else { '[OK]' }

        $lines.Add("|  $aIcon $($alerts.Count) active -- $($critical.Count) Critical | $($warning.Count) Warning")
        foreach ($al in ($critical | Select-Object -First 10)) {
            $res = $al.associatedResource.resourceName ?? 'Unknown'
            $lines.Add("|    [CRIT] $res - $($al.description)")
        }
        foreach ($al in ($warning | Select-Object -First 5)) {
            $res = $al.associatedResource.resourceName ?? 'Unknown'
            $lines.Add("|    [WARN] $res - $($al.description)")
        }
        if ($alerts.Count -gt 15) { $lines.Add("|    ... $($alerts.Count - 15) more - review OneView console") }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve alerts: $($_.Exception.Message)")
    }

    # -- SERVER HARDWARE -------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Server Hardware')
    try {
        $hwResp  = Invoke-OV -Method GET -Path '/rest/server-hardware?start=0&count=500'
        $servers = $hwResp.members
        $srvCrit = @($servers | Where-Object { $_.status -eq 'Critical' })
        $srvWarn = @($servers | Where-Object { $_.status -eq 'Warning'  })
        $srvOk   = @($servers | Where-Object { $_.status -eq 'OK'       })

        $hwIcon = if ($srvCrit.Count -gt 0) { $issueCount++; '[FAIL]' }
                  elseif ($srvWarn.Count -gt 0) { $issueCount++; '[WARN]' }
                  else { '[OK]' }

        $lines.Add("|  $hwIcon $($servers.Count) servers -- OK: $($srvOk.Count) | Warn: $($srvWarn.Count) | Critical: $($srvCrit.Count)")
        foreach ($s in $srvCrit) { $lines.Add("|    [FAIL] $($s.name) - $($s.status) | Power: $($s.powerState)") }
        foreach ($s in $srvWarn) { $lines.Add("|    [WARN] $($s.name) - $($s.status) | Power: $($s.powerState)") }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve server hardware: $($_.Exception.Message)")
    }

    # -- ENCLOSURES (C7000) ----------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Enclosures (C7000)')
    try {
        $encs = (Invoke-OV -Method GET -Path '/rest/enclosures?start=0&count=100').members
        if ($encs.Count -gt 0) {
            foreach ($enc in $encs) {
                $icon = Get-Icon -Status $enc.status
                if ($enc.status -notin @('OK','Normal')) { $issueCount++ }
                $lines.Add("|  $icon $($enc.name) - Status: $($enc.status) | State: $($enc.state)")
            }
        } else {
            $lines.Add('|  [INFO] No C7000 enclosures found')
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve enclosures: $($_.Exception.Message)")
    }

    # -- SYNERGY LOGICAL ENCLOSURES --------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Synergy Frames (Logical Enclosures)')
    try {
        $les = (Invoke-OV -Method GET -Path '/rest/logical-enclosures?start=0&count=100').members
        if ($les.Count -gt 0) {
            foreach ($le in $les) {
                $icon = Get-Icon -Status $le.status
                if ($le.status -notin @('OK','Normal')) { $issueCount++ }
                $lines.Add("|  $icon $($le.name) - Status: $($le.status) | State: $($le.state)")
            }
        } else {
            $lines.Add('|  [INFO] No Synergy logical enclosures found')
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve logical enclosures: $($_.Exception.Message)")
    }

    # -- INTERCONNECTS ---------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Interconnects (Synergy Fabric)')
    try {
        $ics    = (Invoke-OV -Method GET -Path '/rest/interconnects?start=0&count=200').members
        $icBad  = @($ics | Where-Object { $_.status -notin @('OK','Normal') })
        $icIcon = if ($icBad.Count -gt 0) { $issueCount++; '[WARN]' } else { '[OK]' }
        $lines.Add("|  $icIcon $($ics.Count) interconnects -- $($icBad.Count) not OK")
        foreach ($ic in $icBad) { $lines.Add("|    [WARN] $($ic.name) - Status: $($ic.status)") }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve interconnects: $($_.Exception.Message)")
    }

    # -- LOGOUT ----------------------------------------------------------------
    try { Invoke-OV -Method DELETE -Path '/rest/login-sessions' | Out-Null } catch {}

} catch {
    $issueCount++
    $lines.Add('')
    $lines.Add("[FAIL] Fatal error: $($_.Exception.Message)")
    $lines.Add('Check credentials, network access, and OneView availability.')
}

# -- SUMMARY -------------------------------------------------------------------
$lines.Add('')
$lines.Add('=' * 70)
if ($issueCount -eq 0) {
    $lines.Add('  RESULT : ALL HEALTHY')
    $lines.Add('  ACTION : Safe to close SNOW tickets as "Closed Complete":')
    $lines.Add('           "Check Health of All Synergy Frames, hosts, and components"')
    $lines.Add('           "Weekly Review Task - US Synergy Compute Health Check"')
    $lines.Add('           "Weekly Review Task - US C7000 Compute Health Check"')
} else {
    $lines.Add("  RESULT : $issueCount ISSUE(S) FOUND - Review flagged items above")
    $lines.Add('  ACTION : Investigate before closing. Escalate FAIL/CRIT items.')
}
$lines.Add("  Run by : $env:USERNAME on $env:COMPUTERNAME")
$lines.Add('=' * 70)

$report = $lines -join "`n"
Write-Output $report

if ($OutputPath) {
    $report | Out-File -FilePath $OutputPath -Encoding UTF8
    Write-Host "`nReport written to: $OutputPath" -ForegroundColor Cyan
}

exit $(if ($issueCount -eq 0) { 0 } else { 1 })
