"""
record_meeting.py - record your mic + what you hear, transcribe locally with Whisper.

Usage:
    python record_meeting.py "aws-call"

Press Enter to stop. The transcript is saved to ~/MeetingNotes/ and copied to your
clipboard so you can paste it straight into a chat for action items.

Nothing leaves your machine. (The Whisper model is downloaded once on first run.)
"""
import datetime
import pathlib
import re
import subprocess
import sys
import threading
import wave

import numpy as np
import soundcard as sc
from faster_whisper import WhisperModel

# ---- settings you might change -------------------------------------------
MODEL_SIZE = "small.en"   # "base.en" = faster, "medium.en" = more accurate
KEEP_AUDIO = False        # True = also save .wav files next to the transcript
OUT_DIR = pathlib.Path.home() / "MeetingNotes"
# ---------------------------------------------------------------------------

SR = 16000  # Whisper wants 16 kHz


def record(device, channels, stop, chunks):
    """Read audio from one device in half-second pieces until told to stop."""
    with device.recorder(samplerate=SR, channels=channels) as rec:
        while not stop.is_set():
            chunks.append(rec.record(numframes=SR // 2))


def to_mono(chunks):
    if not chunks:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(chunks).mean(axis=1).astype(np.float32)


def save_wav(path, audio):
    pcm = (np.clip(audio, -1, 1) * 32767).astype(np.int16)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def transcribe(model, audio, who):
    if audio.size < SR:  # under 1 second, nothing to do
        return []
    segments, _ = model.transcribe(audio, language="en", vad_filter=True)
    return [(s.start, who, s.text.strip()) for s in segments if s.text.strip()]


def stamp(seconds):
    m, s = divmod(int(seconds), 60)
    return f"{m:02d}:{s:02d}"


def main():
    name = sys.argv[1] if len(sys.argv) > 1 else "meeting"
    name = re.sub(r"[^\w\- ]", "", name).strip().replace(" ", "-") or "meeting"  # safe filename
    now = datetime.datetime.now()

    speaker = sc.default_speaker()
    loopback = sc.get_microphone(id=str(speaker.name), include_loopback=True)
    mic = sc.default_microphone()
    print(f"Mic:          {mic.name}")
    print(f"System audio: {speaker.name}")

    stop = threading.Event()
    mic_chunks, sys_chunks = [], []
    threads = [
        threading.Thread(target=record, args=(mic, 1, stop, mic_chunks), daemon=True),
        threading.Thread(target=record, args=(loopback, loopback.channels, stop, sys_chunks), daemon=True),
    ]
    for t in threads:
        t.start()

    input("Recording... press Enter to stop.\n")
    stop.set()
    for t in threads:
        t.join(timeout=3)  # loopback can stall when nothing is playing; don't hang

    me = to_mono(mic_chunks)
    them = to_mono(sys_chunks)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    base = OUT_DIR / f"{now:%Y-%m-%d_%H%M}_{name}"
    if KEEP_AUDIO:
        save_wav(base.with_name(base.name + "_me.wav"), me)
        save_wav(base.with_name(base.name + "_them.wav"), them)

    print(f"Loading Whisper model ({MODEL_SIZE})...")
    model = WhisperModel(MODEL_SIZE, device="cpu", compute_type="int8")
    print("Transcribing (this can take a few minutes)...")
    lines = transcribe(model, me, "Me") + transcribe(model, them, "Them")
    lines.sort(key=lambda x: x[0])

    body = "\n".join(f"[{stamp(t)}] {who}: {text}" for t, who, text in lines)
    header = f"Meeting: {name}\nDate: {now:%Y-%m-%d %H:%M}\n\n"
    text_out = header + (body or "(no speech detected)")

    txt_path = base.with_suffix(".txt")
    txt_path.write_text(text_out, encoding="utf-8")

    try:  # copy to clipboard so you can paste it straight into a chat
        subprocess.run(["clip"], input=text_out.encode("utf-16-le"), check=False)
        print("Copied to clipboard.")
    except Exception:
        pass
    print(f"Saved: {txt_path}")


if __name__ == "__main__":
    main()
