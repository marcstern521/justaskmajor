# ============================================================
# Globalscape EFT / DMZ upgrade toolkit - shared helpers
# Dot-sourced by GS_1 .. GS_7. Keep this file in the same folder.
# Windows PowerShell 5.1 compatible. ASCII only on purpose.
# Version/hop data comes from the Globalscape Upgrade Runbook.
# ============================================================

$script:WorkDir       = 'C:\temp\globalscape'
$script:DefaultDomain = 'inucn.com'
$script:LogPath       = $null

# --- Targets (runbook) ---
$script:EFTTarget  = [version]'8.3.2.565'
$script:DMZTarget  = [version]'4.1.0'     # 4.1.0 build 88 is current; DisplayVersion format may vary
$script:EFTHopList = @('8.0.7.4','8.1.0.16','8.2.0.46','8.2.1.408','8.3.0.410','8.3.2.565') | ForEach-Object { [version]$_ }

# --- Small helpers ---
function Resolve-GSHost {
    param([Parameter(Mandatory)][string]$Name, [string]$Domain = $script:DefaultDomain)
    if ($Name -match '\.') { $Name } else { '{0}.{1}' -f $Name, $Domain }
}

function Get-GSCredential {
    param([pscredential]$Credential)
    if ($Credential) { $Credential } else { Get-Credential -Message 'Admin credentials for the target servers' }
}

function Start-GSLog {
    param([Parameter(Mandatory)][string]$Name)
    New-Item -Path $script:WorkDir -ItemType Directory -Force | Out-Null
    $script:LogPath = Join-Path $script:WorkDir ('{0}_{1}.txt' -f $Name, (Get-Date -Format 'yyyyMMdd'))
}

function Write-Log {
    param([string]$Message, [string]$Color = 'White')
    $entry = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Write-Host $entry -ForegroundColor $Color
    if ($script:LogPath) { Add-Content -Path $script:LogPath -Value $entry }
}

function Confirm-Typed {
    param([Parameter(Mandatory)][string]$Prompt, [string]$Expected = 'YES')
    (Read-Host ('{0} (type {1})' -f $Prompt, $Expected)) -eq $Expected
}

function ConvertTo-GSVersion {
    param($Text)
    try { [version]("$Text".Trim()) } catch { $null }
}

# --- Upgrade plan from the runbook's "Upgrade Paths by Current Version" table ---
#   8.0.2.x          -> 8.0.7.4 > 8.1.0.16 > 8.2.0.46 > 8.2.1.408 > 8.3.0.410 > 8.3.2.565
#   8.0.6.x / 8.0.7.x -> 8.1.0.16 > 8.2.0.46 > 8.2.1.408 > 8.3.0.410 > 8.3.2.565
#   8.1.0.x          -> 8.2.0.46 > ... > 8.3.2.565
#   8.3.0.x          -> 8.3.2.565 direct
# Anything older than 8.0.2 needs the staged 7.4.13.15 / 8.0.x path - not scripted.
function Get-EFTUpgradePlan {
    param([Parameter(Mandatory)][version]$Current)
    if ($Current -ge $script:EFTTarget)       { return [pscustomobject]@{ Status = 'Current'; Hops = @() } }
    if ($Current -lt [version]'8.0.2.0')      { return [pscustomobject]@{ Status = 'Manual';  Hops = @() } }
    $hops = @($script:EFTHopList | Where-Object { $_ -gt $Current })
    # 8.0.7.4 is only a required stop for builds older than 8.0.6
    if ($Current -ge [version]'8.0.6.0') { $hops = @($hops | Where-Object { $_ -ne [version]'8.0.7.4' }) }
    [pscustomobject]@{ Status = 'Upgrade'; Hops = $hops }
}

# --- Remote inventory ---
function Get-EFTInfo {
    param([Parameter(Mandatory)]$Session)
    Invoke-Command -Session $Session -ScriptBlock {
        $svc = Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like 'EFT Server*' -or $_.DisplayName -like 'EFT Server*' } |
            Select-Object -First 1

        $installDir = $null
        $exe = $null
        if ($svc -and $svc.PathName) {
            if     ($svc.PathName -match '^\s*"([^"]+)"') { $exe = $Matches[1] }
            elseif ($svc.PathName -match '^(.+?\.exe)')   { $exe = $Matches[1] }
            if ($exe) { $installDir = Split-Path $exe -Parent }
        }

        $uninstall = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
                     'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
        $app = Get-ChildItem $uninstall -ErrorAction SilentlyContinue |
            Get-ItemProperty -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like '*EFT*' -and $_.DisplayName -notlike '*DMZ*' } |
            Select-Object -First 1

        $net = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction SilentlyContinue
        $c = Get-PSDrive C -ErrorAction SilentlyContinue
        $d = Get-PSDrive D -ErrorAction SilentlyContinue

        # EFT data folder = the folder that holds ServerConfig.db (config DBs, logs, AdvancedProperties.json).
        # On these servers it is D:\Globalscape\EFT Server, separate from the program folder.
        $dataCands = @()
        if ($installDir) { $dataCands += $installDir }
        foreach ($root in @($env:ProgramData, 'C:\ProgramData', 'D:\ProgramData')) {
            if ($root) {
                foreach ($sub in 'Globalscape\EFT Server', 'Globalscape\EFT Server Enterprise') { $dataCands += ('{0}\{1}' -f $root, $sub) }
            }
        }
        foreach ($drv in 'C', 'D', 'E', 'F') {
            foreach ($sub in 'Globalscape\EFT Server', 'Globalscape\EFT Server Enterprise') { $dataCands += ('{0}:\{1}' -f $drv, $sub) }
        }
        $dataDir = $dataCands | Where-Object { Test-Path -LiteralPath ('{0}\ServerConfig.db' -f $_) } | Select-Object -First 1
        $ap = $null
        if ($dataDir) {
            $apFile = '{0}\AdvancedProperties.json' -f $dataDir
            if (Test-Path -LiteralPath $apFile) { $ap = $apFile }
        }

        [pscustomobject]@{
            Version        = $app.DisplayVersion
            AppName        = $app.DisplayName
            ServiceName    = $svc.Name
            ServiceState   = $svc.State
            ServiceAccount = $svc.StartName
            InstallDir     = $installDir
            DotNetRelease  = $net.Release
            DotNet48       = ([int]$net.Release -ge 528040)
            CFreeGB        = if ($c) { [math]::Round($c.Free / 1GB, 1) } else { $null }
            DFreeGB        = if ($d) { [math]::Round($d.Free / 1GB, 1) } else { $null }
            APJson         = $ap
            DataDir        = $dataDir
            OS             = (Get-CimInstance Win32_OperatingSystem).Caption
        }
    }
}

function Get-DMZInfo {
    param([Parameter(Mandatory)]$Session)
    Invoke-Command -Session $Session -ScriptBlock {
        $svc = Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*DMZ*' -or $_.DisplayName -like '*DMZ Gateway*' -or $_.PathName -like '*DMZ*' } |
            Select-Object -First 1

        $uninstall = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
                     'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
        $app = Get-ChildItem $uninstall -ErrorAction SilentlyContinue |
            Get-ItemProperty -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like '*DMZ Gateway*' } |
            Select-Object -First 1
        $version = $app.DisplayVersion
        if (-not $version) {
            $reg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -ErrorAction SilentlyContinue
            if (-not $reg) { $reg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -ErrorAction SilentlyContinue }
            $version = $reg.DisplayVersion
        }

        $c = Get-PSDrive C -ErrorAction SilentlyContinue
        $d = Get-PSDrive D -ErrorAction SilentlyContinue

        [pscustomobject]@{
            Version        = $version
            ServiceName    = $svc.Name
            ServiceState   = $svc.State
            ServiceAccount = $svc.StartName
            CFreeGB        = if ($c) { [math]::Round($c.Free / 1GB, 1) } else { $null }
            DFreeGB        = if ($d) { [math]::Round($d.Free / 1GB, 1) } else { $null }
            OS             = (Get-CimInstance Win32_OperatingSystem).Caption
        }
    }
}

# --- Remote actions ---
function Wait-GSService {
    param([Parameter(Mandatory)]$Session, [Parameter(Mandatory)][string]$Name, [int]$TimeoutSec = 180)
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    do {
        $state = Invoke-Command -Session $Session -ScriptBlock {
            param($n)
            (Get-CimInstance Win32_Service -Filter "Name='$n'" -ErrorAction SilentlyContinue).State
        } -ArgumentList $Name
        if ($state -eq 'Running') { return $true }
        Start-Sleep -Seconds 5
    } while ((Get-Date) -lt $deadline)
    $false
}

# Runs an installer on the remote box and waits up to the timeout.
# On timeout it does NOT kill the process - runbook says to kill it and run manually over RDP.
function Invoke-GSInstaller {
    param(
        [Parameter(Mandatory)]$Session,
        [Parameter(Mandatory)][string]$Path,
        [string]$InstallerArgs = '/S',
        [int]$TimeoutMinutes = 30
    )
    Invoke-Command -Session $Session -ScriptBlock {
        param($p, $installerArgs, $timeoutMs)
        $proc = Start-Process -FilePath $p -ArgumentList $installerArgs -PassThru
        if (-not $proc.WaitForExit($timeoutMs)) {
            return [pscustomobject]@{ TimedOut = $true; ExitCode = $null }
        }
        [pscustomobject]@{ TimedOut = $false; ExitCode = $proc.ExitCode }
    } -ArgumentList $Path, $InstallerArgs, ($TimeoutMinutes * 60 * 1000)
}
