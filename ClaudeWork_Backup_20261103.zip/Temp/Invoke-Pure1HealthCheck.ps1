#Requires -Version 7.0
<#
.SYNOPSIS
    Weekly Pure1 Array Fleet Health Check
.DESCRIPTION
    Connects to pure1.purestorage.com via REST API, checks health and alerts
    across all registered arrays (all global sites). Outputs a SNOW-ready
    summary and exits 0 (healthy) or 1 (issues found).
.PARAMETER ApiToken
    Pure1 API token. If omitted, will prompt. Generate at:
    pure1.purestorage.com -> Administration -> API Registration
.PARAMETER OutputPath
    Optional path to write the report as a .txt file.
.NOTES
    Pure1 uses OAuth2 with an API token (not username/password).
    Generate a token once and store it - it does not expire unless revoked.
    See: https://support.purestorage.com/Pure1/Pure1_Manage/Pure1_REST_API
.EXAMPLE
    .\Invoke-Pure1HealthCheck.ps1
.EXAMPLE
    .\Invoke-Pure1HealthCheck.ps1 -OutputPath C:\temp\pure1.txt
#>

[CmdletBinding()]
param(
    [Parameter()]
    [string]$ApiToken,

    [Parameter()]
    [string]$OutputPath
)

Set-StrictMode -Off
$ErrorActionPreference = 'Stop'

# Pure1 REST API base
$Pure1Base    = 'https://api.pure1.purestorage.com/api/1.latest'
$Pure1AuthUrl = 'https://api.pure1.purestorage.com/oauth2/1.0/token'

# -- SSL + TLS -----------------------------------------------------------------



# -- API TOKEN -----------------------------------------------------------------
if (-not $ApiToken) {
    $ApiToken = Read-Host -Prompt 'Pure1 API Token (from pure1.purestorage.com > Administration > API Registration)'
}

# -- HELPERS -------------------------------------------------------------------
function Get-Pure1Token {
    param([string]$Token)
    # Pure1 uses a signed JWT (private key auth) OR a simple API token
    # For API token bearer auth:
    $headers = @{ 'Content-Type' = 'application/x-www-form-urlencoded' }
    $body    = "grant_type=urn%3Apure%3Aoauth2%3Agrant_type%3Aapi-token&api_token=$Token"
    $resp    = Invoke-RestMethod -Uri $Pure1AuthUrl -Method POST -Headers $headers -Body $body -SkipCertificateCheck
    return $resp.access_token
}

function Invoke-Pure1Get {
    param([string]$BearerToken, [string]$Path, [string]$Filter = '')
    $uri = "$Pure1Base$Path"
    if ($Filter) { $uri += "?filter=$([System.Uri]::EscapeDataString($Filter))" }
    $headers = @{ 'Authorization' = "Bearer $BearerToken" }
    $resp = Invoke-RestMethod -Uri $uri -Method GET -Headers $headers -SkipCertificateCheck
    return $resp.items
}

function Get-Icon {
    param([string]$Status)
    switch -Regex ($Status.ToLower()) {
        'ok|healthy|normal|online|true'   { return '[OK]'   }
        'warning|degraded|attention'       { return '[WARN]' }
        'error|critical|fail|unhealthy'   { return '[FAIL]' }
        default                            { return '[INFO]' }
    }
}

# -- REPORT SETUP --------------------------------------------------------------
$lines      = [System.Collections.Generic.List[string]]::new()
$issueCount = 0
$timestamp  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

$lines.Add('=' * 70)
$lines.Add('  PURE1 FLEET WEEKLY HEALTH CHECK')
$lines.Add("  Run    : $timestamp")
$lines.Add('  Source : pure1.purestorage.com (all global sites)')
$lines.Add('  Scope  : Array Health | Capacity | Alerts')
$lines.Add('=' * 70)

try {
    # -- AUTHENTICATE ----------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Authentication')
    $bearer = Get-Pure1Token -Token $ApiToken
    $lines.Add('|  [OK] Pure1 access token obtained')

    # -- ARRAYS ----------------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Array Fleet Health')
    try {
        $arrays = Invoke-Pure1Get -BearerToken $bearer -Path '/arrays'
        $lines.Add("|  Total arrays: $($arrays.Count)")

        foreach ($arr in ($arrays | Sort-Object name)) {
            $status = if ($arr.os) { 'online' } else { 'unknown' }

            # Capacity
            $usedPct = 0
            if ($arr.space -and $arr.space.capacity -gt 0) {
                $usedPct = [math]::Round(($arr.space.total_used / $arr.space.capacity) * 100, 1)
            }
            $capIcon = if ($usedPct -ge 95) { $issueCount++; '[FAIL]' }
                       elseif ($usedPct -ge 85) { $issueCount++; '[WARN]' }
                       else { '[OK]' }

            $lines.Add("|")
            $lines.Add("|  Array  : $($arr.name)")
            $lines.Add("|  Model  : $($arr.model)  |  OS: $($arr.os)")
            $lines.Add("|  Cap    : $capIcon $usedPct% used")
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve arrays: $($_.Exception.Message)")
    }

    # -- ALERTS ----------------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Active Alerts (All Arrays)')
    try {
        $alerts = Invoke-Pure1Get -BearerToken $bearer -Path '/alerts' -Filter "state='open'"
        if (-not $alerts) { $alerts = @() }

        $critical = @($alerts | Where-Object { $_.severity -eq 'error' })
        $warning  = @($alerts | Where-Object { $_.severity -eq 'warning' })

        $aIcon = if ($critical.Count -gt 0) { $issueCount++; '[FAIL]' }
                 elseif ($warning.Count -gt 0) { $issueCount++; '[WARN]' }
                 else { '[OK]' }

        $lines.Add("|  $aIcon $($alerts.Count) open alert(s) -- $($critical.Count) Error | $($warning.Count) Warning")

        foreach ($al in ($critical | Select-Object -First 10)) {
            $arrName = if ($al.arrays) { ($al.arrays | Select-Object -First 1).name } else { 'Unknown' }
            $lines.Add("|    [ERROR] [$arrName] $($al.summary)")
        }
        foreach ($al in ($warning | Select-Object -First 5)) {
            $arrName = if ($al.arrays) { ($al.arrays | Select-Object -First 1).name } else { 'Unknown' }
            $lines.Add("|    [WARN]  [$arrName] $($al.summary)")
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve alerts: $($_.Exception.Message)")
    }

    # -- VOLUMES (offline check) -----------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Volume Status (offline check)')
    try {
        $vols    = Invoke-Pure1Get -BearerToken $bearer -Path '/volumes'
        if (-not $vols) { $vols = @() }
        $offline = @($vols | Where-Object { $_.destroyed -eq $true })
        $vIcon   = if ($offline.Count -gt 0) { $issueCount++; '[WARN]' } else { '[OK]' }
        $lines.Add("|  $vIcon $($vols.Count) volumes | $($offline.Count) destroyed/offline")
        foreach ($v in ($offline | Select-Object -First 5)) {
            $lines.Add("|    [WARN] $($v.name) -- destroyed")
        }
    } catch {
        $lines.Add('|  [INFO] Volume status not available via this token scope')
    }

} catch {
    $issueCount++
    $lines.Add('')
    $lines.Add("[FAIL] Fatal error: $($_.Exception.Message)")
    $lines.Add('Check API token and network access to api.pure1.purestorage.com')
}

# -- SUMMARY -------------------------------------------------------------------
$lines.Add('')
$lines.Add('=' * 70)
if ($issueCount -eq 0) {
    $lines.Add('  RESULT : ALL ARRAYS HEALTHY')
    $lines.Add('  ACTION : Safe to close SNOW ticket as "Closed Complete":')
    $lines.Add('           "Weekly Review Task - Check Pure1 Portal for all arrays health"')
} else {
    $lines.Add("  RESULT : $issueCount ISSUE(S) FOUND - Review flagged items above")
    $lines.Add('  ACTION : Investigate before closing. Check pure1.purestorage.com for detail.')
}
$lines.Add("  Run by : $env:USERNAME on $env:COMPUTERNAME")
$lines.Add('=' * 70)

$report = $lines -join "`n"
Write-Output $report

if ($OutputPath) {
    $report | Out-File -FilePath $OutputPath -Encoding UTF8
    Write-Host "`nReport written to: $OutputPath" -ForegroundColor Cyan
}

exit $(if ($issueCount -eq 0) { 0 } else { 1 })
