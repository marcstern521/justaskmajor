# ============================================================
# GS - Script 3 - Push Installers
# Copies installers from your laptop to D:\temp on each server.
# For EFT servers it works out which hops are needed from the current
# version, so it only pushes what that server needs. Skips files that are
# already there with the same size.
#
# Example:
#   .\GS_3_Push_Installers.ps1 -EftServer aaa-incdr01,aab-incdr01 -DmzServer aaa-inftp01
# ============================================================
[CmdletBinding()]
param(
    [string[]]$EftServer,
    [string[]]$DmzServer,
    [string]$Source = 'C:\Temp\globalscape',
    [string]$RemoteDir = 'D:\temp',
    [string]$DmzInstaller = 'dmz-gateway-windows-x86-64.exe',
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
if (-not $EftServer -and -not $DmzServer) { throw 'Give me at least one server: -EftServer and/or -DmzServer' }

$Credential = Get-GSCredential $Credential
Start-GSLog -Name 'push_installers'
$RemoteDir = $RemoteDir.TrimEnd('\')

Write-Log '=== Push installers ===' Cyan

# --- Pass 1: work out what each server needs ---
$jobs = @()
foreach ($name in $EftServer) {
    $server = Resolve-GSHost $name $Domain
    try {
        $s = New-PSSession -ComputerName $server -Credential $Credential -ErrorAction Stop
        $i = Get-EFTInfo -Session $s
        Remove-PSSession $s
    } catch {
        Write-Log "  $server UNREACHABLE - $_" Red
        continue
    }
    $ver = ConvertTo-GSVersion $i.Version
    if (-not $ver) { Write-Log "  $server - cannot read EFT version, skipping" Red; continue }
    $plan = Get-EFTUpgradePlan $ver
    switch ($plan.Status) {
        'Current' { Write-Log "  $server - already on $ver, nothing to push" Yellow }
        'Manual'  { Write-Log "  $server - on $ver, needs the staged manual path, skipping" Red }
        default {
            $files = @($plan.Hops | ForEach-Object { 'EFT-nodb_{0}.exe' -f $_ })
            Write-Log ("  {0} - on {1}, needs {2} installer(s)" -f $server, $ver, $files.Count)
            $jobs += [pscustomobject]@{ Server = $server; Files = $files }
        }
    }
}
foreach ($name in $DmzServer) {
    $server = Resolve-GSHost $name $Domain
    Write-Log "  $server - DMZ installer: $DmzInstaller"
    $jobs += [pscustomobject]@{ Server = $server; Files = @($DmzInstaller) }
}

if ($jobs.Count -eq 0) { Write-Log 'Nothing to push' Yellow; exit 0 }

# --- Verify every source file exists before copying anything ---
Write-Log "`nVerifying source files in $Source ..." Yellow
$missing = @()
foreach ($f in ($jobs.Files | Sort-Object -Unique)) {
    $path = Join-Path $Source $f
    if (Test-Path $path) {
        Write-Log ("  OK       {0} ({1} MB)" -f $f, [math]::Round((Get-Item $path).Length / 1MB, 1))
    } else {
        Write-Log "  MISSING  $f" Red
        $missing += $f
    }
}
if ($missing.Count -gt 0) {
    Write-Log "$($missing.Count) file(s) missing from $Source - resolve before continuing" Red
    exit 1
}

# --- Pass 2: copy ---
$failed = @()
foreach ($job in $jobs) {
    Write-Log "`nCopying to $($job.Server) ..." Yellow
    try {
        $s = New-PSSession -ComputerName $job.Server -Credential $Credential -ErrorAction Stop
        Invoke-Command -Session $s -ScriptBlock { param($d) New-Item -ItemType Directory -Path $d -Force | Out-Null } -ArgumentList $RemoteDir

        foreach ($f in $job.Files) {
            $local  = Join-Path $Source $f
            $remote = '{0}\{1}' -f $RemoteDir, $f
            $size   = (Get-Item $local).Length

            $remoteSize = Invoke-Command -Session $s -ScriptBlock {
                param($p); if (Test-Path $p) { (Get-Item $p).Length }
            } -ArgumentList $remote

            if ($remoteSize -eq $size) {
                Write-Log "  $f already there, same size - skipped" Yellow
                continue
            }
            Write-Log "  Copying $f ..."
            Copy-Item -Path $local -Destination $remote -ToSession $s -Force

            $remoteSize = Invoke-Command -Session $s -ScriptBlock {
                param($p); if (Test-Path $p) { (Get-Item $p).Length }
            } -ArgumentList $remote
            if ($remoteSize -ne $size) { throw "Size mismatch on $f (local $size, remote $remoteSize)" }
            Write-Log "  $f copied and verified" Green
        }
        Remove-PSSession $s
    } catch {
        Write-Log "  FAILED on $($job.Server) - $_" Red
        $failed += $job.Server
    }
}

if ($failed.Count -gt 0) {
    Write-Log "Failed: $($failed -join ', ')" Red
    exit 1
}
Write-Log "`nAll installers pushed" Green
Write-Log 'Next: GS_4_DMZ_Upgrade.ps1 (DMZ first), then GS_5_EFT_Hop_Upgrade.ps1' Cyan
