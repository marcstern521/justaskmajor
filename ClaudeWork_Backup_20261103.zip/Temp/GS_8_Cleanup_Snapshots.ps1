# ============================================================
# GS - Script 8 - Snapshot cleanup
# Finds OUR rollback snapshots and (optionally) removes the ones older than N days.
#   VMware: only snapshots named  Pre-Globalscape-Upgrade-*
#   EC2   : only snapshots tagged Purpose = 'Globalscape upgrade rollback'
# Anything else (for example another admin's snapshots) is never touched.
#
# Default is a DRY RUN: it lists what it found and what is old enough. Add -Delete
# to remove the old ones (you must type DELETE). VMware removals merge the snapshot
# into the disk, which can take a while on a big one - do not run it inside a window.
#
# Examples:
#   .\GS_8_Cleanup_Snapshots.ps1 -VMName sgp-incdr01,sgp-incdr02,ty6-incdr01,ty6-incdr02 -DaysOld 3
#   .\GS_8_Cleanup_Snapshots.ps1 -Region ap-southeast-2 -ProfileName ic-prod -DaysOld 7
#   .\GS_8_Cleanup_Snapshots.ps1 -Region ap-northeast-1 -ProfileName ic-prod -DaysOld 7 -Delete
# ============================================================
[CmdletBinding()]
param(
    [int]$DaysOld = 7,
    [string[]]$VMName,
    [string]$vCenterServer = 'lax-vmvce01.inucn.com',
    [string]$Region,
    [string]$ProfileName,
    [switch]$Delete,
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
if (-not $VMName -and -not $Region) { throw 'Give me -VMName (VMware) and/or -Region (EC2)' }

Start-GSLog -Name 'snapshot_cleanup'
$cut   = (Get-Date).AddDays(-$DaysOld)
$found = @()
Write-Log "=== Snapshot cleanup (older than $DaysOld day(s) = before $cut) ===" Cyan

# --- VMware ---
if ($VMName) {
    if (-not (Get-Command Connect-VIServer -ErrorAction SilentlyContinue)) {
        throw 'VMware PowerCLI is not loaded. Run: Import-Module VMware.PowerCLI'
    }
    $connected = $global:DefaultVIServers | Where-Object { $_.Name -eq $vCenterServer -and $_.IsConnected }
    if (-not $connected) {
        $cred = Get-GSCredential $Credential
        Connect-VIServer -Server $vCenterServer -Credential $cred -ErrorAction Stop | Out-Null
    }
    foreach ($n in $VMName) {
        $vm = Get-VM -Name $n -ErrorAction SilentlyContinue
        if (-not $vm) { Write-Log "  $n not found in vCenter" Yellow; continue }
        foreach ($sn in @(Get-Snapshot -VM $vm | Where-Object { $_.Name -like 'Pre-Globalscape-Upgrade-*' })) {
            $found += [pscustomobject]@{
                Type = 'VMware'; Where = $vm.Name; Name = $sn.Name; Created = $sn.Created
                SizeGB = [math]::Round($sn.SizeGB, 1)
                AgeDays = [math]::Floor(((Get-Date) - $sn.Created).TotalDays)
                Eligible = ($sn.Created -lt $cut); Ref = $sn
            }
        }
    }
}

# --- EC2 ---
$aws = @{}
if ($Region) {
    if (-not (Get-Command Get-EC2Snapshot -ErrorAction SilentlyContinue)) {
        throw 'AWS Tools for PowerShell not loaded. Run: Install-Module AWS.Tools.EC2'
    }
    $aws.Region = $Region
    if ($ProfileName) { $aws.ProfileName = $ProfileName }
    foreach ($sn in @(Get-EC2Snapshot @aws -OwnerId self -Filter @{ Name = 'tag:Purpose'; Values = 'Globalscape upgrade rollback' })) {
        $found += [pscustomobject]@{
            Type = 'EC2'; Where = $sn.VolumeId
            Name = (($sn.Tags | Where-Object { $_.Key -eq 'Name' }).Value)
            Created = $sn.StartTime; SizeGB = $sn.VolumeSize   # EC2: volume size, not snapshot size
            AgeDays = [math]::Floor(((Get-Date) - $sn.StartTime).TotalDays)
            Eligible = ($sn.StartTime -lt $cut); Ref = $sn.SnapshotId
        }
    }
}

if ($found.Count -eq 0) { Write-Log 'No matching snapshots found.' Yellow; exit 0 }

$found | Sort-Object Type, Where | Format-Table Type, Where, Name, Created, SizeGB, AgeDays, Eligible -AutoSize
$todo = @($found | Where-Object { $_.Eligible })
Write-Log ("{0} snapshot(s) found, {1} older than {2} day(s)" -f $found.Count, $todo.Count, $DaysOld)

if ($todo.Count -eq 0) { Write-Log 'Nothing old enough to remove yet.' Green; exit 0 }
if (-not $Delete) {
    Write-Log 'Dry run only. Add -Delete to remove the old ones listed as Eligible = True.' Yellow
    exit 0
}

if (-not (Confirm-Typed "`nRemove these $($todo.Count) snapshot(s)?" 'DELETE')) {
    Write-Log 'Cancelled - nothing removed' Yellow
    exit 0
}

foreach ($item in $todo) {
    try {
        if ($item.Type -eq 'VMware') {
            Write-Log "Removing VMware snapshot '$($item.Name)' on $($item.Where) (can take a while)..." Yellow
            Remove-Snapshot -Snapshot $item.Ref -Confirm:$false -ErrorAction Stop
        } else {
            Write-Log "Removing EC2 snapshot $($item.Ref) ($($item.Name))..." Yellow
            Remove-EC2Snapshot @aws -SnapshotId $item.Ref -Force -ErrorAction Stop
        }
        Write-Log '  Removed' Green
    } catch {
        Write-Log "  FAILED - $_" Red
    }
}
Write-Log 'Cleanup finished' Cyan
