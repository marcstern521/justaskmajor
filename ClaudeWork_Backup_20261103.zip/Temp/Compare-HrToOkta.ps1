<#
.SYNOPSIS
  Compares the HR active-employee list to an Okta user export and lists Okta accounts that should be reviewed for termination.
  READ-ONLY: it only reads two files and writes CSVs. It never touches Okta, AWS or AD.

.EXAMPLE
  .\Compare-HrToOkta.ps1 -HrFile .\HR_Active_Nov2026.csv -OktaFile .\okta_users.csv

.NOTES
  HR file : CSV (or .xlsx if the ImportExcel module is installed). Needs an email column. Employee ID / name columns help.
  Okta    : Admin > Directory > People > Export (CSV). Columns are auto-detected (Username, Primary Email, Status...).
  Output  : <OutDir>\Okta_ToTerm_<stamp>.csv       Okta-active, not found on HR list at all  -> review, then approve
            <OutDir>\Okta_Review_<stamp>.csv       partial match only (same name or same email prefix) -> a human decides
            <OutDir>\Okta_Excluded_<stamp>.csv     skipped on purpose (service/admin/test accounts, not active, -Exclude list)
            <OutDir>\HR_NotInOkta_<stamp>.csv      on HR list, no Okta account (FYI only)
            <OutDir>\Compare_Summary_<stamp>.txt
  Safety  : if ToTerm is more than -MaxTermPercent of Okta-active users, it stops. That almost always means the HR file is
            partial or a column was mis-detected. Use -Force only after you have looked at the file.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$HrFile,
    [Parameter(Mandatory)][string]$OktaFile,
    [string]$HrEmailColumn,
    [string]$HrIdColumn,
    [string]$HrFirstColumn,
    [string]$HrLastColumn,
    [string]$OktaEmailColumn,
    [string]$OktaLoginColumn,
    [string]$OktaStatusColumn,
    [string]$OktaFirstColumn,
    [string]$OktaLastColumn,
    [string]$OktaIdColumn,
    # Okta statuses treated as "live" accounts that need a decision
    [string[]]$LiveStatus = @('ACTIVE','STAGED','PROVISIONED','RECOVERY','PASSWORD_EXPIRED','LOCKED_OUT','SUSPENDED'),
    # Accounts never proposed for termination (regex on login/email). Edit to fit.
    [string]$ExcludeRegex = '(^_)|(^|[._-])(svc|service|admin|adm|test|noreply|no-reply|breakglass|break-glass|automation|bot|api|okta|superadmin)([._-]|@)|@serviceuser\.com|@niceonline\.onmicrosoft\.com|-ncc@|@nccgroup\.com',
    [string[]]$Exclude = @(),                 # exact logins/emails to skip (shared mailboxes, vendors, contractors)
    [int]$MaxTermPercent = 5,
    [int]$StaleDays = 90,                     # last login older than this = STALE; newer = RECENT (probably still working, check HR name)
    [switch]$Force,
    [string]$OutDir = 'C:\Temp\OktaReview'
)
$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function Read-Table([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { throw "File not found: $path" }
    switch ([IO.Path]::GetExtension($path).ToLower()) {
        '.csv'  { return @(Import-Csv -LiteralPath $path) }
        '.xlsx' {
            if (-not (Get-Module -ListAvailable ImportExcel)) { throw "Save '$path' as CSV (File > Save As > CSV), or install ImportExcel (Install-Module ImportExcel -Scope CurrentUser)." }
            Import-Module ImportExcel; return @(Import-Excel -Path $path)
        }
        default { throw "Unsupported file type: $path (use .csv or .xlsx)" }
    }
}
function Find-Col($rows, [string]$explicit, [string[]]$patterns, [string]$label, [switch]$Optional) {
    $names = @($rows[0].PSObject.Properties.Name)
    $script:colMap = @{}; foreach ($n in $names) { $script:colMap[($n -replace '^user\.','')] = $n }
    if ($explicit) { if ($names -contains $explicit) { return $explicit } else { throw "$label column '$explicit' not found. Columns: $($names -join ', ')" } }
    foreach ($p in $patterns) { $m = $names | Where-Object { ($_ -replace '^user\.','') -match $p } | Select-Object -First 1; if ($m) { return $m } }
    if ($Optional) { return $null }
    throw "Could not detect the $label column. Columns are: $($names -join ', '). Pass it with the matching -...Column parameter."
}
function Norm([string]$s) { if ($null -eq $s) { return '' }; $s.Trim().ToLower() }
function Prefix([string]$e) { $e = Norm $e; if ($e -match '^([^@]+)@') { return $Matches[1] } return '' }
function NameKey($f, $l) { $k = ((Norm $f) + '|' + (Norm $l)) -replace '[^a-z|]', ''; if ($k -eq '|' -or $k.StartsWith('|') -or $k.EndsWith('|')) { return '' } return $k }

function Fold([string]$s) { if (-not $s) { return '' }; $d = $s.Normalize([Text.NormalizationForm]::FormD); (($d -replace '\p{Mn}','').ToLower() -replace '[^a-z]','') }
$hr   = Read-Table $HrFile
$okta = Read-Table $OktaFile
if (-not $hr.Count)   { throw 'HR file has no rows.' }
if (-not $okta.Count) { throw 'Okta file has no rows.' }

$hEmail = Find-Col $hr   $HrEmailColumn   @('^e-?mail','work.*mail','mail') 'HR email'
$hId    = Find-Col $hr   $HrIdColumn      @('employee.?(id|number)','^emp.?(id|no)','^id$','worker') 'HR employee ID' -Optional
$hFirst = Find-Col $hr   $HrFirstColumn   @('^first.?name','^first$','preferred.*first','given') 'HR first name' -Optional
$hLast  = Find-Col $hr   $HrLastColumn    @('^last.?name','^last$','surname','family') 'HR last name' -Optional
$oEmail = Find-Col $okta $OktaEmailColumn @('^primary.?e-?mail','^e-?mail$','^email') 'Okta email' -Optional
$oLogin = Find-Col $okta $OktaLoginColumn @('^username$','^login$','user.?name','^login') 'Okta username'
$oStat  = Find-Col $okta $OktaStatusColumn @('^status$') 'Okta status'
$oFirst = Find-Col $okta $OktaFirstColumn @('^first.?name','^first$') 'Okta first name' -Optional
$oLast  = Find-Col $okta $OktaLastColumn  @('^last.?name','^last$','^surname') 'Okta last name' -Optional
$oId    = Find-Col $okta $OktaIdColumn    @('^id$','^user.?id$','okta.?id') 'Okta user ID' -Optional
$oFull  = Find-Col $okta $null @('^full.?name$') 'Okta full name' -Optional
$oLast2 = Find-Col $okta $null @('^last.?login$') 'Okta last login' -Optional
$hFull  = Find-Col $hr   $null @('^employee.?name$','^full.?name$','^name$') 'HR full name' -Optional
$hType  = Find-Col $hr   $null @('person.?type','worker.?type','^type$') 'HR person type' -Optional
$oEmail2 = Find-Col $okta $null @('secondary.?e-?mail') 'Okta secondary email' -Optional

Write-Host ("HR columns   : email={0} id={1} first={2} last={3}" -f $hEmail,$hId,$hFirst,$hLast)
Write-Host ("Okta columns : login={0} email={1} status={2} first={3} last={4} id={5}" -f $oLogin,$oEmail,$oStat,$oFirst,$oLast,$oId)

# ---- HR lookups ----
$hrEmails = @{}; $hrPrefix = @{}; $hrNames = @{}; $hrSeen = @{}
foreach ($r in $hr) {
    $e = Norm $r.$hEmail
    if ($e) { $hrEmails[$e] = $r; $p = Prefix $e; if ($p) { if (-not $hrPrefix.ContainsKey($p)) { $hrPrefix[$p] = @() }; $hrPrefix[$p] += $r } }
    $k = ''
    if ($hFull) { $k = Fold $r.$hFull } elseif ($hFirst -and $hLast) { $k = Fold ($r.$hFirst + $r.$hLast) }
    if ($k) { if (-not $hrNames.ContainsKey($k)) { $hrNames[$k] = @() }; $hrNames[$k] += $r }
}
if ($hrEmails.Count -lt 10) { throw "Only $($hrEmails.Count) HR emails found. Wrong column or empty file?" }

$toTerm = New-Object System.Collections.Generic.List[object]
$review = New-Object System.Collections.Generic.List[object]
$excl   = New-Object System.Collections.Generic.List[object]
$matched = 0; $aliasMatched = 0
$excludeSet = @{}; foreach ($x in $Exclude) { $excludeSet[(Norm $x)] = 1 }

foreach ($u in $okta) {
    $login = Norm $u.$oLogin
    $mail  = if ($oEmail) { Norm $u.$oEmail } else { '' }
    $mail2 = if ($oEmail2) { Norm $u.$oEmail2 } else { '' }
    $status = ([string]$u.$oStat).Trim().ToUpper()
    $first = if ($oFirst) { $u.$oFirst } else { '' }; $last = if ($oLast) { $u.$oLast } else { '' }
    $row = [ordered]@{ OktaId = $(if ($oId) { $u.$oId } else { '' }); Login = $u.$oLogin; Email = $(if ($oEmail) { $u.$oEmail } else { '' }); First = $first; Last = $last; Status = $status; LastLogin = $(if ($oLast2) { $u.$oLast2 } else { '' }); Reason = '' }

    if ($LiveStatus -notcontains $status) { $row.Reason = "Status $status (not a live account)"; $excl.Add([pscustomobject]$row); continue }
    if ($excludeSet.ContainsKey($login) -or ($mail -and $excludeSet.ContainsKey($mail))) { $row.Reason = 'In -Exclude list'; $excl.Add([pscustomobject]$row); continue }
    if (($login -match $ExcludeRegex) -or ($mail -match $ExcludeRegex)) { $row.Reason = 'Service/admin/test account or NCC Group vendor (skipped on purpose)'; $excl.Add([pscustomobject]$row); continue }

    # 1) exact email match on login, primary or secondary email
    if (($login -and $hrEmails.ContainsKey($login)) -or ($mail -and $hrEmails.ContainsKey($mail)) -or ($mail2 -and $hrEmails.ContainsKey($mail2))) { $matched++; continue }

    # 2) name key (full name, or first+last) and email prefix, checked against HR
    $nk = ''
    if ($oFull -and $u.$oFull) { $nk = Fold $u.$oFull } 
    $nk2 = Fold ($first + $last)
    $nameHit = ($nk -and $hrNames.ContainsKey($nk)) -or ($nk2 -and $hrNames.ContainsKey($nk2))
    $prefHit = $false; foreach ($e in @($login, $mail, $mail2)) { $p = Prefix $e; if ($p -and $hrPrefix.ContainsKey($p)) { $prefHit = $true; $hit = $hrPrefix[$p][0].$hEmail; break } }
    # same prefix AND same name = same person on a different email domain (alias): counts as a match
    if ($prefHit -and $nameHit) { $matched++; $aliasMatched++; continue }
    $why = @()
    if ($prefHit) { $why += "Same email prefix as HR '$hit' but name differs" }
    if ($nameHit) { $why += 'Same name as an HR person but a different email' }
    if ($why.Count) { $row.Reason = ($why -join '; '); $review.Add([pscustomobject]$row); continue }

    $row.Reason = 'Not on HR active list'
    $toTerm.Add([pscustomobject]$row)
}

# Tier each candidate by last login so the safest ones are obvious
foreach ($coll in @($toTerm, $review)) {
    foreach ($x in $coll) {
        $d = [datetime]::MinValue
        $tier = 'NEVER_LOGGED_IN'
        if ($x.LastLogin -and [datetime]::TryParse(([string]$x.LastLogin), [ref]$d)) { $tier = $(if (((Get-Date) - $d).TotalDays -gt $StaleDays) { 'STALE' } else { 'RECENT_CHECK_FIRST' }) }
        $x | Add-Member -NotePropertyName Tier -NotePropertyValue $tier -Force
    }
}
$order = @{ 'NEVER_LOGGED_IN' = 0; 'STALE' = 1; 'RECENT_CHECK_FIRST' = 2 }
$toTermSorted = @($toTerm | Sort-Object @{ Expression = { $order[$_.Tier] } }, Login)

# HR people with no Okta account (FYI)
$oktaKeys = @{}
foreach ($u in $okta) { foreach ($e in @((Norm $u.$oLogin), $(if ($oEmail) { Norm $u.$oEmail }), $(if ($oEmail2) { Norm $u.$oEmail2 }))) { if ($e) { $oktaKeys[$e] = 1 } } }
$hrNoOkta = @($hr | Where-Object { $e = Norm $_.$hEmail; $e -and -not $oktaKeys.ContainsKey($e) } | ForEach-Object {
    [pscustomobject]@{ Email = $_.$hEmail; EmployeeId = $(if ($hId) { $_.$hId } else { '' }); First = $(if ($hFirst) { $_.$hFirst } else { '' }); Last = $(if ($hLast) { $_.$hLast } else { '' }) } })

$liveCount = $matched + $toTerm.Count + $review.Count
$pct = if ($liveCount) { [math]::Round(100 * $toTerm.Count / $liveCount, 1) } else { 0 }

$f1 = Join-Path $OutDir "Okta_ToTerm_$stamp.csv"
$f2 = Join-Path $OutDir "Okta_Review_$stamp.csv"
$f3 = Join-Path $OutDir "Okta_Excluded_$stamp.csv"
$f4 = Join-Path $OutDir "HR_NotInOkta_$stamp.csv"
$f5 = Join-Path $OutDir "Compare_Summary_$stamp.txt"

$summary = @(
    "HR vs Okta compare - $(Get-Date -Format 'yyyy-MM-dd HH:mm')",
    "HR file   : $HrFile  ($($hr.Count) rows, $($hrEmails.Count) emails)",
    "Okta file : $OktaFile  ($($okta.Count) rows)",
    "",
    "Okta live accounts checked : $liveCount",
    "  Matched to HR            : $matched  (incl. $aliasMatched on a different email domain, same name)",
    "  To terminate (no match)  : $($toTerm.Count)  ($pct% of live)",
    "     never logged in       : $(@($toTerm | Where-Object { -not $_.LastLogin }).Count)",
    "  Review (partial match)   : $($review.Count)",
    "Excluded on purpose        : $($excl.Count)",
    "On HR list, no Okta acct   : $($hrNoOkta.Count)"
)
$summary | Set-Content -Path $f5 -Encoding UTF8
$summary | ForEach-Object { Write-Host $_ }

if ($pct -gt $MaxTermPercent -and -not $Force) {
    Write-Host ''
    Write-Host "STOP: $pct% of live Okta users would be flagged (limit $MaxTermPercent%). The HR file is probably partial or a column is wrong." -ForegroundColor Red
    Write-Host "Check the columns printed above. If the numbers are real, re-run with -Force." -ForegroundColor Red
    exit 2
}

$toTermSorted | Export-Csv $f1 -NoTypeInformation -Encoding UTF8
$review | Export-Csv $f2 -NoTypeInformation -Encoding UTF8
$excl   | Export-Csv $f3 -NoTypeInformation -Encoding UTF8
$hrNoOkta | Export-Csv $f4 -NoTypeInformation -Encoding UTF8
Write-Host ''
Write-Host "Wrote files to $OutDir" -ForegroundColor Green
Write-Host "Next: open the ToTerm and Review CSVs, strike anyone who should stay (contractors, vendors, shared accounts), and send me the final list." -ForegroundColor Cyan
