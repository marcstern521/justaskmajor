﻿# === Run-SUSE-Inventory.ps1 ===

$ErrorActionPreference = "Stop"

# ---- Config ----
$User        = "patrol"                              # prod uses patrol
$LocalTool   = "C:\temp\suse_dc_tool.sh"             # tool location on Windows
$RemoteDir   = "/home/patrol"                        # drop it here before sudo moving
$FinalDir    = "/root"                               # where the tool will run
$LocalOutDir = "C:\temp\out"                         # outputs land here
$SshOpts     = "-o StrictHostKeyChecking=no"

# Host list
$Hosts = @(
  "eng-epros01.in.lab",
  "eng-epnwv01.in.lab"
)

# ---- Prep ----
if (-not (Test-Path $LocalTool)) {
  throw "Tool not found at $LocalTool"
}
New-Item -ItemType Directory -Force -Path $LocalOutDir | Out-Null

Write-Host "`n[+] Starting collection on $($Hosts.Count) hosts..."

foreach ($h in $Hosts) {
  Write-Host "`n=== $h ==="

  try {
    # 1) Copy tool up
    Write-Host " - Uploading tool..."
    scp $SshOpts $LocalTool "$User@${h}:$RemoteDir/" | Out-Null

    # 2) Move into /root, chmod, and run with sudo
    Write-Host " - Executing tool with sudo..."
    $Cmd = @"
sudo mv $RemoteDir/suse_dc_tool.sh $FinalDir/ && \
sudo chmod 755 $FinalDir/suse_dc_tool.sh && \
cd $FinalDir && \
sudo ./suse_dc_tool.sh -y
"@
    ssh $SshOpts "$User@${h}" $Cmd

    # 3) Find newest output tar on remote
    Write-Host " - Locating output tar..."
    $RemoteTar = ssh $SshOpts "$User@${h}" "cd $FinalDir && ls -1t *.output.tar* 2>/dev/null | head -1"
    $RemoteTar = ($RemoteTar | Out-String).Trim()
    if ([string]::IsNullOrWhiteSpace($RemoteTar)) {
      throw "No *.output.tar* found in $FinalDir"
    }
    Write-Host "   Found: $RemoteTar"

    # 4) Pull tar down to local folder
    $LocalName = "$($h)-$RemoteTar" -replace "[:/\\]", "_"
    $LocalPath = Join-Path $LocalOutDir $LocalName
    Write-Host " - Downloading to $LocalPath"
    scp $SshOpts "$User@${h}:$FinalDir/$RemoteTar" $LocalPath | Out-Null

    # 5) Clean remote artifacts
    Write-Host " - Cleaning remote artifacts..."
    $CleanCmd = @"
sudo rm -rf $FinalDir/*.output $FinalDir/*.output.tar* || true
"@
    ssh $SshOpts "$User@${h}" $CleanCmd | Out-Null

    Write-Host " ✓ $h complete."
  } catch {
    Write-Warning " ! $h failed: $($_.Exception.Message)"
  }
}

Write-Host "`n[+] Done. Files saved under: $LocalOutDir"
