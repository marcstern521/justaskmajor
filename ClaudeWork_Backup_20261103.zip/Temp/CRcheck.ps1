﻿# Prompt for credentials once
$Cred   = Get-Credential -Message "Enter credentials to query remote services"

# List of server short names
$Servers = @(
"LAX-ENSCR01",
"LAX-ENSTS01",
"DAL-NWSOL02",
"LAX-ECWEB03",
"FRA-INDBS01",
"MUN-INMDR01",
"MUN-INNSE01",
"FRA-WF4594619A",
"FRA-WF4594619W",
"FRA-ICCLGR01",
"AAA-ENDBF01",
"AOB-C9STM01",
"AVA-NIFSV01",
"AVA-NIAPP01",
"AVA-NIDBS01",
"AVA-NIPLT01",
"AVA-NI-SRVCL01",
"AVA-NISQL01-1",
"AVA-NISQL01-3",
"AOB-C28STM01",
"AOB-B3STM01",
"AOB-C29STM01",
"AOB-C32STM01",
"AOB-C4STM01",
"AOB-C6STM01",
"AOB-C11STM01",
"AOB-C12STM01",
"AOB-C17STM01",
"AOB-C19STM01",
"AOB-C27STM01",
"AAB-A32STM01",
"AOB-C20STM01",
"AOB-C14STM01",
"AOB-C18STM01",
"AOA-C33PEN01",
"AFB-E32STM01",
"AOB-C35STM01",
"AO-VC-QMRPT1-NY",
"AO-VC-QMAPP1-NY",
"AOB-C36STM01",
"AOB-C36API01",
"AOB-C38STM01",
"AOB-C40STM01",
"AOB-C42STM01",
"AOB-B31STM01",
"ALB-L32STM01",
"AOB-C43STM01",
"AOB-C44STM01",
"AMB-M32STM01",
"AOB-C46STM01",
"AOB-C45STM01",
"SGP-PCRLR08",
"SGP-PCRLR10",
"AAB-A35STM01",
"AFA-PCPEN01",
"LAX-VL250TEST",
"LAX-WEB-TEMP",
"AO-VC-QMRPT4-NY",
"AO-VC-QMAPP4-NY",
"DAL-BMPCS01-N",
"LAX-DIDBS01-N",
"LAX-DIDBS02-N",
"AOA-C64IVR01",
"AOB-C64IVR01",
"LAX-C64MEI01",
"LAX-C64MEI02",
"LAX-C64MEI03",
"LAX-C64MEI04",
"LAX-C64MEI05",
"LAX-C64MEI06",
"LAX-C64MEI07",
"LAX-C64MEI08",
"DAL-C63MEI01",
"DAL-C63MEI02",
"DAL-C63MEI03",
"DAL-C63MEI04",
"DAL-C63MEI05",
"DAL-C63MEI06",
"DAL-C63MEI07",
"DAL-C63MEI08",
"DAL-C63MEI09",
"DAL-C64MEI01",
"DAL-C64MEI02",
"DAL-C64MEI03",
"DAL-C64MEI04",
"DAL-C64MEI05",
"DAL-C64MEI06",
"DAL-C64MEI07",
"DAL-C64MEI08",
"DAL-C64MEI09",
"LAX-C64MEI09",
"LAX-INDCO01-NN",
"EUFTA-INDBI01",
"EUFTB-INDBI01",
"LAX-RSIDR02",
"LAX-C213-MEI02",
"LAX-INASR06",
"DAL-INASR06",
"ACSL-MC-26DWA1",
"ALB-L35WEB02-O",
"ALB-L33WEB02-O",
"AFA-E36API04-O",
"ALB-L35API05-O",
"LAX-VXLAN01",
"AFA-E31API06-O",
"ALB-L32API01-O",
"ALB-L36API01-O",
"AFA-E34API07-O",
"AFA-E33API05-O",
"AOA-C57MED02",
"ALB-L38MED02",
"LAX-INTTS25",
"LAX-INTTS26",
"LAX-INTTS27",
"LAX-INTTS28",
"LAX-INTTS29",
"LAX-INTTS30",
"DAL-INTTS25",
"DAL-INTTS26",
"DAL-INTTS27",
"DAL-INTTS28",
"DAL-INTTS29",
"DAL-INTTS30",
"AFB-E31API01-O",
"AOB-C45AGM01",
"AOB-C56AGM01",
"AOA-C56AGM01",
"ACVAB-27MED02",
"LAX-C203MED11",
"LAX-C203MED12",
"LAX-C203MED13",
"LAX-C203MED14",
"LAX-C203MED15",
"LAX-C203MED16",
"LAX-C203MED17",
"LAX-C203MED18",
"LAX-C203MED19",
"LAX-C203MED20",
"LAX-C203MED21",
"LAX-C203MED22",
"LAX-C203MED23",
"LAX-C203MED24",
"LAX-C203MED25",
"LAX-C203MED26",
"LAX-C203MED27",
"LAX-C203MED28",
"LAX-C203MED29",
"LAX-C203MED30",
"DAL-C203MED11",
"DAL-C203MED12",
"DAL-C203MED13",
"DAL-C203MED14",
"DAL-C203MED15",
"DAL-C203MED16",
"DAL-C203MED17",
"DAL-C203MED18",
"DAL-C203MED19",
"DAL-C203MED20",
"DAL-C203MED21",
"DAL-C203MED22",
"DAL-C203MED23",
"DAL-C203MED24",
"DAL-C203MED25",
"DAL-C203MED26",
"DAL-C203MED27",
"DAL-C203MED28",
"DAL-C203MED29",
"DAL-C203MED30",
"ACVAB-INTTS02",
"ACVAA-27MEI01",
"ACVAB-27MEI01",
"ACVAB-27MEI02",
"ACVAB-27MEI03",
"ACVAA-27MEI04",
"ACVAA-27MEI02",
"ACVAA-27MEI03",
"ACVAB-27MEI04",
"ACVAA-27MEI05",
"ACVAA-27MEI06",
"ACVAB-27MEI06",
"ACVAA-27MEI08",
"ACVAA-27MEI07",
"ACVAB-27MEI05",
"ACVAB-27MEI07",
"ACVAB-27MEI08",
"DAL-VXLAN01",
"DAL-VXLAN02",
"ACVAB-29IVR01"
)

# Domain suffix
$Domain = ".inucn.com"

# Store results


$Results = foreach ($ServerName in $Servers) {

    $Server = "$ServerName$Domain"

    if (-not (Test-Connection -ComputerName $Server -Count 1 -Quiet)) {
        [PSCustomObject]@{
            Server = $Server
            Result = "FAIL"
            Detail = "Host unreachable"
        }
        continue
    }

    try {
        $Service = Invoke-Command `
            -ComputerName $Server `
            -Credential $Cred `
            -ScriptBlock {
                Get-Service -Name "CybereasonActiveProbe" -ErrorAction SilentlyContinue
            }

        if (-not $Service) {
            [PSCustomObject]@{
                Server = $Server
                Result = "FAIL"
                Detail = "ActiveProbe service missing"
            }
        }
        elseif ($Service.Status -eq "Running") {
            [PSCustomObject]@{
                Server = $Server
                Result = "PASS"
                Detail = "Cybereason ActiveProbe running"
            }
        }
        else {
            [PSCustomObject]@{
                Server = $Server
                Result = "FAIL"
                Detail = "ActiveProbe $($Service.Status)"
            }
        }
    }
    catch {
        [PSCustomObject]@{
            Server = $Server
            Result = "FAIL"
            Detail = "Error: $($_.Exception.Message)"
        }
    }
}

$Results | Sort-Object Result, Server | Format-Table -AutoSize
