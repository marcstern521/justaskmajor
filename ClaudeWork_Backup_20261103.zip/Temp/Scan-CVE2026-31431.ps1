﻿Import-Module Posh-SSH

# --- CONFIG ---
$csvPath    = "C:\Temp\CVE-2026-31431_remediation_tracker.csv"
$outputPath = "C:\Temp\CVE-2026-31431_scan_results.csv"
$sshUser    = "patrol"   # <-- change this
# --------------

$cred    = Get-Credential -UserName $sshUser -Message "SSH credentials"
$servers = Import-Csv $csvPath | Where-Object { $_.PatchAction -ne "INVESTIGATE" -and $_.IP -ne "" }
$results = [System.Collections.Generic.List[object]]::new()
$total   = $servers.Count
$i       = 0

foreach ($server in $servers) {
    $i++
    Write-Progress -Activity "Scanning hosts for CVE-2026-31431" `
                   -Status "$i of $total — $($server.Hostname)" `
                   -PercentComplete (($i / $total) * 100)

    $kernelVer  = ""
    $algLoaded  = ""
    $scanStatus = ""

    try {
        $session = New-SSHSession -ComputerName $server.IP `
                                  -Credential $cred `
                                  -AcceptKey `
                                  -ConnectionTimeout 10 `
                                  -ErrorAction Stop

        $kernelVer = (Invoke-SSHCommand -SessionId $session.SessionId -Command "uname -r" -TimeOut 10).Output | Select-Object -First 1
        $algCheck  = (Invoke-SSHCommand -SessionId $session.SessionId -Command "lsmod | grep -c algif_aead" -TimeOut 10).Output | Select-Object -First 1
        $algLoaded = if ([int]($algCheck -replace '\D','0') -gt 0) { "YES - EXPOSED" } else { "No" }
        $scanStatus = "OK"

        Remove-SSHSession -SessionId $session.SessionId | Out-Null
    }
    catch {
        $scanStatus = "UNREACHABLE: $($_.Exception.Message)"
        $kernelVer  = "N/A"
        $algLoaded  = "UNKNOWN"
    }

    $server.KernelVersion      = $kernelVer
    $server.algif_aead_Loaded  = $algLoaded
    $server | Add-Member -NotePropertyName "ScanStatus" -NotePropertyValue $scanStatus -Force

    $results.Add($server)

    # Live feedback
    $symbol = if ($algLoaded -eq "YES - EXPOSED") { "⚠ EXPOSED" } elseif ($algLoaded -eq "No") { "✓ Clean" } else { "✗ Unreachable" }
    Write-Host "[$i/$total] $($server.Hostname) ($($server.IP)) — $symbol"
}

$results | Export-Csv $outputPath -NoTypeInformation
Write-Host "`nDone. Results saved to $outputPath"
Write-Host "Exposed hosts: $(($results | Where-Object { $_.algif_aead_Loaded -eq 'YES - EXPOSED' }).Count)"
Write-Host "Unreachable:   $(($results | Where-Object { $_.ScanStatus -like 'UNREACHABLE*' }).Count)"