﻿<#
.SYNOPSIS
    Runs ProdReadinessCheck-Linux.sh against one or more Linux servers over
    SSH, from a Windows machine - for non-domain-joined boxes where the
    Windows script's AD/WinRM approach doesn't apply.

.DESCRIPTION
    Uses the Windows OpenSSH client (ssh.exe / scp.exe - built into Windows 10
    1809+ and Windows 11, and Windows Server 2019+; if missing, install via
    Settings > Optional Features > OpenSSH Client, or
    'Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0').

    For each host, this:
      1. scp's ProdReadinessCheck-Linux.sh up to the account's home directory
      2. ssh's in and runs it with sudo
      3. scp's the resulting CSV back down next to this script

    You'll be prompted for the username (if not passed via -UserName) and for
    the account's password (or passphrase, if using a key) by ssh/scp
    directly - this script never sees, stores, or passes a password itself.
    Native OpenSSH won't accept a password as a command-line argument at all
    (that's deliberate on its part, not a limitation of this script), so
    there's no way to have it typed once into a PowerShell prompt and silently
    reused - it always asks you at the console when it needs to authenticate.
    You'll be asked up to three times per host (upload/run/download). SSH
    connection multiplexing (ControlMaster) would normally cut that down to
    once per host, but the Windows OpenSSH client's support for it is
    unreliable (it throws "getsockname failed: Not a socket" instead of
    falling back cleanly), so this script doesn't use it. Set up an SSH key
    beforehand (ssh-keygen, then copy the public key to each host's
    ~/.ssh/authorized_keys) if you want to stop being prompted at all - worth
    doing given how many more of these Linux tickets are coming.

    If a host is unreachable, that's almost certainly network/firewall (same
    kind of thing we ran into trying WinRM from a laptop into Production) -
    not a finding about the server. This script reports that and moves on to
    the next host rather than stopping the batch.

.PARAMETER ComputerNames
    Linux hostnames or IPs to check.

.PARAMETER UserName
    SSH account to connect as. If not passed, you'll be prompted for it -
    this varies by environment (e.g. "admin" vs "patrol"), so there's no
    hardcoded default.

.PARAMETER RemoteScriptPath
    Local path to ProdReadinessCheck-Linux.sh to upload. Default assumes it's
    in the same folder as this script.

.PARAMETER OutDir
    Where to save the CSVs pulled back from each host. Created if missing.

.PARAMETER Role
.PARAMETER Domain
    Passed through to the Linux script's -r/-d flags (informational only,
    doesn't change which checks run).

.PARAMETER CheckAuditd
    Passes -c through to the Linux script (the Rapid7 auditd compatibility-
    mode check, off by default there too).

.EXAMPLE
    .\Invoke-LinuxReadinessCheck.ps1 -ComputerNames dal-nwmcp01,lax-nwmcp01 -Role network_mcp_server

.EXAMPLE
    .\Invoke-LinuxReadinessCheck.ps1 -ComputerNames 172.19.140.35 -UserName patrol -OutDir .\linux-readiness
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string[]]$ComputerNames,
    [string]$UserName,
    [string]$RemoteScriptPath = ".\ProdReadinessCheck-Linux.sh",
    [string]$OutDir = ".\linux-readiness",
    [string]$Role = "Other",
    [string]$Domain = "",
    [switch]$CheckAuditd
)

if (-not (Get-Command ssh -ErrorAction SilentlyContinue) -or -not (Get-Command scp -ErrorAction SilentlyContinue)) {
    Write-Host "ssh/scp not found on PATH. Install the Windows OpenSSH client:" -ForegroundColor Red
    Write-Host "  Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0" -ForegroundColor Red
    exit 1
}

if (-not $UserName) {
    $UserName = Read-Host "SSH username"
}

if (-not (Test-Path $RemoteScriptPath)) {
    Write-Host "Can't find $RemoteScriptPath - run this from the same folder as ProdReadinessCheck-Linux.sh, or pass -RemoteScriptPath." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir | Out-Null
}

$remoteScriptName = Split-Path $RemoteScriptPath -Leaf
$summary = New-Object System.Collections.Generic.List[object]

foreach ($cn in $ComputerNames) {
    Write-Host ""
    Write-Host "========== $cn ==========" -ForegroundColor Cyan

    $target = "$UserName@$cn"
    $remoteCsv = "readiness-$cn.csv"
    $localCsv = Join-Path $OutDir "$cn-readiness.csv"

    try {
        Write-Host "Uploading script (you'll be prompted for the $UserName password/passphrase)..."
        scp $RemoteScriptPath "${target}:~/$remoteScriptName"
        if ($LASTEXITCODE -ne 0) { throw "scp upload failed (exit $LASTEXITCODE) - check network reachability / credentials for $cn" }

        $roleArg = "-r '$Role'"
        $domainArg = if ($Domain) { "-d '$Domain'" } else { "" }
        $auditdArg = if ($CheckAuditd) { "-c" } else { "" }
        $remoteCmd = "chmod +x ~/$remoteScriptName && sudo ~/$remoteScriptName $roleArg $domainArg $auditdArg -o ~/$remoteCsv"

        Write-Host "Running readiness check (you'll likely be prompted again here, plus sudo may prompt separately on the box itself)..."
        # -t forces ssh to allocate a pseudo-terminal for the remote command.
        # Without it, sudo on the far end has no terminal to prompt into and
        # fails with "sudo: a terminal is required to read the password" even
        # though the ssh login itself succeeded.
        ssh -t $target $remoteCmd
        if ($LASTEXITCODE -ne 0) { throw "ssh run failed (exit $LASTEXITCODE)" }

        Write-Host "Pulling results back (one more prompt)..."
        scp "${target}:~/$remoteCsv" $localCsv
        if ($LASTEXITCODE -ne 0) { throw "scp download of results failed (exit $LASTEXITCODE)" }

        $rows = Import-Csv $localCsv
        $pass = ($rows | Where-Object Status -eq "PASS").Count
        $fail = ($rows | Where-Object Status -eq "FAIL").Count
        $manual = ($rows | Where-Object Status -eq "MANUAL").Count
        $skip = ($rows | Where-Object Status -eq "SKIP").Count
        $summary.Add([pscustomobject]@{ Server = $cn; PASS = $pass; FAIL = $fail; MANUAL = $manual; SKIP = $skip; Csv = $localCsv })
    } catch {
        Write-Host "FAILED: $($_.Exception.Message)" -ForegroundColor Red
        $summary.Add([pscustomobject]@{ Server = $cn; PASS = "-"; FAIL = "-"; MANUAL = "-"; SKIP = "-"; Csv = "ERROR: $($_.Exception.Message)" })
    }
}

Write-Host ""
Write-Host "=== Batch Summary: $($ComputerNames.Count) server(s) ===" -ForegroundColor Cyan
$summary | Format-Table -AutoSize
$summary | Export-Csv -Path (Join-Path $OutDir "_batch-summary.csv") -NoTypeInformation
Write-Host "Per-server CSVs and rollup summary written to $OutDir"