﻿#Requires -Version 5.1

<#
.SYNOPSIS
    Weekly Nimble Array Health Check - DAL, LAX, OPS Lab
.DESCRIPTION
    Connects to all three HPE Nimble arrays via REST API, collects health data,
    and outputs a formatted SNOW-ready summary. Returns exit code 0 (all healthy)
    or 1 (issues found) for use in automation pipelines.
.PARAMETER ProdCredential
    PSCredential for DAL-NIMB01 and LAX-NIMB01. If omitted, prompts interactively.
.PARAMETER LabCredential
    PSCredential for OUA-NIMB01 (Ops Lab). If omitted, prompts interactively.
.PARAMETER OutputPath
    Optional path to write the report as a .txt file.
.PARAMETER SkipSSLValidation
    Bypass SSL cert validation (common on internal/lab arrays).
.EXAMPLE
    .\Invoke-NimbleHealthCheck.ps1 -SkipSSLValidation
.EXAMPLE
    $prod = Get-Credential -Message 'Prod (DAL/LAX)'
    $lab  = Get-Credential -Message 'Lab (OPS)'
    .\Invoke-NimbleHealthCheck.ps1 -ProdCredential $prod -LabCredential $lab -SkipSSLValidation -OutputPath C:\reports\nimble.txt
#>

[CmdletBinding()]
param(
    [Parameter()]
    [PSCredential]$ProdCredential,

    [Parameter()]
    [PSCredential]$LabCredential,

    [Parameter()]
    [string]$OutputPath,

    [Parameter()]
    [switch]$SkipSSLValidation
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -- ARRAY TARGETS --
$Arrays = @(
    @{ Name = 'DAL-NIMB01';  BaseUrl = 'https://dal-nimb01:5392';              CredGroup = 'Prod' },
    @{ Name = 'LAX-NIMB01';  BaseUrl = 'https://lax-nimb01:5392';              CredGroup = 'Prod' },
    @{ Name = 'OUA-NIMB01';  BaseUrl = 'https://oua-nimb01.inopslab.com:5392'; CredGroup = 'Lab'  },
    @{ Name = 'OUB-NIMB01';  BaseUrl = 'https://oub-nimb01.inopslab.com:5392'; CredGroup = 'Lab'  }
)

# -- SSL BYPASS --
if ($SkipSSLValidation) {
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
}

# -- CREDENTIAL PROMPTS --
if (-not $ProdCredential) {
    $ProdCredential = Get-Credential -Message 'Prod Nimble credentials (DAL-NIMB01 / LAX-NIMB01)'
}
if (-not $LabCredential) {
    $LabCredential  = Get-Credential -Message 'Lab Nimble credentials (OUA-NIMB01 / Ops Lab)'
}

$CredMap = @{
    Prod = $ProdCredential
    Lab  = $LabCredential
}

# -- HELPERS --
function Get-NimbleToken {
    param([string]$BaseUrl, [PSCredential]$Cred)

    # Correct JSON format
    $body = @{
        username = $Cred.UserName
        password = $Cred.GetNetworkCredential().Password
    } | ConvertTo-Json

    # Required in PowerShell 5.1
    $utf8 = [System.Text.Encoding]::UTF8.GetBytes($body)

    $r = Invoke-RestMethod -Uri "$BaseUrl/v1/tokens" -Method POST `
         -Body $utf8 -ContentType 'application/json'

    return $r.data.session_token
}

function Invoke-NimbleGet {
    param([string]$BaseUrl, [string]$Token, [string]$Endpoint)
    $headers = @{ 'X-Auth-Token' = $Token }
    $r = Invoke-RestMethod -Uri "$BaseUrl/v1/$Endpoint" -Method GET -Headers $headers -ContentType 'application/json'
    return $r.data
}

function Format-Bytes {
    param([long]$Bytes)
    if ($Bytes -ge 1TB) { return '{0:N2} TB' -f ($Bytes / 1TB) }
    if ($Bytes -ge 1GB) { return '{0:N2} GB' -f ($Bytes / 1GB) }
    return '{0:N2} MB' -f ($Bytes / 1MB)
}

function Get-Icon {
    param([string]$Status)
    switch -Regex ($Status.ToLower()) {
        'normal|ok|online|active|healthy|valid|spare' { '[OK]' }
        'warning|degraded|attention'                   { '[WARN]' }
        'critical|error|failed|offline|dead|fault'    { '[FAIL]' }
        default                                        { '[INFO]' }
    }
}

# -- MAIN --
$lines       = [System.Collections.Generic.List[string]]::new()
$issueCount  = 0
$timestamp   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

$lines.Add('=' * 70)
$lines.Add('  NIMBLE ARRAY WEEKLY HEALTH CHECK')
$lines.Add("  Run   : $timestamp")
$lines.Add('  Arrays: DAL-NIMB01 (Prod) | LAX-NIMB01 (Prod) | OUA-NIMB01 (Lab) | OUB-NIMB01 (Lab)')
$lines.Add('=' * 70)

foreach ($arr in $Arrays) {

    $lines.Add('')
    $lines.Add("+-- $($arr.Name)  ($($arr.BaseUrl))")

    try {
        $cred  = $CredMap[$arr.CredGroup]
        $token = Get-NimbleToken -BaseUrl $arr.BaseUrl -Cred $cred

        # Array info
        $aData = Invoke-NimbleGet -BaseUrl $arr.BaseUrl -Token $token `
            -Endpoint 'arrays?fields=name,model,serial,version,status,capacity,vol_usage_compressed_bytes,snap_usage_compressed_bytes'
        $a = $aData | Select-Object -First 1

        $usedBytes  = [long]$a.vol_usage_compressed_bytes + [long]$a.snap_usage_compressed_bytes
        $totalBytes = [long]$a.capacity
        $usedPct    = if ($totalBytes -gt 0) { [math]::Round(($usedBytes / $totalBytes) * 100, 1) } else { 0 }
        $capIcon    = if ($usedPct -ge 95) { $issueCount++; '[FAIL]' }
                      elseif ($usedPct -ge 85) { $issueCount++; '[WARN]' }
                      else { '[OK]' }

        $arrIcon = Get-Icon -Status $a.status
        if ($a.status -notmatch 'normal|ok') { $issueCount++ }

        $lines.Add("|  Array     : $($a.name)  Model: $($a.model)  NimbleOS: $($a.version)")
        $lines.Add("|  Status    : $arrIcon $($a.status)")
        $lines.Add("|  Capacity  : $capIcon $(Format-Bytes $usedBytes) used of $(Format-Bytes $totalBytes) ($usedPct%)")

        # Controllers
        $ctrls = Invoke-NimbleGet -BaseUrl $arr.BaseUrl -Token $token `
            -Endpoint 'controllers?fields=name,state,serial'
        $lines.Add("|  Controllers:")
        foreach ($c in $ctrls) {
            $icon = Get-Icon -Status $c.state
            if ($c.state -notmatch 'active|standby') { $issueCount++ }
            $lines.Add("|    $icon $($c.name) - $($c.state)  (S/N: $($c.serial))")
        }

        # Disks
        $disks = Invoke-NimbleGet -BaseUrl $arr.BaseUrl -Token $token `
            -Endpoint 'disks?fields=slot,disk_state,serial'
        $badDisks = $disks | Where-Object { $_.disk_state -notmatch 'active|valid|spare' }
        $dIcon = if ($badDisks.Count -gt 0) { $issueCount++; '[FAIL]' } else { '[OK]' }
        $lines.Add("|  Disks     : $dIcon $($disks.Count) total | $($badDisks.Count) degraded/failed")
        foreach ($bd in $badDisks) {
            $lines.Add("|    [FAIL] Slot $($bd.slot) - $($bd.disk_state)  (S/N: $($bd.serial))")
        }

        # Shelves
        try {
            $shelves = Invoke-NimbleGet -BaseUrl $arr.BaseUrl -Token $token `
                -Endpoint 'shelves?fields=serial,model,status'
            foreach ($sh in $shelves) {
                $icon = Get-Icon -Status $sh.status
                if ($sh.status -notmatch 'normal|ok') { $issueCount++ }
                $lines.Add("|  Shelf     : $icon Model: $($sh.model)  Status: $($sh.status)  (S/N: $($sh.serial))")
            }
        } catch {
            $lines.Add('|  Shelves   : [INFO] None attached or endpoint not available')
        }

        # Alerts
        $alerts = Invoke-NimbleGet -BaseUrl $arr.BaseUrl -Token $token `
            -Endpoint 'alerts?fields=severity,status,activity&filter=active eq true'
        $active = $alerts | Where-Object { $_.status -eq 'active' }
        $aIcon  = if ($active.Count -gt 0) { $issueCount += $active.Count; '[WARN]' } else { '[OK]' }
        $lines.Add("|  Alerts    : $aIcon $($active.Count) active")
        foreach ($al in ($active | Select-Object -First 5)) {
            $lines.Add("|    [$($al.severity.ToUpper())] $($al.activity)")
        }
        if ($active.Count -gt 5) {
            $lines.Add("|    ... $($active.Count - 5) more - check Nimble console for full list")
        }

        # Volumes
        try {
            $vols = Invoke-NimbleGet -BaseUrl $arr.BaseUrl -Token $token `
                -Endpoint 'volumes?fields=name,online'
            $offVols = $vols | Where-Object { $_.online -ne $true }
            $vIcon = if ($offVols.Count -gt 0) { $issueCount++; '[WARN]' } else { '[OK]' }
            $lines.Add("|  Volumes   : $vIcon $($vols.Count) total | $($offVols.Count) offline")
            foreach ($ov in $offVols) { $lines.Add("|    [WARN] Offline: $($ov.name)") }
        } catch {
            $lines.Add('|  Volumes   : [INFO] Unable to retrieve volume list')
        }

        # Logout
        try {
            Invoke-RestMethod -Uri "$($arr.BaseUrl)/v1/tokens/$token" -Method DELETE `
                -Headers @{ 'X-Auth-Token' = $token } -ContentType 'application/json' | Out-Null
        } catch {}

        $lines.Add("+-- $($arr.Name): COMPLETE")

    } catch {
        $issueCount++
        $lines.Add("|  [FAIL] $($_.Exception.Message)")
        $lines.Add("+-- $($arr.Name): CONNECTION FAILED - manual check required")
    }
}

# -- SUMMARY --
$lines.Add('')
$lines.Add('=' * 70)
if ($issueCount -eq 0) {
    $lines.Add('  RESULT : ALL ARRAYS HEALTHY')
    $lines.Add('  ACTION : Safe to close weekly Nimble SNOW tickets as "Closed Complete"')
} else {
    $lines.Add("  RESULT : $issueCount ISSUE(S) FOUND - Review flagged items above")
    $lines.Add('  ACTION : Investigate before closing. Escalate FAIL items.')
}
$lines.Add("  Run by : $env:USERNAME on $env:COMPUTERNAME")
$lines.Add('=' * 70)

$report = $lines -join "`n"
Write-Output $report

if ($OutputPath) {
    $report | Out-File -FilePath $OutputPath -Encoding UTF8
    Write-Host "`nReport written to: $OutputPath" -ForegroundColor Cyan
}

exit $(if ($issueCount -eq 0) { 0 } else { 1 })