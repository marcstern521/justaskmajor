# ============================================================
# GS - Script 0 - Install .NET 4.8 (prerequisite for EFT 8.2.x and later)
# Runs ONE server at a time, in the order you list them, and pauses between
# servers so you can check SFTP is healthy before touching the other side of
# a pair. Skips servers that already have 4.8.
#
# The install normally needs a REBOOT = the EFT/CDR SFTP service is down for
# several minutes. Do it in a window / under a CR.
#
# You need the offline installer on your laptop (from Microsoft):
#   ndp48-x86-x64-allos-enu.exe   (default path: C:\Temp\globalscape)
#
# Example:
#   .\GS_0_Install_DotNet48.ps1 -EftServer aaa-incdr01,aab-incdr01 -ChangeRef CHG0177747
#   .\GS_0_Install_DotNet48.ps1 -EftServer aaa-incdr01 -NoReboot     # install now, reboot yourself later
# ============================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string[]]$EftServer,
    [string]$Installer = 'C:\Temp\globalscape\ndp48-x86-x64-allos-enu.exe',
    [string]$RemoteDir = 'D:\temp',
    [string]$ChangeRef = '',
    [switch]$NoReboot,
    [int]$InstallTimeoutMinutes = 30,
    [int]$RebootTimeoutMinutes = 15,
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
if (-not (Test-Path $Installer)) { throw "Installer not found: $Installer - download the offline .NET 4.8 installer from Microsoft first" }

$Credential      = Get-GSCredential $Credential
$RemoteDir       = $RemoteDir.TrimEnd('\')
$remoteInstaller = '{0}\{1}' -f $RemoteDir, (Split-Path $Installer -Leaf)
$remoteLog       = '{0}\dotnet48_install.log' -f $RemoteDir
$summary         = @()
Start-GSLog -Name ('dotnet48_{0}' -f ($EftServer[0] -split '\.')[0])   # own log per run, so parallel windows don't fight over one file

function Add-Result {
    param([string]$Result)
    $script:summary += [pscustomobject]@{ Server = $server; Result = $Result }
}

function Test-PendingReboot {
    param($Session)
    Invoke-Command -Session $Session -ScriptBlock {
        $p = $false
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $p = $true }
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $p = $true }
        $r = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
        if ($r.PendingFileRenameOperations) { $p = $true }
        $p
    }
}

Write-Log "=== .NET 4.8 install ($($EftServer.Count) server(s), one at a time) $ChangeRef ===" Cyan
$idx = 0
foreach ($name in $EftServer) {
    $idx++
    $server = Resolve-GSHost $name $Domain
    Write-Log "--- [$idx/$($EftServer.Count)] $server ---" Cyan
    try {
        $s    = New-PSSession -ComputerName $server -Credential $Credential -ErrorAction Stop
        $info = Get-EFTInfo -Session $s

        if ($info.DotNet48) {
            Write-Log "  .NET 4.8 already installed (Release $($info.DotNetRelease)) - skipping" Green
            Remove-PSSession $s
            Add-Result 'Already installed'
            continue
        }

        Write-Log ("  OS: {0} | .NET Release: {1} | EFT service: {2} ({3}) | D: free: {4} GB" -f $info.OS, $info.DotNetRelease, $info.ServiceName, $info.ServiceState, $info.DFreeGB)
        if (Test-PendingReboot -Session $s) {
            Write-Log '  A reboot is ALREADY pending on this server - the install may fail or need a second reboot' Yellow
        }

        Write-Host "`n*** PRODUCTION SERVER ***" -ForegroundColor Red
        Write-Host "   $server" -ForegroundColor Yellow
        Write-Host '   .NET 4.8 normally needs a reboot: EFT / CDR SFTP is down for several minutes' -ForegroundColor Yellow
        Write-Host '   Confirm the CR / window is active and the other side of this pair is up' -ForegroundColor Yellow
        if (-not (Confirm-Typed "Install .NET 4.8 on $server?" 'YES')) {
            Remove-PSSession $s
            Add-Result 'Skipped by user'
            continue
        }

        # --- Copy installer ---
        Invoke-Command -Session $s -ScriptBlock { param($d) New-Item -ItemType Directory -Path $d -Force | Out-Null } -ArgumentList $RemoteDir
        $size = (Get-Item $Installer).Length
        $have = Invoke-Command -Session $s -ScriptBlock { param($p) if (Test-Path $p) { (Get-Item $p).Length } } -ArgumentList $remoteInstaller
        if ($have -ne $size) {
            Write-Log '  Copying installer...'
            Copy-Item -Path $Installer -Destination $remoteInstaller -ToSession $s -Force
            $have = Invoke-Command -Session $s -ScriptBlock { param($p) if (Test-Path $p) { (Get-Item $p).Length } } -ArgumentList $remoteInstaller
            if ($have -ne $size) { throw "Installer size mismatch (local $size, remote $have)" }
        } else {
            Write-Log '  Installer already on the server' Yellow
        }

        # --- Install (no automatic restart) ---
        Write-Log '  Running installer (quiet, no restart) - can take 5-15 minutes...'
        $r = Invoke-GSInstaller -Session $s -Path $remoteInstaller -InstallerArgs "/q /norestart /log $remoteLog" -TimeoutMinutes $InstallTimeoutMinutes
        if ($r.TimedOut) {
            Write-Log "  Installer still running after $InstallTimeoutMinutes minutes - NOT killed. RDP in and check. Stopping." Red
            Add-Result 'Installer timed out'
            break
        }
        Write-Log "  Installer exit code: $($r.ExitCode)  (log: $remoteLog on the server)"

        if ($r.ExitCode -eq 0) {
            $needReboot = $false
        } elseif ($r.ExitCode -eq 3010 -or $r.ExitCode -eq 1641) {
            $needReboot = $true
        } else {
            Write-Log "  Install FAILED (exit $($r.ExitCode)). 5100 = OS requirements not met. Check $remoteLog. Stopping." Red
            Add-Result "Install failed (exit $($r.ExitCode))"
            break
        }

        # --- Reboot ---
        if ($needReboot) {
            if ($NoReboot) {
                Write-Log '  Installed - REBOOT REQUIRED (-NoReboot given, leaving it). 4.8 is not active until it reboots.' Yellow
                Remove-PSSession $s
                Add-Result 'Installed - reboot pending'
                continue
            }
            if (-not (Confirm-Typed "  Reboot $server now? EFT / SFTP is down until it is back" 'REBOOT')) {
                Write-Log '  Reboot declined - 4.8 is not active until it reboots.' Yellow
                Remove-PSSession $s
                Add-Result 'Installed - reboot pending'
                continue
            }
            Remove-PSSession $s
            Write-Log "  Rebooting $server and waiting for PowerShell remoting (up to $RebootTimeoutMinutes min)..." Yellow
            Restart-Computer -ComputerName $server -Credential $Credential -Force -Wait -For PowerShell -Timeout ($RebootTimeoutMinutes * 60) -Delay 10 -ErrorAction Stop
            $s = New-PSSession -ComputerName $server -Credential $Credential -ErrorAction Stop
        }

        # --- Verify ---
        $after   = Get-EFTInfo -Session $s
        $running = Wait-GSService -Session $s -Name $info.ServiceName -TimeoutSec 180
        Remove-PSSession $s
        if ($after.DotNet48) { Write-Log "  .NET 4.8 confirmed (Release $($after.DotNetRelease))" Green }
        else                 { Write-Log "  .NET 4.8 NOT showing yet (Release $($after.DotNetRelease)) - reboot may still be needed" Red }
        Write-Log ("  EFT service {0}: {1}" -f $info.ServiceName, $(if ($running) { 'Running' } else { 'NOT running - check before moving on' })) $(if ($running) { 'Green' } else { 'Red' })
        Add-Result $(if ($after.DotNet48 -and $running) { 'OK' } else { 'CHECK' })

        if ($idx -lt $EftServer.Count) {
            $next = Read-Host "`nCheck SFTP is healthy on $server. Type NEXT to continue to the next server, or STOP"
            if ($next -ne 'NEXT') { Write-Log 'Stopped by user' Yellow; break }
        }
    } catch {
        Write-Log "  FAILED on $server - $_" Red
        Add-Result "Error: $_"
        break
    }
}

Write-Host "`n=== Summary ===" -ForegroundColor Cyan
$summary | Format-Table -AutoSize
Write-Log 'Re-run GS_1_Preflight_Check.ps1 to confirm .NET 4.8 shows True on every server before the upgrade windows' Cyan
