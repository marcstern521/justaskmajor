<#
.SYNOPSIS
    Checks a list of servers for a Cortex (Palo Alto Cortex XDR / Traps) agent service
    and exports Reachable / Installed / Not-Installed status to CSV.

.DESCRIPTION
    Run this FROM a domain-joined machine (jump box, admin workstation) that has
    network line-of-sight to the target servers, using an account with local admin
    rights on those servers (or WMI/CIM read rights at minimum).

    It reads the same "All Server Details" export CSV (or the cluster_mapping.csv -
    both have a ServerName column), does a fast port pre-check, then checks each
    reachable server for a Windows service whose Name or DisplayName matches the
    given pattern(s), and writes results to an output CSV you can hand back for
    cluster rollup reporting.

.PARAMETER InputCsv
    Path to the server export CSV (must have a "ServerName" column).

.PARAMETER OutputCsv
    Path to write results to.

.PARAMETER ServicePatterns
    One or more wildcard patterns to match against service Name/DisplayName.
    Cortex XDR's Windows service is often named "Cortex XDR" or (legacy Traps
    naming) "cyserver" / "Cortex XDR Service". Adjust if your install differs -
    to find the real name, run `Get-Service | Where DisplayName -like '*cortex*'`
    on one server you know has it installed, then update this list.

.PARAMETER Credential
    Credential to connect with. If omitted, you'll be prompted once (recommended -
    do not hardcode passwords in this script or pass them on the command line).

.PARAMETER Protocol
    'Cim' (default, uses DCOM/RPC over port 135 - no WinRM required) or
    'Wsman' (uses WinRM/PSRemoting over port 5985/5986 - faster/more reliable if
    WinRM is enabled fleet-wide).

.PARAMETER ThrottleLimit
    Max concurrent connections. Default 32. Lower this if you see timeouts/
    network saturation.

.PARAMETER PortTimeoutMs
    How long to wait (ms) on the fast TCP pre-check before declaring a server
    unreachable. Default 1500ms. This is what keeps 10,000+ server runs from
    taking forever when a chunk of them are offline/decommissioned/firewalled.

.EXAMPLE
    .\Check-CortexService.ps1 -InputCsv ".\AllServerDetails.csv" -OutputCsv ".\CortexStatus.csv"

.EXAMPLE
    .\Check-CortexService.ps1 -InputCsv ".\AllServerDetails.csv" -OutputCsv ".\CortexStatus.csv" `
        -ServicePatterns '*cortex*','cyserver' -Protocol Wsman -Credential (Get-Credential)
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$InputCsv,

    [Parameter(Mandatory = $true)]
    [string]$OutputCsv,

    [string[]]$ServicePatterns = @('*cortex*', 'cyserver', '*traps*'),

    [System.Management.Automation.PSCredential]$Credential,

    [ValidateSet('Cim', 'Wsman')]
    [string]$Protocol = 'Cim',

    [int]$ThrottleLimit = 32,

    [int]$PortTimeoutMs = 3000
)

if (-not (Test-Path $InputCsv)) {
    throw "Input CSV not found: $InputCsv"
}

if (-not $Credential) {
    Write-Host "Enter credentials with admin/WMI rights on the target servers." -ForegroundColor Cyan
    $Credential = Get-Credential
}

$servers = Import-Csv -Path $InputCsv
if (-not ($servers | Get-Member -Name ServerName)) {
    throw "Input CSV has no 'ServerName' column. Check the header row / delimiter."
}

$names = $servers | ForEach-Object { $_.ServerName.Trim() } | Where-Object { $_ } | Select-Object -Unique
Write-Host "Loaded $($names.Count) unique server names from $InputCsv" -ForegroundColor Cyan

$patterns    = $ServicePatterns
$portTimeout = $PortTimeoutMs
$checkPort   = if ($Protocol -eq 'Wsman') { 5985 } else { 135 }

Write-Host "Querying $($names.Count) servers via $Protocol (throttle $ThrottleLimit, port $checkPort pre-check @ ${portTimeout}ms)..." -ForegroundColor Cyan
Write-Host "This can take a while for large lists even with the fast pre-check." -ForegroundColor Cyan

# Shared logic as text so it can be dot-sourced identically in both the
# sequential (PS 5.1) and -Parallel (PS 7+) code paths - ForEach-Object
# -Parallel cannot accept a passed-in scriptblock variable via $using:, so this
# avoids maintaining two copies that can drift out of sync.
$checkOneDef = {
    function Test-CortexOnServer {
        param($ComputerName, $Patterns, $Cred, $Proto, $Port, $TimeoutMs)

        $result = [ordered]@{
            ServerName      = $ComputerName
            Reachable       = $false
            CortexInstalled = $false
            MatchedService  = ''
            ServiceStatus   = ''
            Error           = ''
        }

        # Fast pre-check so offline/firewalled/decommissioned hosts fail in
        # milliseconds instead of waiting on the full CIM/WSMan timeout.
        # NOTE: uses raw Socket.BeginConnect/EndConnect + WaitHandle.WaitOne
        # rather than TcpClient.ConnectAsync().Wait() - the latter reliably
        # timed out on every single host when run inside ForEach-Object
        # -Parallel (Task continuation not completing in time on those
        # runspace threads), even though the ports were confirmed open via
        # Test-NetConnection. This pattern is a plain blocking wait on a
        # WaitHandle with no Task/async machinery involved, so it isn't
        # affected by that.
        $socket = New-Object System.Net.Sockets.Socket(
            [System.Net.Sockets.AddressFamily]::InterNetwork,
            [System.Net.Sockets.SocketType]::Stream,
            [System.Net.Sockets.ProtocolType]::Tcp)
        try {
            $iar = $socket.BeginConnect($ComputerName, $Port, $null, $null)
            $connected = $iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false) -and $socket.Connected
            if ($connected) {
                try { $socket.EndConnect($iar) } catch { }
            } else {
                $result.Error = "Port $Port unreachable (timeout)"
                return [PSCustomObject]$result
            }
        } catch {
            $result.Error = "Port $Port unreachable: $($_.Exception.Message)"
            return [PSCustomObject]$result
        } finally {
            $socket.Close()
        }

        try {
            if ($Proto -eq 'Wsman') {
                $services = Invoke-Command -ComputerName $ComputerName -Credential $Cred -ErrorAction Stop -ScriptBlock {
                    Get-Service | Select-Object Name, DisplayName, Status
                }
            } else {
                # Get-CimInstance's -ComputerName parameter set has no -Credential
                # parameter (that's a Get-WmiObject thing, not CimCmdlets) - it
                # fails with "A parameter cannot be found that matches parameter
                # name 'Credential'." Have to build an explicit CimSession first.
                $cimSession = $null
                try {
                    $sessionOption = New-CimSessionOption -Protocol Dcom
                    $cimSession = New-CimSession -ComputerName $ComputerName -Credential $Cred -SessionOption $sessionOption -ErrorAction Stop
                    $services = Get-CimInstance -CimSession $cimSession -ClassName Win32_Service -ErrorAction Stop |
                        Select-Object Name, DisplayName, State
                } finally {
                    if ($cimSession) { Remove-CimSession -CimSession $cimSession -ErrorAction SilentlyContinue }
                }
            }

            $result.Reachable = $true

            $match = $services | Where-Object {
                $svc = $_
                $Patterns | Where-Object { $svc.Name -like $_ -or $svc.DisplayName -like $_ }
            } | Select-Object -First 1

            if ($match) {
                $result.CortexInstalled = $true
                $result.MatchedService  = $match.DisplayName
                $result.ServiceStatus   = if ($match.Status) { $match.Status } else { $match.State }
            }
        } catch {
            $result.Error = $_.Exception.Message
        }

        [PSCustomObject]$result
    }
}

if ($PSVersionTable.PSVersion.Major -ge 7) {
    $checkOneDefText = $checkOneDef.ToString()
    $results = $names | ForEach-Object -ThrottleLimit $ThrottleLimit -Parallel {
        . ([ScriptBlock]::Create($using:checkOneDefText))
        Test-CortexOnServer -ComputerName $_ -Patterns $using:patterns -Cred $using:Credential `
            -Proto $using:Protocol -Port $using:checkPort -TimeoutMs $using:portTimeout
    }
} else {
    Write-Warning "PowerShell 7+ not detected - running sequentially (Windows PowerShell 5.1 has no ForEach-Object -Parallel). This will be slow for thousands of servers; consider installing PS7 or splitting the list across multiple jump boxes/sessions."
    . $checkOneDef
    $results = foreach ($n in $names) {
        Test-CortexOnServer -ComputerName $n -Patterns $patterns -Cred $Credential -Proto $Protocol -Port $checkPort -TimeoutMs $portTimeout
    }
}

$results | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8

$total       = $results.Count
$reachable   = ($results | Where-Object Reachable).Count
$installed   = ($results | Where-Object CortexInstalled).Count
$unreachable = $total - $reachable

Write-Host ""
Write-Host "Done. $total servers checked." -ForegroundColor Green
Write-Host "  Reachable:        $reachable"
Write-Host "  Unreachable:      $unreachable"
Write-Host "  Cortex installed: $installed"
Write-Host "Results written to $OutputCsv"
