#Requires -Version 5.1
<#
.SYNOPSIS
    One-time setup: stores credentials securely and registers a weekly
    Windows Scheduled Task to run Invoke-NimbleHealthCheck.ps1.
.DESCRIPTION
    Run this ONCE as yourself (not as admin) so credentials encrypt
    to your Windows profile. The scheduled task runs under your account
    every Thursday at 06:30 AM, saves a timestamped report to the log
    folder, and keeps the last 52 weeks of logs.

    Re-run at any time to update credentials or reschedule.
.NOTES
    - Credentials are stored via Export-Clixml (DPAPI-encrypted, only
      decryptable by your account on this machine)
    - Both scripts must be in the same folder
    - Requires the Task Scheduler service to be running
#>

[CmdletBinding()]
param (
    # Day of week the SNOW tickets are generated (match to your ticket schedule)
    [ValidateSet('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')]
    [string]$RunDay = 'Thursday',

    # Time to run — 06:30 gives tickets time to generate at 06:00
    [string]$RunTime = '06:30',

    # Where to save weekly reports (created if it doesn't exist)
    [string]$LogFolder = "$env:USERPROFILE\Documents\NimbleHealthChecks",

    # Task name in Windows Task Scheduler
    [string]$TaskName = 'SysOps - Weekly Nimble Array Health Check'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ScriptDir     = $PSScriptRoot
$MainScript    = Join-Path $ScriptDir 'Invoke-NimbleHealthCheck.ps1'
$CredFileINCUN = Join-Path $ScriptDir '.nimble_cred_inucn.xml'
$CredFileOps   = Join-Path $ScriptDir '.nimble_cred_opslab.xml'

# ── PRE-FLIGHT ────────────────────────────────────────────────────────────────
if (-not (Test-Path $MainScript)) {
    throw "Cannot find Invoke-NimbleHealthCheck.ps1 in $ScriptDir. Ensure both scripts are in the same folder."
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Nimble Health Check — One-Time Setup  " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ── CREDENTIAL STORAGE ────────────────────────────────────────────────────────
Write-Host "Step 1 of 3: Store credentials (DPAPI-encrypted to your Windows profile)" -ForegroundColor Yellow
Write-Host ""

# INUCN
if (Test-Path $CredFileINCUN) {
    $overwrite = Read-Host "  INUCN creds already stored. Overwrite? (y/N)"
    if ($overwrite -ne 'y') {
        Write-Host "  Keeping existing INUCN credentials." -ForegroundColor Gray
    } else {
        $cred = Get-Credential -Message "Enter INUCN credentials (for DAL-NIMB01 + LAX-NIMB01)"
        $cred | Export-Clixml -Path $CredFileINCUN -Force
        Write-Host "  [OK] INUCN credentials saved." -ForegroundColor Green
    }
} else {
    $cred = Get-Credential -Message "Enter INUCN credentials (for DAL-NIMB01 + LAX-NIMB01)"
    $cred | Export-Clixml -Path $CredFileINCUN -Force
    Write-Host "  [OK] INUCN credentials saved." -ForegroundColor Green
}

# OpsLab
if (Test-Path $CredFileOps) {
    $overwrite = Read-Host "  OpsLab creds already stored. Overwrite? (y/N)"
    if ($overwrite -ne 'y') {
        Write-Host "  Keeping existing OpsLab credentials." -ForegroundColor Gray
    } else {
        $cred = Get-Credential -Message "Enter OpsLab credentials (for OUA-NIMB01)"
        $cred | Export-Clixml -Path $CredFileOps -Force
        Write-Host "  [OK] OpsLab credentials saved." -ForegroundColor Green
    }
} else {
    $cred = Get-Credential -Message "Enter OpsLab credentials (for OUA-NIMB01)"
    $cred | Export-Clixml -Path $CredFileOps -Force
    Write-Host "  [OK] OpsLab credentials saved." -ForegroundColor Green
}

# ── LOG FOLDER ────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Step 2 of 3: Create log folder" -ForegroundColor Yellow
if (-not (Test-Path $LogFolder)) {
    New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
    Write-Host "  [OK] Created: $LogFolder" -ForegroundColor Green
} else {
    Write-Host "  [OK] Exists : $LogFolder" -ForegroundColor Green
}

# ── SCHEDULED TASK ────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Step 3 of 3: Register Windows Scheduled Task" -ForegroundColor Yellow
Write-Host "  Task  : $TaskName"
Write-Host "  Runs  : Every $RunDay at $RunTime"
Write-Host ""

# Build the PowerShell command the task will execute
# Loads creds from encrypted XML, passes to main script, saves timestamped log
$taskScript = @"
`$credINCUN  = Import-Clixml -Path '$CredFileINCUN'
`$credOpsLab = Import-Clixml -Path '$CredFileOps'
`$timestamp  = Get-Date -Format 'yyyy-MM-dd'
`$logFile    = '$LogFolder\NimbleHealth_' + `$timestamp + '.txt'
& '$MainScript' -CredentialINCUN `$credINCUN -CredentialOpsLab `$credOpsLab -OutputToFile 2>&1 | Tee-Object -FilePath `$logFile
# Prune logs older than 52 weeks
Get-ChildItem '$LogFolder' -Filter '*.txt' |
    Where-Object { `$_.LastWriteTime -lt (Get-Date).AddDays(-365) } |
    Remove-Item -Force
"@

# Encode so Task Scheduler doesn't choke on special chars
$encoded = [Convert]::ToBase64String(
    [System.Text.Encoding]::Unicode.GetBytes($taskScript)
)

$action  = New-ScheduledTaskAction `
    -Execute 'powershell.exe' `
    -Argument "-NonInteractive -WindowStyle Hidden -EncodedCommand $encoded"

$trigger = New-ScheduledTaskTrigger `
    -Weekly -DaysOfWeek $RunDay `
    -At $RunTime

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 1) `
    -RunOnlyIfNetworkAvailable `
    -StartWhenAvailable `
    -MultipleInstances IgnoreNew

# Remove existing task if present, then register fresh
$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "  Removed previous task registration." -ForegroundColor Gray
}

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action   $action `
    -Trigger  $trigger `
    -Settings $settings `
    -RunLevel Highest `
    -Description "Weekly Nimble array health check: DAL-NIMB01 (INUCN), LAX-NIMB01 (INUCN), OUA-NIMB01 (OpsLab). Auto-saves report to $LogFolder." | Out-Null

Write-Host "  [OK] Task registered successfully." -ForegroundColor Green

# ── SUMMARY ───────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Setup Complete                        " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Scheduled Task : $TaskName"
Write-Host "  Next run       : $RunDay at $RunTime"
Write-Host "  Reports saved  : $LogFolder"
Write-Host "  Cred files     : $ScriptDir\.nimble_cred_*.xml"
Write-Host ""
Write-Host "  To run immediately (test):"
Write-Host "  Start-ScheduledTask -TaskName '$TaskName'" -ForegroundColor White
Write-Host ""
Write-Host "  To view in Task Scheduler:"
Write-Host "  taskschd.msc" -ForegroundColor White
Write-Host ""

# ── OPTIONAL: RUN NOW ─────────────────────────────────────────────────────────
$runNow = Read-Host "Run the health check now to verify? (y/N)"
if ($runNow -eq 'y') {
    Write-Host ""
    Write-Host "Running now..." -ForegroundColor Yellow
    $credINCUN  = Import-Clixml -Path $CredFileINCUN
    $credOpsLab = Import-Clixml -Path $CredFileOps
    & $MainScript -CredentialINCUN $credINCUN -CredentialOpsLab $credOpsLab -OutputToFile
}
