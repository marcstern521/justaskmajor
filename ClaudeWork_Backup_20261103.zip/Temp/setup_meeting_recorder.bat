@echo off
setlocal
title Meeting Recorder Setup
set "DEST=%USERPROFILE%\MeetingRecorder"

if not exist "%~dp0record_meeting.py" (
  echo record_meeting.py must be in the same folder as this file.
  pause & exit /b 1
)
if not exist "%~dp0Record Meeting.bat" (
  echo "Record Meeting.bat" must be in the same folder as this file.
  pause & exit /b 1
)

python --version >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install it first:  winget install Python.Python.3.12
  echo Then close and reopen this window and run setup again.
  pause & exit /b 1
)

echo Copying files to %DEST% ...
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0record_meeting.py" "%DEST%\record_meeting.py" >nul
copy /Y "%~dp0Record Meeting.bat" "%DEST%\Record Meeting.bat" >nul

echo Installing Python packages (one time)...
python -m pip install --upgrade soundcard numpy faster-whisper
if errorlevel 1 (
  echo Package install failed. Send me the error text above.
  pause & exit /b 1
)

echo Creating desktop shortcut (hotkey Ctrl+Alt+R)...
powershell -NoProfile -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\Record Meeting.lnk'); $s.TargetPath='%DEST%\Record Meeting.bat'; $s.WorkingDirectory='%DEST%'; $s.Hotkey='CTRL+ALT+R'; $s.Save()"

echo.
echo Done. Double-click "Record Meeting" on your desktop, or press Ctrl+Alt+R.
echo Transcripts are saved in %USERPROFILE%\MeetingNotes
pause
