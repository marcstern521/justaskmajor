# ============================================================
# GS - Script 2b - EC2 snapshots (use instead of GS_2 for AWS servers)
# Finds each instance, snapshots every attached EBS volume, tags them, and
# (by default) waits until they are all 'completed'.
# Instance is picked by matching the server's DNS IP to the instance private IP,
# so look-alike names (e.g. aaa-incdr01 vs aaa-incdr01-n) can't be mixed up.
# If DNS fails, it falls back to an exact Name tag match. -TrustNameTag also
# allows the exact Name tag when the IP check finds no match.
# Needs AWS Tools for PowerShell:  Install-Module AWS.Tools.EC2
#
# Example:
#   .\GS_2b_Snapshot_EC2.ps1 -Name aaa-incdr01,aab-incdr01 -Region ap-southeast-2 -ProfileName <profile> -ChangeRef CHG0177747
#
# Rollback: stop the instance, detach the volumes, create new volumes from
# these snapshots, attach them on the same device names, start the instance.
# ============================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string[]]$Name,
    [Parameter(Mandatory)][string]$Region,
    [string]$ProfileName,
    [string]$ChangeRef = '',
    [string]$Domain = 'inucn.com',
    [switch]$TrustNameTag,
    [switch]$NoWait
)

. "$PSScriptRoot\GS_Common.ps1"
Start-GSLog -Name 'ec2_snapshot'

if (-not (Get-Command New-EC2Snapshot -ErrorAction SilentlyContinue)) {
    throw 'AWS Tools for PowerShell not loaded. Run: Install-Module AWS.Tools.EC2 (or import AWSPowerShell.NetCore)'
}

# Picks the instance that is really the server: DNS IP match first, exact Name tag only as a fallback
function Select-GSInstance {
    param($Candidates, [string]$Name, [string[]]$DnsIps, [switch]$TrustNameTag)
    if ($DnsIps.Count) {
        $byIp = @($Candidates | Where-Object {
            $ips = @($_.PrivateIpAddress) + @($_.NetworkInterfaces | ForEach-Object { $_.PrivateIpAddresses } | ForEach-Object { $_.PrivateIpAddress })
            @($ips | Where-Object { $DnsIps -contains $_ }).Count -gt 0
        })
        if ($byIp.Count -eq 1) { return [pscustomobject]@{ Instance = $byIp[0]; How = 'DNS IP match' } }
    }
    if ($TrustNameTag -or $DnsIps.Count -eq 0) {
        $exact = @($Candidates | Where-Object { (($_.Tags | Where-Object { $_.Key -eq 'Name' }).Value) -eq $Name })
        if ($exact.Count -eq 1) { return [pscustomobject]@{ Instance = $exact[0]; How = 'exact Name tag (NOT verified by IP)' } }
    }
    $null
}

$aws = @{ Region = $Region }
if ($ProfileName) { $aws.ProfileName = $ProfileName }

$SnapshotName = 'Pre-Globalscape-Upgrade-{0}' -f (Get-Date -Format 'yyyy-MM-dd')
Write-Log "=== EC2 snapshots ($Region) ===" Cyan

# --- Find instances ---
$targets = @()
foreach ($n in $Name) {
    try {
        $res = Get-EC2Instance @aws -Filter @{ Name = 'tag:Name'; Values = "$n*" } -ErrorAction Stop
    } catch {
        Write-Log "Lookup failed for $n - $_" Red
        exit 1
    }
    $cands = @($res | ForEach-Object { if ($_.Instances) { $_.Instances } else { $_ } }) |
        Where-Object { "$($_.State.Name)" -ne 'terminated' }

    $fqdn   = Resolve-GSHost $n $Domain
    $dnsIps = @()
    try { $dnsIps = @([System.Net.Dns]::GetHostAddresses($fqdn) | ForEach-Object { $_.IPAddressToString }) }
    catch { Write-Log "  DNS lookup failed for $fqdn - falling back to exact Name tag" Yellow }

    $pick = Select-GSInstance -Candidates $cands -Name $n -DnsIps $dnsIps -TrustNameTag:$TrustNameTag
    if (-not $pick) {
        Write-Log "Could not safely pick an instance for $n (DNS $fqdn = $($dnsIps -join ', '))" Red
        $cands | ForEach-Object {
            Write-Log ("   {0}  {1}  {2}" -f $_.InstanceId, (($_.Tags | Where-Object Key -eq 'Name').Value), $_.PrivateIpAddress) Red
        }
        Write-Log '   Check region/profile, or pass -TrustNameTag to accept the exact Name tag.' Red
        exit 1
    }
    $i    = $pick.Instance
    $vols = @($i.BlockDeviceMappings | Where-Object { $_.Ebs } | ForEach-Object { $_.Ebs.VolumeId })
    Write-Log ("  {0} -> {1} {2} ({3}) via {4} - {5} volume(s): {6}" -f $n, $i.InstanceId, $i.PrivateIpAddress, $i.State.Name, $pick.How, $vols.Count, ($vols -join ', '))
    if ($pick.How -like '*NOT verified*') { Write-Log '    Double-check this is the right instance before typing YES' Yellow }
    $targets += [pscustomobject]@{ Name = $n; InstanceId = $i.InstanceId; Volumes = $vols }
}

if (-not (Confirm-Typed "`nSnapshot $(($targets.Volumes).Count) volume(s) across $($targets.Count) instance(s) as '$SnapshotName'?" 'YES')) {
    Write-Log 'Exiting - no snapshots taken' Yellow
    exit 0
}

# --- Take snapshots ---
$snapIds = @()
$allGood = $true
foreach ($t in $targets) {
    foreach ($v in $t.Volumes) {
        try {
            $desc = ('{0} {1} {2} {3}' -f $SnapshotName, $t.Name, $t.InstanceId, $ChangeRef).Trim()
            $snap = New-EC2Snapshot @aws -VolumeId $v -Description $desc -ErrorAction Stop
            New-EC2Tag @aws -Resource $snap.SnapshotId -Tag @(
                @{ Key = 'Name';    Value = ('{0}-{1}' -f $SnapshotName, $t.Name) },
                @{ Key = 'Purpose'; Value = 'Globalscape upgrade rollback' }
            ) | Out-Null
            $snapIds += $snap.SnapshotId
            Write-Log "  $($t.Name) $v -> $($snap.SnapshotId) started" Green
        } catch {
            Write-Log "  $($t.Name) $v FAILED - $_" Red
            $allGood = $false
        }
    }
}

# --- Wait for completion ---
if ($snapIds.Count -gt 0 -and -not $NoWait) {
    Write-Log 'Waiting for snapshots to reach completed (Ctrl+C to stop waiting - they keep running)...' Yellow
    do {
        Start-Sleep -Seconds 30
        $state = @(Get-EC2Snapshot @aws -SnapshotId $snapIds)
        $done  = @($state | Where-Object { "$($_.State)" -eq 'completed' }).Count
        $err   = @($state | Where-Object { "$($_.State)" -eq 'error' })
        Write-Log ("  {0}/{1} completed  ({2})" -f $done, $snapIds.Count, (($state | ForEach-Object { $_.Progress }) -join ' '))
        if ($err.Count) { Write-Log "  $($err.Count) snapshot(s) in ERROR state" Red; $allGood = $false; break }
    } while ($done -lt $snapIds.Count)
}

if ($allGood) {
    Write-Log "Snapshots good. Name: $SnapshotName  IDs: $($snapIds -join ', ')" Green
    Write-Log 'Next: GS_5_EFT_Hop_Upgrade.ps1 inside the maintenance window' Cyan
} else {
    Write-Log 'One or more snapshots failed - DO NOT proceed until resolved' Red
}
