﻿# Sweep-CDrive.ps1
param(
    [string[]]$Domains   = @('inucn.com','ineur.eu','in.lab'),
    [int]$BatchSize      = 500,
    [int]$Throttle       = 64,
    [int]$StaleDays      = 30,
    [string]$OutDir      = ".\CSweep_$(Get-Date -Format yyyyMMdd)",
    [switch]$UseCurrentLogon   # use this process's identity (runas /netonly); no password prompts
)

New-Item $OutDir -ItemType Directory -Force | Out-Null
$results = Join-Path $OutDir 'results.csv'
$unreach = Join-Path $OutDir 'unreachable.csv'

$sb = {
    $d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
    [pscustomobject]@{
        Server  = $env:COMPUTERNAME
        SizeGB  = [math]::Round($d.Size/1GB,1)
        FreeGB  = [math]::Round($d.FreeSpace/1GB,1)
        PctFree = [math]::Round(($d.FreeSpace/$d.Size)*100,1)
    }
}
$opt = New-PSSessionOption -OpenTimeout 15000 -OperationTimeout 60000 -NoMachineProfile
function Get-ShortName([string]$n) { ($n -split '\.')[0].ToUpper() }

foreach ($dom in $Domains) {
    $cred = $null
    if (-not $UseCurrentLogon) {
        $cred = Get-Credential -Message "Credentials for $dom (UPN form, e.g. marc.stern@$dom)"
        if (-not $cred) { Write-Warning "No credentials for $dom, skipping"; continue }
    }

    # ---- AD query over LDAP ----
    $ft  = (Get-Date).AddDays(-$StaleDays).ToFileTime()
    $all = @()
    try {
        if ($cred) { $root = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$dom", $cred.UserName, $cred.GetNetworkCredential().Password) }
        else       { $root = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$dom") }
        $ds = New-Object System.DirectoryServices.DirectorySearcher($root)
        $ds.PageSize = 1000
        $ds.Filter = "(&(objectCategory=computer)(operatingSystem=*Server*)(!(userAccountControl:1.2.840.113556.1.4.803:=2))(lastLogonTimestamp>=$ft))"
        [void]$ds.PropertiesToLoad.Add('dnshostname')
        $all = @($ds.FindAll() | ForEach-Object { $_.Properties['dnshostname'][0] } | Where-Object { $_ })
    } catch {
        Write-Warning "$dom : LDAP query failed - $($_.Exception.Message)"
        continue
    }

    # ---- resume: skip anything already recorded ----
    $done = @()
    if (Test-Path $results) { $done += (Import-Csv $results).Server | ForEach-Object { Get-ShortName $_ } }
    if (Test-Path $unreach) { $done += (Import-Csv $unreach).Server | ForEach-Object { Get-ShortName $_ } }
    $todo = @($all | Where-Object { $done -notcontains (Get-ShortName $_) })
    Write-Host "$dom : $($all.Count) servers found, $($todo.Count) to check"
    if ($todo.Count -eq 0) { continue }

    # ---- sweep in batches ----
    for ($i = 0; $i -lt $todo.Count; $i += $BatchSize) {
        $batch = $todo[$i..([math]::Min($i + $BatchSize, $todo.Count) - 1)]
        $fails = $null
        $icArgs = @{}
        if ($cred) { $icArgs.Credential = $cred }
        $ok = Invoke-Command -ComputerName $batch -ScriptBlock $sb @icArgs `
                -ThrottleLimit $Throttle -SessionOption $opt `
                -ErrorAction SilentlyContinue -ErrorVariable fails

        @($ok) | Where-Object { $_ } |
            Select-Object @{n='Domain';e={$dom}}, Server, SizeGB, FreeGB, PctFree |
            Export-Csv $results -Append -NoTypeInformation

        @($fails) | Where-Object { $_ } | ForEach-Object {
            [pscustomobject]@{
                Domain = $dom
                Server = "$($_.TargetObject)"
                Reason = ($_.Exception.Message -split "`n")[0].Trim()
            }
        } | Export-Csv $unreach -Append -NoTypeInformation

        Write-Host ("  batch {0}: {1} ok, {2} failed" -f ([math]::Floor($i / $BatchSize) + 1), @($ok).Count, @($fails).Count)
    }
}

# ---- summary ----
if (Test-Path $results) {
    $r = Import-Csv $results
    Write-Host "`nLowest 40 by % free (full list: $results)"
    $r | Sort-Object { [double]$_.PctFree } | Select-Object -First 40 | Format-Table -AutoSize
    "{0} servers checked, {1} under 15% free, {2} under 5% free" -f $r.Count,
        @($r | Where-Object { [double]$_.PctFree -lt 15 }).Count,
        @($r | Where-Object { [double]$_.PctFree -lt 5 }).Count
}
if (Test-Path $unreach) { Write-Host "Unreachable: $((Import-Csv $unreach).Count) (see $unreach)" }