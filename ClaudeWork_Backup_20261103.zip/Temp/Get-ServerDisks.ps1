﻿# -----------------------------
# Fixed paths
# -----------------------------
$CsvPath  = "C:\Temp\COR_servers.csv"
$Today    = Get-Date -Format "yyyy-MM-dd"
$Now      = Get-Date -Format "HHmmss"
$OutDir   = "C:\Temp\DiskReport_$Today"
$OutPath  = "$OutDir\ServerDiskReport_${Today}_$Now.csv"

# -----------------------------
# Settings
# -----------------------------
$ThrottleLimit    = 20
$FreePctThreshold = 75.0

# Auth fallback order that actually works with Invoke-Command
$AuthOrder = @("Negotiate","Kerberos","Default")

# WinRM session options (helps avoid long hangs)
$SessOpt = New-PSSessionOption -OperationTimeout 30000 -OpenTimeout 15000

# -----------------------------
# Prep output folder
# -----------------------------
if (-not (Test-Path $OutDir)) { New-Item -Path $OutDir -ItemType Directory -Force | Out-Null }
if (-not (Test-Path $CsvPath)) { throw "Server list not found: $CsvPath" }

# -----------------------------
# Read CSV
# -----------------------------
$raw = Import-Csv -Path $CsvPath
if (-not ($raw[0].PSObject.Properties.Name -contains "ServerName")) {
  throw "CSV must contain a 'ServerName' column."
}
$ipCol = ($raw[0].PSObject.Properties.Name | Where-Object { $_ -match "IPV4" } | Select-Object -First 1)

$servers = @()
foreach ($r in $raw) {
  $name = "$($r.ServerName)".Trim()
  if ([string]::IsNullOrWhiteSpace($name)) { continue }

  $ip = $null
  if ($ipCol) {
    $ip = "$($r.$ipCol)".Replace("`t","").Trim()
    if ([string]::IsNullOrWhiteSpace($ip)) { $ip = $null }
  }

  $servers += [pscustomobject]@{ ServerName=$name; ServerIPV4Address=$ip }
}
if ($servers.Count -eq 0) { throw "No servers found in CSV." }

# -----------------------------
# Prompt once for INUCN creds
# -----------------------------
$cred = Get-Credential -Message "Enter INUCN credentials (example: INUCN\marc.stern)"

# -----------------------------
# Output container (always produce rows)
# -----------------------------
$results = @()
$lastErrByServer = @{}   # server -> last error string

function Add-Row {
  param(
    [string]$Server,[string]$IP,[string]$Status,[string]$Error,
    [string]$AuthUsed = $null,
    [string]$DriveLetter = $null,
    [double]$SizeGB = $null,[double]$FreeGB = $null,[double]$FreePct = $null,
    [bool]$FlagUnder75 = $false,
    [string]$AvailableDriveLetters = $null
  )
  $script:results += [pscustomobject]@{
    ServerName=$Server
    ServerIPV4Address=$IP
    AuthUsed=$AuthUsed
    DriveLetter=$DriveLetter
    SizeGB=$SizeGB
    FreeGB=$FreeGB
    FreePct=$FreePct
    FlagUnder75=$FlagUnder75
    AvailableDriveLetters=$AvailableDriveLetters
    Status=$Status
    Error=$Error
  }
}

# -----------------------------
# Remote work block
# -----------------------------
$diskBlock = {
  param($FreePctThreshold)

  $disks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" |
    Select-Object DeviceID, Size, FreeSpace

  $usedLetters = @($disks.DeviceID | ForEach-Object { $_.TrimEnd(":").ToUpper() })
  $allLetters  = 65..90 | ForEach-Object { [char]$_ }
  $available   = $allLetters | Where-Object { $usedLetters -notcontains $_ }
  $availStr    = ($available -join ",")

  if (-not $disks -or $disks.Count -eq 0) {
    return @([pscustomobject]@{
      DriveLetter=$null; SizeGB=$null; FreeGB=$null; FreePct=$null
      FlagUnder75=$false; AvailableDriveLetters=$availStr
      Status="NO_LOCAL_DISKS_RETURNED"
    })
  }

  foreach ($d in $disks) {
    $sizeGB = if ($d.Size) { [math]::Round(($d.Size / 1GB), 2) } else { $null }
    $freeGB = if ($d.FreeSpace -ne $null) { [math]::Round(($d.FreeSpace / 1GB), 2) } else { $null }
    $pct    = if ($d.Size -gt 0 -and $d.FreeSpace -ne $null) { [math]::Round((($d.FreeSpace / $d.Size) * 100), 2) } else { $null }

    [pscustomobject]@{
      DriveLetter=$d.DeviceID
      SizeGB=$sizeGB
      FreeGB=$freeGB
      FreePct=$pct
      FlagUnder75=($pct -ne $null -and $pct -lt $FreePctThreshold)
      AvailableDriveLetters=$availStr
      Status="OK"
    }
  }
}

# -----------------------------
# Auth fallback passes
# -----------------------------
$remaining = @($servers)

foreach ($auth in $AuthOrder) {
  if ($remaining.Count -eq 0) { break }

  Write-Host "Running disk collection with auth: $auth on $($remaining.Count) servers..."

  $jobs = Invoke-Command `
    -ComputerName ($remaining | Select-Object -ExpandProperty ServerName) `
    -Credential $cred `
    -Authentication $auth `
    -SessionOption $SessOpt `
    -AsJob `
    -ThrottleLimit $ThrottleLimit `
    -ScriptBlock $diskBlock `
    -ArgumentList $FreePctThreshold

  Wait-Job $jobs | Out-Null

  $failed = @()

  foreach ($job in $jobs.ChildJobs) {
    $server = $job.Location
    $obj = $remaining | Where-Object { $_.ServerName -eq $server } | Select-Object -First 1
    $ip = $obj.ServerIPV4Address

    try {
      $out = Receive-Job -Job $job -ErrorAction Stop

      foreach ($row in $out) {
        Add-Row -Server $server -IP $ip -AuthUsed $auth -Status $row.Status -Error $null `
          -DriveLetter $row.DriveLetter -SizeGB $row.SizeGB -FreeGB $row.FreeGB -FreePct $row.FreePct `
          -FlagUnder75 $row.FlagUnder75 -AvailableDriveLetters $row.AvailableDriveLetters
      }
    } catch {
      $msg = $_.Exception.Message
      $lastErrByServer[$server] = "Auth=$auth :: $msg"
      if ($obj) { $failed += $obj }
    }
  }

  Remove-Job $jobs -Force -ErrorAction SilentlyContinue | Out-Null
  $remaining = @($failed)
}

# Any servers that failed all auth methods → write ERROR row
foreach ($s in $remaining) {
  $err = $lastErrByServer[$s.ServerName]
  if (-not $err) { $err = "Unknown failure" }
  Add-Row -Server $s.ServerName -IP $s.ServerIPV4Address -Status "ERROR" -Error $err
}

# -----------------------------
# Export (don’t keep file open in Excel)
# -----------------------------
$results |
  Sort-Object ServerName, DriveLetter |
  Export-Csv -Path $OutPath -NoTypeInformation

Write-Host "✔ Disk report complete"
Write-Host "📄 $OutPath"
Write-Host "Tip: Filter FlagUnder75 = TRUE to see drives under $FreePctThreshold% free."
