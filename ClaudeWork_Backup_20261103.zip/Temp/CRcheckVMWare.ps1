﻿# =======================
# CREDENTIALS
# =======================
$Cred  = Get-Credential -Message "Enter credentials for Windows servers"
$VCred = Get-Credential -Message "Enter vCenter credentials"

# =======================
# SERVER LIST
# =======================
$Servers = @(
"LAX-ENSCR01",
"LAX-ENSTS01",
"DAL-NWSOL02",
"LAX-ECWEB03",
"FRA-INDBS01",
"MUN-INMDR01",
"MUN-INNSE01",
"FRA-WF4594619A",
"FRA-WF4594619W",
"FRA-ICCLGR01",
"AAA-ENDBF01",
"AOB-C9STM01",
"AVA-NIFSV01",
"AVA-NIAPP01",
"AVA-NIDBS01",
"AVA-NIPLT01",
"AVA-NI-SRVCL01",
"AVA-NISQL01-1",
"AVA-NISQL01-3",
"AOB-C28STM01",
"AOB-B3STM01",
"AOB-C29STM01",
"AOB-C32STM01",
"AOB-C4STM01",
"AOB-C6STM01",
"AOB-C11STM01",
"AOB-C12STM01",
"AOB-C17STM01",
"AOB-C19STM01",
"AOB-C27STM01",
"AAB-A32STM01",
"AOB-C20STM01",
"AOB-C14STM01",
"AOB-C18STM01",
"AOA-C33PEN01",
"AFB-E32STM01",
"AOB-C35STM01",
"AO-VC-QMRPT1-NY",
"AO-VC-QMAPP1-NY",
"AOB-C36STM01",
"AOB-C36API01",
"AOB-C38STM01",
"AOB-C40STM01",
"AOB-C42STM01",
"AOB-B31STM01",
"ALB-L32STM01",
"AOB-C43STM01",
"AOB-C44STM01",
"AMB-M32STM01",
"AOB-C46STM01",
"AOB-C45STM01",
"SGP-PCRLR08",
"SGP-PCRLR10",
"AAB-A35STM01",
"AFA-PCPEN01",
"LAX-VL250TEST",
"LAX-WEB-TEMP",
"AO-VC-QMRPT4-NY",
"AO-VC-QMAPP4-NY",
"DAL-BMPCS01-N",
"LAX-DIDBS01-N",
"LAX-DIDBS02-N",
"AOA-C64IVR01",
"AOB-C64IVR01",
"LAX-C64MEI01","LAX-C64MEI02","LAX-C64MEI03","LAX-C64MEI04","LAX-C64MEI05",
"LAX-C64MEI06","LAX-C64MEI07","LAX-C64MEI08","LAX-C64MEI09",
"DAL-C63MEI01","DAL-C63MEI02","DAL-C63MEI03","DAL-C63MEI04",
"DAL-C63MEI05","DAL-C63MEI06","DAL-C63MEI07","DAL-C63MEI08","DAL-C63MEI09",
"DAL-C64MEI01","DAL-C64MEI02","DAL-C64MEI03","DAL-C64MEI04",
"DAL-C64MEI05","DAL-C64MEI06","DAL-C64MEI07","DAL-C64MEI08","DAL-C64MEI09",
"LAX-INDCO01-NN",
"EUFTA-INDBI01",
"EUFTB-INDBI01",
"LAX-RSIDR02",
"LAX-C213-MEI02",
"LAX-INASR06",
"DAL-INASR06",
"LAX-VXLAN01",
"DAL-VXLAN01",
"DAL-VXLAN02",
"ACVAB-27MED02",
"ACVAB-27MEI05",
"ACVAB-27MEI07",
"ACVAB-27MEI08",
"ACVAB-29IVR01"
)

# =======================
$Domain = ".inucn.com"

# =======================
# VMWARE SETUP
# =======================
Import-Module VMware.PowerCLI
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

$vCenters = @(
    "vcenter01.inucn.com"
)

foreach ($vc in $vCenters) {
    Connect-VIServer -Server $vc -Credential $VCred | Out-Null
}

# =======================
# MAIN CHECK
# =======================
$Results = foreach ($ServerName in $Servers) {

    $FQDN = "$ServerName$Domain"

    # VMware inventory check
    $VM = Get-VM -Name $ServerName -ErrorAction SilentlyContinue
    $VMwareStatus = if ($VM) { "Present" } else { "Missing" }

    # Ping check
    if (-not (Test-Connection -ComputerName $FQDN -Count 1 -Quiet)) {
        [PSCustomObject]@{
            Server       = $FQDN
            VMwareStatus = $VMwareStatus
            RemoteStatus = "Unreachable"
            Result       = "FAIL"
            Detail       = "No ICMP response"
        }
        continue
    }

    try {
        $Service = Invoke-Command -ComputerName $FQDN `
            -Credential $Cred `
            -ScriptBlock {
                Get-Service -Name "CybereasonActiveProbe" -ErrorAction SilentlyContinue
            }

        if (-not $Service) {
            [PSCustomObject]@{
                Server       = $FQDN
                VMwareStatus = $VMwareStatus
                RemoteStatus = "Reachable"
                Result       = "FAIL"
                Detail       = "ActiveProbe service missing"
            }
        }
        elseif ($Service.Status -eq "Running") {
            [PSCustomObject]@{
                Server       = $FQDN
                VMwareStatus = $VMwareStatus
                RemoteStatus = "Reachable"
                Result       = "PASS"
                Detail       = "Cybereason ActiveProbe running"
            }
        }
        else {
            [PSCustomObject]@{
                Server       = $FQDN
                VMwareStatus = $VMwareStatus
                RemoteStatus = "Reachable"
                Result       = "FAIL"
                Detail       = "ActiveProbe $($Service.Status)"
            }
        }
    }
    catch {
        $msg = $_.Exception.Message
        $RemoteStatus =
            if ($msg -match "Access is denied") { "AccessDenied" }
            elseif ($msg -match "WinRM|WS-Management") { "WinRMUnavailable" }
            else { "Error" }

        [PSCustomObject]@{
            Server       = $FQDN
            VMwareStatus = $VMwareStatus
            RemoteStatus = $RemoteStatus
            Result       = "FAIL"
            Detail       = $msg
        }
    }
}

# =======================
# OUTPUT
# =======================
$Results | Sort-Object VMwareStatus, Result, Server | Format-Table -AutoSize

# Optional export
$Results | Export-Csv ".\Cybereason_VMware_Check.csv" -NoTypeInformation