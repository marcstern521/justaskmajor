# Server readiness check automation: overview

Prepared by Marc Stern, Cloud Systems. October 2026.

## The problem
Every new server comes with a "Systems Production Readiness Check" ticket. Today each one means logging in to the box (RDP for Windows, SSH for Linux), running the check script by hand, reading the output and writing the case note. There were 18 open readiness tickets covering about 45 servers when we started.

## What was built
A single PowerShell runner (`Invoke-ReadinessRun.ps1`) that works from a laptop. It uses the existing check scripts unchanged (`ProdReadinessCheck-Windows.ps1` and `ProdReadinessCheck-Linux.sh`).

1. Reads a queue of tickets and hosts (`readiness-queue.csv`).
2. Looks up each host (DNS, open ports, EC2 details) and picks a route: SSM Run Command, SSH (Linux), WinRM with a domain login (Windows), VMware Tools, or a paste-in bundle as the last resort.
3. Runs the check, collects the CSV results and writes a paste-ready note per ticket: HOLD with the failed items, or OK to close after the manual items.
4. Overnight mode asks for logins once, keeps the laptop awake and runs the whole queue unattended.

It is read-only. It never closes or updates a ticket, never patches or reboots, and stores no passwords.

## Results so far
- First overnight run (Oct 19): 40 queue rows in about 28 minutes. 29 Windows hosts returned full results across three tickets (20 c213 API hosts, 8 of 10 m36 API hosts, and one DWA host).
- After the accepted items (30-day patch cycle, AD/OU lookup owned by SysEng, LogReaderSVC not required for API), no failures remained on those hosts.
- Each ticket's MANUAL items (LogZipper logs, Administrators group, Group Policy, InfraWatch, Cortex console) still need a person.
- Previously this was roughly an hour of hands-on time per ticket.

## What has not been proven yet
- Linux over SSH from the runner has not completed on a real host (the one attempt hit a password refusal and an unaccepted host key).
- SSM Run Command and the VMware Tools route are built but untested against real servers.
- Eleven hosts cannot be reached from the laptop (FedRAMP, UK Sov, lab). They fall back to a paste-in bundle that still needs a person to paste it.

## Security note
On Oct 19 the WinRM activity was blocked by Cortex and raised as INC5487641 (CSOC). The runner sends the check script in a compressed, encoded form and returns results between marker strings, which looks like attacker tooling. It is our own read-only script, run under Marc's account. Before wider use we want CSOC to agree an allow for it or review it, and we plan to switch to a plain, unencoded file copy so it no longer resembles an attack.

## What is needed to go further
1. CSOC review and an allow for the runner.
2. CloudOps approval for `ssm:SendCommand` (read-only use of AWS-RunPowerShellScript and AWS-RunShellScript). This removes RDP from every EC2 ticket.
3. An SSH key or service login for the Linux hosts.
4. Update the Linux script to check Cortex instead of Cybereason.
5. Build the accepted items in as formal waivers so future runs list only real failures.

## Files in this package
- `scripts/Invoke-ReadinessRun.ps1`: the runner
- `scripts/ProdReadinessCheck-Windows.ps1` and `ProdReadinessCheck-Linux.sh`: the existing checks
- `data/readiness-queue.csv`: the ticket and host queue
- `ReadinessAutomation_README.md`: how to run it
- `sample-output/Readiness-Paste-FINAL-20261019.txt`: the output for the three tickets run on Oct 19
