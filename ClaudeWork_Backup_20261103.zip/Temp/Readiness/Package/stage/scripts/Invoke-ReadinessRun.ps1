<#
.SYNOPSIS
    READ-ONLY runner for "Systems Production Readiness Check" tickets (Windows and Linux), driven from your laptop.

.DESCRIPTION
    Takes hosts from the readiness queue (data\readiness-queue.csv) or -Hosts, works out the routes that can reach each
    server, runs the EXISTING check scripts (ProdReadinessCheck-Windows.ps1 / ProdReadinessCheck-Linux.sh, unchanged),
    parses the CSV results and writes a per-ticket summary plus plain-text status you can paste into the ticket.
    It never closes or updates a ServiceNow ticket, never uses -AutoPatch / -AutoReboot, and changes nothing on the servers.

    Routes, tried in this order for each host until one works (-Via picks one route only). Bundle is always the last resort:
      Ssm     EC2 via AWS SSM Run Command. OFF unless -AllowSsm (needs ssm:SendCommand, pending CloudOps approval).
      Ssh     Linux, port 22. ONE ssh connection: sends the script, runs it with sudo, returns the result. With a login
              (Get-Credential / -Credential) it needs no typing: the password goes to ssh through SSH_ASKPASS and to sudo
              through stdin, never on a command line. With -KeyFile or no login given, ssh asks you at the console.
      WinRM   Windows, port 5985/5986. Sends the script to the server and runs it THERE (so the AD lookup and everything
              else is local), using a login for the server's domain (-Credential, or asked once per domain). The Sep 30
              "Access is denied" came from calling remoting with the laptop's own corp identity; a domain login fixes that
              in most cases. Not allowed from the laptop? Falls through.
      VMware  Windows (or Linux with a root login) VM found in a vCenter you list with -VCenters. Uses PowerCLI
              Invoke-VMScript through VMware Tools: no network path to the guest is needed, only vCenter and the ESXi host.
      Bundle  Writes one paste-able command per host. Paste it into an elevated PowerShell (Windows, over RDP) or a shell
              (Linux), copy the single READINESS-RESULT line it prints, then run -ImportResult clipboard.

    -Overnight asks for every login up front, keeps the laptop awake, never stops to ask anything afterwards, runs every
    host, and leaves Readiness-Paste-*.txt (paste-ready status per ticket) in the output folder. Leave the laptop plugged in
    and on the network/VPN.

    AWS facts (read-only describe calls, no SSM): for hosts that are EC2 instances in a signed-in profile the notes also list
    instance type, state, IPv6 address (the checklist wants IPv6 off) and EBS volumes (type, IOPS) for the manual checks.

.PARAMETER Hosts         Explicit hosts (skips the queue). Use -Role for the role.
.PARAMETER Ticket        Only queue rows for these SCTASK numbers.
.PARAMETER Via           Auto (default), Ssh, Ssm, WinRM, VMware, Bundle.
.PARAMETER Plan          Triage only: DNS, ports, EC2 lookup, the route chain per host. Nothing is run.
.PARAMETER Overnight     Unattended run (see above). Logins are asked once at the start.
.PARAMETER Credential    One login to use for every route (otherwise asked per domain / for SSH / for vCenter).
.PARAMETER UserName      SSH username when you want to type the password at the console instead of giving a login.
.PARAMETER DefaultDomain Domain assumed for short Windows hostnames. Default inucn.com.
.PARAMETER VCenters      vCenter servers to search for VMs (enables the VMware route), e.g. eng-vmvce01.in.lab,lax-vmvce01.inucn.com
.PARAMETER AllowSsm      Permit the SSM Run Command route.
.PARAMETER IncludeHold   Also run queue rows marked Hold.
.PARAMETER KeyFile       SSH private key (skips password handling).
.PARAMETER NoAws         Skip the AWS lookups.
.PARAMETER ImportResult  File path or 'clipboard' with READINESS-RESULT line(s) from Bundle runs.
.PARAMETER OutDir        Where files go. Default C:\Temp\Readiness\yyyyMMdd.

.EXAMPLE   .\Invoke-ReadinessRun.ps1 -Plan
.EXAMPLE   .\Invoke-ReadinessRun.ps1 -Overnight
.EXAMPLE   .\Invoke-ReadinessRun.ps1 -Ticket SCTASK0156622 -Via WinRM
.EXAMPLE   .\Invoke-ReadinessRun.ps1 -Overnight -VCenters eng-vmvce01.in.lab,lax-vmvce01.inucn.com
.EXAMPLE   .\Invoke-ReadinessRun.ps1 -ImportResult clipboard
#>
[CmdletBinding()]
param(
    [string[]]$Hosts,
    [string[]]$Ticket,
    [string]$Queue,
    [string]$Role,
    [ValidateSet('Auto', 'Ssh', 'Ssm', 'WinRM', 'VMware', 'Bundle')][string]$Via = 'Auto',
    [switch]$Plan,
    [switch]$Overnight,
    [pscredential]$Credential,
    [string]$UserName,
    [string]$DefaultDomain = 'inucn.com',
    [string[]]$VCenters = @(),
    [switch]$AllowSsm,
    [switch]$IncludeHold,
    [string]$KeyFile,
    [switch]$NoAws,
    [string[]]$AwsProfiles = @('ic-prod', 'ic-dev', 'ic-staging', 'ic-test', 'ic-perf', 'ic-ops', 'uk-sov', 'uk-sov2', 'eu-sov-fra', 'eu-sov-ie', 'au-sov'),
    [string]$ImportResult,
    [string]$OutDir,
    [string]$WindowsScript,
    [string]$LinuxScript,
    [switch]$SimulateRemote   # testing only: run WinRM payloads on this machine instead of remotely
)

$ErrorActionPreference = 'Continue'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$isWin = ($env:OS -eq 'Windows_NT')
if (-not $Queue)         { $Queue = Join-Path (Join-Path (Split-Path -Parent $here) 'data') 'readiness-queue.csv' }
if (-not $WindowsScript) { $WindowsScript = Join-Path $here 'ProdReadinessCheck-Windows.ps1' }
if (-not $LinuxScript)   { $LinuxScript = Join-Path $here 'ProdReadinessCheck-Linux.sh' }
if (-not $OutDir) {
    $base = if ($isWin) { 'C:\Temp\Readiness' } else { Join-Path ([IO.Path]::GetTempPath()) 'Readiness' }
    $OutDir = Join-Path $base (Get-Date -Format 'yyyyMMdd')
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$validRoles = @('COR', 'DWA', 'MED', 'WEB', 'API', 'BIT', 'WFO', 'AGM', 'AGT', 'IVR', 'MEI', 'MEA', 'ASR', 'CDR', 'Other')
$ProfileRegions = @{
    'ic-prod' = @('us-west-2', 'us-east-1'); 'ic-dev' = @('us-west-2', 'us-east-1'); 'ic-staging' = @('us-west-2', 'us-east-1'); 'ic-test' = @('us-west-2', 'us-east-1')
    'ic-perf' = @('us-west-2', 'us-east-1'); 'ic-ops' = @('us-west-2', 'us-east-1'); 'uk-sov' = @('eu-west-2'); 'uk-sov2' = @('eu-west-2')
    'eu-sov-fra' = @('eu-central-1'); 'eu-sov-ie' = @('eu-west-1'); 'au-sov' = @('ap-southeast-2')
}
$script:noPrompt = [bool]$Overnight
$script:cred = @{}
$script:ec2 = @{}
$script:vi = @{}
$script:awsOk = $null
$script:sshUser = $UserName
if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }

# ----------------------------------------------------------------------------------------------- helpers
function ConvertTo-Gz64 {
    param([string]$Text)
    $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
    $ms = New-Object IO.MemoryStream
    $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Compress)
    $gz.Write($bytes, 0, $bytes.Length); $gz.Close()
    [Convert]::ToBase64String($ms.ToArray())
}
function ConvertFrom-Gz64 {
    param([string]$B64)
    $ms = New-Object IO.MemoryStream(, [Convert]::FromBase64String(($B64 -replace '\s', '')))
    $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Decompress)
    (New-Object IO.StreamReader($gz, [Text.Encoding]::UTF8)).ReadToEnd()
}
function Read-ScriptText {
    param([string]$Path, [switch]$Unix)
    $t = [IO.File]::ReadAllText($Path).TrimStart([char]0xFEFF)
    if ($Unix) { $t = $t -replace "`r`n", "`n" }
    $t
}
function Test-Port {
    param([string]$Address, [int]$Port, [int]$Ms = 1500)
    $c = New-Object Net.Sockets.TcpClient
    try { $a = $c.BeginConnect($Address, $Port, $null, $null); return ($a.AsyncWaitHandle.WaitOne($Ms) -and $c.Connected) } catch { return $false } finally { $c.Close() }
}
function Write-Log { param([string]$Msg) Add-Content -LiteralPath (Join-Path $OutDir '_run-log.txt') -Value ("{0} {1}" -f (Get-Date -Format 's'), $Msg) }
function Get-Counts {
    param($Rows)
    $r = @($Rows)
    [pscustomobject]@{
        Pass   = @($r | Where-Object { $_.Status -eq 'PASS' }).Count
        Fail   = @($r | Where-Object { $_.Status -eq 'FAIL' }).Count
        Manual = @($r | Where-Object { $_.Status -eq 'MANUAL' }).Count
        Skip   = @($r | Where-Object { $_.Status -eq 'SKIP' }).Count
    }
}
function Get-CsvText { param([string]$Text) @($Text | ConvertFrom-Csv) }
function Get-Short { param([string]$H) ($H -split '\.')[0] }
function Get-Role {
    param($W)
    $r = $W.Role; if (-not $r) { $r = 'Other' }
    if ($validRoles -notcontains $r) { Write-Warning "Role '$r' is not valid for the Windows script; using Other."; $r = 'Other' }
    $r
}

# logins: asked once per key (domain, ssh, vcenter), never typed on a command line, never written to disk by this script
function Get-LoginCred {
    param([string]$Key, [string]$Message)
    if ($Credential) { return $Credential }
    if ($script:cred.ContainsKey($Key)) { return $script:cred[$Key] }
    if ($script:noPrompt) { return $null }
    $c = $null
    try { $c = Get-Credential -Message $Message } catch {}
    $script:cred[$Key] = $c
    $c
}
function Get-DomainKey {
    param($W)
    if ($W.Host -match '\.(.+)$') { return $Matches[1].ToLower() }
    $DefaultDomain.ToLower()
}

# ----------------------------------------------------------------------------------------------- work items
function Get-WorkItems {
    $items = New-Object System.Collections.Generic.List[object]
    if ($Hosts) {
        foreach ($h in $Hosts) {
            $items.Add([pscustomobject]@{ Ticket = ($Ticket | Select-Object -First 1); RITM = ''; Host = $h.Trim(); Role = $(if ($Role) { $Role } else { 'Other' }); OS = ''; FedRAMP = ''; ClusterSide = ''; Hold = ''; Notes = '' })
        }
        return $items
    }
    if (-not (Test-Path -LiteralPath $Queue)) { throw "Queue file not found: $Queue  (use -Hosts, or create the queue CSV: Ticket,RITM,Host,Role,OS,FedRAMP,ClusterSide,Hold,Notes)" }
    foreach ($r in (Import-Csv -LiteralPath $Queue)) {
        if ($Ticket -and ($Ticket -notcontains $r.Ticket)) { continue }
        $items.Add($r)
    }
    $items
}

# ----------------------------------------------------------------------------------------------- AWS (read-only describe calls)
function Initialize-Aws {
    if ($null -ne $script:awsOk) { return }
    $script:awsOk = New-Object System.Collections.Generic.List[string]
    if ($NoAws) { return }
    if (-not (Get-Command aws -ErrorAction SilentlyContinue)) { Write-Host '   [aws] CLI not found: EC2 lookups skipped.' -ForegroundColor DarkYellow; return }
    foreach ($p in $AwsProfiles) {
        $null = & aws sts get-caller-identity --profile $p --output json 2>&1
        if ($LASTEXITCODE -eq 0) { $script:awsOk.Add($p) } else { Write-Host "   [aws] $p not signed in (.\Connect-AwsSso.ps1 -Profiles $p): skipped" -ForegroundColor DarkYellow }
    }
}
function Initialize-Ec2Inventory {
    param([string[]]$Names)
    Initialize-Aws
    if (-not $script:awsOk.Count) { return }
    $vals = (@($Names | ForEach-Object { $_.ToLower(); $_.ToUpper() }) | Select-Object -Unique) -join ','
    $q = "Reservations[].Instances[].{Id:InstanceId,Name:Tags[?Key=='Name']|[0].Value,Type:InstanceType,State:State.Name,Ip:PrivateIpAddress,V6:NetworkInterfaces[].Ipv6Addresses[].Ipv6Address,Platform:PlatformDetails}"
    foreach ($p in $script:awsOk) {
        foreach ($r in $ProfileRegions[$p]) {
            try {
                $txt = (& aws ec2 describe-instances --profile $p --region $r --filters "Name=tag:Name,Values=$vals" --query $q --output json 2>$null | Out-String)
                if ($LASTEXITCODE -ne 0 -or -not $txt.Trim()) { continue }
                foreach ($i in @($txt | ConvertFrom-Json)) {
                    if (-not $i -or -not $i.Name) { continue }
                    $k = (Get-Short $i.Name).ToLower()
                    if ($script:ec2.ContainsKey($k) -and $script:ec2[$k].State -eq 'running') { continue }
                    $script:ec2[$k] = [pscustomobject]@{ Profile = $p; Region = $r; InstanceId = $i.Id; Name = $i.Name; Type = $i.Type; State = $i.State; Ip = $i.Ip; V6 = @($i.V6 | Where-Object { $_ }); Platform = $(if ("$($i.Platform)" -match 'Windows') { 'Windows' } else { 'Linux' }); Vols = @() }
                }
            } catch {}
        }
    }
    foreach ($grp in ($script:ec2.Values | Group-Object { "$($_.Profile)|$($_.Region)" })) {
        $p, $r = $grp.Name -split '\|'
        $ids = ($grp.Group | ForEach-Object { $_.InstanceId }) -join ','
        try {
            $vq = 'Volumes[].{Inst:Attachments[0].InstanceId,Type:VolumeType,Size:Size,Iops:Iops,Tput:Throughput}'
            $vt = (& aws ec2 describe-volumes --profile $p --region $r --filters "Name=attachment.instance-id,Values=$ids" --query $vq --output json 2>$null | Out-String)
            if ($LASTEXITCODE -eq 0 -and $vt.Trim()) {
                foreach ($v in @($vt | ConvertFrom-Json)) {
                    $inst = $grp.Group | Where-Object { $_.InstanceId -eq $v.Inst } | Select-Object -First 1
                    if ($inst) { $inst.Vols += ("{0} GB {1} {2} IOPS{3}" -f $v.Size, $v.Type, $v.Iops, $(if ($v.Tput) { " $($v.Tput) MB/s" } else { '' })) }
                }
            }
        } catch {}
    }
}
function Get-FactsText {
    param($W)
    $i = $script:ec2[(Get-Short $W.Host).ToLower()]
    if (-not $i) { return '' }
    $v6 = if ($i.V6.Count) { "IPv6 PRESENT ($($i.V6 -join ', ')) - checklist wants IPv6 off" } else { 'no IPv6 address' }
    "EC2 $($i.InstanceId) ($($i.Profile)/$($i.Region)): $($i.Type), $($i.State), $($i.Ip), $v6; volumes: $(if ($i.Vols.Count) { $i.Vols -join '; ' } else { 'n/a' })"
}

# ----------------------------------------------------------------------------------------------- triage
function Get-Triage {
    param($W)
    $short = Get-Short $W.Host
    $ip = ''
    try { $ip = ([Net.Dns]::GetHostAddresses($W.Host) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1).IPAddressToString } catch {}
    $open = @()
    if ($ip) { foreach ($p in 22, 445, 3389, 5985, 5986) { if (Test-Port $ip $p) { $open += $p } } }
    $inst = $script:ec2[$short.ToLower()]
    $os = $W.OS
    if (-not $os) {
        if ($open -contains 3389 -or $open -contains 5985 -or $open -contains 5986 -or $open -contains 445) { $os = 'Windows' }
        elseif ($open -contains 22) { $os = 'Linux' }
        elseif ($inst) { $os = $inst.Platform }
    }
    $ssmOnline = $false
    if ($AllowSsm -and $inst -and $inst.State -eq 'running') {
        $ping = (& aws ssm describe-instance-information --profile $inst.Profile --region $inst.Region --filters "Key=InstanceIds,Values=$($inst.InstanceId)" --query 'InstanceInformationList[0].PingStatus' --output text 2>$null | Out-String).Trim()
        $ssmOnline = ($ping -eq 'Online')
    }
    $routes = New-Object System.Collections.Generic.List[string]
    if ($Via -ne 'Auto') { $routes.Add($Via) }
    else {
        if ($AllowSsm -and $ssmOnline) { $routes.Add('Ssm') }
        if ($os -eq 'Linux' -and ($open -contains 22 -or $SimulateRemote)) { $routes.Add('Ssh') }
        if ($os -ne 'Linux' -and ($open -contains 5985 -or $open -contains 5986 -or $SimulateRemote)) { $routes.Add('WinRM') }
        if ($VCenters.Count) { $routes.Add('VMware') }
    }
    if ($routes -notcontains 'Bundle') { $routes.Add('Bundle') }
    $why = @()
    if (-not $ip) { $why += 'DNS did not resolve from here' }
    if ($AllowSsm -and $inst -and -not $ssmOnline) { $why += 'EC2 found, SSM not online' }
    if ($inst) { $why += "EC2 $($inst.InstanceId)" }
    [pscustomobject]@{ Short = $short; Ip = $ip; Open = ($open -join ' '); OS = $os; Routes = @($routes); Chain = ($routes -join ' > '); Why = ($why -join '; '); Instance = $inst }
}

# ----------------------------------------------------------------------------------------------- payloads
function Get-WinArgs {
    param($W)
    $a = "-ComputerName `$env:COMPUTERNAME -Role '$(Get-Role $W)' -RequestedName '$(Get-Short $W.Host)'"
    if ($W.FedRAMP -match '^(y|yes|true|1)$') { $a += ' -FedRAMP' }
    if ($W.ClusterSide -match '^[AB]$') { $a += " -ClusterSide $($W.ClusterSide)" }
    $a
}
function Get-WinPayloadLines {
    param($W, [switch]$ForBundle)
    $b64 = ConvertTo-Gz64 (Read-ScriptText $WindowsScript)
    $argText = Get-WinArgs $W
    $l = New-Object System.Collections.Generic.List[string]
    $l.Add("`$ErrorActionPreference = 'Stop'")
    $l.Add("`$b = '$b64'")
    $l.Add('$ms = New-Object IO.MemoryStream(,[Convert]::FromBase64String($b))')
    $l.Add('$gz = New-Object IO.Compression.GZipStream($ms,[IO.Compression.CompressionMode]::Decompress)')
    $l.Add('$sb = [scriptblock]::Create((New-Object IO.StreamReader($gz,[Text.Encoding]::UTF8)).ReadToEnd())')
    $l.Add("`$csv = Join-Path `$env:TEMP 'prc-result.csv'")
    if ($ForBundle) { $l.Add("& `$sb $argText -OutCsv `$csv") } else { $l.Add("& `$sb $argText -OutCsv `$csv *> `$null") }
    $l.Add('$raw = [IO.File]::ReadAllText($csv)')
    $l.Add('$o = New-Object IO.MemoryStream; $g = New-Object IO.Compression.GZipStream($o,[IO.Compression.CompressionMode]::Compress); $by = [Text.Encoding]::UTF8.GetBytes($raw); $g.Write($by,0,$by.Length); $g.Close()')
    if ($ForBundle) {
        $l.Add("Write-Host ('READINESS-RESULT|$($W.Ticket)|$($W.Host)|Windows|' + [Convert]::ToBase64String(`$o.ToArray()) + '|END')")
    } else {
        $l.Add("Write-Output ('@@CSVGZ@@' + [Convert]::ToBase64String(`$o.ToArray()) + '@@END@@')")
    }
    $l.Add('Remove-Item $csv -Force -ErrorAction SilentlyContinue')
    $l
}
# One self-contained shell script meant to be run AS ROOT (sudo bash, or SSM/VMware as root).
function Get-LinuxWrapperText {
    param($W, [switch]$ForBundle)
    $b64 = ConvertTo-Gz64 (Read-ScriptText $LinuxScript -Unix)
    $r = ($W.Role -replace '[^A-Za-z0-9_.-]', ''); if (-not $r) { $r = 'Other' }
    $emit = if ($ForBundle) { "echo `"READINESS-RESULT|$($W.Ticket)|$($W.Host)|Linux|`$(gzip -c `"`$d/r.csv`" | base64 -w0)|END`"" } else { 'echo "@@CSVGZ@@$(gzip -c "$d/r.csv" | base64 -w0)@@END@@"' }
    $lines = @(
        'd=$(mktemp -d)'
        'trap ''rm -rf "$d"'' EXIT'
        "echo '$b64' | base64 -d | gunzip > `"`$d/s.sh`""
        "bash `"`$d/s.sh`" -r '$r' -o `"`$d/r.csv`" > /dev/null 2>&1 < /dev/null"
        $emit
    )
    ($lines -join "`n") + "`n"
}

# ----------------------------------------------------------------------------------------------- routes
function Invoke-ViaSsm {
    param($W, $T)
    $inst = $T.Instance
    if (-not $inst) { return @{ Ok = $false; Error = 'no EC2 instance resolved' } }
    $doc = if ($T.OS -eq 'Windows') { 'AWS-RunPowerShellScript' } else { 'AWS-RunShellScript' }
    $lines = if ($T.OS -eq 'Windows') { @(Get-WinPayloadLines $W) } else { @((Get-LinuxWrapperText $W) -split "`n" | Where-Object { $_ -ne '' }) }
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ("ssm-" + [guid]::NewGuid().ToString('N') + '.json')
    @{ commands = @($lines) } | ConvertTo-Json -Compress | Set-Content -LiteralPath $tmp -Encoding ASCII
    try {
        $cmdId = (& aws ssm send-command --profile $inst.Profile --region $inst.Region --document-name $doc --instance-ids $inst.InstanceId --parameters "file://$tmp" `
                --comment "Read-only production readiness check $($W.Ticket)" --timeout-seconds 900 --query 'Command.CommandId' --output text 2>&1 | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) {
            $why = if ($cmdId -match 'AccessDenied|not authorized') { 'ssm:SendCommand not permitted for this role (pending CloudOps approval?)' } else { $cmdId }
            return @{ Ok = $false; Error = $why }
        }
        Write-Host "   SSM command $cmdId sent to $($inst.InstanceId); waiting..." -ForegroundColor DarkGray
        $deadline = (Get-Date).AddMinutes(12)
        do {
            Start-Sleep -Seconds 5
            $j = (& aws ssm get-command-invocation --profile $inst.Profile --region $inst.Region --command-id $cmdId --instance-id $inst.InstanceId --output json 2>$null | Out-String)
            $inv = $null; if ($j.Trim()) { try { $inv = $j | ConvertFrom-Json } catch {} }
        } while ((-not $inv -or $inv.Status -in 'Pending', 'InProgress', 'Delayed') -and (Get-Date) -lt $deadline)
        if (-not $inv -or $inv.Status -ne 'Success') { return @{ Ok = $false; Error = "SSM status: $(if ($inv) { $inv.Status } else { 'unknown' })" } }
        if ($inv.StandardOutputContent -match '@@CSVGZ@@([A-Za-z0-9+/=\s]+)@@END@@') { return @{ Ok = $true; Csv = (ConvertFrom-Gz64 $Matches[1]) } }
        return @{ Ok = $false; Error = 'SSM finished but no result block in output' }
    } finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
}

function Invoke-ViaWinRM {
    param($W, $T)
    $domain = Get-DomainKey $W
    $cred = Get-LoginCred "win:$domain" "Windows login for $domain (for example $($domain.Split('.')[0].ToUpper())\your.name). Used for WinRM; cancel to use the laptop's own login."
    $target = $W.Host
    if ($target -notmatch '\.') { $target = "$target.$domain" }
    $text = ''
    $errA = ''
    # Method A: the whole check as one in-memory scriptblock
    try {
        $sb = [scriptblock]::Create((@(Get-WinPayloadLines $W) -join "`n"))
        if ($SimulateRemote) { $text = (& $sb | Out-String) }
        else {
            $so = New-PSSessionOption -OpenTimeout 30000 -OperationTimeout 480000
            $icm = @{ ComputerName = $target; ScriptBlock = $sb; SessionOption = $so; ErrorAction = 'Stop' }
            if ($cred) { $icm.Credential = $cred }
            if ($T.Open -match '5986' -and $T.Open -notmatch '5985') { $icm.UseSSL = $true }
            $text = (Invoke-Command @icm | Out-String)
        }
        if ($text -match '@@CSVGZ@@([A-Za-z0-9+/=\s]+)@@END@@') { return @{ Ok = $true; Csv = (ConvertFrom-Gz64 $Matches[1]) } }
        $errA = 'ran but returned no result block'
    } catch {
        $m = $_.Exception.Message
        $errA = if ($m -match 'Access is denied') { 'refused the login (that account is not an admin there, or wrong domain)' }
        elseif ($m -match 'TrustedHosts') { 'needs the server in this laptop''s WinRM TrustedHosts list, or use the FQDN with Kerberos' }
        else { ($m -split "`n")[0] }
        if ($m -match 'Access is denied|TrustedHosts|cannot connect|The client cannot|timed out') { return @{ Ok = $false; Error = "WinRM $errA" } }
    }
    if ($SimulateRemote) { return @{ Ok = $false; Error = "WinRM $errA" } }
    # Method B (login worked but the one-shot scriptblock failed, e.g. "WSMan provider host process did not return a proper response"):
    # copy the script to the server's temp folder over the session, run it there, copy the CSV back, delete both.
    $sess = $null
    try {
        $so = New-PSSessionOption -OpenTimeout 30000 -OperationTimeout 480000
        $ns = @{ ComputerName = $target; SessionOption = $so; ErrorAction = 'Stop' }
        if ($cred) { $ns.Credential = $cred }
        if ($T.Open -match '5986' -and $T.Open -notmatch '5985') { $ns.UseSSL = $true }
        $sess = New-PSSession @ns
        $tag = [guid]::NewGuid().ToString('N').Substring(0, 8)
        $remoteInfo = Invoke-Command -Session $sess -ScriptBlock { [pscustomobject]@{ Temp = $env:TEMP; Name = $env:COMPUTERNAME; Mode = "$($ExecutionContext.SessionState.LanguageMode)" } }
        $rs = Join-Path $remoteInfo.Temp "prc-$tag.ps1"
        $rc = Join-Path $remoteInfo.Temp "prc-$tag.csv"
        $local = Join-Path ([IO.Path]::GetTempPath()) "prc-$tag.ps1"
        [IO.File]::WriteAllText($local, (Read-ScriptText $WindowsScript), (New-Object Text.UTF8Encoding($true)))
        Copy-Item -LiteralPath $local -Destination $rs -ToSession $sess -ErrorAction Stop
        Remove-Item -LiteralPath $local -Force -ErrorAction SilentlyContinue
        $argLine = Get-WinArgs $W
        $runner = [scriptblock]::Create("`$ErrorActionPreference='Continue'; & '$rs' $argLine -OutCsv '$rc' *> `$null; Test-Path '$rc'")
        $ok = Invoke-Command -Session $sess -ScriptBlock $runner
        if ($ok -contains $true) {
            $localCsv = Join-Path ([IO.Path]::GetTempPath()) "prc-$tag.csv"
            Copy-Item -FromSession $sess -Path $rc -Destination $localCsv -ErrorAction Stop
            $csvText = [IO.File]::ReadAllText($localCsv); Remove-Item -LiteralPath $localCsv -Force -ErrorAction SilentlyContinue
            Invoke-Command -Session $sess -ScriptBlock ([scriptblock]::Create("Remove-Item '$rs','$rc' -Force -ErrorAction SilentlyContinue"))
            if ($csvText.Trim()) { return @{ Ok = $true; Csv = $csvText } }
        }
        try { Invoke-Command -Session $sess -ScriptBlock ([scriptblock]::Create("Remove-Item '$rs','$rc' -Force -ErrorAction SilentlyContinue")) } catch {}
        return @{ Ok = $false; Error = "WinRM login worked (language mode $($remoteInfo.Mode)) but the check produced no CSV. Method A: $errA" }
    } catch {
        return @{ Ok = $false; Error = "WinRM login worked but both methods failed. A: $errA | B: $(($_.Exception.Message -split "`n")[0])" }
    } finally { if ($sess) { Remove-PSSession $sess -ErrorAction SilentlyContinue } }
}

function Invoke-ViaVmware {
    param($W, $T)
    if (-not $VCenters.Count) { return @{ Ok = $false; Error = 'no vCenters given (-VCenters)' } }
    if (-not (Get-Module -ListAvailable -Name VMware.VimAutomation.Core)) { return @{ Ok = $false; Error = 'VMware PowerCLI not installed' } }
    try {
        Import-Module VMware.VimAutomation.Core -ErrorAction Stop
        $null = Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false -ParticipateInCEIP $false
    } catch { return @{ Ok = $false; Error = "PowerCLI load failed: $($_.Exception.Message)" } }
    $vm = $null
    foreach ($vc in $VCenters) {
        if (-not $script:vi.ContainsKey($vc)) {
            $c = Get-LoginCred "vc:$vc" "vCenter login for $vc"
            if (-not $c) { $script:vi[$vc] = $null; continue }
            try { $script:vi[$vc] = Connect-VIServer -Server $vc -Credential $c -ErrorAction Stop } catch { Write-Host "   vCenter $vc : $($_.Exception.Message)" -ForegroundColor DarkYellow; $script:vi[$vc] = $null }
        }
        if (-not $script:vi[$vc]) { continue }
        $vm = Get-VM -Name $T.Short -Server $script:vi[$vc] -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($vm) { break }
    }
    if (-not $vm) { return @{ Ok = $false; Error = 'VM not found in the listed vCenters' } }
    if ($vm.PowerState -ne 'PoweredOn') { return @{ Ok = $false; Error = "VM is $($vm.PowerState)" } }
    if ("$($vm.ExtensionData.Guest.ToolsRunningStatus)" -ne 'guestToolsRunning') { return @{ Ok = $false; Error = 'VMware Tools not running in the guest' } }
    $domain = Get-DomainKey $W
    $gc = Get-LoginCred "guest:$domain" "Guest OS login for $($T.Short) (admin in $domain, or local admin / root). Used by VMware Tools."
    if (-not $gc) { return @{ Ok = $false; Error = 'no guest login supplied' } }
    $isLinuxGuest = ("$($vm.Guest.OSFullName)" -match 'Linux|Red Hat|CentOS|Ubuntu|SUSE|Amazon') -or $T.OS -eq 'Linux'
    try {
        if ($isLinuxGuest) { $r = Invoke-VMScript -VM $vm -ScriptText (Get-LinuxWrapperText $W) -ScriptType Bash -GuestCredential $gc -ErrorAction Stop }
        else { $r = Invoke-VMScript -VM $vm -ScriptText ((@(Get-WinPayloadLines $W)) -join "`n") -ScriptType PowerShell -GuestCredential $gc -ErrorAction Stop }
    } catch { return @{ Ok = $false; Error = "Invoke-VMScript: $(($_.Exception.Message -split "`n")[0])" } }
    if ("$($r.ScriptOutput)" -match '@@CSVGZ@@([A-Za-z0-9+/=\s]+)@@END@@') { return @{ Ok = $true; Csv = (ConvertFrom-Gz64 $Matches[1]) } }
    @{ Ok = $false; Error = 'VMware script ran but returned no result block' }
}

function Invoke-ViaSsh {
    param($W, $T)
    $b64 = ConvertTo-Gz64 (Get-LinuxWrapperText $W)
    $tag = [guid]::NewGuid().ToString('N').Substring(0, 8)
    $c = $null
    if (-not $KeyFile) { $c = Get-LoginCred 'ssh' 'SSH login for the Linux hosts (user and password; the password is used for ssh and sudo). Cancel to type passwords at the console instead.' }
    $user = $null
    if ($c) { $user = $c.UserName } else {
        if ($script:noPrompt -and -not $script:sshUser) { return @{ Ok = $false; Error = 'no SSH login supplied' } }
        if (-not $script:sshUser) { $script:sshUser = Read-Host 'SSH username' }
        $user = $script:sshUser
    }
    $target = "$user@$($W.Host)"
    $opts = @('-o', 'ConnectTimeout=20')
    if ($KeyFile) { $opts += @('-i', "`"$KeyFile`"") }
    if (-not $c) {
        # interactive: ssh and sudo ask you at the console; the result is read back with a second connection
        $remoteI = "umask 077; echo '$b64' | base64 -d | gunzip > ~/.prc-$tag.sh; sudo bash ~/.prc-$tag.sh > ~/.prc-$tag.out; rm -f ~/.prc-$tag.sh"
        $a = ((@('-tt') + $opts + @($target, "`"$remoteI`"")) -join ' ')
        $p = Start-Process -FilePath 'ssh' -ArgumentList $a -NoNewWindow -Wait -PassThru
        if ($p.ExitCode -ne 0) { return @{ Ok = $false; Error = "ssh failed (exit $($p.ExitCode))" } }
        $o = & ssh @opts $target "cat ~/.prc-$tag.out; rm -f ~/.prc-$tag.out"
        if ("$($o -join "`n")" -match '@@CSVGZ@@([A-Za-z0-9+/=\s]+)@@END@@') { return @{ Ok = $true; Csv = (ConvertFrom-Gz64 $Matches[1]) } }
        return @{ Ok = $false; Error = 'no result block came back' }
    }
    # unattended: one connection. Password to ssh via SSH_ASKPASS (OpenSSH 8.4+), to sudo via stdin. Nothing is typed, nothing is on a command line.
    $remote = "umask 077; echo '$b64' | base64 -d | gunzip > ~/.prc-$tag.sh; sudo -S -p '' bash ~/.prc-$tag.sh; rm -f ~/.prc-$tag.sh"
    $helperPs = Join-Path ([IO.Path]::GetTempPath()) "readiness-askpass-$tag.ps1"
    $helperCmd = Join-Path ([IO.Path]::GetTempPath()) "readiness-askpass-$tag.cmd"
    Set-Content -LiteralPath $helperPs -Encoding ASCII -Value 'param($Prompt) if ($Prompt -match "continue connecting|fingerprint") { Write-Output "no" } else { [Console]::Out.Write($env:READINESS_PW) }'
    if ($isWin) { Set-Content -LiteralPath $helperCmd -Encoding ASCII -Value "@powershell -NoProfile -ExecutionPolicy Bypass -File `"$helperPs`" %*" }
    else { Set-Content -LiteralPath $helperCmd -Encoding ASCII -Value "#!/bin/sh`npwsh -NoProfile -File `"$helperPs`" `"`$@`""; & chmod +x $helperCmd }
    $pw = $null
    try {
        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = 'ssh'
        $psi.Arguments = ((@('-o', 'NumberOfPasswordPrompts=1') + $opts + @($target, "`"$remote`"")) -join ' ')
        $psi.UseShellExecute = $false; $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true
        $pw = $c.GetNetworkCredential().Password
        $psi.EnvironmentVariables['SSH_ASKPASS'] = $helperCmd
        $psi.EnvironmentVariables['SSH_ASKPASS_REQUIRE'] = 'force'
        if (-not $psi.EnvironmentVariables.ContainsKey('DISPLAY')) { $psi.EnvironmentVariables['DISPLAY'] = 'readiness:0' }
        $psi.EnvironmentVariables['READINESS_PW'] = $pw
        $proc = New-Object Diagnostics.Process; $proc.StartInfo = $psi
        $null = $proc.Start()
        $outTask = $proc.StandardOutput.ReadToEndAsync(); $errTask = $proc.StandardError.ReadToEndAsync()
        $proc.StandardInput.Write($pw + "`n"); $proc.StandardInput.Close()
        if (-not $proc.WaitForExit(480000)) { try { $proc.Kill() } catch {}; return @{ Ok = $false; Error = 'ssh timed out after 8 minutes' } }
        $so = $outTask.Result; $se = $errTask.Result
        if ($so -match '@@CSVGZ@@([A-Za-z0-9+/=\s]+)@@END@@') { return @{ Ok = $true; Csv = (ConvertFrom-Gz64 $Matches[1]) } }
        $why = if ($se -match 'Host key verification failed|continue connecting') { 'unknown host key: connect once with ssh to accept it, then rerun' }
        elseif ($se -match 'Permission denied') { 'login refused (wrong password for this host?)' }
        elseif ($se -match 'sudo') { 'sudo refused: ' + (($se -split "`n")[0]) }
        else { (($se -split "`n" | Where-Object { $_.Trim() } | Select-Object -First 1)) }
        return @{ Ok = $false; Error = "ssh: $why" }
    } finally {
        Remove-Item -LiteralPath $helperPs, $helperCmd -Force -ErrorAction SilentlyContinue
        $pw = $null
    }
}

function New-Bundle {
    param($W, $T)
    $os = if ($T.OS) { $T.OS } else { 'Windows' }
    $file = Join-Path $OutDir ((Get-Short $W.Host) + '-paste.txt')
    if ($os -eq 'Linux') {
        $b64 = ConvertTo-Gz64 (Get-LinuxWrapperText $W -ForBundle)
        $body = "echo '$b64' | base64 -d | gunzip | sudo bash"
        $how = "Paste into a shell on $($W.Host) (needs sudo). It prints one READINESS-RESULT line."
    } else {
        $body = (@(Get-WinPayloadLines $W -ForBundle)) -join '; '
        $how = "Paste into an ELEVATED PowerShell on $($W.Host) (RDP). It prints the normal report, then one READINESS-RESULT line."
    }
    Set-Content -LiteralPath $file -Value "# $how`r`n# Then copy that READINESS-RESULT line to your laptop clipboard and run:  .\Invoke-ReadinessRun.ps1 -ImportResult clipboard`r`n$body`r`n" -Encoding UTF8
    $file
}

# ----------------------------------------------------------------------------------------------- results
$summary = New-Object System.Collections.Generic.List[object]
$detail = @{}
function Add-Outcome {
    param($W, [string]$OS, [string]$Route, [string]$CsvText, [string]$Err, [string]$Extra)
    $short = Get-Short $W.Host
    $rows = @(); $csvPath = ''
    if ($CsvText) {
        $rows = Get-CsvText $CsvText
        $csvPath = Join-Path $OutDir "$short-readiness.csv"
        Set-Content -LiteralPath $csvPath -Value $CsvText -Encoding UTF8
        $detail[$W.Host] = $rows
    }
    $c = Get-Counts $rows
    $summary.Add([pscustomobject]@{
            Ticket = $W.Ticket; RITM = $W.RITM; Host = $W.Host; OS = $OS; Role = $W.Role; Route = $Route
            Pass = $(if ($rows.Count) { $c.Pass } else { '-' }); Fail = $(if ($rows.Count) { $c.Fail } else { '-' })
            Manual = $(if ($rows.Count) { $c.Manual } else { '-' }); Skip = $(if ($rows.Count) { $c.Skip } else { '-' })
            Csv = $csvPath; Error = $Err; Notes = $Extra; Facts = (Get-FactsText $W)
        })
    Write-Log "$($W.Ticket) $($W.Host) route=$Route pass=$($c.Pass) fail=$($c.Fail) manual=$($c.Manual) err=$Err"
}

# ----------------------------------------------------------------------------------------------- import mode
if ($ImportResult) {
    $raw = if ($ImportResult -eq 'clipboard') { (Get-Clipboard -Raw) } else { [IO.File]::ReadAllText($ImportResult) }
    $ms = [regex]::Matches([string]$raw, 'READINESS-RESULT\|([^|]*)\|([^|]*)\|([^|]*)\|([A-Za-z0-9+/=\s]+?)\|END')
    if (-not $ms.Count) { Write-Host 'No READINESS-RESULT line found in that text. Copy the whole line, ending in |END.' -ForegroundColor Red; return }
    foreach ($m in $ms) {
        $w = [pscustomobject]@{ Ticket = $m.Groups[1].Value; RITM = ''; Host = $m.Groups[2].Value; Role = ''; OS = $m.Groups[3].Value }
        if (Test-Path -LiteralPath $Queue) {
            $q = Import-Csv -LiteralPath $Queue | Where-Object { $_.Host -eq $w.Host -and $_.Ticket -eq $w.Ticket } | Select-Object -First 1
            if ($q) { $w = $q }
        }
        try { Add-Outcome -W $w -OS $m.Groups[3].Value -Route 'Bundle' -CsvText (ConvertFrom-Gz64 $m.Groups[4].Value) -Err '' -Extra 'imported' }
        catch { Add-Outcome -W $w -OS $m.Groups[3].Value -Route 'Bundle' -CsvText '' -Err "could not decode result: $($_.Exception.Message)" -Extra '' }
    }
}
else {
    # ------------------------------------------------------------------------------------------- main
    $items = @(Get-WorkItems)
    if (-not $items.Count) { Write-Host 'Nothing to do (queue empty or no ticket matched).' -ForegroundColor Yellow; return }
    Write-Host ("Readiness run {0}: {1} queue row(s), mode={2}, via={3}, SSM={4}, vCenters={5}" -f $stamp, $items.Count, $(if ($Plan) { 'PLAN (nothing is run)' } elseif ($Overnight) { 'OVERNIGHT' } else { 'RUN' }), $Via, $(if ($AllowSsm) { 'allowed' } else { 'off' }), $VCenters.Count) -ForegroundColor Cyan

    $runnable = New-Object System.Collections.Generic.List[object]
    $triage = New-Object System.Collections.Generic.List[object]
    foreach ($w in $items) {
        if (-not $w.Host) { $triage.Add([pscustomobject]@{ Ticket = $w.Ticket; Host = '(none)'; OS = ''; Ip = ''; Open = ''; Route = 'HOLD'; Why = $(if ($w.Hold) { $w.Hold } else { 'no host in queue' }) }); continue }
        if ($w.Hold -and -not $IncludeHold -and -not $Hosts) { $triage.Add([pscustomobject]@{ Ticket = $w.Ticket; Host = $w.Host; OS = ''; Ip = ''; Open = ''; Route = 'HOLD'; Why = $w.Hold }); continue }
        $runnable.Add($w)
    }
    if ($runnable.Count) {
        Write-Host 'Looking up EC2 instances (read-only)...' -ForegroundColor DarkGray
        Initialize-Ec2Inventory -Names @($runnable | ForEach-Object { Get-Short $_.Host })
    }
    $tri = @{}
    foreach ($w in $runnable) {
        $t = Get-Triage $w
        $tri[$w.Host] = $t
        $triage.Add([pscustomobject]@{ Ticket = $w.Ticket; Host = $w.Host; OS = $t.OS; Ip = $t.Ip; Open = $t.Open; Route = $t.Chain; Why = $t.Why })
    }
    Write-Host ""; Write-Host '=== Triage ===' -ForegroundColor Cyan
    ($triage | Format-Table Ticket, Host, OS, Ip, Open, Route, Why -AutoSize -Wrap | Out-String -Width 230) | Write-Host
    if ($Plan) { $triage | Export-Csv -LiteralPath (Join-Path $OutDir "Readiness-Plan-$stamp.csv") -NoTypeInformation; Write-Host "Plan saved: $(Join-Path $OutDir "Readiness-Plan-$stamp.csv")" -ForegroundColor Green; return }

    # ---- overnight: every login up front, then no more questions
    $keepAwake = $false
    if ($Overnight) {
        Write-Host 'OVERNIGHT: asking for every login now. After this nothing will stop to ask.' -ForegroundColor Yellow
        $script:noPrompt = $false
        $needWin = @($runnable | Where-Object { $tri[$_.Host].Routes -contains 'WinRM' } | ForEach-Object { Get-DomainKey $_ } | Select-Object -Unique)
        foreach ($d in $needWin) { $null = Get-LoginCred "win:$d" "Windows login for $d (for example $($d.Split('.')[0].ToUpper())\your.name). Used for WinRM; cancel to use the laptop's own login." }
        if (-not $KeyFile -and @($runnable | Where-Object { $tri[$_.Host].Routes -contains 'Ssh' }).Count) { $null = Get-LoginCred 'ssh' 'SSH login for the Linux hosts (user and password; used for ssh and sudo). Cancel to skip Linux tonight.' }
        foreach ($vc in $VCenters) { $null = Get-LoginCred "vc:$vc" "vCenter login for $vc (cancel to skip)" }
        if ($VCenters.Count) { foreach ($d in @($runnable | ForEach-Object { Get-DomainKey $_ } | Select-Object -Unique)) { $null = Get-LoginCred "guest:$d" "Guest OS login for VMs in $d (admin; used by VMware Tools; cancel to skip)" } }
        $script:noPrompt = $true
        if ($isWin) {
            try {
                Add-Type -Namespace Win32 -Name Power -MemberDefinition '[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);' -ErrorAction Stop
                $null = [Win32.Power]::SetThreadExecutionState([uint32]2147483649); $keepAwake = $true
                Write-Host 'Keeping the laptop awake while this runs. Leave it plugged in and on the network.' -ForegroundColor Green
            } catch {}
        }
    }

    $n = 0
    foreach ($w in $runnable) {
        $n++
        $t = $tri[$w.Host]
        Write-Host ""; Write-Host "=== [$n/$($runnable.Count)] $($w.Ticket)  $($w.Host)  [$($t.OS)]  $($t.Chain) ===" -ForegroundColor Cyan
        $done = $false; $errs = New-Object System.Collections.Generic.List[string]
        foreach ($route in $t.Routes) {
            if ($route -eq 'Bundle') { break }
            $res = $null
            try {
                switch ($route) {
                    'Ssh'    { $res = if ($t.OS -eq 'Windows') { @{ Ok = $false; Error = 'Ssh is Linux only' } } else { Invoke-ViaSsh $w $t } }
                    'Ssm'    { $res = if (-not $AllowSsm) { @{ Ok = $false; Error = 'needs -AllowSsm' } } else { Invoke-ViaSsm $w $t } }
                    'WinRM'  { $res = if ($t.OS -eq 'Linux') { @{ Ok = $false; Error = 'WinRM is Windows only' } } else { Invoke-ViaWinRM $w $t } }
                    'VMware' { $res = Invoke-ViaVmware $w $t }
                }
            } catch { $res = @{ Ok = $false; Error = "$route crashed: $($_.Exception.Message)" } }
            if ($res.Ok) { Add-Outcome -W $w -OS $t.OS -Route $route -CsvText $res.Csv -Err '' -Extra ''; $done = $true; Write-Host "   done via $route" -ForegroundColor Green; break }
            $errs.Add("${route}: $($res.Error)"); Write-Host "   $route failed: $($res.Error)" -ForegroundColor Yellow
        }
        if ($done) { continue }
        $b = ''
        try { $b = New-Bundle $w $t; Write-Host "   bundle written: $b" -ForegroundColor Green } catch { $errs.Add("bundle: $($_.Exception.Message)") }
        Add-Outcome -W $w -OS $t.OS -Route 'Bundle (pending)' -CsvText '' -Err ($errs -join ' | ') -Extra $(if ($b) { "paste $b, then -ImportResult clipboard" } else { '' })
    }
    foreach ($k in @($script:vi.Keys)) { if ($script:vi[$k]) { try { Disconnect-VIServer -Server $script:vi[$k] -Confirm:$false -ErrorAction SilentlyContinue } catch {} } }
    if ($keepAwake) { $null = [Win32.Power]::SetThreadExecutionState([uint32]2147483648) }
}

# ----------------------------------------------------------------------------------------------- report
if (-not $summary.Count) { return }
Write-Host ""; Write-Host '=== Results ===' -ForegroundColor Cyan
($summary | Format-Table Ticket, Host, OS, Route, Pass, Fail, Manual, Skip, Error -AutoSize -Wrap | Out-String -Width 230) | Write-Host
$sumPath = Join-Path $OutDir "Readiness-Summary-$stamp.csv"
$summary | Export-Csv -LiteralPath $sumPath -NoTypeInformation

$today = Get-Date -Format 'yyyy-MM-dd'
$md = New-Object System.Collections.Generic.List[string]     # markdown review file
$tx = New-Object System.Collections.Generic.List[string]     # plain text, ready to paste into tickets
$md.Add("# Production readiness: status ($(Get-Date -Format 'yyyy-MM-dd HH:mm'))"); $md.Add('')
$md.Add('DRAFTS. Nothing was posted or closed. MANUAL items are not verified by the script, so confirm them before closing.'); $md.Add('')
foreach ($grp in ($summary | Group-Object Ticket)) {
    $all = @($grp.Group)
    $ran = @($all | Where-Object { $_.Csv })
    $notRan = @($all | Where-Object { -not $_.Csv })
    $ticketNo = $grp.Name
    $md.Add("## $ticketNo  ($($all.Count) host(s))")
    if (-not $ran.Count) {
        $why = ($notRan | ForEach-Object { "$($_.Host): $($_.Error) $($_.Notes)" }) -join ' | '
        $md.Add("**NOT RUN.** $why"); $md.Add('')
        $tx.Add("===== $ticketNo   [NOT RUN] ====="); $tx.Add("Not run yet. $why"); $tx.Add(''); continue
    }
    $totFail = [int](($ran | Measure-Object -Property Fail -Sum).Sum)
    $clean = @($ran | Where-Object { $_.Fail -eq 0 }).Count
    $verdict = if ($totFail -gt 0) { "HOLD: $totFail FAIL item(s) across $(@($ran | Where-Object { $_.Fail -gt 0 }).Count) of $($ran.Count) host(s). Fix or send back before closing." } else { "No FAILs on $($ran.Count) host(s). Confirm the MANUAL items, then close." }
    $md.Add("**$verdict**"); $md.Add('')
    $names = ($ran | ForEach-Object { Get-Short $_.Host }) -join ', '
    $routes = (($ran | Select-Object -ExpandProperty Route -Unique)) -join '/'
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("Production readiness check run $today with the read-only readiness script ($routes) on: $names.")
    if ($ran.Count -le 3) {
        foreach ($r in $ran) {
            $lines.Add("$(Get-Short $r.Host) ($($r.OS), role $($r.Role)): $($r.Pass) PASS, $($r.Fail) FAIL, $($r.Manual) MANUAL, $($r.Skip) SKIP.")
            foreach ($f in @($detail[$r.Host] | Where-Object { $_.Status -eq 'FAIL' })) { $d = "$($f.Detail)"; if ($d.Length -gt 170) { $d = $d.Substring(0, 170) + '...' }; $lines.Add("  FAIL - $($f.Item): $d") }
        }
    } else {
        $lines.Add("$clean of $($ran.Count) hosts have no FAIL items.")
        $byItem = @{}
        foreach ($r in $ran) { foreach ($f in @($detail[$r.Host] | Where-Object { $_.Status -eq 'FAIL' })) { if (-not $byItem.ContainsKey($f.Item)) { $byItem[$f.Item] = New-Object System.Collections.Generic.List[object] }; $byItem[$f.Item].Add([pscustomobject]@{ Host = (Get-Short $r.Host); Detail = $f.Detail }) } }
        foreach ($k in ($byItem.Keys | Sort-Object { - $byItem[$_].Count })) {
            $list = $byItem[$k]; $d = "$($list[0].Detail)"; if ($d.Length -gt 140) { $d = $d.Substring(0, 140) + '...' }
            $lines.Add("  FAIL - $k on $($list.Count)/$($ran.Count): $(($list | Select-Object -First 8 | ForEach-Object { $_.Host }) -join ', ')$(if ($list.Count -gt 8) { ', ...' }). e.g. $d")
        }
        $lines.Add('Per host (PASS/FAIL/MANUAL/SKIP): ' + (($ran | ForEach-Object { "$(Get-Short $_.Host) $($_.Pass)/$($_.Fail)/$($_.Manual)/$($_.Skip)" }) -join '; ') + '.')
    }
    $manualItems = @($ran | ForEach-Object { $detail[$_.Host] | Where-Object { $_.Status -eq 'MANUAL' } | Select-Object -ExpandProperty Item } | Select-Object -Unique)
    if ($manualItems.Count) { $lines.Add("Manual checks still to confirm: $($manualItems -join '; ').") }
    $factsList = @($ran | Where-Object { $_.Facts } | ForEach-Object { "$(Get-Short $_.Host): $($_.Facts)" })
    if ($factsList.Count -and $ran.Count -le 6) { foreach ($f in $factsList) { $lines.Add("AWS facts - $f") } }
    if ($notRan.Count) { $lines.Add("Not yet run: $(($notRan | ForEach-Object { Get-Short $_.Host }) -join ', ').") }
    foreach ($l in $lines) { $md.Add("> $l") }
    $md.Add('')
    $tx.Add("===== $ticketNo   [$(if ($totFail -gt 0) { 'HOLD' } else { 'OK to close after manual items' })] ====="); foreach ($l in $lines) { $tx.Add($l) }; $tx.Add('')
}
$mdPath = Join-Path $OutDir "Readiness-Notes-$stamp.md"
$txPath = Join-Path $OutDir "Readiness-Paste-$stamp.txt"
Set-Content -LiteralPath $mdPath -Value $md -Encoding UTF8
Set-Content -LiteralPath $txPath -Value $tx -Encoding UTF8
Write-Host "Summary CSV : $sumPath" -ForegroundColor Green
Write-Host "Review notes: $mdPath" -ForegroundColor Green
Write-Host "Paste file  : $txPath" -ForegroundColor Green
