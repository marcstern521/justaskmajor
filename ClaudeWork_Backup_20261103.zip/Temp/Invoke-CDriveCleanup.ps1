<#
.SYNOPSIS
  C: drive cleanup for the servers in a list. DRY RUN BY DEFAULT: it only reports what WOULD be deleted and how much space
  that frees. Nothing is removed unless you add -Execute (and a -ChangeNumber, and type DELETE at the prompt).

.DESCRIPTION
  Tasks (pick with -Tasks; the first six are on by default):
    Temp             C:\Temp, C:\_temp, C:\Windows\Temp and the Temp folder of each profile that is NOT logged on.
                     Only items whose newest file is older than -TempAgeDays (default 14). Use -TempAgeDays 0 to clear everything.
    Profiles         Local user profiles unused for more than -ProfileAgeDays (default 180). Never touches: logged-on/loaded
                     profiles, system/special profiles, or names matching -ExcludeProfile. Removed the proper way (WMI Delete),
                     so the registry entry goes too. Age = the NEWER of Windows' LastUseTime and the NTUSER.DAT date.
    SqlBootstrapLogs SQL "Setup Bootstrap\Log\<session>" report folders (KB1563220). Keeps the newest -BootKeep (default 2) and
                     anything newer than -BootAgeDays (default 30). Never touches the rest of Setup Bootstrap (install cache).
    RecycleBin       C:\$Recycle.Bin contents
    WER              Windows Error Reporting queue/archive older than 7 days
    LiveKernel       C:\Windows\LiveKernelReports *.dmp older than 7 days
    WuCache          (opt-in) SoftwareDistribution\Download. Skipped if patching is running or a reboot is pending.
    IisLogs          (opt-in) C:\inetpub\logs\LogFiles *.log older than -IisAgeDays (default 60). Check your log-retention rule first.

  NOT touched on purpose: Windows\Installer, WinSxS (use DISM), page file, Program Files\Rapid7, ProgramData\Nuance, Radius logs,
  msdb.bck, SQL data/backups. Those need an owner decision.

  Safety: reparse points/junctions are skipped, directories are removed with "rd /s /q" (does not follow links), files in use are
  reported as PARTIAL/FAILED and left alone, scan runs at BelowNormal priority. Your own Windows login is used; add -PromptCredential
  only for a different account (typed at the prompt, never stored). The CSVs in -OutDir are your audit trail.

.EXAMPLE
  .\Invoke-CDriveCleanup.ps1 -ComputerName AOB-C42BIT01,AJA-J32DWA01                  # dry run on 2 servers
  .\Invoke-CDriveCleanup.ps1 -ServerFile .\pilot.txt                                  # dry run on a list
  .\Invoke-CDriveCleanup.ps1 -ServerFile .\pilot.txt -Execute -ChangeNumber CHG0123456 # real run
  .\Invoke-CDriveCleanup.ps1 -Local -Tasks Temp,SqlBootstrapLogs                       # on one server by itself
#>
param(
    [string]$ServerFile,
    [string[]]$ComputerName,
    [switch]$Local,
    [string]$Suffix,
    [ValidateSet('Temp', 'Profiles', 'SqlBootstrapLogs', 'RecycleBin', 'WER', 'LiveKernel', 'WuCache', 'IisLogs')]
    [string[]]$Tasks = @('Temp', 'Profiles', 'SqlBootstrapLogs', 'RecycleBin', 'WER', 'LiveKernel'),
    [int]$TempAgeDays = 14,
    [int]$ProfileAgeDays = 180,
    [int]$BootKeep = 2,
    [int]$BootAgeDays = 30,
    [int]$IisAgeDays = 60,
    [string[]]$ExcludeProfile = @('Administrator', 'Public', 'Default*', 'All Users', '*svc*', '*service*'),
    [switch]$Execute,
    [string]$ChangeNumber = '',
    [int]$ThrottleLimit = 4,
    [int]$BatchSize = 10,
    [int]$TimeoutMinutes = 60,
    [string]$OutDir = 'C:\Temp\CDriveCleanup',
    [switch]$PromptCredential
)
$ErrorActionPreference = 'Continue'

# ---------- what runs on each server ----------
$clean = {
    param($Tasks, [int]$TempAgeDays, [int]$ProfileAgeDays, [int]$BootKeep, [int]$BootAgeDays, [int]$IisAgeDays, $ExcludeProfile, [bool]$Execute)
    try { [System.Threading.Thread]::CurrentThread.Priority = 'BelowNormal' } catch {}
    $rows = New-Object System.Collections.Generic.List[object]
    function Row($task, $item, $bytes, $action, $note) {
        $rows.Add([pscustomobject]@{ Task = $task; Item = $item; MB = [math]::Round([double]$bytes / 1MB, 1); Action = $action; Note = $note })
    }
    function Get-Bytes($p) {
        $i = Get-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue
        if (-not $i) { return [double]0 }
        if (-not $i.PSIsContainer) { return [double]$i.Length }
        $m = Get-ChildItem -LiteralPath $p -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum
        if ($m.Sum) { return [double]$m.Sum } else { return [double]0 }
    }
    function Get-Newest($i) {
        if (-not $i.PSIsContainer) { return $i.LastWriteTime }
        $m = Get-ChildItem -LiteralPath $i.FullName -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object LastWriteTime -Maximum
        if ($m.Maximum -and $m.Maximum -gt $i.LastWriteTime) { return $m.Maximum } else { return $i.LastWriteTime }
    }
    function Test-Reparse($i) { return (($i.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) }
    function Remove-Thing($task, $p, $note) {
        $b = Get-Bytes $p
        if (-not $Execute) { Row $task $p $b 'WOULD DELETE' $note; return }
        try {
            $i = Get-Item -LiteralPath $p -Force -ErrorAction Stop
            if ($i.PSIsContainer) { & cmd.exe /c rd /s /q "$p" 2>&1 | Out-Null }
            else { Remove-Item -LiteralPath $p -Force -ErrorAction Stop }
            if (Test-Path -LiteralPath $p) { Row $task $p ($b - (Get-Bytes $p)) 'PARTIAL (in use)' $note }
            else { Row $task $p $b 'DELETED' $note }
        } catch { Row $task $p 0 'FAILED' $_.Exception.Message }
    }
    function Clear-Root($task, $root, [int]$ageDays) {
        if (-not (Test-Path -LiteralPath $root)) { return }
        $cut = (Get-Date).AddDays(-$ageDays); $kept = 0
        foreach ($c in @(Get-ChildItem -LiteralPath $root -Force -ErrorAction SilentlyContinue)) {
            if ($c.Name -like 'CDrive*' -or $c.Name -eq 'desktop.ini') { continue }
            if (Test-Reparse $c) { Row $task $c.FullName 0 'SKIPPED (link)' ''; continue }
            $newest = Get-Newest $c
            if ($newest -lt $cut) { Remove-Thing $task $c.FullName ("newest file {0:yyyy-MM-dd}" -f $newest) } else { $kept++ }
        }
        if ($kept) { Row $task $root 0 'KEPT (recent)' "$kept item(s) newer than $ageDays days" }
    }

    $di = New-Object System.IO.DriveInfo 'C'
    $free0 = $di.AvailableFreeSpace
    $loaded = @{}
    $wmiProfiles = @()
    try { $wmiProfiles = @(Get-WmiObject Win32_UserProfile -ErrorAction Stop) } catch {}
    foreach ($p in $wmiProfiles) { if ($p.Loaded) { $loaded[$p.LocalPath.ToLower()] = 1 } }

    if ($Tasks -contains 'Temp') {
        foreach ($r in @('C:\Temp', 'C:\_temp', 'C:\Windows\Temp')) { Clear-Root 'Temp' $r $TempAgeDays }
        foreach ($u in @(Get-ChildItem 'C:\Users' -Directory -Force -ErrorAction SilentlyContinue)) {
            if ($loaded.ContainsKey($u.FullName.ToLower())) { continue }
            Clear-Root 'Temp' (Join-Path $u.FullName 'AppData\Local\Temp') $TempAgeDays
        }
    }
    if ($Tasks -contains 'Profiles') {
        $cut = (Get-Date).AddDays(-$ProfileAgeDays)
        foreach ($p in $wmiProfiles) {
            if ($p.Special -or $p.SID -notlike 'S-1-5-21-*' -or $p.LocalPath -notlike 'C:\Users\*') { continue }
            $name = Split-Path $p.LocalPath -Leaf
            $ex = $false; foreach ($pat in $ExcludeProfile) { if ($name -like $pat) { $ex = $true } }
            if ($ex) { Row 'Profiles' $p.LocalPath 0 'KEPT (excluded name)' ''; continue }
            if ($p.Loaded) { Row 'Profiles' $p.LocalPath 0 'KEPT (logged on / loaded)' ''; continue }
            $dates = @()
            if ($p.LastUseTime) { try { $dates += [System.Management.ManagementDateTimeConverter]::ToDateTime($p.LastUseTime) } catch {} }
            $dat = Get-Item -LiteralPath (Join-Path $p.LocalPath 'NTUSER.DAT') -Force -ErrorAction SilentlyContinue
            if ($dat) { $dates += $dat.LastWriteTime }
            if (-not $dates.Count) { Row 'Profiles' $p.LocalPath 0 'KEPT (no age info)' ''; continue }
            $last = ($dates | Sort-Object -Descending | Select-Object -First 1)
            $age = [int]((Get-Date) - $last).TotalDays
            if ($last -ge $cut) { Row 'Profiles' $p.LocalPath 0 'KEPT (recent)' "last used $age days ago"; continue }
            $b = Get-Bytes $p.LocalPath
            $note = "last used $age days ago ({0:yyyy-MM-dd}) SID $($p.SID)" -f $last
            if (-not $Execute) { Row 'Profiles' $p.LocalPath $b 'WOULD DELETE' $note; continue }
            try {
                $p.Delete()
                if (Test-Path -LiteralPath $p.LocalPath) { Row 'Profiles' $p.LocalPath ($b - (Get-Bytes $p.LocalPath)) 'PARTIAL (folder remains)' $note }
                else { Row 'Profiles' $p.LocalPath $b 'DELETED' $note }
            } catch { Row 'Profiles' $p.LocalPath 0 'FAILED' $_.Exception.Message }
        }
    }
    if ($Tasks -contains 'SqlBootstrapLogs') {
        foreach ($l in @(Get-ChildItem -Path 'C:\Program Files\Microsoft SQL Server\*\Setup Bootstrap\Log' -Directory -ErrorAction SilentlyContinue)) {
            $sess = @(Get-ChildItem -LiteralPath $l.FullName -Directory -Force -ErrorAction SilentlyContinue | Sort-Object CreationTime -Descending)
            $cut = (Get-Date).AddDays(-$BootAgeDays)
            $old = @($sess | Select-Object -Skip $BootKeep | Where-Object { $_.CreationTime -lt $cut })
            foreach ($s in $old) { Remove-Thing 'SqlBootstrapLogs' $s.FullName ("created {0:yyyy-MM-dd}" -f $s.CreationTime) }
            Row 'SqlBootstrapLogs' $l.FullName 0 'KEPT' ("{0} session folder(s) total, {1} newest kept, {2} newer than {3} days kept" -f $sess.Count, [math]::Min($BootKeep, $sess.Count), ($sess.Count - $old.Count - [math]::Min($BootKeep, $sess.Count)), $BootAgeDays)
        }
    }
    if ($Tasks -contains 'RecycleBin') {
        foreach ($d in @(Get-ChildItem -LiteralPath 'C:\$Recycle.Bin' -Force -Directory -ErrorAction SilentlyContinue)) {
            foreach ($c in @(Get-ChildItem -LiteralPath $d.FullName -Force -ErrorAction SilentlyContinue)) {
                if ($c.Name -eq 'desktop.ini') { continue }
                Remove-Thing 'RecycleBin' $c.FullName ''
            }
        }
    }
    if ($Tasks -contains 'WER') {
        foreach ($r in @('C:\ProgramData\Microsoft\Windows\WER\ReportArchive', 'C:\ProgramData\Microsoft\Windows\WER\ReportQueue', 'C:\ProgramData\Microsoft\Windows\WER\Temp')) { Clear-Root 'WER' $r 7 }
    }
    if ($Tasks -contains 'LiveKernel') {
        $cut = (Get-Date).AddDays(-7)
        foreach ($f in @(Get-ChildItem 'C:\Windows\LiveKernelReports' -Recurse -File -Force -Filter *.dmp -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $cut })) {
            Remove-Thing 'LiveKernel' $f.FullName ("{0:yyyy-MM-dd}" -f $f.LastWriteTime)
        }
    }
    if ($Tasks -contains 'WuCache') {
        $dl = 'C:\Windows\SoftwareDistribution\Download'
        if (Test-Path $dl) {
            $busy = @(Get-Process -Name TiWorker -ErrorAction SilentlyContinue).Count -gt 0
            $pend = Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
            if ($busy -or $pend) { Row 'WuCache' $dl 0 'SKIPPED' 'patching running or reboot pending' }
            elseif (-not $Execute) { Row 'WuCache' $dl (Get-Bytes $dl) 'WOULD DELETE' 'contents' }
            else {
                $svc = Get-Service wuauserv -ErrorAction SilentlyContinue; $was = if ($svc) { $svc.Status } else { '' }
                try { if ($svc -and $was -eq 'Running') { Stop-Service wuauserv -Force -ErrorAction Stop } } catch {}
                foreach ($c in @(Get-ChildItem -LiteralPath $dl -Force -ErrorAction SilentlyContinue)) { Remove-Thing 'WuCache' $c.FullName '' }
                try { if ($was -eq 'Running') { Start-Service wuauserv -ErrorAction Stop } } catch { Row 'WuCache' 'wuauserv' 0 'FAILED' 'could not restart Windows Update service' }
            }
        }
    }
    if ($Tasks -contains 'IisLogs') {
        $cut = (Get-Date).AddDays(-$IisAgeDays)
        foreach ($f in @(Get-ChildItem 'C:\inetpub\logs\LogFiles' -Recurse -File -Force -Filter *.log -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt $cut })) {
            Remove-Thing 'IisLogs' $f.FullName ("{0:yyyy-MM-dd}" -f $f.LastWriteTime)
        }
    }
    $di2 = New-Object System.IO.DriveInfo 'C'
    Row 'Drive' 'C: free (MB) before' $free0 'INFO' ''
    Row 'Drive' 'C: free (MB) after' $di2.AvailableFreeSpace 'INFO' ''
    Row 'Drive' 'C: size (MB)' $di2.TotalSize 'INFO' ''
    $rows
}

# ---------- launcher ----------
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -Force | Out-Null }
$mode = if ($Execute) { 'EXECUTED' } else { 'DRYRUN' }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$tag = if ($ChangeNumber) { "${mode}_${ChangeNumber}_$stamp" } else { "${mode}_$stamp" }
$detail = New-Object System.Collections.Generic.List[object]
$failed = New-Object System.Collections.Generic.List[object]
$argList = @($Tasks, $TempAgeDays, $ProfileAgeDays, $BootKeep, $BootAgeDays, $IisAgeDays, $ExcludeProfile, [bool]$Execute)

if ($Local) { $targets = @($env:COMPUTERNAME) }
elseif ($ComputerName) { $targets = @($ComputerName) }
else {
    if (-not $ServerFile -or -not (Test-Path $ServerFile)) { throw 'Give -ServerFile, -ComputerName or -Local.' }
    $targets = @(Get-Content $ServerFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') } | Sort-Object -Unique)
}
if ($Suffix -and -not $Local) { $targets = $targets | ForEach-Object { if ($_ -like '*.*') { $_ } else { "$_.$Suffix" } } }

Write-Host ("Mode: {0}. {1} server(s). Tasks: {2}" -f $mode, $targets.Count, ($Tasks -join ', ')) -ForegroundColor Cyan
if ($Execute) {
    if (-not $ChangeNumber) { throw 'Real run needs -ChangeNumber (it is written into the audit CSVs).' }
    Write-Host "THIS WILL DELETE FILES on $($targets.Count) server(s) under $ChangeNumber. Profiles older than $ProfileAgeDays days, temp older than $TempAgeDays days." -ForegroundColor Yellow
    if ((Read-Host 'Type DELETE to continue') -cne 'DELETE') { throw 'Cancelled. Nothing was deleted.' }
}

if ($Local) {
    foreach ($r in (& $clean @argList)) { $detail.Add([pscustomobject]@{ Server = $env:COMPUTERNAME; Task = $r.Task; Item = $r.Item; MB = $r.MB; Action = $r.Action; Note = $r.Note; Change = $ChangeNumber; Mode = $mode }) }
} else {
    $so = New-PSSessionOption -OpenTimeout 30000 -OperationTimeout ($TimeoutMinutes * 60000)
    $cred = $null; if ($PromptCredential) { $cred = Get-Credential -Message 'Account with admin rights on the servers' }
    for ($i = 0; $i -lt $targets.Count; $i += $BatchSize) {
        $chunk = @($targets[$i..([math]::Min($i + $BatchSize, $targets.Count) - 1)])
        Write-Host ("Batch {0}-{1} of {2} ..." -f ($i + 1), ($i + $chunk.Count), $targets.Count) -ForegroundColor DarkCyan
        $remErr = $null
        $splat = @{ ComputerName = $chunk; ScriptBlock = $clean; ArgumentList = $argList; ThrottleLimit = $ThrottleLimit; SessionOption = $so; ErrorAction = 'SilentlyContinue'; ErrorVariable = 'remErr' }
        if ($cred) { $splat.Credential = $cred }
        foreach ($r in @(Invoke-Command @splat)) {
            if ($r.Task) { $detail.Add([pscustomobject]@{ Server = "$($r.PSComputerName)"; Task = $r.Task; Item = $r.Item; MB = $r.MB; Action = $r.Action; Note = $r.Note; Change = $ChangeNumber; Mode = $mode }) }
        }
        foreach ($e in @($remErr)) {
            $h = if ($e.TargetObject) { "$($e.TargetObject)" } else { '?' }
            $failed.Add([pscustomobject]@{ Server = $h; Reason = ("$($e.Exception.Message)").Split([char]10)[0].Trim() })
        }
        $detail | Export-Csv -NoTypeInformation -Path (Join-Path $OutDir "Cleanup_Detail_$tag.csv")
    }
}

# ---------- summary ----------
$hit = 'WOULD DELETE', 'DELETED', 'PARTIAL (in use)', 'PARTIAL (folder remains)'
function Sum-MB($rows, $task) { $m = $rows | Where-Object { $_.Task -eq $task -and $hit -contains $_.Action } | Measure-Object MB -Sum; [math]::Round([double]$m.Sum, 0) }
$summary = foreach ($g in ($detail | Group-Object Server)) {
    $r = $g.Group
    $fb = ($r | Where-Object { $_.Item -eq 'C: free (MB) before' }).MB; $fa = ($r | Where-Object { $_.Item -eq 'C: free (MB) after' }).MB
    $sz = ($r | Where-Object { $_.Item -eq 'C: size (MB)' }).MB
    $tot = ($r | Where-Object { $_.Task -ne 'Drive' -and $hit -contains $_.Action } | Measure-Object MB -Sum).Sum
    [pscustomobject]@{
        Server = $g.Name; Mode = $mode; SizeGB = [math]::Round($sz / 1024, 1); FreeBeforeGB = [math]::Round($fb / 1024, 1)
        FreeAfterGB = if ($Execute) { [math]::Round($fa / 1024, 1) } else { '' }
        TotalReclaimGB = [math]::Round([double]$tot / 1024, 2)
        TempMB = Sum-MB $r 'Temp'; ProfilesMB = Sum-MB $r 'Profiles'; SqlBootstrapMB = Sum-MB $r 'SqlBootstrapLogs'
        RecycleMB = Sum-MB $r 'RecycleBin'; WerMB = Sum-MB $r 'WER'; LiveKernelMB = Sum-MB $r 'LiveKernel'; WuCacheMB = Sum-MB $r 'WuCache'; IisMB = Sum-MB $r 'IisLogs'
        Failures = @($r | Where-Object { $_.Action -like 'FAILED*' -or $_.Action -like 'PARTIAL*' }).Count
    }
}
$summary = @($summary | Sort-Object FreeBeforeGB)
$f1 = Join-Path $OutDir "Cleanup_Summary_$tag.csv"; $f2 = Join-Path $OutDir "Cleanup_Detail_$tag.csv"
$summary | Export-Csv -NoTypeInformation -Path $f1
$detail | Export-Csv -NoTypeInformation -Path $f2
$word = if ($Execute) { 'Freed' } else { 'Would free' }
$totGB = [math]::Round((($summary | Measure-Object TotalReclaimGB -Sum).Sum), 1)

Write-Host "`nPer server (lowest free space first):" -ForegroundColor Cyan
$summary | Format-Table Server, SizeGB, FreeBeforeGB, FreeAfterGB, TotalReclaimGB, TempMB, ProfilesMB, SqlBootstrapMB, RecycleMB, WerMB, LiveKernelMB, Failures -AutoSize
$prof = @($detail | Where-Object { $_.Task -eq 'Profiles' -and $hit -contains $_.Action } | Sort-Object MB -Descending)
if ($prof.Count) {
    Write-Host ("Profiles {0} ({1}) - review these names:" -f $(if ($Execute) { 'removed' } else { 'that WOULD be removed' }), $prof.Count) -ForegroundColor Yellow
    $prof | Select-Object -First 40 | Format-Table Server, Item, MB, Note -AutoSize -Wrap
}
Write-Host ("{0} {1} GB across {2} server(s). Items needing a look (failed/partial): {3}" -f $word, $totGB, $summary.Count, (($summary | Measure-Object Failures -Sum).Sum)) -ForegroundColor Green
if ($failed.Count) { Write-Host 'Could not reach:' -ForegroundColor Yellow; $failed | Sort-Object Server -Unique | Format-Table -AutoSize -Wrap; $failed | Export-Csv -NoTypeInformation -Path (Join-Path $OutDir "Cleanup_Failed_$tag.csv") }
Write-Host "`nAudit files:`n  $f1`n  $f2" -ForegroundColor Green
if (-not $Execute) { Write-Host 'DRY RUN - nothing was deleted. Re-run with -Execute -ChangeNumber <CHG> to delete.' -ForegroundColor Yellow }
