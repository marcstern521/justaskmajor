# ============================================================
# GS - Script 1 - Pre-Flight Check (read-only, no changes made)
# Works on any number of servers. Works out each EFT server's hop path
# from its current version using the runbook table.
#
# Example:
#   .\GS_1_Preflight_Check.ps1 -EftServer aaa-incdr01,aab-incdr01 -DmzServer aaa-inftp01
# ============================================================
[CmdletBinding()]
param(
    [string[]]$EftServer,
    [string[]]$DmzServer,
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
if (-not $EftServer -and -not $DmzServer) { throw 'Give me at least one server: -EftServer and/or -DmzServer' }

$Credential = Get-GSCredential $Credential
Start-GSLog -Name 'preflight'
$report = @()

function New-Row {
    param($Server, $Role, $Version, $Plan, $State, $Account, $Net48, $CFree, $DFree, $Dir, $APJson, $Notes)
    [pscustomobject]@{
        Server = $Server; Role = $Role; Version = $Version; Plan = $Plan
        ServiceState = $State; ServiceAccount = $Account; DotNet48 = $Net48
        CFreeGB = $CFree; DFreeGB = $DFree; InstallDir = $Dir; APJson = $APJson
        Notes = ($Notes -join '; ')
    }
}

Write-Log '=== Globalscape Pre-Flight Check ===' Cyan

# --- EFT servers ---
foreach ($name in $EftServer) {
    $server = Resolve-GSHost $name $Domain
    Write-Log "Checking EFT: $server" Yellow
    try {
        $s = New-PSSession -ComputerName $server -Credential $Credential -ErrorAction Stop
        $i = Get-EFTInfo -Session $s
        Remove-PSSession $s
    } catch {
        Write-Log "  UNREACHABLE - $_" Red
        $report += New-Row $server 'EFT' $null 'UNREACHABLE' $null $null $null $null $null $null $null @("$_")
        continue
    }

    $notes = @()
    $ver   = ConvertTo-GSVersion $i.Version
    if (-not $ver) {
        $plan = 'UNKNOWN'
        $notes += 'could not read EFT version'
    } else {
        $p = Get-EFTUpgradePlan $ver
        switch ($p.Status) {
            'Current' { $plan = 'Already current' }
            'Manual'  { $plan = 'MANUAL staged path'; $notes += 'older than 8.0.2 - use the Fortra staged path, not scripted' }
            default   { $plan = '{0} hops: {1}' -f $p.Hops.Count, ($p.Hops -join ' > ') }
        }
    }
    if (-not $i.ServiceName)        { $notes += 'EFT service not found' }
    elseif ($i.ServiceState -ne 'Running') { $notes += "service $($i.ServiceState)" }
    if (-not $i.DotNet48)           { $notes += '.NET 4.8 NOT installed' }
    if ($null -eq $i.DFreeGB)       { $notes += 'no D: drive' }
    elseif ($i.DFreeGB -lt 5)       { $notes += 'D: under 5 GB free' }
    if (-not $i.APJson)             { $notes += 'AdvancedProperties.json not found' }

    Write-Log ("  Version: {0} | Service: {1} ({2}) | .NET 4.8: {3} | D: free: {4} GB" -f $i.Version, $i.ServiceName, $i.ServiceState, $i.DotNet48, $i.DFreeGB)
    Write-Log "  Plan:    $plan"
    if ($notes.Count) { Write-Log ("  Notes:   " + ($notes -join '; ')) Yellow }

    $report += New-Row $server 'EFT' $i.Version $plan $i.ServiceState $i.ServiceAccount $i.DotNet48 $i.CFreeGB $i.DFreeGB $i.InstallDir $i.APJson $notes
}

# --- DMZ Gateway servers ---
foreach ($name in $DmzServer) {
    $server = Resolve-GSHost $name $Domain
    Write-Log "Checking DMZ: $server" Yellow
    try {
        $s = New-PSSession -ComputerName $server -Credential $Credential -ErrorAction Stop
        $d = Get-DMZInfo -Session $s
        Remove-PSSession $s
    } catch {
        Write-Log "  UNREACHABLE - $_" Red
        $report += New-Row $server 'DMZ' $null 'UNREACHABLE' $null $null $null $null $null $null $null @("$_")
        continue
    }

    $notes = @()
    $ver   = ConvertTo-GSVersion $d.Version
    if (-not $ver)                         { $plan = 'UNKNOWN'; $notes += 'could not read DMZ version' }
    elseif ($ver -ge $script:DMZTarget)    { $plan = 'Already current' }
    else                                   { $plan = 'Upgrade to 4.x (single hop) - do this BEFORE the paired EFT' }
    if (-not $d.ServiceName)               { $notes += 'DMZ service not found' }
    elseif ($d.ServiceState -ne 'Running') { $notes += "service $($d.ServiceState)" }
    if ($null -eq $d.DFreeGB)              { $notes += 'no D: drive' }

    Write-Log ("  Version: {0} | Service: {1} ({2}) / {3}" -f $d.Version, $d.ServiceName, $d.ServiceState, $d.ServiceAccount)
    Write-Log "  Plan:    $plan"
    if ($notes.Count) { Write-Log ("  Notes:   " + ($notes -join '; ')) Yellow }

    $report += New-Row $server 'DMZ' $d.Version $plan $d.ServiceState $d.ServiceAccount $null $d.CFreeGB $d.DFreeGB $null $null $notes
}

# --- Export + summary ---
$csv = Join-Path $script:WorkDir ('preflight_{0}.csv' -f (Get-Date -Format 'yyyyMMdd-HHmm'))
$report | Export-Csv -Path $csv -NoTypeInformation
Write-Host ''
$report | Format-Table Server, Role, Version, Plan, DotNet48, DFreeGB, Notes -AutoSize -Wrap
Write-Log "Report saved to $csv" Green
Write-Log 'Reminder: runbook order is DMZ Gateway first, then EFT. Snapshot (or EBS snapshot / AMI for EC2) before touching anything.' Cyan
