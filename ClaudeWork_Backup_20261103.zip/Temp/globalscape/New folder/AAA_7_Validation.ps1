# ============================================================
# AAA - Script 7 - Post Upgrade Validation
# Validates AAA-QWEFT01 and AAA-INFTP01 after full upgrade
# Requires Nmap installed on management machine
# ============================================================

$EFTServer   = 'AAA-INEFT01.inucn.com'
$DMZServer   = 'AAA-INFTP01.inucn.com'
$ServiceName = 'EFT Server Enterprise'
$NmapPath    = 'C:\Program Files (x86)\Nmap\nmap.exe'
$ReportPath  = "C:\temp\globalscape\aaa_validation_$(Get-Date -Format 'yyyyMMdd').csv"
$TargetVer   = '8.3.2.565'
$creds       = Get-Credential
$Results     = @()

New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null

Write-Host "`n=== AAA Post Upgrade Validation ===" -ForegroundColor Cyan

# --- EFT Server ---
Write-Host "`nValidating EFT: $EFTServer" -ForegroundColor Yellow
try {
    $data = Invoke-Command -ComputerName $EFTServer -Credential $creds -ErrorAction Stop -ScriptBlock {
        param($svcName)
        $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
            Get-ItemProperty -EA SilentlyContinue |
            Where-Object { $_.DisplayName -like '*EFT*' } |
            Select-Object -First 1
        $svc = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -EA SilentlyContinue
        [PSCustomObject]@{
            EFTVersion    = $reg.DisplayVersion
            ServiceStatus = $svc.State
        }
    } -ArgumentList $ServiceName

    $versionOK = $data.EFTVersion -eq $TargetVer
    $serviceOK = $data.ServiceStatus -eq 'Running'

    Write-Host "  Version: $(if ($data.EFTVersion) {$data.EFTVersion} else {'verify in admin console'}) $(if ($versionOK) {'✅'} else {'⚠️ verify in admin console'})"
    Write-Host "  Service: $($data.ServiceStatus) $(if ($serviceOK) {'✅'} else {'❌'})"

} catch {
    Write-Host "  ❌ Cannot connect" -ForegroundColor Red
    $data      = [PSCustomObject]@{ EFTVersion = 'UNREACHABLE'; ServiceStatus = 'UNREACHABLE' }
    $versionOK = $false
    $serviceOK = $false
}

# Nmap scan
Write-Host "  Running Nmap SSH scan on port 22..."
$nmapOut = & $NmapPath -p 22 --script ssh2-enum-algos $EFTServer 2>&1

$hasEd25519 = [bool]($nmapOut -match 'ssh-ed25519')
$hasEcdsa   = [bool]($nmapOut -match 'ecdsa-sha2-nistp256')
$hasRsaSha2 = [bool]($nmapOut -match 'rsa-sha2-256')
$hasCBC     = [bool]($nmapOut -match '-cbc')
$has3DES    = [bool]($nmapOut -match '3des')
$hasSHA1    = [bool]($nmapOut -match 'hmac-sha1[^-]|hmac-sha1$')
$hasMD5     = [bool]($nmapOut -match 'hmac-md5')

Write-Host "  ssh-ed25519:         $(if ($hasEd25519) {'✅'} else {'❌ MISSING - add host key in admin console'})"
Write-Host "  ecdsa-sha2-nistp256: $(if ($hasEcdsa)   {'✅'} else {'❌ MISSING - add host key in admin console'})"
Write-Host "  rsa-sha2-256:        $(if ($hasRsaSha2) {'✅'} else {'❌ MISSING'})"
Write-Host "  CBC ciphers:         $(if ($hasCBC)     {'⚠️  Present (intentional - pending exception list)'} else {'✅ Removed'})"
Write-Host "  3des-cbc:            $(if ($has3DES)    {'⚠️  Present (intentional - pending exception list)'} else {'✅ Removed'})"
Write-Host "  SHA1 MACs:           $(if ($hasSHA1)    {'⚠️  Present (intentional - pending exception list)'} else {'✅ Removed'})"
Write-Host "  MD5 MACs:            $(if ($hasMD5)     {'❌ Still present - check AdvancedProperties.json'} else {'✅ Removed'})"

$eftPass = ($serviceOK -and $hasEd25519 -and $hasEcdsa -and $hasRsaSha2 -and -not $hasMD5)

$Results += [PSCustomObject]@{
    Server           = $EFTServer
    Role             = 'EFT'
    Version          = $data.EFTVersion
    ServiceRunning   = $serviceOK
    HasEd25519       = $hasEd25519
    HasEcdsa256      = $hasEcdsa
    HasRsaSha2       = $hasRsaSha2
    CBCPresent       = $hasCBC
    TripleDESPresent = $has3DES
    SHA1Present      = $hasSHA1
    MD5Removed       = -not $hasMD5
    OverallPass      = $eftPass
}

# --- DMZ Server ---
Write-Host "`nValidating DMZ: $DMZServer" -ForegroundColor Yellow
try {
    $dmz = Invoke-Command -ComputerName $DMZServer -Credential $creds -ErrorAction Stop -ScriptBlock {
        $reg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
        if (-not $reg) { $reg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
        if (-not $reg) {
            $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                Get-ItemProperty -EA SilentlyContinue |
                Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
                Select-Object -First 1
        }
        $svc = Get-WmiObject Win32_Service -EA SilentlyContinue |
            Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
            Select-Object -First 1
        [PSCustomObject]@{
            DMZVersion    = $reg.DisplayVersion
            ServiceName   = $svc.Name
            ServiceStatus = $svc.State
        }
    }

    $dmzOK = $dmz.ServiceStatus -eq 'Running'
    Write-Host "  DMZ Version: $(if ($dmz.DMZVersion) {$dmz.DMZVersion} else {'check admin console'})"
    Write-Host "  Service:     $($dmz.ServiceName) - $($dmz.ServiceStatus) $(if ($dmzOK) {'✅'} else {'❌'})"

    $Results += [PSCustomObject]@{
        Server         = $DMZServer
        Role           = 'DMZ'
        Version        = $dmz.DMZVersion
        ServiceRunning = $dmzOK
        OverallPass    = $dmzOK
    }

} catch {
    Write-Host "  ❌ Cannot connect" -ForegroundColor Red
    $Results += [PSCustomObject]@{
        Server = $DMZServer; Role = 'DMZ'
        Version = 'UNREACHABLE'; ServiceRunning = $false; OverallPass = $false
    }
}

# --- Export ---
$Results | Export-Csv -Path $ReportPath -NoTypeInformation
Write-Host "`n✅ Report saved to $ReportPath" -ForegroundColor Green

# --- Summary ---
Write-Host "`n=== Validation Summary ===" -ForegroundColor Cyan
$pass = ($Results | Where-Object { $_.OverallPass }).Count
$fail = ($Results | Where-Object { -not $_.OverallPass }).Count

if ($fail -eq 0) {
    Write-Host "  ✅ Both servers passed!" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Next steps:" -ForegroundColor Cyan
    Write-Host "  1. Have Fivetran customer test connection to $EFTServer" -ForegroundColor White
    Write-Host "  2. Share Nmap output with SysSecOps and Lyle May" -ForegroundColor White
    Write-Host "  3. Update SCTASK0126730 with completion status" -ForegroundColor White
    Write-Host "  4. Reply to EA IEX FTP email thread with update" -ForegroundColor White
} else {
    Write-Host "  Failed: $fail server(s)" -ForegroundColor Red
    $Results | Where-Object { -not $_.OverallPass } | ForEach-Object {
        Write-Host "    ❌ $($_.Server)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "NOTE: CBC/3DES/SHA1 warnings are intentional - kept pending Bryant customer exception list" -ForegroundColor Yellow
