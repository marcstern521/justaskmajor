# ============================================================
# AAA - Script 6 - Apply SSH Cipher Config
# Target: AAA-INEFT01.inucn.com
# Adds modern algorithms - does NOT remove legacy ones yet
# (legacy removal pending Bryant customer exception list)
#
# Approvals on file:
#   SysArch:    Lyle May       03/30/2026 ✅
#   Compliance: Stuart Kirkham 04/06/2026 ✅
# ============================================================

$TargetServer = 'AAA-INEFT01.inucn.com'
$ServiceName  = 'EFT Server Enterprise'
$InstallPath  = 'D:\ProgramData\Globalscape\EFT Server\'
$APJsonPath   = "$InstallPath\AdvancedProperties.json"
$BackupPath   = "$InstallPath\AdvancedProperties_backup_$(Get-Date -Format 'yyyyMMdd-HHmm').json"
$creds        = Get-Credential

# Approved cipher config - adding modern, NOT removing legacy yet
$ApprovedCiphers = "aes256-gcm@openssh.com,aes128-gcm@openssh.com,chacha20-poly1305@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr"
$ApprovedKEX     = "curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group16-sha512,diffie-hellman-group-exchange-sha256,diffie-hellman-group14-sha1"

Write-Host "`n=== Apply SSH Cipher Config on $TargetServer ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Approvals on file:" -ForegroundColor Green
Write-Host "  SysArch:    Lyle May       03/30/2026 ✅" -ForegroundColor Green
Write-Host "  Compliance: Stuart Kirkham 04/06/2026 ✅" -ForegroundColor Green
Write-Host ""
Write-Host "NOTE: Legacy algorithms kept intentionally pending Bryant exception list" -ForegroundColor Yellow
Write-Host "      Only MD5-based MACs will be disabled in this run" -ForegroundColor Yellow

$approval = Read-Host "`nType APPROVED to apply cipher config"
if ($approval -ne 'APPROVED') { Write-Host "Exiting"; exit }

Write-Host "`nApplying config on $TargetServer..." -ForegroundColor Cyan

Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($apPath, $backupPath, $ciphers, $kex)

    # Backup existing file
    if (Test-Path $apPath) {
        Copy-Item $apPath $backupPath -Force
        Write-Host "✅ Backed up to $backupPath"
    } else {
        Write-Host "⚠️  AdvancedProperties.json not found - will create new"
    }

    # Load or create
    $ap = if (Test-Path $apPath) { Get-Content $apPath -Raw | ConvertFrom-Json } else { [PSCustomObject]@{} }

    # Apply modern cipher settings
    $ap | Add-Member -NotePropertyName 'SftpClientCiphers'       -NotePropertyValue $ciphers -Force
    $ap | Add-Member -NotePropertyName 'SftpClientKexAlgorithms' -NotePropertyValue $kex     -Force

    # Disable MD5 only - SHA1/CBC kept pending exception list
    $ap | Add-Member -NotePropertyName 'SFTP2_MD5'    -NotePropertyValue $false -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_MD5_96' -NotePropertyValue $false -Force

    $ap | ConvertTo-Json -Depth 10 | Set-Content $apPath -Force
    Write-Host "✅ AdvancedProperties.json updated"

} -ArgumentList $APJsonPath, $BackupPath, $ApprovedCiphers, $ApprovedKEX

# Restart service
Write-Host "Restarting $ServiceName..." -ForegroundColor Yellow
Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($svcName)
    Restart-Service -Name $svcName -Force -EA SilentlyContinue
    Start-Sleep -Seconds 30
    $status = (Get-WmiObject Win32_Service -Filter "Name='$svcName'").State
    Write-Host "Service status: $status"
} -ArgumentList $ServiceName

Write-Host "`n✅ Cipher config applied on $TargetServer" -ForegroundColor Green
Write-Host ""
Write-Host "⚠️  MANUAL STEP REQUIRED - Add host keys in EFT Admin Console:" -ForegroundColor Yellow
Write-Host "  1. Connect to $TargetServer" -ForegroundColor White
Write-Host "  2. Right-click site > Properties > Security > SFTP Settings" -ForegroundColor White
Write-Host "  3. Click CREATE > Type: ED25519 > 256 bit > Next" -ForegroundColor White
Write-Host "     Passphrase: use standard > Next > Add to site (multiple host keys) > Finish" -ForegroundColor White
Write-Host "  4. Click CREATE > Type: ECDSA > 256 bit > Next" -ForegroundColor White
Write-Host "     Passphrase: use standard > Next > Add to site (multiple host keys) > Finish" -ForegroundColor White
Write-Host "  5. Click Apply" -ForegroundColor White
Write-Host "  6. Restart EFT service" -ForegroundColor White
Write-Host ""
Write-Host "Then run AAA_7_Validation.ps1" -ForegroundColor Cyan
