# ============================================================
# GS - Script 6 - Apply SSH Cipher Config
# Per the runbook: do NOT apply until InfoSec, Compliance, Systems
# Architecture and Product sign-off is in. You must pass -ApprovalRef
# (ticket / email reference) so it is recorded in the log.
#
# Writes SftpClientCiphers / SftpClientKexAlgorithms and turns off the
# MD5 MACs in AdvancedProperties.json, then restarts the EFT service.
# NOTE: those two lists REPLACE whatever is there. If legacy algorithms
# must stay for customers on the exception list, include them in
# -Ciphers / -Kex.
#
# Example:
#   .\GS_6_Apply_Cipher_Config.ps1 -EftServer aaa-ineft01 -ApprovalRef CHG0177747
# ============================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$EftServer,
    [Parameter(Mandatory)][string]$ApprovalRef,
    [string]$ConfigFile,
    [string]$Ciphers = 'aes256-gcm@openssh.com,aes128-gcm@openssh.com,chacha20-poly1305@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr',
    [string]$Kex = 'curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group16-sha512,diffie-hellman-group-exchange-sha256,diffie-hellman-group14-sha1',
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
$Credential = Get-GSCredential $Credential
$Target     = Resolve-GSHost $EftServer $Domain
Start-GSLog -Name ('cipher_{0}' -f ($EftServer -split '\.')[0])

Write-Log "=== Apply SSH cipher config on $Target ===" Cyan
Write-Log "Approval reference: $ApprovalRef"

$s    = New-PSSession -ComputerName $Target -Credential $Credential -ErrorAction Stop
$info = Get-EFTInfo -Session $s
if (-not $info.ServiceName) { Write-Log 'EFT service not found' Red; exit 1 }

# Do not create a new file - a new AdvancedProperties.json in the wrong folder silently does nothing
$apPath = if ($ConfigFile) { $ConfigFile } else { $info.APJson }
if (-not $apPath) {
    Write-Log 'AdvancedProperties.json not found. Pass -ConfigFile with the real path.' Red
    exit 1
}
$exists = Invoke-Command -Session $s -ScriptBlock { param($p) Test-Path $p } -ArgumentList $apPath
if (-not $exists) { Write-Log "Config file not found: $apPath" Red; exit 1 }
Write-Log "Config file: $apPath"

# Preview what is there now
$keys = 'SftpClientCiphers', 'SftpClientKexAlgorithms', 'SFTP2_MD5', 'SFTP2_MD5_96'
$now = Invoke-Command -Session $s -ScriptBlock {
    param($p, $k)
    $j = Get-Content $p -Raw | ConvertFrom-Json
    foreach ($name in $k) { '{0} = {1}' -f $name, $(if ($j -and $j.PSObject.Properties[$name]) { $j.$name } else { '(not set)' }) }
} -ArgumentList $apPath, $keys
Write-Host "`nCurrent values:" -ForegroundColor Cyan
$now | ForEach-Object { Write-Host "  $_" }
Write-Host "`nWill set:" -ForegroundColor Cyan
Write-Host "  SftpClientCiphers       = $Ciphers"
Write-Host "  SftpClientKexAlgorithms = $Kex"
Write-Host '  SFTP2_MD5 / SFTP2_MD5_96 = false'

if (-not (Confirm-Typed "`nApproval $ApprovalRef is on file and covers this change. Apply?" 'APPROVED')) {
    Write-Log 'Exiting - nothing changed' Yellow
    exit 0
}

# --- Apply ---
$backup = $apPath -replace '\.json$', ('_backup_{0}.json' -f (Get-Date -Format 'yyyyMMdd-HHmm'))
Invoke-Command -Session $s -ScriptBlock {
    param($p, $bak, $ciphers, $kex)
    Copy-Item $p $bak -Force
    Write-Host "Backed up to $bak"

    $ap = Get-Content $p -Raw | ConvertFrom-Json
    if (-not $ap) { $ap = [pscustomobject]@{} }
    $ap | Add-Member -NotePropertyName 'SftpClientCiphers'       -NotePropertyValue $ciphers -Force
    $ap | Add-Member -NotePropertyName 'SftpClientKexAlgorithms' -NotePropertyValue $kex     -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_MD5'               -NotePropertyValue $false   -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_MD5_96'            -NotePropertyValue $false   -Force

    # UTF-8 without BOM
    [System.IO.File]::WriteAllText($p, ($ap | ConvertTo-Json -Depth 10), (New-Object System.Text.UTF8Encoding($false)))
    Write-Host 'AdvancedProperties.json updated'
} -ArgumentList $apPath, $backup, $Ciphers, $Kex
Write-Log "AdvancedProperties.json updated (backup: $backup)" Green

# --- Restart ---
Write-Log "Restarting $($info.ServiceName)..." Yellow
try {
    Invoke-Command -Session $s -ScriptBlock { param($n) Restart-Service -Name $n -Force -ErrorAction Stop } -ArgumentList $info.ServiceName
} catch {
    Write-Log "Restart failed - $_" Red
}
$running = Wait-GSService -Session $s -Name $info.ServiceName -TimeoutSec 180
Write-Log "Service: $(if ($running) {'Running'} else {'NOT running - investigate, restore the backup if needed'})" $(if ($running) { 'Green' } else { 'Red' })
Remove-PSSession $s

Write-Host "`nMANUAL STEP - add host keys in EFT Admin Console:" -ForegroundColor Yellow
Write-Host "  1. Connect to $Target" -ForegroundColor White
Write-Host '  2. Right-click site > Properties > Security > SFTP Settings' -ForegroundColor White
Write-Host '  3. CREATE > Type: ED25519 > 256 bit > Next > passphrase: use standard > Next > Add to site (multiple host keys) > Finish' -ForegroundColor White
Write-Host '  4. CREATE > Type: ECDSA > 256 bit > Next > passphrase: use standard > Next > Add to site (multiple host keys) > Finish' -ForegroundColor White
Write-Host '  5. Apply, then restart the EFT service' -ForegroundColor White
Write-Host "`nThen run GS_7_Validation.ps1" -ForegroundColor Cyan
