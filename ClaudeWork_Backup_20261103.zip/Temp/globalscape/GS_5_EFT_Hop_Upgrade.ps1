# ============================================================
# GS - Script 5 - EFT Hop Upgrade
# Hop path is worked out from the server's current version (runbook table).
# Run GS_4 (DMZ Gateway) first if this EFT has a paired gateway.
#
# Example:
#   .\GS_5_EFT_Hop_Upgrade.ps1 -EftServer aaa-incdr01 -ChangeRef CHG0177747
#   .\GS_5_EFT_Hop_Upgrade.ps1 -EftServer aaa-ineft01 -DmzServer aaa-inftp01
#
# BEFORE RUNNING:
#   1. Snapshot / EBS snapshot confirmed (GS_2)
#   2. Installers pushed to D:\temp (GS_3)
#   3. CR approved and maintenance window active
# ============================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$EftServer,
    [string]$DmzServer,
    [string]$ChangeRef = '',
    [string]$RemoteDir = 'D:\temp',
    [string]$BackupRoot = 'D:\temp\EFT_ConfigBackup',
    [string]$ConfigPath,
    [int]$InstallTimeoutMinutes = 30,
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
$Credential = Get-GSCredential $Credential
$Target     = Resolve-GSHost $EftServer $Domain
$RemoteDir  = $RemoteDir.TrimEnd('\')
Start-GSLog -Name ('eft_upgrade_{0}' -f ($EftServer -split '\.')[0])

Write-Log '=== EFT upgrade started ===' Cyan
Write-Log "Server: $Target   Change: $ChangeRef"

$s = New-PSSession -ComputerName $Target -Credential $Credential -ErrorAction Stop

# --- Pre-checks ---
$info    = Get-EFTInfo -Session $s
$current = ConvertTo-GSVersion $info.Version
if (-not $info.ServiceName) { Write-Log 'EFT service not found - is this the right server?' Red; exit 1 }
if (-not $current)          { Write-Log "Cannot read the EFT version from the registry ('$($info.Version)')" Red; exit 1 }

$plan = Get-EFTUpgradePlan $current
switch ($plan.Status) {
    'Current' { Write-Log "Already on $current - nothing to do" Green; exit 0 }
    'Manual'  { Write-Log "On $current - older than 8.0.2, needs the staged 7.4.13.15 / 8.0.x path. Not scripted." Red; exit 1 }
}
Write-Log "Current version: $current"
Write-Log "Service: $($info.ServiceName) ($($info.ServiceState)) / $($info.ServiceAccount)   Install dir: $($info.InstallDir)"
Write-Log ("Upgrade path ({0} hops): {1} > {2}" -f $plan.Hops.Count, $current, ($plan.Hops -join ' > ')) Yellow

if (-not $info.DotNet48) { Write-Log '.NET 4.8 is required before 8.2.x - install it first' Red; exit 1 }

# Runbook: DMZ Gateway before EFT
if ($DmzServer) {
    $dmzHost = Resolve-GSHost $DmzServer $Domain
    try {
        $ds   = New-PSSession -ComputerName $dmzHost -Credential $Credential -ErrorAction Stop
        $dmz  = Get-DMZInfo -Session $ds
        Remove-PSSession $ds
        $dver = ConvertTo-GSVersion $dmz.Version
        if ($dver -and $dver -ge $script:DMZTarget) {
            Write-Log "DMZ Gateway $dmzHost is on $($dmz.Version) - OK" Green
        } else {
            Write-Log "DMZ Gateway $dmzHost is on '$($dmz.Version)' - runbook says upgrade the DMZ FIRST" Red
            if (-not (Confirm-Typed 'Continue with the EFT upgrade anyway?' 'CONTINUE')) { exit 1 }
        }
    } catch {
        Write-Log "Could not check DMZ Gateway $dmzHost - $_" Yellow
        if (-not (Confirm-Typed 'Continue without the DMZ check?' 'CONTINUE')) { exit 1 }
    }
} else {
    Write-Log 'No -DmzServer given - skipping the DMZ-first check (fine if this EFT has no gateway)' Yellow
}

# Fail fast: every installer must already be on the box before hop 1
$missing = @()
foreach ($hop in $plan.Hops) {
    $path = '{0}\EFT-nodb_{1}.exe' -f $RemoteDir, $hop
    $ok = Invoke-Command -Session $s -ScriptBlock { param($p) Test-Path $p } -ArgumentList $path
    if (-not $ok) { $missing += $path }
}
if ($missing.Count -gt 0) {
    Write-Log 'Missing installers on the server - run GS_3_Push_Installers.ps1 first:' Red
    $missing | ForEach-Object { Write-Log "  $_" Red }
    exit 1
}

# Config location for the per-hop backup
if (-not $ConfigPath) {
    $ConfigPath = Invoke-Command -Session $s -ScriptBlock {
        param($installDir)
        $c = @()
        if ($installDir) { $c += (Join-Path $installDir 'Server Config') }
        $c += (Join-Path $env:ProgramData 'Globalscape\EFT Server Enterprise')
        $c += (Join-Path $env:ProgramData 'Globalscape\EFT Server')
        $c += 'D:\ProgramData\Globalscape\EFT Server'
        $c | Where-Object { Test-Path $_ } | Select-Object -First 1
    } -ArgumentList $info.InstallDir
}
if ($ConfigPath) { Write-Log "Config backup source: $ConfigPath" }
else { Write-Log 'Could not find the EFT config folder - you will be asked to back up manually before each hop' Yellow }

# --- Confirm ---
Write-Host "`n*** PRODUCTION SERVER ***" -ForegroundColor Red
Write-Host "   Server: $Target   $current  ->  $($script:EFTTarget)" -ForegroundColor Yellow
Write-Host '   Confirm the snapshot exists, the CR is approved and the window is active' -ForegroundColor Yellow
if (-not (Confirm-Typed 'Begin upgrade?' 'YES')) { Write-Log 'Cancelled by user' Yellow; exit 0 }

# --- Hop loop ---
$hopNo = 0
foreach ($hop in $plan.Hops) {
    $hopNo++
    $installer = '{0}\EFT-nodb_{1}.exe' -f $RemoteDir, $hop
    $installLog = '{0}\install_{1}.log' -f $RemoteDir, $hop
    Write-Log ("--- Hop {0}/{1}: {2} > {3} ---" -f $hopNo, $plan.Hops.Count, $current, $hop) Cyan

    # Backup (runbook: fresh backup before EACH hop - restore only works to the same version)
    if ($ConfigPath) {
        $dest = Invoke-Command -Session $s -ScriptBlock {
            param($src, $root, $label)
            $dest = Join-Path $root ('pre_{0}_{1}' -f $label, (Get-Date -Format 'yyyyMMdd-HHmm'))
            if ($dest.StartsWith($src.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
                throw "Backup destination $dest is inside the source $src - refusing"
            }
            New-Item -ItemType Directory -Path $dest -Force | Out-Null
            Copy-Item -Path (Join-Path $src '*') -Destination $dest -Recurse -Force
            $dest
        } -ArgumentList $ConfigPath, $BackupRoot, $current
        Write-Log "Config backed up to $dest"
    } else {
        if (-not (Confirm-Typed 'Take a config backup manually now, then confirm' 'BACKED-UP')) { exit 1 }
    }

    # Install
    Write-Log "Running $(Split-Path $installer -Leaf) (silent) - a few minutes..."
    Write-Log "If it hangs: kill the process in Task Manager, RDP in and run it manually from $RemoteDir"
    $r = Invoke-GSInstaller -Session $s -Path $installer -InstallerArgs "/S /log $installLog" -TimeoutMinutes $InstallTimeoutMinutes
    if ($r.TimedOut) {
        Write-Log "Installer still running after $InstallTimeoutMinutes minutes - NOT killed. RDP in, kill it and run manually, then re-run this script (it will pick up from the current version)." Red
        exit 1
    }
    Write-Log "Installer exit code: $($r.ExitCode)  (log: $installLog on the server)"

    # Service + version check
    Start-Sleep -Seconds 15
    $running = Wait-GSService -Session $s -Name $info.ServiceName -TimeoutSec 180
    Write-Log "Service $($info.ServiceName): $(if ($running) {'Running'} else {'NOT running - check admin console / event log'})" $(if ($running) { 'Green' } else { 'Red' })

    $after = ConvertTo-GSVersion (Get-EFTInfo -Session $s).Version
    if ($after -eq $hop) {
        Write-Log "Registry version now $after - matches" Green
    } else {
        Write-Log "Registry shows '$after' but expected $hop" Red
        if (-not (Confirm-Typed 'Version does not match. Only continue if the Admin Console title bar shows the right version' 'CONTINUE')) { exit 1 }
    }

    # Manual console check (runbook: per-hop steps)
    Write-Host "`n================================================================" -ForegroundColor Magenta
    Write-Host "  MANUAL STEP - hop to $hop" -ForegroundColor Magenta
    Write-Host '================================================================' -ForegroundColor Magenta
    Write-Host "  1. EFT Admin Console > connect to $Target" -ForegroundColor White
    Write-Host "  2. Title bar shows EFT $hop" -ForegroundColor White
    Write-Host '  3. Site shows RUNNING (green dot)' -ForegroundColor White
    Write-Host '  4. Licensed modules show Standard License (not Evaluation Expired)' -ForegroundColor White
    Write-Host '  5. Quick WinSCP test connection on port 22' -ForegroundColor White
    Write-Host "================================================================`n" -ForegroundColor Magenta

    if ((Read-Host 'Type OK to continue to the next hop, or ABORT to stop and investigate') -eq 'ABORT') {
        Write-Log "Aborted by user after hop to $hop" Yellow
        Write-Log 'Rollback: stop the EFT service, revert snapshot Pre-Globalscape-Upgrade-<date> in vCenter (EC2: restore EBS snapshot/AMI)' Yellow
        exit 1
    }
    Write-Log "Hop to $hop confirmed OK" Green
    $current = $hop
}

Remove-PSSession $s
Write-Log "=== EFT upgrade complete on $Target - now $($script:EFTTarget) ===" Green

Write-Host "`nPost-final-hop checklist (runbook):" -ForegroundColor Cyan
Write-Host '  - EFT version shows 8.3.2.565 in Admin Console title bar' -ForegroundColor White
Write-Host '  - EFT Server service Running and set to Automatic' -ForegroundColor White
Write-Host '  - Site RUNNING; SFTP, FTP/S, DMZ Gateway and ARM modules all Standard License' -ForegroundColor White
Write-Host '  - WinSCP SFTP test passes; Gateway shows Connected' -ForegroundColor White
Write-Host '  - Data-at-rest encryption re-enabled if it was configured before' -ForegroundColor White
Write-Host "`nNext: GS_6_Apply_Cipher_Config.ps1 (only with approval), then GS_7_Validation.ps1" -ForegroundColor Cyan
