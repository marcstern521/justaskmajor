# ============================================================
# AAA - Script 4 - EFT Hop Upgrade
# Target: AAA-QWEFT01.inucn.com
# Service: EFT Server Enterprise
# Install: D:\Program Files (x86)\Globalscape\EFT Server Enterprise\
# Path: 8.0.6.18 > 8.1.0.16 > 8.2.0.46 > 8.2.1.408 > 8.3.0.410 > 8.3.2.565
#
# BEFORE RUNNING:
#   1. Snapshots confirmed (Script 2)
#   2. Installers pushed to D:\temp\ (Script 3)
#   3. CR approved and maintenance window active
# ============================================================

$TargetServer  = 'AAA-QWEFT01.inucn.com'
$ServiceName   = 'EFT Server Enterprise'
$InstallPath   = 'D:\Program Files (x86)\Globalscape\EFT Server Enterprise'
$ConfigBackup  = "$InstallPath\Server Config"
$InstallerBase = 'D:\temp'
$LogPath       = "C:\temp\globalscape\aaa_eft_upgrade_$(Get-Date -Format 'yyyyMMdd').txt"

$creds = Get-Credential

$Installers = [ordered]@{
    '8.1.0.16'  = 'EFT-nodb_8.1.0.16.exe'
    '8.2.0.46'  = 'EFT-nodb_8.2.0.46.exe'
    '8.2.1.408' = 'EFT-nodb_8.2.1.408.exe'
    '8.3.0.410' = 'EFT-nodb_8.3.0.410.exe'
    '8.3.2.565' = 'EFT-nodb_8.3.2.565.exe'
}

$HopSequence = @('8.1.0.16','8.2.0.46','8.2.1.408','8.3.0.410','8.3.2.565')

# --- Helpers ---
function Write-Log {
    param($msg, $color = 'White')
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $msg"
    Write-Host $entry -ForegroundColor $color
    Add-Content -Path $LogPath -Value $entry
}

function Get-EFTVersion {
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        $r = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
            Get-ItemProperty -EA SilentlyContinue |
            Where-Object { $_.DisplayName -like '*EFT*' } |
            Select-Object -First 1
        $r.DisplayVersion
    }
}

function Get-ServiceStatus {
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($n)
        (Get-WmiObject Win32_Service -Filter "Name='$n'" -EA SilentlyContinue).State
    } -ArgumentList $ServiceName
}

function Backup-Config {
    param($version)
    $dest = "$ConfigBackup\Backup_pre_$version-$(Get-Date -Format 'yyyyMMdd-HHmm')"
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($src, $dst)
        if (Test-Path $src) {
            Copy-Item $src $dst -Recurse -Force
            Write-Host "  Config backed up to $dst"
        } else {
            Write-Host "  ⚠️ Config path not found: $src - skipping"
        }
    } -ArgumentList $ConfigBackup, $dest
}

# --- Start ---
New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null
New-Item -Path $LogPath -ItemType File -Force | Out-Null

Write-Log "=== EFT Upgrade Started ===" Cyan
Write-Log "Server:       $TargetServer"
Write-Log "Service:      $ServiceName"
Write-Log "Install path: $InstallPath"

$currentVersion = Get-EFTVersion
Write-Log "Current version: $currentVersion" Yellow
Write-Log "Upgrade path: $($HopSequence -join ' > ')"

# Production confirmation
Write-Host "`n⚠️  PRODUCTION SERVER" -ForegroundColor Red
Write-Host "   Server:  $TargetServer" -ForegroundColor Yellow
Write-Host "   Service: $ServiceName" -ForegroundColor Yellow
Write-Host "   Confirm CR is approved and maintenance window is active" -ForegroundColor Yellow
$confirm = Read-Host "Type YES to begin upgrade"
if ($confirm -ne 'YES') { Write-Log "Cancelled by user" Yellow; exit }

# --- Hop Loop ---
foreach ($targetVersion in $HopSequence) {

    if ($currentVersion -ge $targetVersion) {
        Write-Log "Skipping $targetVersion - already on $currentVersion" Yellow
        continue
    }

    Write-Log "--- Hop: $currentVersion > $targetVersion ---" Cyan

    # Backup config
    Write-Log "Backing up config..."
    Backup-Config -version $currentVersion

    # Check installer exists on remote server
    $installer     = $Installers[$targetVersion]
    $installerPath = "$InstallerBase\$installer"

    $exists = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($p); Test-Path $p
    } -ArgumentList $installerPath

    if (-not $exists) {
        Write-Log "❌ Installer not found at $installerPath on $TargetServer" Red
        Write-Log "   Run AAA_3_Push_Installers.ps1 first" Red
        exit
    }

    # Run installer
    Write-Log "Running $installer - this will take a few minutes..."
    Write-Log "NOTE: If it hangs - RDP into $TargetServer and run from D:\temp\ manually"
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($path, $logfile)
        Start-Process -FilePath $path -ArgumentList "/S /log $logfile" -Wait
    } -ArgumentList $installerPath, "D:\temp\install_$targetVersion.log"

    # Wait for service
    Write-Log "Waiting 45 seconds for service to stabilize..."
    Start-Sleep -Seconds 45

    # Check service
    $status = Get-ServiceStatus
    Write-Log "Service status: $status $(if ($status -eq 'Running') {'✅'} else {'⚠️ check admin console'})"

    # Manual console check
    Write-Host "`n================================================================" -ForegroundColor Magenta
    Write-Host "  MANUAL STEP - Hop to $targetVersion" -ForegroundColor Magenta
    Write-Host "================================================================" -ForegroundColor Magenta
    Write-Host "  1. Open EFT Admin Console > connect to $TargetServer" -ForegroundColor White
    Write-Host "  2. Confirm title bar shows EFT $targetVersion" -ForegroundColor White
    Write-Host "  3. Confirm site shows RUNNING" -ForegroundColor White
    Write-Host "  4. Confirm licensed modules show Standard License" -ForegroundColor White
    Write-Host "  5. Quick WinSCP test on port 22" -ForegroundColor White
    Write-Host "================================================================`n" -ForegroundColor Magenta

    $check = Read-Host "Type OK to continue or ABORT to stop and investigate"
    if ($check -eq 'ABORT') {
        Write-Log "Aborted by user after hop to $targetVersion" Yellow
        Write-Log "Rollback: revert snapshot Pre-Globalscape-AAA-Upgrade in vCenter" Yellow
        exit
    }

    Write-Log "Hop to $targetVersion confirmed OK ✅" Green
    $currentVersion = Get-EFTVersion
    if (-not $currentVersion) { $currentVersion = $targetVersion }
}

Write-Log "=== EFT Upgrade Complete on $TargetServer ===" Green
Write-Host "`n✅ All hops complete - AAA-QWEFT01 now on 8.3.2.565" -ForegroundColor Green
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Run AAA_5_DMZ_Upgrade.ps1 to upgrade AAA-INFTP01" -ForegroundColor White
Write-Host "  2. Then run AAA_6_Apply_Cipher_Config.ps1" -ForegroundColor White
Write-Host "  3. Add host keys manually in EFT Admin Console" -ForegroundColor White
Write-Host "  4. Run AAA_7_Validation.ps1" -ForegroundColor White
