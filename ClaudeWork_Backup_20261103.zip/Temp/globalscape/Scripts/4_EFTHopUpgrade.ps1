﻿# ============================================================
# Script 4 - EFT Hop-by-Hop Upgrade
# Run once per EFT server
# Installers must be staged in D:\temp\ on each target server
#
# ENA-INEFT01 path: 8.0.7.4 > 8.1.0.16 > 8.2.0.46 > 8.2.1.408 > 8.3.0.410 > 8.3.2.565
# ENA-INEFT03 path: 8.0.2.23 > 8.0.7.4 > 8.1.0.16 > 8.2.0.46 > 8.2.1.408 > 8.3.0.410 > 8.3.2.565
#
# BEFORE RUNNING:
#   1. Snapshots confirmed (done 04/02/2026)
#   2. .NET 4.8 on INEFT03 confirmed
#   3. All installers copied to D:\temp\ on each server
# ============================================================

# --- UPDATE THIS per server ---
$TargetServer = 'ENA-INEFT01.in.lab'   # Change to ENA-INEFT03.in.lab for second run

$creds          = Get-Credential
$InstallerBase  = 'D:\temp'
$ConfigBackup   = 'D:\Program Files\GlobalScape\EFT Server\Server Config'
$LogPath        = "D:\temp\upgrade_log_$(Get-Date -Format 'yyyyMMdd').txt"

# Actual installer filenames from Fortra portal
$Installers = [ordered]@{
    '8.0.7.4'   = 'EFT-nodb_8.0.7.4.exe'
    '8.1.0.16'  = 'EFT-nodb_8.1.0.16.exe'
    '8.2.0.46'  = 'EFT-nodb_8.2.0.46.exe'
    '8.2.1.408' = 'EFT-nodb_8.2.1.408.exe'
    '8.3.0.410' = 'EFT-nodb_8.3.0.410.exe'
    '8.3.2.565' = 'EFT-nodb_8.3.2.565.exe'
}

# Hop sequence per server
$HopSequence = @{
    'ENA-INEFT01.in.lab' = @('8.1.0.16','8.2.0.46','8.2.1.408','8.3.0.410','8.3.2.565')
    'ENA-INEFT03.in.lab' = @('8.0.7.4','8.1.0.16','8.2.0.46','8.2.1.408','8.3.0.410','8.3.2.565')
}

# --- Helpers ---
function Write-Log {
    param($msg, $color = 'White')
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $msg"
    Write-Host $entry -ForegroundColor $color
    Add-Content -Path $LogPath -Value $entry
}

function Get-EFTVersion {
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        $r = Get-ItemProperty 'HKLM:\SOFTWARE\Globalscape\EFT Server' -EA SilentlyContinue
        if (-not $r) { $r = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Globalscape\EFT Server' -EA SilentlyContinue }
        $r.DisplayVersion
    }
}

function Get-ServiceStatus {
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        (Get-Service -Name 'EFT Server' -EA SilentlyContinue).Status
    }
}

function Backup-Config {
    param($version)
    $dest = "$ConfigBackup\Backup_pre_$version-$(Get-Date -Format 'yyyyMMdd-HHmm')"
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($src, $dst)
        if (Test-Path $src) {
            Copy-Item $src $dst -Recurse -Force
            Write-Host "  Config backed up to $dst"
        } else {
            Write-Host "  ⚠️ Config path not found: $src"
        }
    } -ArgumentList $ConfigBackup, $dest
}

# --- Start ---
New-Item -Path $LogPath -ItemType File -Force | Out-Null
Write-Log "=== EFT Upgrade Started on $TargetServer ===" Cyan

$currentVersion = Get-EFTVersion
Write-Log "Current version: $currentVersion"

$hops = $HopSequence[$TargetServer]
if (-not $hops) { Write-Log "❌ No hop sequence for $TargetServer" Red; exit }

Write-Log "Upgrade path: $currentVersion > $($hops -join ' > ')"

# Confirm
Write-Host "`n⚠️  Ready to upgrade $TargetServer" -ForegroundColor Yellow
$confirm = Read-Host "Type YES to begin"
if ($confirm -ne 'YES') { Write-Log "Cancelled by user" Yellow; exit }

# --- Hop Loop ---
foreach ($targetVersion in $hops) {

    if ($currentVersion -ge $targetVersion) {
        Write-Log "Skipping $targetVersion - already on $currentVersion" Yellow
        continue
    }

    Write-Log "--- Hop: $currentVersion > $targetVersion ---" Cyan

    # Backup
    Write-Log "Backing up config..."
    Backup-Config -version $currentVersion

    # Check installer
    $installer     = $Installers[$targetVersion]
    $installerPath = "$InstallerBase\$installer"
    $exists = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock { param($p); Test-Path $p } -ArgumentList $installerPath

    if (-not $exists) {
        Write-Log "❌ Installer not found: $installerPath" Red
        Write-Log "   Copy $installer to D:\temp\ on $TargetServer and re-run" Red
        exit
    }

    # Run installer
    Write-Log "Running $installer..."
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($path, $log)
        Start-Process -FilePath $path -ArgumentList "/S /log $log" -Wait
    } -ArgumentList $installerPath, "D:\temp\install_$targetVersion.log"

    # Restart service
    Write-Log "Restarting EFT service..."
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        Restart-Service -Name 'EFT Server' -Force -EA SilentlyContinue
        Start-Sleep -Seconds 15
    }

    # Check service
    $status = Get-ServiceStatus
    Write-Log "Service status: $status"
    if ($status -ne 'Running') {
        Write-Log "❌ Service not running after hop to $targetVersion - check D:\temp\install_$targetVersion.log" Red
        exit
    }

    # Verify version
    $newVersion = Get-EFTVersion
    Write-Log "Version confirmed: $newVersion $(if ($newVersion -eq $targetVersion) {'✅'} else {'⚠️ mismatch'})"

    # Manual console check
    Write-Host "`n================================================================" -ForegroundColor Magenta
    Write-Host "  MANUAL STEP - Hop to $targetVersion complete" -ForegroundColor Magenta
    Write-Host "================================================================" -ForegroundColor Magenta
    Write-Host "  1. Open EFT Admin Console > connect to $TargetServer" -ForegroundColor White
    Write-Host "  2. Confirm site shows RUNNING" -ForegroundColor White
    Write-Host "  3. Confirm licensed modules still active" -ForegroundColor White
    Write-Host "  4. Quick WinSCP test connection on port 22" -ForegroundColor White
    Write-Host "================================================================`n" -ForegroundColor Magenta

    $check = Read-Host "Type OK to continue to next hop, or ABORT to stop"
    if ($check -eq 'ABORT') { Write-Log "Aborted after $targetVersion" Yellow; exit }

    Write-Log "Console confirmed for $targetVersion ✅" Green
    $currentVersion = $newVersion
}

Write-Log "=== Upgrade Complete - Final version: $currentVersion ===" Green
Write-Host "`n✅ All hops complete on $TargetServer" -ForegroundColor Green
Write-Host "Next: Run Script 5 to apply cipher config" -ForegroundColor Cyan