﻿$servers = @('SERVER01','SERVER02','SERVER03')

Invoke-Command -ComputerName $servers -ScriptBlock {
    Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -Recurse | 
    Get-ItemProperty -Name Version -EA 0 | 
    Where-Object { $_.Version -match '^\d' } | 
    Select-Object PSChildName, Version | 
    Sort-Object Version -Descending | 
    Select-Object -First 1
} | Select-Object PSComputerName, PSChildName, Version | Sort-Object PSComputerName