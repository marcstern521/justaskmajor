# ============================================================
# Wave 1 - Script 6 - Post Upgrade Validation
# Run after ALL Wave 1 servers upgraded + cipher config applied
# Requires Nmap installed on management machine
# ============================================================

$EFTServers = @(
    'AAA-QWEFT01.inucn.com'
    'HY1-INCDR01.inucn.com'
    'MB1-INCDR01.inucn.com'
    'SP4-INCDR01.inucn.com'
    'SP4-INCDR02.inucn.com'
    'SGP-INCDR01.inucn.com'
    'SGP-INCDR02.inucn.com'
    'TY6-INCDR01.inucn.com'
    'TY6-INCDR02.inucn.com'
)

$DMZServers = @(
    'AAA-INFTP01.inucn.com'
)

$ServiceNames = @{
    'AAA-QWEFT01.inucn.com' = 'EFT Server Enterprise'
}
$DefaultServiceName = 'EFT Server'

$creds        = Get-Credential
$NmapPath     = 'C:\Program Files (x86)\Nmap\nmap.exe'
$ReportPath   = "C:\temp\globalscape\wave1_validation_$(Get-Date -Format 'yyyyMMdd').csv"
$TargetEFTVer = '8.3.2.565'
$Results      = @()

New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null

Write-Host "`n=== Wave 1 Post Upgrade Validation ===" -ForegroundColor Cyan

# --- EFT Servers ---
foreach ($server in $EFTServers) {
    Write-Host "`nValidating EFT: $server" -ForegroundColor Yellow
    $svcName = if ($ServiceNames[$server]) { $ServiceNames[$server] } else { $DefaultServiceName }

    try {
        $data = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {
            param($svcName)
            $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                Get-ItemProperty -EA SilentlyContinue |
                Where-Object { $_.DisplayName -like '*EFT*' } |
                Select-Object -First 1
            $svc = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -EA SilentlyContinue
            [PSCustomObject]@{
                EFTVersion    = $reg.DisplayVersion
                ServiceStatus = $svc.State
            }
        } -ArgumentList $svcName

        $versionOK = $data.EFTVersion -eq $TargetEFTVer
        $serviceOK = $data.ServiceStatus -eq 'Running'

        Write-Host "  Version: $(if ($data.EFTVersion) {$data.EFTVersion} else {'verify in admin console'}) $(if ($versionOK) {'✅'} else {'⚠️'})"
        Write-Host "  Service: $($data.ServiceStatus) $(if ($serviceOK) {'✅'} else {'❌'})"

    } catch {
        Write-Host "  ❌ Cannot connect" -ForegroundColor Red
        $data      = [PSCustomObject]@{ EFTVersion = 'UNREACHABLE'; ServiceStatus = 'UNREACHABLE' }
        $versionOK = $false
        $serviceOK = $false
    }

    # Nmap SSH scan
    Write-Host "  Running Nmap SSH scan..."
    $nmapOut = & $NmapPath -p 22 --script ssh2-enum-algos $server 2>&1

    $hasEd25519 = [bool]($nmapOut -match 'ssh-ed25519')
    $hasEcdsa   = [bool]($nmapOut -match 'ecdsa-sha2-nistp256')
    $hasRsaSha2 = [bool]($nmapOut -match 'rsa-sha2-256')
    $hasCBC     = [bool]($nmapOut -match '-cbc')
    $has3DES    = [bool]($nmapOut -match '3des')
    $hasSHA1    = [bool]($nmapOut -match 'hmac-sha1[^-]|hmac-sha1$')
    $hasMD5     = [bool]($nmapOut -match 'hmac-md5')

    Write-Host "  ssh-ed25519:         $(if ($hasEd25519) {'✅'} else {'❌ MISSING - add host key in admin console'})"
    Write-Host "  ecdsa-sha2-nistp256: $(if ($hasEcdsa)   {'✅'} else {'❌ MISSING - add host key in admin console'})"
    Write-Host "  rsa-sha2-256:        $(if ($hasRsaSha2) {'✅'} else {'❌ MISSING'})"
    Write-Host "  CBC ciphers:         $(if ($hasCBC)     {'⚠️  Present (intentional - pending exception list)'} else {'✅ Removed'})"
    Write-Host "  3des-cbc:            $(if ($has3DES)    {'⚠️  Present (intentional - pending exception list)'} else {'✅ Removed'})"
    Write-Host "  SHA1 MACs:           $(if ($hasSHA1)    {'⚠️  Present (intentional - pending exception list)'} else {'✅ Removed'})"
    Write-Host "  MD5 MACs:            $(if ($hasMD5)     {'❌ Still present - check AdvancedProperties.json'} else {'✅ Removed'})"

    $overallPass = ($serviceOK -and $hasEd25519 -and $hasEcdsa -and $hasRsaSha2 -and -not $hasMD5)

    $Results += [PSCustomObject]@{
        Server           = $server
        Role             = 'EFT'
        Version          = $data.EFTVersion
        ServiceRunning   = $serviceOK
        HasEd25519       = $hasEd25519
        HasEcdsa256      = $hasEcdsa
        HasRsaSha2       = $hasRsaSha2
        CBCPresent       = $hasCBC
        TripleDESPresent = $has3DES
        SHA1Present      = $hasSHA1
        MD5Removed       = -not $hasMD5
        OverallPass      = $overallPass
    }
}

# --- DMZ Servers ---
foreach ($server in $DMZServers) {
    Write-Host "`nValidating DMZ: $server" -ForegroundColor Yellow
    try {
        $svc = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {
            $reg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
            if (-not $reg) { $reg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
            if (-not $reg) {
                $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                    Get-ItemProperty -EA SilentlyContinue |
                    Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
                    Select-Object -First 1
            }
            $s = Get-WmiObject Win32_Service -EA SilentlyContinue |
                Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
                Select-Object -First 1
            [PSCustomObject]@{
                DMZVersion    = $reg.DisplayVersion
                ServiceName   = $s.Name
                ServiceStatus = $s.State
            }
        }
        $serviceOK = $svc.ServiceStatus -eq 'Running'
        Write-Host "  DMZ Version: $(if ($svc.DMZVersion) {$svc.DMZVersion} else {'check admin console'})"
        Write-Host "  Service:     $($svc.ServiceName) - $($svc.ServiceStatus) $(if ($serviceOK) {'✅'} else {'❌'})"
        $Results += [PSCustomObject]@{
            Server = $server; Role = 'DMZ'
            Version = $svc.DMZVersion; ServiceRunning = $serviceOK; OverallPass = $serviceOK
        }
    } catch {
        Write-Host "  ❌ Cannot connect" -ForegroundColor Red
        $Results += [PSCustomObject]@{
            Server = $server; Role = 'DMZ'; Version = 'UNREACHABLE'; ServiceRunning = $false; OverallPass = $false
        }
    }
}

# --- Export & Summary ---
$Results | Export-Csv -Path $ReportPath -NoTypeInformation
Write-Host "`n✅ Report saved to $ReportPath" -ForegroundColor Green

Write-Host "`n=== Wave 1 Summary ===" -ForegroundColor Cyan
$pass = ($Results | Where-Object { $_.OverallPass }).Count
$fail = ($Results | Where-Object { -not $_.OverallPass }).Count
Write-Host "  Passed: $pass / $($Results.Count)" -ForegroundColor Green
if ($fail -gt 0) {
    Write-Host "  Failed: $fail" -ForegroundColor Red
    $Results | Where-Object { -not $_.OverallPass } | ForEach-Object { Write-Host "    ❌ $($_.Server)" -ForegroundColor Red }
} else {
    Write-Host "`n✅ All Wave 1 servers passed!" -ForegroundColor Green
    Write-Host "   Share report with Dusty / Lyle / SysSecOps to close out Wave 1" -ForegroundColor Cyan
}
Write-Host "`nNOTE: CBC/3DES/SHA1 shown as warnings - intentionally kept pending Bryant customer exception list" -ForegroundColor Yellow
