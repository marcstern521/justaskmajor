# ============================================================
# Wave 1 - DMZ Upgrade - AAA-INFTP01.inucn.com
# Single hop: 3.5.0.35 -> 4.x
# Run AFTER EFT upgrade on AAA-QWEFT01 is complete
# ============================================================

$TargetServer  = 'AAA-INFTP01.inucn.com'
$InstallerPath = 'D:\temp\dmz-gateway-windows-x86-64.exe'
$LogPath       = "C:\temp\globalscape\wave1_dmz_upgrade_INFTP01_$(Get-Date -Format 'yyyyMMdd').txt"
$creds         = Get-Credential

New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null
New-Item -Path $LogPath -ItemType File -Force | Out-Null

function Write-Log {
    param($msg, $color = 'White')
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $msg"
    Write-Host $entry -ForegroundColor $color
    Add-Content -Path $LogPath -Value $entry
}

Write-Log "=== DMZ Gateway Upgrade Started on $TargetServer ===" Cyan

# Check current version
$current = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    $r = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
    if (-not $r) { $r = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
    if (-not $r) {
        $r = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
            Get-ItemProperty -EA SilentlyContinue |
            Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
            Select-Object -First 1
    }
    $svc = Get-WmiObject Win32_Service -EA SilentlyContinue |
        Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
        Select-Object -First 1
    [PSCustomObject]@{
        Version        = $r.DisplayVersion
        ServiceName    = $svc.Name
        ServiceStatus  = $svc.State
        ServiceAccount = $svc.StartName
    }
}

Write-Log "Current DMZ version: $($current.Version)"
Write-Log "Service: $($current.ServiceName) - $($current.ServiceStatus) / Account: $($current.ServiceAccount)"

# Check installer exists
$exists = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($p); Test-Path $p
} -ArgumentList $InstallerPath

if (-not $exists) {
    Write-Log "❌ Installer not found at $InstallerPath" Red
    Write-Log "   Copy dmz-gateway-windows-x86-64.exe to D:\temp\ on $TargetServer" Red
    exit
}

# Confirm
Write-Host "`n⚠️  PRODUCTION - Ready to upgrade DMZ Gateway on $TargetServer" -ForegroundColor Red
Write-Host "   Current version: $($current.Version)" -ForegroundColor Yellow
Write-Host "   Confirm CR is approved and AAA-QWEFT01 EFT upgrade is complete first" -ForegroundColor Yellow
$confirm = Read-Host "Type YES to begin"
if ($confirm -ne 'YES') { Write-Log "Cancelled by user" Yellow; exit }

Write-Log "⚠️  Service account ($($current.ServiceAccount)) will reset to Local System during upgrade" Yellow

# Run installer
Write-Log "Running DMZ Gateway installer..."
Write-Log "NOTE: If it hangs - RDP in and run D:\temp\dmz-gateway-windows-x86-64.exe manually"
Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($path)
    Start-Process -FilePath $path -ArgumentList '/S' -Wait
} -ArgumentList $InstallerPath

# Wait
Write-Log "Waiting 45 seconds for service to start..."
Start-Sleep -Seconds 45

# Check post-upgrade
$postUpgrade = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    $svc = Get-WmiObject Win32_Service -EA SilentlyContinue |
        Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
        Select-Object -First 1
    [PSCustomObject]@{
        ServiceName    = $svc.Name
        ServiceStatus  = $svc.State
        ServiceAccount = $svc.StartName
    }
}

Write-Log "Post-upgrade service: $($postUpgrade.ServiceName) - $($postUpgrade.ServiceStatus)"
if ($postUpgrade.ServiceAccount -eq 'LocalSystem') {
    Write-Log "⚠️  Service account reset to LocalSystem - was $($current.ServiceAccount)" Yellow
    Write-Log "   Update if a specific service account is required" Yellow
}

# Manual verification
Write-Host "`n================================================================" -ForegroundColor Magenta
Write-Host "  MANUAL STEP - DMZ Upgrade Complete" -ForegroundColor Magenta
Write-Host "================================================================" -ForegroundColor Magenta
Write-Host "  1. Confirm DMZ version in admin console on $TargetServer" -ForegroundColor White
Write-Host "  2. From EFT Admin Console on AAA-QWEFT01 - confirm Gateway" -ForegroundColor White
Write-Host "     shows Connected under Server > Gateway" -ForegroundColor White
Write-Host "  3. Run a WinSCP test SFTP connection" -ForegroundColor White
Write-Host "================================================================`n" -ForegroundColor Magenta

$check = Read-Host "Type OK when verified or ABORT if issues"
if ($check -eq 'ABORT') {
    Write-Log "Issues reported post DMZ upgrade" Red
    Write-Log "Rollback: revert snapshot Pre-Globalscape-Wave1-Upgrade" Yellow
    exit
}

Write-Log "DMZ upgrade on $TargetServer confirmed ✅" Green
Write-Log "=== DMZ Gateway Upgrade Complete ===" Green
Write-Host "`n✅ AAA-INFTP01 DMZ upgrade done!" -ForegroundColor Green
Write-Host "Run W1_6_Validation.ps1 to validate all Wave 1 servers" -ForegroundColor Cyan
