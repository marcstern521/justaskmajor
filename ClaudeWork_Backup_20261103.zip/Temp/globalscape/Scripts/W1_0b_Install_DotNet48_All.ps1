# ============================================================
# Wave 1 - Install .NET 4.8 on servers that need it
# Servers needing .NET 4.8:
#   SP4-INCDR01, SP4-INCDR02
#   SGP-INCDR01
#   TY6-INCDR01, TY6-INCDR02
#
# All servers have internet access - downloads directly
# Reboots each server after install and waits for it to come back
# ============================================================

$ServersNeedingDotNet = @(
    'SP4-INCDR01.inucn.com'
    'SP4-INCDR02.inucn.com'
    'SGP-INCDR01.inucn.com'
    'TY6-INCDR01.inucn.com'
    'TY6-INCDR02.inucn.com'
)

$creds   = Get-Credential
$Results = @()

Write-Host "`n=== .NET 4.8 Install - Wave 1 Servers ===" -ForegroundColor Cyan
Write-Host "Targets: $($ServersNeedingDotNet -join ', ')`n"

foreach ($server in $ServersNeedingDotNet) {
    Write-Host "Processing: $server" -ForegroundColor Yellow

    try {
        # Check current version
        $current = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {
            (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -EA SilentlyContinue).Version
        }
        Write-Host "  Current .NET: $current"

        if ($current -ge '4.8') {
            Write-Host "  ✅ Already on 4.8 or higher - skipping" -ForegroundColor Green
            $Results += [PSCustomObject]@{ Server = $server; Status = 'Already 4.8'; Before = $current; After = $current }
            continue
        }

        # Download installer on the remote server
        Write-Host "  Downloading .NET 4.8 installer on $server..."
        Invoke-Command -ComputerName $server -Credential $creds -ScriptBlock {
            New-Item -ItemType Directory -Path 'D:\temp' -Force | Out-Null
            Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/?linkid=2088631' -OutFile 'D:\temp\ndp48-web.exe' -UseBasicParsing
            Write-Host "  Download complete"
        }

        # Install silently
        Write-Host "  Installing .NET 4.8 - this takes 3-5 minutes..."
        Invoke-Command -ComputerName $server -Credential $creds -ScriptBlock {
            Start-Process -FilePath 'D:\temp\ndp48-web.exe' -ArgumentList '/quiet /norestart /log D:\temp\dotnet48_install.log' -Wait
            Write-Host "  Install complete"
        }

        # Reboot and wait for server to come back
        Write-Host "  Rebooting $server and waiting for it to come back..." -ForegroundColor Yellow
        Restart-Computer -ComputerName $server -Credential $creds -Force -Wait -For WinRM -Timeout 300 -Delay 15
        Write-Host "  $server is back online ✅" -ForegroundColor Green

        # Verify new version
        $newVersion = Invoke-Command -ComputerName $server -Credential $creds -ScriptBlock {
            (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -EA SilentlyContinue).Version
        }

        $success = $newVersion -ge '4.8'
        Write-Host "  New .NET version: $newVersion $(if ($success) {'✅'} else {'❌ Install may have failed'})"

        if (-not $success) {
            Write-Host "  Check install log: D:\temp\dotnet48_install.log on $server" -ForegroundColor Yellow
        }

        $Results += [PSCustomObject]@{
            Server = $server
            Status = if ($success) { 'Success' } else { 'Failed - check log' }
            Before = $current
            After  = $newVersion
        }

    } catch {
        Write-Host "  ❌ Error on $server - $_" -ForegroundColor Red
        $Results += [PSCustomObject]@{
            Server = $server
            Status = "FAILED: $_"
            Before = 'Unknown'
            After  = 'Unknown'
        }
    }

    Write-Host ""
}

# Summary
Write-Host "`n=== .NET 4.8 Install Summary ===" -ForegroundColor Cyan
$Results | Format-Table -AutoSize

$failed = $Results | Where-Object { $_.Status -notlike 'Success*' -and $_.Status -notlike 'Already*' }
if ($failed) {
    Write-Host "⚠️  $($failed.Count) server(s) failed - resolve before running EFT upgrade" -ForegroundColor Red
    $failed | ForEach-Object { Write-Host "    ❌ $($_.Server)" -ForegroundColor Red }
} else {
    Write-Host "✅ All servers ready for EFT upgrade" -ForegroundColor Green
    Write-Host "Next: Run W1_4_EFT_Hop_Upgrade.ps1 per server" -ForegroundColor Cyan
}
