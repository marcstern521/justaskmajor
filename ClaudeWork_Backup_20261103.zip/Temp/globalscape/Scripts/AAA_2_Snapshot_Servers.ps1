# ============================================================
# AAA - Script 2 - VMware Snapshots
# Snapshots AAA-QWEFT01 and AAA-INFTP01 before any changes
# Includes auto-connect to vCenter if session is not active
# ============================================================

$vCenterServer = 'lax-vmvce01.inucn.com'
$SnapshotName  = "Pre-Globalscape-AAA-Upgrade-$(Get-Date -Format 'yyyy-MM-dd')"
$SnapshotDesc  = "Pre-upgrade snapshot - Globalscape EFT/DMZ AAA upgrade - SCTASK0126730"

$VMs = @(
    'AAA-QWEFT01'
    'AAA-INFTP01'
)

# --- Check / Connect to vCenter ---
Write-Host "`n=== Checking vCenter Connection ===" -ForegroundColor Cyan

$connected = $global:DefaultVIServers | Where-Object { $_.Name -eq $vCenterServer -and $_.IsConnected -eq $true }

if ($connected) {
    Write-Host "Already connected to $vCenterServer as $($connected.User)" -ForegroundColor Green
} else {
    Write-Host "Not connected to $vCenterServer - connecting now..." -ForegroundColor Yellow
    try {
        Connect-VIServer -Server $vCenterServer -Credential (Get-Credential) -ErrorAction Stop
        Write-Host "Connected to $vCenterServer" -ForegroundColor Green
    } catch {
        Write-Host "Failed to connect to vCenter: $_" -ForegroundColor Red
        Write-Host "   Check that lax-vmvce01.inucn.com is reachable and credentials are correct"
        exit
    }
}

# --- Verify VMs exist ---
Write-Host "`nVerifying VMs in vCenter..." -ForegroundColor Yellow
$foundVMs   = @()
$missingVMs = @()

foreach ($vm in $VMs) {
    $found = Get-VM -Name $vm -EA SilentlyContinue
    if ($found) {
        $foundVMs += $vm
        Write-Host "  $vm - $($found.PowerState)"
    } else {
        $missingVMs += $vm
        Write-Host "  $vm not found in vCenter - check VM name" -ForegroundColor Red
    }
}

if ($missingVMs.Count -gt 0) {
    Write-Host "`n$($missingVMs.Count) VM(s) not found - do not proceed until resolved" -ForegroundColor Red
    exit
}

# --- Confirm ---
Write-Host ""
$proceed = Read-Host "Both VMs confirmed. Type YES to take snapshots"
if ($proceed -ne 'YES') {
    Write-Host "Exiting - no snapshots taken"
    exit
}

# --- Take snapshots ---
Write-Host "`n=== Taking Snapshots ===" -ForegroundColor Cyan
$allGood = $true

foreach ($vm in $foundVMs) {
    Write-Host "Snapshotting $vm..." -ForegroundColor Yellow
    try {
        $snap = New-Snapshot -VM $vm -Name $SnapshotName -Description $SnapshotDesc -Memory:$false -Quiesce:$false -Confirm:$false -ErrorAction Stop
        Write-Host "  Done - $($snap.Name) at $($snap.Created)" -ForegroundColor Green
    } catch {
        Write-Host "  Failed - $_" -ForegroundColor Red
        $allGood = $false
    }
}

# --- Summary ---
Write-Host ""
if ($allGood) {
    Write-Host "All snapshots successful - safe to proceed" -ForegroundColor Green
    Write-Host "Snapshot name: $SnapshotName" -ForegroundColor Cyan
    Write-Host "Next: Run AAA_3_Push_Installers.ps1" -ForegroundColor Cyan
} else {
    Write-Host "One or more snapshots failed - DO NOT proceed until resolved" -ForegroundColor Red
}
