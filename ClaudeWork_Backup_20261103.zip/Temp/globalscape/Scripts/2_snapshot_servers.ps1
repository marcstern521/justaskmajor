﻿# ============================================================
# Script 2 - VMware Snapshots
# NOTE: Already completed 04/02/2026 - kept for reference
# Snapshot name: Pre-Globalscape-Upgrade-2026-04-02
# ============================================================

$vCenterServer = 'eng-vmvce01.in.lab'
$SnapshotName  = "Pre-Globalscape-Upgrade-$(Get-Date -Format 'yyyy-MM-dd')"
$SnapshotDesc  = "Pre-upgrade snapshot before Globalscape EFT/DMZ lab upgrade - SCTASK0126730"
$LabVMs        = @('ena-ineft01','ena-ineft03','ena-inftp01','ena-inftp03')

Connect-VIServer -Server $vCenterServer -Credential (Get-Credential)

foreach ($vm in $LabVMs) {
    Write-Host "Snapshotting $vm..." -ForegroundColor Yellow
    try {
        $snapshot = New-Snapshot -VM $vm -Name $SnapshotName -Description $SnapshotDesc -Memory:$false -Quiesce:$false -Confirm:$false
        Write-Host "  ✅ Done - $($snapshot.Name) at $($snapshot.Created)" -ForegroundColor Green
    } catch {
        Write-Host "  ❌ Failed - $_" -ForegroundColor Red
    }
}

Disconnect-VIServer -Server $vCenterServer -Confirm:$false