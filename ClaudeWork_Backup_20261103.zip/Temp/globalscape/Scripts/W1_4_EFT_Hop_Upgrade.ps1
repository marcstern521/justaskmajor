# ============================================================
# Wave 1 - Script 4 - EFT Hop-by-Hop Upgrade
# Run once per server - change $TargetServer each time
#
# Upgrade paths (all servers same path from 8.0.6.x or 8.0.7.x):
#   8.0.6.x: 8.1.0.16 > 8.2.0.46 > 8.2.1.408 > 8.3.0.410 > 8.3.2.565
#   8.0.7.x: 8.1.0.16 > 8.2.0.46 > 8.2.1.408 > 8.3.0.410 > 8.3.2.565
#
# BEFORE RUNNING:
#   1. Snapshots confirmed (Script 2)
#   2. .NET 4.8 installed where needed (Script 3)
#   3. All installers copied to D:\temp\ on each target server
#   4. CR approved and scheduled
# ============================================================

# --- UPDATE THIS per server ---
$TargetServer = 'HY1-INCDR01.inucn.com'

# Service name - update for AAA-QWEFT01 only
$ServiceNames = @{
    'AAA-QWEFT01.inucn.com' = 'EFT Server Enterprise'
}
$ServiceName = if ($ServiceNames[$TargetServer]) { $ServiceNames[$TargetServer] } else { 'EFT Server' }

# Install paths
$InstallPaths = @{
    'AAA-QWEFT01.inucn.com' = 'D:\Program Files (x86)\Globalscape\EFT Server Enterprise'
}
$InstallPath  = if ($InstallPaths[$TargetServer]) { $InstallPaths[$TargetServer] } else { 'D:\Program Files (x86)\Globalscape\EFT Server' }
$ConfigBackup = "$InstallPath\Server Config"
$InstallerBase = 'D:\temp'
$LogPath      = "C:\temp\globalscape\wave1_upgrade_log_$(($TargetServer -split '\.')[0])_$(Get-Date -Format 'yyyyMMdd').txt"

$creds = Get-Credential

# Installers - update filenames if different from what's in D:\temp
$Installers = [ordered]@{
    '8.1.0.16'  = 'EFT-nodb_8.1.0.16.exe'
    '8.2.0.46'  = 'EFT-nodb_8.2.0.46.exe'
    '8.2.1.408' = 'EFT-nodb_8.2.1.408.exe'
    '8.3.0.410' = 'EFT-nodb_8.3.0.410.exe'
    '8.3.2.565' = 'EFT-nodb_8.3.2.565.exe'
}

# All Wave 1 servers use same hop sequence
$HopSequence = @('8.1.0.16','8.2.0.46','8.2.1.408','8.3.0.410','8.3.2.565')

# --- Helpers ---
function Write-Log {
    param($msg, $color = 'White')
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $msg"
    Write-Host $entry -ForegroundColor $color
    Add-Content -Path $LogPath -Value $entry
}

function Get-EFTVersion {
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        $r = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
            Get-ItemProperty -EA SilentlyContinue |
            Where-Object { $_.DisplayName -like '*EFT*' } |
            Select-Object -First 1
        $r.DisplayVersion
    }
}

function Get-ServiceStatus {
    param($svcName)
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($n)
        (Get-WmiObject Win32_Service -Filter "Name='$n'" -EA SilentlyContinue).State
    } -ArgumentList $svcName
}

function Backup-Config {
    param($version)
    $dest = "$ConfigBackup\Backup_pre_$version-$(Get-Date -Format 'yyyyMMdd-HHmm')"
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($src, $dst)
        if (Test-Path $src) {
            Copy-Item $src $dst -Recurse -Force
            Write-Host "  Config backed up to $dst"
        } else {
            Write-Host "  ⚠️ Config path not found: $src - skipping backup"
        }
    } -ArgumentList $ConfigBackup, $dest
}

# --- Start ---
New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null
New-Item -Path $LogPath -ItemType File -Force | Out-Null

Write-Log "=== EFT Upgrade Started ===" Cyan
Write-Log "Server:       $TargetServer"
Write-Log "Service name: $ServiceName"
Write-Log "Install path: $InstallPath"

$currentVersion = Get-EFTVersion
Write-Log "Current version: $currentVersion" Yellow
Write-Log "Upgrade path: $currentVersion > $($HopSequence -join ' > ')"

# Confirm
Write-Host "`n⚠️  PRODUCTION SERVER - Ready to upgrade $TargetServer" -ForegroundColor Red
Write-Host "   Confirm CR is approved and maintenance window is active" -ForegroundColor Yellow
$confirm = Read-Host "Type YES to begin"
if ($confirm -ne 'YES') { Write-Log "Cancelled by user" Yellow; exit }

# --- Hop Loop ---
foreach ($targetVersion in $HopSequence) {

    if ($currentVersion -ge $targetVersion) {
        Write-Log "Skipping $targetVersion - already on $currentVersion" Yellow
        continue
    }

    Write-Log "--- Hop: $currentVersion > $targetVersion ---" Cyan

    # Backup config
    Write-Log "Backing up config..."
    Backup-Config -version $currentVersion

    # Check installer on remote server
    $installer     = $Installers[$targetVersion]
    $installerPath = "$InstallerBase\$installer"

    $exists = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($p); Test-Path $p
    } -ArgumentList $installerPath

    if (-not $exists) {
        Write-Log "❌ Installer not found at $installerPath on $TargetServer" Red
        Write-Log "   Copy $installer to D:\temp\ on $TargetServer and re-run" Red
        exit
    }

    # Run installer
    Write-Log "Running $installer - this will take a few minutes..."
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($path, $logfile)
        Start-Process -FilePath $path -ArgumentList "/S /log $logfile" -Wait
    } -ArgumentList $installerPath, "D:\temp\install_$targetVersion.log"

    # Wait for service
    Write-Log "Waiting 45 seconds for service to stabilize..."
    Start-Sleep -Seconds 45

    # Check service
    $status = Get-ServiceStatus -svcName $ServiceName
    Write-Log "Service status: $status $(if ($status -eq 'Running') {'✅'} else {'⚠️'})"

    if ($status -ne 'Running') {
        Write-Log "⚠️  Service not showing Running - check admin console manually" Yellow
        Write-Log "   Install log: D:\temp\install_$targetVersion.log on $TargetServer" Yellow
    }

    # Manual console check
    Write-Host "`n================================================================" -ForegroundColor Magenta
    Write-Host "  MANUAL STEP - Hop to $targetVersion" -ForegroundColor Magenta
    Write-Host "================================================================" -ForegroundColor Magenta
    Write-Host "  1. Open EFT Admin Console > connect to $TargetServer" -ForegroundColor White
    Write-Host "  2. Confirm version shows $targetVersion in title bar" -ForegroundColor White
    Write-Host "  3. Confirm site shows RUNNING" -ForegroundColor White
    Write-Host "  4. Confirm licensed modules still show Standard License" -ForegroundColor White
    Write-Host "================================================================`n" -ForegroundColor Magenta

    $check = Read-Host "Type OK to continue or ABORT to stop and investigate"
    if ($check -eq 'ABORT') {
        Write-Log "Aborted by user after hop to $targetVersion" Yellow
        Write-Log "Rollback option: revert to snapshot Pre-Globalscape-Wave1-Upgrade-$(Get-Date -Format 'yyyy-MM-dd')" Yellow
        exit
    }

    Write-Log "Hop to $targetVersion confirmed OK ✅" Green
    $currentVersion = Get-EFTVersion
    if (-not $currentVersion) { $currentVersion = $targetVersion }
}

Write-Log "=== Upgrade Complete on $TargetServer ===" Green
Write-Host "`n✅ All hops complete on $TargetServer" -ForegroundColor Green
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Run Script 5 to apply cipher config (if approved)" -ForegroundColor White
Write-Host "  2. Manually add host keys in EFT Admin Console" -ForegroundColor White
Write-Host "  3. Run Script 6 to validate" -ForegroundColor White
Write-Host "  4. Change TargetServer and repeat for next server" -ForegroundColor White
