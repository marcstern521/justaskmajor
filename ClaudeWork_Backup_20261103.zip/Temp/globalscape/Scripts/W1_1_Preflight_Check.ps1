# ============================================================
# Wave 1 - Script 1 - Pre-Flight Check
# Targets: AAA-QWEFT01, HY1-INCDR01, MB1-INCDR01,
#          SP4-INCDR01/02, SGP-INCDR01/02, TY6-INCDR01/02
#          DMZ: AAA-INFTP01
# Run BEFORE anything else - no changes made
# ============================================================

$EFTServers = @(
    'AAA-QWEFT01.inucn.com'
    'HY1-INCDR01.inucn.com'
    'MB1-INCDR01.inucn.com'
    'SP4-INCDR01.inucn.com'
    'SP4-INCDR02.inucn.com'
    'SGP-INCDR01.inucn.com'
    'SGP-INCDR02.inucn.com'
    'TY6-INCDR01.inucn.com'
    'TY6-INCDR02.inucn.com'
)

$DMZServers = @(
    'AAA-INFTP01.inucn.com'
)

# Service name varies per server
$ServiceNames = @{
    'AAA-QWEFT01.inucn.com' = 'EFT Server Enterprise'
}
$DefaultServiceName = 'EFT Server'

# Install paths vary per server
$InstallPaths = @{
    'AAA-QWEFT01.inucn.com' = 'D:\Program Files (x86)\Globalscape\EFT Server Enterprise'
}
$DefaultInstallPath = 'D:\Program Files (x86)\Globalscape\EFT Server'

$ReportPath = "C:\temp\globalscape\wave1_preflight_$(Get-Date -Format 'yyyyMMdd').csv"
$Results    = @()
$creds      = Get-Credential

New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null

Write-Host "`n=== Wave 1 Pre-Flight Check ===" -ForegroundColor Cyan
Write-Host "Checking $($EFTServers.Count) EFT servers + $($DMZServers.Count) DMZ server`n"

# --- EFT Servers ---
foreach ($server in $EFTServers) {
    Write-Host "Checking EFT: $server" -ForegroundColor Yellow
    $svcName     = if ($ServiceNames[$server]) { $ServiceNames[$server] } else { $DefaultServiceName }
    $installPath = if ($InstallPaths[$server]) { $InstallPaths[$server] } else { $DefaultInstallPath }

    try {
        $data = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {
            param($svcName, $installPath)

            $eft = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                Get-ItemProperty -EA SilentlyContinue |
                Where-Object { $_.DisplayName -like '*EFT*' } |
                Select-Object -First 1

            $dotnet  = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -EA SilentlyContinue
            $svc     = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -EA SilentlyContinue
            $cDrive  = Get-PSDrive C -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            $dDrive  = Get-PSDrive D -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            $ram     = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2)
            $os      = (Get-CimInstance Win32_OperatingSystem).Caption
            $apPath  = "$installPath\AdvancedProperties.json"

            [PSCustomObject]@{
                EFTVersion      = $eft.DisplayVersion
                ServiceStatus   = $svc.State
                ServiceAccount  = $svc.StartName
                DotNetVersion   = $dotnet.Version
                DotNet48Ready   = ($dotnet.Version -ge '4.8')
                CDriveFreeGB    = $cDrive.FreeGB
                DDriveFreeGB    = if ($dDrive) { $dDrive.FreeGB } else { 'No D drive' }
                RAM             = $ram
                OS              = $os
                APJsonExists    = (Test-Path $apPath)
                InstallPath     = $installPath
            }
        } -ArgumentList $svcName, $installPath

        $data | Add-Member -NotePropertyName Server -NotePropertyValue $server
        $Results += $data

        Write-Host "  EFT Version:    $($data.EFTVersion)"
        Write-Host "  Service:        $($data.ServiceStatus) / $($data.ServiceAccount)"
        Write-Host "  .NET:           $($data.DotNetVersion) $(if ($data.DotNet48Ready) {'✅'} else {'❌ NEEDS 4.8 before upgrade'})"
        Write-Host "  C: Free:        $($data.CDriveFreeGB) GB"
        Write-Host "  D: Free:        $($data.DDriveFreeGB) GB"
        Write-Host "  RAM:            $($data.RAM) GB"
        Write-Host "  Install Path:   $($data.InstallPath)"
        Write-Host "  AP.json exists: $($data.APJsonExists)`n"

    } catch {
        Write-Host "  ❌ UNREACHABLE - $_`n" -ForegroundColor Red
        $Results += [PSCustomObject]@{
            Server = $server; EFTVersion = 'UNREACHABLE'
            ServiceStatus = 'UNREACHABLE'; DotNet48Ready = $false
        }
    }
}

# --- DMZ Servers ---
foreach ($server in $DMZServers) {
    Write-Host "Checking DMZ: $server" -ForegroundColor Yellow
    try {
        $data = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {
            $dmzReg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
            if (-not $dmzReg) { $dmzReg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
            if (-not $dmzReg) {
                $dmzReg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                    Get-ItemProperty -EA SilentlyContinue |
                    Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
                    Select-Object -First 1
            }
            $svc    = Get-WmiObject Win32_Service -EA SilentlyContinue |
                Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
                Select-Object -First 1
            $cDrive = Get-PSDrive C -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            $dDrive = Get-PSDrive D -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}

            [PSCustomObject]@{
                DMZVersion     = $dmzReg.DisplayVersion
                ServiceName    = $svc.Name
                ServiceStatus  = $svc.State
                ServiceAccount = $svc.StartName
                CDriveFreeGB   = $cDrive.FreeGB
                DDriveFreeGB   = if ($dDrive) { $dDrive.FreeGB } else { 'No D drive' }
                OS             = (Get-CimInstance Win32_OperatingSystem).Caption
            }
        }

        Write-Host "  DMZ Version:    $($data.DMZVersion)"
        Write-Host "  Service:        $($data.ServiceName) - $($data.ServiceStatus) / $($data.ServiceAccount)"
        Write-Host "  C: Free:        $($data.CDriveFreeGB) GB"
        Write-Host "  D: Free:        $($data.DDriveFreeGB) GB`n"

    } catch {
        Write-Host "  ❌ UNREACHABLE - $_`n" -ForegroundColor Red
    }
}

# --- Export ---
$Results | Export-Csv -Path $ReportPath -NoTypeInformation
Write-Host "✅ Report saved to $ReportPath" -ForegroundColor Green

# --- Action Items ---
Write-Host "`n=== Action Items ===" -ForegroundColor Cyan
$Results | Where-Object { $_.DotNet48Ready -eq $false } | ForEach-Object {
    Write-Host "  ❌ $($_.Server) — needs .NET 4.8 before upgrade" -ForegroundColor Red
}
$Results | Where-Object { $_.DotNet48Ready -eq $true -and $_.EFTVersion -ne 'UNREACHABLE' } | ForEach-Object {
    Write-Host "  ✅ $($_.Server) — .NET 4.8 ready" -ForegroundColor Green
}
