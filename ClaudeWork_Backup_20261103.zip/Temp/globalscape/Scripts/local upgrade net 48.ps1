﻿# Download and install .NET 4.8 silently
$url = "https://go.microsoft.com/fwlink/?linkid=2088631"
$installer = "C:\temp\ndp48-web.exe"
Invoke-WebRequest -Uri $url -OutFile $installer
Start-Process -FilePath $installer -ArgumentList "/quiet /norestart" -Wait