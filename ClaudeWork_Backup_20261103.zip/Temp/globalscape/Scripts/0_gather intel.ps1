﻿$creds = Get-Credential

$servers = @(
    '172.29.1.24',
     '172.29.1.34',
      '172.29.1.34',
    '172.29.1.25'
)

foreach ($server in $servers) {
    Write-Host "`n=== $server ===" -ForegroundColor Cyan
    try {
        Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {

            # EFT Version
            $eft = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                Get-ItemProperty -EA SilentlyContinue |
                Where-Object { $_.DisplayName -like '*EFT*' } |
                Select-Object -First 1
            
            # Also try executable path
            $svc = Get-WmiObject Win32_Service -Filter "Name='EFT Server'" -EA SilentlyContinue

            # .NET version
            $dotnet = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -EA SilentlyContinue

            # Disk space
            $c = Get-PSDrive C -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            $d = Get-PSDrive D -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}

            # OS
            $os = (Get-CimInstance Win32_OperatingSystem).Caption

            # RAM
            $ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2)

            Write-Host "  EFT Version:    $($eft.DisplayVersion)"
            Write-Host "  EFT Install:    $($svc.PathName)"
            Write-Host "  Service Status: $($svc.State)"
            Write-Host "  .NET Version:   $($dotnet.Version)"
            Write-Host "  OS:             $os"
            Write-Host "  RAM:            $ram GB"
            Write-Host "  C: Free:        $($c.FreeGB) GB"
            Write-Host "  D: Free:        $(if ($d) {$d.FreeGB} else {'No D drive'}) GB"

        }
    } catch {
        Write-Host "  UNREACHABLE - $_" -ForegroundColor Red
    }
}