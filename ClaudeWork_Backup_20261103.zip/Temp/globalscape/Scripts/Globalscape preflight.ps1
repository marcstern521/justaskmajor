﻿$creds = Get-Credential

$DMZServers = @('DAL-QMFTP01.inucn.com','AFA-INFTP01.inucn.com')

foreach ($server in $DMZServers) {
    Write-Host "`n=== $server ===" -ForegroundColor Cyan
    try {
        Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {
            $reg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
            if (-not $reg) { $reg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
            if (-not $reg) {
                $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                    Get-ItemProperty -EA SilentlyContinue |
                    Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
                    Select-Object -First 1
            }
            $svc    = Get-WmiObject Win32_Service -EA SilentlyContinue |
                      Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
                      Select-Object -First 1
            $cDrive = Get-PSDrive C | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            $dDrive = Get-PSDrive D -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}

            Write-Host "  DMZ Version:    $($reg.DisplayVersion)"
            Write-Host "  Service Name:   $($svc.Name)"
            Write-Host "  Service Status: $($svc.State)"
            Write-Host "  Service Acct:   $($svc.StartName)"
            Write-Host "  OS:             $((Get-CimInstance Win32_OperatingSystem).Caption)"
            Write-Host "  C: Free:        $($cDrive.FreeGB) GB"
            Write-Host "  D: Free:        $(if ($dDrive) {$dDrive.FreeGB} else {'No D drive'}) GB"
        }
    } catch {
        Write-Host "  UNREACHABLE - $_" -ForegroundColor Red
    }
}