﻿# ============================================================
# DMZ Gateway Upgrade - ENA-INFTP01.in.lab
# Single hop: 3.5.0.35 -> 4.x
# Run from your laptop
# ============================================================

$TargetServer  = 'ENA-INFTP01.in.lab'
$InstallerPath = 'D:\temp\dmz-gateway-windows-x86-64.exe'
$LogPath       = "C:\temp\globalscape\upgrade_log_INFTP01_$(Get-Date -Format 'yyyyMMdd').txt"

# --- Helpers ---
function Write-Log {
    param($msg, $color = 'White')
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $msg"
    Write-Host $entry -ForegroundColor $color
    Add-Content -Path $LogPath -Value $entry
}

function Get-DMZService {
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        Get-WmiObject Win32_Service | 
        Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.Name -like '*globalscape*' } | 
        Select-Object Name, State, StartName
    }
}

# --- Start ---
New-Item -Path "C:\temp\globalscape" -ItemType Directory -Force | Out-Null
New-Item -Path $LogPath -ItemType File -Force | Out-Null

Write-Log "=== DMZ Gateway Upgrade Started on $TargetServer ===" Cyan

# Check current DMZ version
Write-Log "Checking current DMZ version..."
$currentVersion = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    $r = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
    if (-not $r) { $r = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
    if (-not $r) {
        # Try uninstall key
        $r = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
            Get-ItemProperty -EA SilentlyContinue |
            Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
            Select-Object -First 1
    }
    $r.DisplayVersion
}
Write-Log "Current DMZ version: $currentVersion"

# Check service before upgrade
Write-Log "Checking DMZ service status..."
$svcBefore = Get-DMZService
Write-Log "Service before upgrade: $($svcBefore.Name) - $($svcBefore.State) - Account: $($svcBefore.StartName)"

# Check installer exists
$installerExists = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($p); Test-Path $p
} -ArgumentList $InstallerPath

if (-not $installerExists) {
    Write-Log "❌ Installer not found at $InstallerPath on $TargetServer" Red
    Write-Log "   Copy dmz-gateway-windows-x86-64.exe to D:\temp\ and re-run" Red
    exit
}

# Confirm
Write-Host "`n⚠️  Ready to upgrade DMZ Gateway on $TargetServer" -ForegroundColor Yellow
Write-Host "   Current version: $currentVersion" -ForegroundColor Yellow
Write-Host "   Snapshot confirmed: Pre-Globalscape-Upgrade-2026-04-02" -ForegroundColor Yellow
$confirm = Read-Host "Type YES to begin"
if ($confirm -ne 'YES') { Write-Log "Cancelled by user" Yellow; exit }

# Note service account before upgrade
Write-Log "⚠️  Note: DMZ service account will reset to Local System during upgrade" Yellow
Write-Log "   Current account: $($svcBefore.StartName) - document if not Local System" Yellow

# Run installer
Write-Log "Running DMZ Gateway installer - this will take a few minutes..."
Write-Log "NOTE: If it hangs like EFT did, RDP in and run manually from D:\temp\"
Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($path)
    Start-Process -FilePath $path -ArgumentList '/S' -Wait
} -ArgumentList $InstallerPath

# Wait for service
Write-Log "Waiting 45 seconds for service to start..."
Start-Sleep -Seconds 45

# Check service after
Write-Log "Checking DMZ service post-upgrade..."
$svcAfter = Get-DMZService
Write-Host ""
if ($svcAfter) {
    Write-Log "Service after upgrade: $($svcAfter.Name) - $($svcAfter.State)" 
    if ($svcAfter.State -eq 'Running') {
        Write-Log "✅ DMZ service is running" Green
    } else {
        Write-Log "⚠️  DMZ service not running - check manually" Yellow
    }
    if ($svcAfter.StartName -eq 'LocalSystem') {
        Write-Log "⚠️  Service account reset to Local System - was: $($svcBefore.StartName)" Yellow
    }
} else {
    Write-Log "⚠️  Could not detect DMZ service - check manually via RDP" Yellow
}

# Manual verification
Write-Host "`n================================================================" -ForegroundColor Magenta
Write-Host "  MANUAL STEP - DMZ Upgrade Complete" -ForegroundColor Magenta
Write-Host "================================================================" -ForegroundColor Magenta
Write-Host "  RDP into $TargetServer and verify:" -ForegroundColor White
Write-Host "  1. DMZ Gateway admin console shows new version" -ForegroundColor White
Write-Host "  2. DMZ service is running" -ForegroundColor White
Write-Host "  3. From EFT Admin Console on Server - check Gateway" -ForegroundColor White
Write-Host "     shows connected under Server > Gateway" -ForegroundColor White
Write-Host "================================================================`n" -ForegroundColor Magenta

$check = Read-Host "Type OK when verified or ABORT if issues"
if ($check -eq 'ABORT') {
    Write-Log "Issues reported post DMZ upgrade - investigate before proceeding" Red
    Write-Log "Rollback option: revert to snapshot Pre-Globalscape-Upgrade-2026-04-02" Yellow
    exit
}

Write-Log "DMZ upgrade on $TargetServer confirmed ✅" Green
Write-Log "=== DMZ Gateway Upgrade Complete ===" Green
Write-Host "`n✅ DMZ upgrade done!" -ForegroundColor Green
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Verify EFT > Gateway connection from INEFT01 admin console" -ForegroundColor White
Write-Host "  2. Run a test SFTP connection" -ForegroundColor White
Write-Host "  3. Let SysOps know ready for testing" -ForegroundColor White