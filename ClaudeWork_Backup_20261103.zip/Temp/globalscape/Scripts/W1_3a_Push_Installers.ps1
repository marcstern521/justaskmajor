﻿# ============================================================
# Wave 1 - Push Installers to All Servers
# Copies EFT installers from your laptop to D:\temp\ on each server
# Source: C:\Temp\globalscape\ on your laptop
# Destination: D:\temp\ on each remote server
# ============================================================

$SourcePath = 'C:\Temp\globalscape'

$EFTServers = @(
    'AAA-QWEFT01.inucn.com'
    'HY1-INCDR01.inucn.com'
    'MB1-INCDR01.inucn.com'
    'SP4-INCDR01.inucn.com'
    'SP4-INCDR02.inucn.com'
    'SGP-INCDR01.inucn.com'
    'SGP-INCDR02.inucn.com'
    'TY6-INCDR01.inucn.com'
    'TY6-INCDR02.inucn.com'
    'AAA-INFTP01.inucn.com'   # DMZ - needs DMZ installer
)

# Files to copy - EFT installers + DMZ installer
$FilesToCopy = @(
    'EFT-nodb_8.1.0.16.exe'
    'EFT-nodb_8.2.0.46.exe'
    'EFT-nodb_8.2.1.408.exe'
    'EFT-nodb_8.3.0.410.exe'
    'EFT-nodb_8.3.2.565.exe'
    'dmz-gateway-windows-x86-64.exe'
)

$creds   = Get-Credential
$Results = @()

Write-Host "`n=== Pushing Installers to Wave 1 Servers ===" -ForegroundColor Cyan
Write-Host "Source: $SourcePath"
Write-Host "Files:  $($FilesToCopy.Count) installers"
Write-Host "Target: $($EFTServers.Count) servers`n"

# Verify source files exist before starting
Write-Host "Verifying source files on laptop..." -ForegroundColor Yellow
$missingFiles = @()
foreach ($file in $FilesToCopy) {
    $fullPath = Join-Path $SourcePath $file
    if (Test-Path $fullPath) {
        $size = [math]::Round((Get-Item $fullPath).Length/1MB, 1)
        Write-Host "  ✅ $file ($size MB)"
    } else {
        Write-Host "  ❌ MISSING: $file" -ForegroundColor Red
        $missingFiles += $file
    }
}

if ($missingFiles.Count -gt 0) {
    Write-Host "`n❌ $($missingFiles.Count) file(s) missing from $SourcePath - resolve before continuing" -ForegroundColor Red
    exit
}

Write-Host "`nAll source files verified - starting copy...`n" -ForegroundColor Green

# Copy to each server
foreach ($server in $EFTServers) {
    Write-Host "Copying to: $server" -ForegroundColor Yellow
    $serverStart = Get-Date

    try {
        # Open PSSession
        $session = New-PSSession -ComputerName $server -Credential $creds -ErrorAction Stop

        # Create D:\temp if it doesn't exist
        Invoke-Command -Session $session -ScriptBlock {
            New-Item -ItemType Directory -Path 'D:\temp' -Force | Out-Null
        }

        # Copy files
        $serverErrors = 0
        foreach ($file in $FilesToCopy) {

            # Skip DMZ installer for EFT-only servers (not AAA-INFTP01)
            # Skip EFT installers for DMZ-only server (AAA-INFTP01)
            if ($server -eq 'AAA-INFTP01.inucn.com' -and $file -notlike '*dmz*') { continue }

            $sourceFull = Join-Path $SourcePath $file
            try {
                Write-Host "  Copying $file..." -NoNewline
                Copy-Item -Path $sourceFull -Destination 'D:\temp\' -ToSession $session -Force
                Write-Host " ✅" -ForegroundColor Green
            } catch {
                Write-Host " ❌ Failed - $_" -ForegroundColor Red
                $serverErrors++
            }
        }

        # Verify files arrived
        $remoteFiles = Invoke-Command -Session $session -ScriptBlock {
            Get-ChildItem 'D:\temp\' -Filter '*.exe' | Select-Object Name, @{N='SizeMB';E={[math]::Round($_.Length/1MB,1)}}
        }

        $elapsed = [math]::Round(((Get-Date) - $serverStart).TotalSeconds, 0)
        Write-Host "  Files on server ($($elapsed)s):"
        $remoteFiles | ForEach-Object { Write-Host "    $($_.Name) ($($_.SizeMB) MB)" }

        Remove-PSSession $session

        $Results += [PSCustomObject]@{
            Server   = $server
            Status   = if ($serverErrors -eq 0) { 'Success' } else { "Partial - $serverErrors errors" }
            FileCount = $remoteFiles.Count
            Elapsed  = "${elapsed}s"
        }

    } catch {
        Write-Host "  ❌ Cannot connect - $_" -ForegroundColor Red
        $Results += [PSCustomObject]@{
            Server    = $server
            Status    = "FAILED: $_"
            FileCount = 0
            Elapsed   = 'N/A'
        }
    }

    Write-Host ""
}

# Summary
Write-Host "`n=== Copy Summary ===" -ForegroundColor Cyan
$Results | Format-Table -AutoSize

$failed = $Results | Where-Object { $_.Status -notlike 'Success*' }
if ($failed) {
    Write-Host "⚠️  $($failed.Count) server(s) had issues - resolve before running upgrade scripts" -ForegroundColor Red
} else {
    Write-Host "✅ All installers pushed successfully - ready to run W1_3_Install_DotNet48.ps1" -ForegroundColor Green
}