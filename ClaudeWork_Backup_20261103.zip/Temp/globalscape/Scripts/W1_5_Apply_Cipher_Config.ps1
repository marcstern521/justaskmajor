# ============================================================
# Wave 1 - Script 5 - Apply SSH Cipher Config
# Run AFTER EFT is on 8.3.2.565 and validated
# Adds modern algorithms - does NOT remove legacy ones yet
# (legacy removal pending Bryant customer exception list)
# ============================================================

# --- UPDATE THIS per server ---
$TargetServer = 'HY1-INCDR01.inucn.com'

# Install paths
$InstallPaths = @{
    'AAA-QWEFT01.inucn.com' = 'D:\Program Files (x86)\Globalscape\EFT Server Enterprise'
}
$InstallPath = if ($InstallPaths[$TargetServer]) { $InstallPaths[$TargetServer] } else { 'D:\Program Files (x86)\Globalscape\EFT Server' }
$APJsonPath  = "$InstallPath\AdvancedProperties.json"
$BackupPath  = "$InstallPath\AdvancedProperties_backup_$(Get-Date -Format 'yyyyMMdd-HHmm').json"

# Service name
$ServiceNames = @{
    'AAA-QWEFT01.inucn.com' = 'EFT Server Enterprise'
}
$ServiceName = if ($ServiceNames[$TargetServer]) { $ServiceNames[$TargetServer] } else { 'EFT Server' }

$creds = Get-Credential

# Approved cipher config - adding modern, NOT removing legacy yet
$ApprovedCiphers = "aes256-gcm@openssh.com,aes128-gcm@openssh.com,chacha20-poly1305@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr"
$ApprovedKEX     = "curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group16-sha512,diffie-hellman-group-exchange-sha256,diffie-hellman-group14-sha1"

Write-Host "`n⚠️  PRODUCTION - Confirm approvals before running:" -ForegroundColor Red
Write-Host "   SysArch: Lyle May ✅ 03/30/2026" -ForegroundColor Green
Write-Host "   Compliance: Stuart Kirkham ✅ 04/06/2026" -ForegroundColor Green
Write-Host "   Note: Legacy algorithms kept intentionally until Bryant exception list confirmed" -ForegroundColor Yellow
$approval = Read-Host "`nType APPROVED to continue"
if ($approval -ne 'APPROVED') { Write-Host "Exiting" Yellow; exit }

Write-Host "`n=== Applying Cipher Config on $TargetServer ===" -ForegroundColor Cyan

Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($apPath, $backupPath, $ciphers, $kex)

    # Backup
    if (Test-Path $apPath) {
        Copy-Item $apPath $backupPath -Force
        Write-Host "✅ Backed up to $backupPath"
    } else {
        Write-Host "⚠️  AdvancedProperties.json not found - will create new"
    }

    # Load or create
    $ap = if (Test-Path $apPath) { Get-Content $apPath -Raw | ConvertFrom-Json } else { [PSCustomObject]@{} }

    # Apply modern cipher settings
    $ap | Add-Member -NotePropertyName 'SftpClientCiphers'       -NotePropertyValue $ciphers -Force
    $ap | Add-Member -NotePropertyName 'SftpClientKexAlgorithms' -NotePropertyValue $kex     -Force

    # Disable only the most dangerous - MD5 (SHA1/CBC kept pending exception list)
    $ap | Add-Member -NotePropertyName 'SFTP2_MD5'    -NotePropertyValue $false -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_MD5_96' -NotePropertyValue $false -Force

    $ap | ConvertTo-Json -Depth 10 | Set-Content $apPath -Force
    Write-Host "✅ AdvancedProperties.json updated"

} -ArgumentList $APJsonPath, $BackupPath, $ApprovedCiphers, $ApprovedKEX

# Restart service
Write-Host "Restarting EFT service ($ServiceName)..." -ForegroundColor Yellow
Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($svcName)
    Restart-Service -Name $svcName -Force -EA SilentlyContinue
    Start-Sleep -Seconds 30
    $status = (Get-WmiObject Win32_Service -Filter "Name='$svcName'").State
    Write-Host "Service status: $status"
} -ArgumentList $ServiceName

Write-Host "`n✅ Cipher config applied on $TargetServer" -ForegroundColor Green
Write-Host "`n⚠️  MANUAL STEP REQUIRED:" -ForegroundColor Yellow
Write-Host "  Open EFT Admin Console on $TargetServer" -ForegroundColor White
Write-Host "  Site > Properties > Security > SFTP Settings" -ForegroundColor White
Write-Host "  Click CREATE > ED25519 (256) > Add to site > Finish" -ForegroundColor White
Write-Host "  Click CREATE > ECDSA (256) > Add to site > Finish" -ForegroundColor White
Write-Host "  Click Apply then restart service" -ForegroundColor White
Write-Host "`nThen run Script 6 to validate" -ForegroundColor Cyan
