# ============================================================
# AAA - Script 3 - Push Installers to Servers
# Copies installers from your laptop C:\Temp\globalscape\
# to D:\temp\ on AAA-QWEFT01 and AAA-INFTP01
# ============================================================

$SourcePath = 'C:\Temp\globalscape'
$creds      = Get-Credential

# EFT installers - all 5 hops needed
$EFTFiles = @(
    'EFT-nodb_8.1.0.16.exe'
    'EFT-nodb_8.2.0.46.exe'
    'EFT-nodb_8.2.1.408.exe'
    'EFT-nodb_8.3.0.410.exe'
    'EFT-nodb_8.3.2.565.exe'
)

# DMZ installer
# $DMZFiles = @(
#    'dmz-gateway-windows-x86-64.exe'
# )

Write-Host "`n=== Pushing Installers to AAA Servers ===" -ForegroundColor Cyan

# Verify all source files exist first
Write-Host "`nVerifying source files on laptop..." -ForegroundColor Yellow
$missing = @()
foreach ($file in ($EFTFiles + $DMZFiles)) {
    $path = Join-Path $SourcePath $file
    if (Test-Path $path) {
        $size = [math]::Round((Get-Item $path).Length/1MB, 1)
        Write-Host "  ✅ $file ($size MB)"
    } else {
        Write-Host "  ❌ MISSING: $file" -ForegroundColor Red
        $missing += $file
    }
}

if ($missing.Count -gt 0) {
    Write-Host "`n❌ $($missing.Count) file(s) missing from $SourcePath - resolve before continuing" -ForegroundColor Red
    exit
}

Write-Host "`nAll files verified - starting copy...`n" -ForegroundColor Green

# --- Push EFT installers to AAA-QWEFT01 ---
$eftServer = 'AAA-INEFT01.inucn.com'
Write-Host "Copying EFT installers to $eftServer..." -ForegroundColor Yellow
try {
    $session = New-PSSession -ComputerName $eftServer -Credential $creds -ErrorAction Stop
    Invoke-Command -Session $session -ScriptBlock { New-Item -ItemType Directory -Path 'D:\temp' -Force | Out-Null }

    foreach ($file in $EFTFiles) {
        Write-Host "  Copying $file..." -NoNewline
        Copy-Item -Path (Join-Path $SourcePath $file) -Destination 'D:\temp\' -ToSession $session -Force
        Write-Host " ✅" -ForegroundColor Green
    }

    # Verify
    $remoteFiles = Invoke-Command -Session $session -ScriptBlock {
        Get-ChildItem 'D:\temp\' -Filter '*.exe' | Select-Object Name, @{N='SizeMB';E={[math]::Round($_.Length/1MB,1)}}
    }
    Write-Host "  Files confirmed on $eftServer`:"
    $remoteFiles | ForEach-Object { Write-Host "    $($_.Name) ($($_.SizeMB) MB)" }
    Remove-PSSession $session

} catch {
    Write-Host "  ❌ Failed on $eftServer - $_" -ForegroundColor Red
}

Write-Host ""

# --- Push DMZ installer to AAA-INFTP01 ---
#$dmzServer = 'AAA-INFTP01.inucn.com'
# Write-Host "Copying DMZ installer to $dmzServer..." -ForegroundColor Yellow
# try {
 #   $session = New-PSSession -ComputerName $dmzServer -Credential $creds -ErrorAction Stop
 #   Invoke-Command -Session $session -ScriptBlock { New-Item -ItemType Directory -Path 'D:\temp' -Force | Out-Null }
#
#    foreach ($file in $DMZFiles) {
#        Write-Host "  Copying $file..." -NoNewline
#       Copy-Item -Path (Join-Path $SourcePath $file) -Destination 'D:\temp\' -ToSession $session -Force
#       Write-Host " ✅" -ForegroundColor Green
#    }

    # Verify
 #   $remoteFiles = Invoke-Command -Session $session -ScriptBlock {
 #       Get-ChildItem 'D:\temp\' -Filter '*.exe' | Select-Object Name, @{N='SizeMB';E={[math]::Round($_.Length/1MB,1)}}
 #   }
 #   Write-Host "  Files confirmed on $dmzServer`:"
 #   $remoteFiles | ForEach-Object { Write-Host "    $($_.Name) ($($_.SizeMB) MB)" }
 #   Remove-PSSession $session
#
#} catch {
#    Write-Host "  ❌ Failed on $dmzServer - $_" -ForegroundColor Red
#}

Write-Host "`n✅ All installers pushed" -ForegroundColor Green
Write-Host "Next: Run AAA_4_EFT_Hop_Upgrade.ps1" -ForegroundColor Cyan
