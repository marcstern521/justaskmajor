# ============================================================
# Wave 1 - Script 2 - VMware Snapshots
# Run BEFORE any upgrades
# Requires PowerCLI connected to vCenter
# Connect first: Connect-VIServer -Server your-vcenter -Credential (Get-Credential)
# ============================================================

$vCenterServer = 'lax-vmvce01.inucn.com/'   # UPDATE THIS for prod vCenter

$SnapshotName = "Pre-Globalscape-Wave1-Upgrade-$(Get-Date -Format 'yyyy-MM-dd')"
$SnapshotDesc = "Pre-upgrade snapshot Wave 1 - Globalscape EFT upgrade - SCTASK0126730"

# VM names as they appear in vCenter (may differ from FQDN - verify first)
$Wave1VMs = @(
    'AAA-QWEFT01'
    'HY1-INCDR01'
    'MB1-INCDR01'
    'SP4-INCDR01'
    'SP4-INCDR02'
    'SGP-INCDR01'
    'SGP-INCDR02'
    'TY6-INCDR01'
    'TY6-INCDR02'
    'AAA-INFTP01'   # DMZ
)

# Connect to vCenter
Write-Host "`n=== Connecting to vCenter ===" -ForegroundColor Cyan
try {
    Connect-VIServer -Server $vCenterServer -Credential (Get-Credential) -ErrorAction Stop
    Write-Host "✅ Connected to $vCenterServer" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed to connect: $_" -ForegroundColor Red
    exit
}

# Verify VMs exist before snapshotting
Write-Host "`nVerifying VMs in vCenter..." -ForegroundColor Yellow
$foundVMs   = @()
$missingVMs = @()
foreach ($vm in $Wave1VMs) {
    $found = Get-VM -Name $vm -EA SilentlyContinue
    if ($found) {
        $foundVMs += $vm
        Write-Host "  ✅ Found: $vm ($($found.PowerState))"
    } else {
        $missingVMs += $vm
        Write-Host "  ❌ Not found: $vm - check VM name in vCenter" -ForegroundColor Red
    }
}

if ($missingVMs.Count -gt 0) {
    Write-Host "`n⚠️  $($missingVMs.Count) VMs not found in vCenter" -ForegroundColor Yellow
    Write-Host "   These may have different names in vCenter than their hostnames" -ForegroundColor Yellow
    $proceed = Read-Host "Proceed with snapshotting the $($foundVMs.Count) found VMs? (y/n)"
    if ($proceed -ne 'y') { exit }
}

# Take snapshots
Write-Host "`n=== Taking Snapshots ===" -ForegroundColor Cyan
$Results = @()
foreach ($vm in $foundVMs) {
    Write-Host "Snapshotting $vm..." -ForegroundColor Yellow
    try {
        $snap = New-Snapshot -VM $vm -Name $SnapshotName -Description $SnapshotDesc -Memory:$false -Quiesce:$false -Confirm:$false -ErrorAction Stop
        Write-Host "  ✅ Done - $($snap.Name) at $($snap.Created)" -ForegroundColor Green
        $Results += [PSCustomObject]@{ VM = $vm; Status = 'Success'; Created = $snap.Created; SnapshotName = $snap.Name }
    } catch {
        Write-Host "  ❌ Failed - $_" -ForegroundColor Red
        $Results += [PSCustomObject]@{ VM = $vm; Status = "FAILED: $_"; Created = 'N/A'; SnapshotName = $SnapshotName }
    }
}

# Summary
Write-Host "`n=== Snapshot Summary ===" -ForegroundColor Cyan
$Results | Format-Table -AutoSize
$failed = $Results | Where-Object { $_.Status -ne 'Success' }
if ($failed) {
    Write-Host "⚠️  $($failed.Count) snapshot(s) failed - resolve before proceeding" -ForegroundColor Red
} else {
    Write-Host "✅ All snapshots successful - safe to proceed with upgrades" -ForegroundColor Green
}

Disconnect-VIServer -Server $vCenterServer -Confirm:$false
