﻿# ============================================================
# Script 1 - Globalscape Lab Pre-Flight Check
# Targets: ENA-INEFT01, ENA-INEFT03, ENA-INFTP01, ENA-INFTP03
# ============================================================

$EFTServers = @('ENA-INEFT01.in.lab','ENA-INEFT03.in.lab')
$DMZServers = @('ENA-INFTP01.in.lab','ENA-INFTP03.in.lab')
$ReportPath = 'D:\temp\preflight_report.csv'
$Results    = @()
$creds      = Get-Credential

Write-Host "`n=== Globalscape Lab Pre-Flight Check ===" -ForegroundColor Cyan

foreach ($server in $EFTServers) {
    Write-Host "Checking EFT: $server" -ForegroundColor Yellow
    try {
        $data = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {
            $eftReg = Get-ItemProperty 'HKLM:\SOFTWARE\Globalscape\EFT Server' -EA SilentlyContinue
            if (-not $eftReg) { $eftReg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Globalscape\EFT Server' -EA SilentlyContinue }
            $dotnet = Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP' -Recurse | Get-ItemProperty -Name Version -EA 0 | Where-Object { $_.PSChildName -eq 'Full' } | Select-Object -First 1
            $svc    = Get-WmiObject Win32_Service -Filter "Name='EFT Server'" -EA SilentlyContinue
            $dDrive = Get-PSDrive D -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            $cDrive = Get-PSDrive C | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            [PSCustomObject]@{
                Role           = 'EFT'
                EFTVersion     = $eftReg.DisplayVersion
                DotNetVersion  = $dotnet.Version
                DotNet48Ready  = ($dotnet.Version -ge '4.8')
                ServiceAccount = $svc.StartName
                ServiceStatus  = $svc.State
                CDriveFreeGB   = $cDrive.FreeGB
                DDriveFreeGB   = if ($dDrive) { $dDrive.FreeGB } else { 'N/A' }
                RAM            = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2)
                OS             = (Get-CimInstance Win32_OperatingSystem).Caption
            }
        }
        $data | Add-Member -NotePropertyName Server -NotePropertyValue $server
        $Results += $data
        Write-Host "  EFT Version:  $($data.EFTVersion)"
        Write-Host "  .NET:         $($data.DotNetVersion) $(if ($data.DotNet48Ready) {'✅'} else {'❌ NEEDS 4.8'})"
        Write-Host "  Service:      $($data.ServiceStatus) / $($data.ServiceAccount)"
        Write-Host "  C: Free:      $($data.CDriveFreeGB) GB  |  D: Free: $($data.DDriveFreeGB) GB`n"
    } catch {
        Write-Host "  ❌ Cannot connect - $_`n" -ForegroundColor Red
    }
}

foreach ($server in $DMZServers) {
    Write-Host "Checking DMZ: $server" -ForegroundColor Yellow
    try {
        $data = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {
            $dmzReg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
            if (-not $dmzReg) { $dmzReg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
            $svc    = Get-WmiObject Win32_Service -Filter "Name LIKE '%DMZ%' OR Name LIKE '%Gateway%'" -EA SilentlyContinue | Select-Object -First 1
            $dDrive = Get-PSDrive D -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            $cDrive = Get-PSDrive C | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            [PSCustomObject]@{
                Role           = 'DMZ'
                DMZVersion     = $dmzReg.DisplayVersion
                ServiceAccount = $svc.StartName
                ServiceStatus  = $svc.State
                CDriveFreeGB   = $cDrive.FreeGB
                DDriveFreeGB   = if ($dDrive) { $dDrive.FreeGB } else { 'N/A' }
                RAM            = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2)
                OS             = (Get-CimInstance Win32_OperatingSystem).Caption
            }
        }
        $data | Add-Member -NotePropertyName Server -NotePropertyValue $server
        $Results += $data
        Write-Host "  DMZ Version:  $($data.DMZVersion)"
        Write-Host "  Service:      $($data.ServiceStatus) / $($data.ServiceAccount)"
        Write-Host "  C: Free:      $($data.CDriveFreeGB) GB  |  D: Free: $($data.DDriveFreeGB) GB`n"
    } catch {
        Write-Host "  ❌ Cannot connect - $_`n" -ForegroundColor Red
    }
}

$Results | Export-Csv -Path $ReportPath -NoTypeInformation
Write-Host "✅ Report saved to $ReportPath" -ForegroundColor Green
Write-Host "`n=== Action Items ===" -ForegroundColor Cyan
$Results | Where-Object { $_.DotNet48Ready -eq $false -and $_.Role -eq 'EFT' } | ForEach-Object { Write-Host "  ❌ $($_.Server) needs .NET 4.8" -ForegroundColor Red }
$Results | Where-Object { $_.DotNet48Ready -eq $true  -and $_.Role -eq 'EFT' } | ForEach-Object { Write-Host "  ✅ $($_.Server) ready" -ForegroundColor Green }