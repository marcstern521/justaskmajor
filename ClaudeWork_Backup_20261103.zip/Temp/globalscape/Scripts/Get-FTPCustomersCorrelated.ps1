# =============================================================================
# Get-FTPCustomersCorrelated.ps1
# Correlates GlobalSCAPE DMZ Gateway logs (port 21 client IPs) with EFT Server
# logs (BUS usernames) to identify real FTP customers by BUS ID + IP.
# Looks back 30 days. Saves results to C:\Temp\globalscape\
# =============================================================================
# USAGE:
#   Run from your laptop. Will prompt once for INUCN credentials.
#   .\Get-FTPCustomersCorrelated.ps1
# =============================================================================

# --- CREDENTIALS -------------------------------------------------------------
Write-Host "=== FTP Customer Correlation Report ===" -ForegroundColor Cyan
Write-Host "Enter your INUCN domain credentials (e.g. INUCN\marc.stern)`n"
$Credential = Get-Credential -Message "Enter your INUCN domain credentials"
if (-not $Credential) { Write-Error "No credentials provided. Exiting."; exit 1 }

# --- CONFIGURATION -----------------------------------------------------------
$LookbackDays   = 30
$CutoffDate     = (Get-Date).AddDays(-$LookbackDays)
$OutputDir      = "C:\Temp\globalscape"
$SummaryCSV     = "$OutputDir\FTP_BUS_Customers_Summary.csv"
$DetailCSV      = "$OutputDir\FTP_BUS_Customers_Detail.csv"
$NoMatchCSV     = "$OutputDir\FTP_BUS_Customers_NoMatch.csv"

# Correlation window: how many minutes either side of a DMZ event to look
# for a matching EFT log entry with the same client IP
$CorrelWindowMinutes = 5

# --- SERVER PAIRS ------------------------------------------------------------
$ServerPairs = @(
    @{
        DMZServer  = "Dal-inftp02"
        DMZDrive   = "c"
        DMZLogDir  = "Program Files\GlobalSCAPE\DMZ Gateway\logs"
        EFTServer  = "Dal-ineft02"
        EFTDrive   = "d"
        EFTLogDir  = "ProgramData\Globalscape\EFT Server Enterprise\Logs"
        EFTPrefix  = "ex"
        FTPHost    = "ftp4.inucn.com"
    },
    @{
        DMZServer  = "Dal-inftp03"
        DMZDrive   = "d"
        DMZLogDir  = "Program Files\GlobalSCAPE\DMZ Gateway\logs"
        EFTServer  = "Dal-ineft03"
        EFTDrive   = "d"
        EFTLogDir  = "ProgramData\Globalscape\EFT Server Enterprise\Logs"
        EFTPrefix  = "u_ex"
        FTPHost    = "ftp6.inucn.com"
    },
    @{
        DMZServer  = "Dal-inftp05"
        DMZDrive   = "d"
        DMZLogDir  = "Program Files\GlobalSCAPE\DMZ Gateway\logs"
        EFTServer  = "Dal-ineft05"
        EFTDrive   = "d"
        EFTLogDir  = "ProgramData\Globalscape\EFT Server\Logs"
        EFTPrefix  = "u_ex"
        FTPHost    = "ftp2.inucn.com"
    },
    @{
        DMZServer  = "Lax-inftp02"
        DMZDrive   = "c"
        DMZLogDir  = "Program Files\GlobalSCAPE\DMZ Gateway\logs"
        EFTServer  = "Lax-ineft02"
        EFTDrive   = "r"
        EFTLogDir  = "Program Files\GlobalScape\EFT Server\Server Config\Logs"
        EFTPrefix  = "u_ex"
        FTPHost    = "ftp3.inucn.com"
    },
    @{
        DMZServer  = "Fra-inftp01.ineur.eu"
        DMZDrive   = "d"
        DMZLogDir  = "Program Files\GlobalSCAPE\DMZ Gateway\logs"
        EFTServer  = "Fra-ineft01.ineur.eu"
        EFTDrive   = "d"
        EFTLogDir  = "ProgramData\Globalscape\EFT Server\Logs"
        EFTPrefix  = "ex"
        FTPHost    = "ftp1.incontact.eu"
    }
)

# --- HELPERS -----------------------------------------------------------------
$AuthedRoots = @{}

function Connect-UNC {
    param([string]$UNCRoot, [System.Management.Automation.PSCredential]$Cred)
    if ($AuthedRoots[$UNCRoot]) { return $true }
    & net use $UNCRoot /delete /yes 2>$null | Out-Null
    $out = & net use $UNCRoot /user:$($Cred.UserName) $($Cred.GetNetworkCredential().Password) 2>&1
    if ($LASTEXITCODE -eq 0) { $AuthedRoots[$UNCRoot] = $true; return $true }
    Write-Warning "    Auth failed for ${UNCRoot}: $out"
    return $false
}

function Disconnect-All {
    Write-Host "`n=== Cleaning up network sessions ===" -ForegroundColor Cyan
    foreach ($r in $AuthedRoots.Keys) {
        & net use $r /delete /yes 2>$null | Out-Null
        Write-Host "    Disconnected $r"
    }
}

# Safely open a file that may be locked by another process
function Open-SharedStream {
    param([string]$FilePath)
    try {
        $fs = [System.IO.FileStream]::new(
            $FilePath,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::ReadWrite)
        return [System.IO.StreamReader]::new($fs)
    } catch {
        return $null
    }
}

# --- PHASE 1: PARSE DMZ GATEWAY LOGS ----------------------------------------
Write-Host "`n=== PHASE 1: Collecting FTP (port 21) events from DMZ Gateway logs ===" -ForegroundColor Yellow

# Key: "ServerName|ClientIP|Date"  Value: list of DateTimes
$DMZEvents = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($Pair in $ServerPairs) {

    $UNCRoot = "\\$($Pair.DMZServer)\$($Pair.DMZDrive)`$"
    $LogPath = "$UNCRoot\$($Pair.DMZLogDir)"

    Write-Host "`n  DMZ: $($Pair.DMZServer)" -ForegroundColor Cyan
    Write-Host "       $LogPath"
    Write-Host "       Authenticating..." -NoNewline

    if (-not (Connect-UNC -UNCRoot $UNCRoot -Cred $Credential)) {
        Write-Host " FAILED" -ForegroundColor Red; continue
    }
    Write-Host " OK" -ForegroundColor Green

    if (-not (Test-Path $LogPath)) {
        Write-Warning "       Path not found after auth. Skipping."; continue
    }

    $LogFiles = Get-ChildItem -Path $LogPath -Filter 'DMZActivity*.log' -File |
        Where-Object { $_.LastWriteTime -ge $CutoffDate -or $_.Name -eq 'DMZActivity.log' } |
        Sort-Object LastWriteTime

    if (-not $LogFiles) { Write-Warning "       No DMZActivity log files found."; continue }
    Write-Host "       Found $($LogFiles.Count) file(s)."

    $fc = 0
    foreach ($File in $LogFiles) {
        $fc++
        Write-Progress -Activity "DMZ: $($Pair.DMZServer)" `
                       -Status "File $fc/$($LogFiles.Count): $($File.Name)" `
                       -PercentComplete (($fc / $LogFiles.Count) * 100)

        $reader = Open-SharedStream $File.FullName
        if (-not $reader) { Write-Warning "       Skipping $($File.Name) (locked)"; continue }

        try {
            while ($null -ne ($Line = $reader.ReadLine())) {
                if ($Line -notlike '*granted+access+to+client*') { continue }

                $Parts = $Line -split '\s+'
                if ($Parts.Count -lt 8) { continue }

                $DateStr     = $Parts[0]
                $TimeStr     = $Parts[1]
                $DestField   = $Parts[5]
                $ClientField = $Parts[7]

                if ($DestField   -notmatch ':(\d+)$') { continue }
                if ($Matches[1] -ne '21') { continue }

                if ($ClientField -notmatch '^/(\d{1,3}(?:\.\d{1,3}){3})') { continue }
                $ClientIP = $Matches[1]

                try {
                    $EventDT = [datetime]::ParseExact("$DateStr $TimeStr", 'yyyy-MM-dd HH:mm:ss', $null)
                } catch { continue }

                if ($EventDT -lt $CutoffDate) { continue }

                $DMZEvents.Add([PSCustomObject]@{
                    DMZServer  = $Pair.DMZServer
                    EFTServer  = $Pair.EFTServer
                    FTPHost    = $Pair.FTPHost
                    ClientIP   = $ClientIP
                    EventDT    = $EventDT
                    DateStr    = $DateStr
                })
            }
        } finally { $reader.Close(); $reader.Dispose() }
    }
    Write-Progress -Activity "DMZ: $($Pair.DMZServer)" -Completed
    Write-Host "       DMZ events collected so far: $($DMZEvents.Count)"
}

Write-Host "`n  Total DMZ FTP (port 21) events: $($DMZEvents.Count)" -ForegroundColor Green

# --- PHASE 2: PARSE EFT SERVER LOGS -----------------------------------------
Write-Host "`n=== PHASE 2: Collecting BUS usernames from EFT Server logs ===" -ForegroundColor Yellow

# Store EFT records: EFTServer -> list of {Username, ClientIP, EventDT}
$EFTRecords = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($Pair in $ServerPairs) {

    $UNCRoot = "\\$($Pair.EFTServer)\$($Pair.EFTDrive)`$"
    $LogPath = "$UNCRoot\$($Pair.EFTLogDir)"

    Write-Host "`n  EFT: $($Pair.EFTServer)" -ForegroundColor Cyan
    Write-Host "       $LogPath"
    Write-Host "       Authenticating..." -NoNewline

    if (-not (Connect-UNC -UNCRoot $UNCRoot -Cred $Credential)) {
        Write-Host " FAILED" -ForegroundColor Red; continue
    }
    Write-Host " OK" -ForegroundColor Green

    if (-not (Test-Path $LogPath)) {
        Write-Warning "       Path not found after auth. Skipping."; continue
    }

    $LogFiles = Get-ChildItem -Path $LogPath -Filter "$($Pair.EFTPrefix)*.log" -File |
        Where-Object { $_.LastWriteTime -ge $CutoffDate } |
        Sort-Object LastWriteTime

    if (-not $LogFiles) { Write-Warning "       No EFT log files found."; continue }
    Write-Host "       Found $($LogFiles.Count) file(s)."

    # EFT W3C log line format:
    # date time clientIP - username [sessionID]command path - status - bytes - port
    # We want lines where username looks like BUS\d+ and capture IP + datetime
    $EFTPattern = '^(?<Date>\d{4}-\d{2}-\d{2})\s+(?<Time>\d{2}:\d{2}:\d{2})\s+(?<IP>\d{1,3}(?:\.\d{1,3}){3})\s+-\s+(?<User>BUS\d+)\s+'

    $fc = 0
    foreach ($File in $LogFiles) {
        $fc++
        Write-Progress -Activity "EFT: $($Pair.EFTServer)" `
                       -Status "File $fc/$($LogFiles.Count): $($File.Name)" `
                       -PercentComplete (($fc / $LogFiles.Count) * 100)

        $reader = Open-SharedStream $File.FullName
        if (-not $reader) { Write-Warning "       Skipping $($File.Name) (locked)"; continue }

        try {
            while ($null -ne ($Line = $reader.ReadLine())) {
                if ($Line -notmatch $EFTPattern) { continue }

                $Username = $Matches['User']
                $ClientIP = $Matches['IP']
                $DateStr  = $Matches['Date']
                $TimeStr  = $Matches['Time']

                try {
                    $EventDT = [datetime]::ParseExact("$DateStr $TimeStr", 'yyyy-MM-dd HH:mm:ss', $null)
                } catch { continue }

                if ($EventDT -lt $CutoffDate) { continue }

                $EFTRecords.Add([PSCustomObject]@{
                    EFTServer = $Pair.EFTServer
                    FTPHost   = $Pair.FTPHost
                    Username  = $Username
                    ClientIP  = $ClientIP
                    EventDT   = $EventDT
                })
            }
        } finally { $reader.Close(); $reader.Dispose() }
    }
    Write-Progress -Activity "EFT: $($Pair.EFTServer)" -Completed
    Write-Host "       EFT records collected so far: $($EFTRecords.Count)"
}

Write-Host "`n  Total EFT BUS records: $($EFTRecords.Count)" -ForegroundColor Green

# --- DISCONNECT --------------------------------------------------------------
Disconnect-All

# --- PHASE 3: CORRELATE ------------------------------------------------------
Write-Host "`n=== PHASE 3: Correlating DMZ events with EFT BUS usernames ===" -ForegroundColor Yellow
Write-Host "  Building optimised lookup (EFTServer + ClientIP + Date)..." -NoNewline

# Key insight: we only need ONE confirmed BUS match per unique
# EFTServer|ClientIP|Date combination — not per individual event.
# This reduces 930K comparisons down to a few thousand unique combos.

# Step 1: Build EFT lookup keyed on EFTServer|ClientIP|Date -> first BUS ID seen
$EFTLookup = @{}
foreach ($rec in $EFTRecords) {
    $key = "$($rec.EFTServer)|$($rec.ClientIP)|$($rec.EventDT.ToString('yyyy-MM-dd'))"
    if (-not $EFTLookup.ContainsKey($key)) {
        $EFTLookup[$key] = $rec.Username
    }
}
Write-Host " Done. ($($EFTLookup.Count) unique IP+Date combos)" -ForegroundColor Green

# Step 2: Deduplicate DMZ events to unique EFTServer|ClientIP|Date combos
Write-Host "  Deduplicating DMZ events..." -NoNewline
$DMZUnique = $DMZEvents |
    Sort-Object EFTServer, ClientIP, DateStr |
    Select-Object EFTServer, DMZServer, FTPHost, ClientIP, DateStr -Unique
Write-Host " Done. ($($DMZUnique.Count) unique combos from $($DMZEvents.Count) events)" -ForegroundColor Green

$MatchedRows = [System.Collections.Generic.List[PSCustomObject]]::new()
$NoMatchRows = [System.Collections.Generic.List[PSCustomObject]]::new()

Write-Host "  Matching $($DMZUnique.Count) unique DMZ combos against EFT lookup..."
$i = 0
foreach ($dmz in $DMZUnique) {
    $i++
    if ($i % 500 -eq 0) {
        Write-Progress -Activity "Correlating" -Status "$i of $($DMZUnique.Count)" `
                       -PercentComplete (($i / $DMZUnique.Count) * 100)
    }

    $key     = "$($dmz.EFTServer)|$($dmz.ClientIP)|$($dmz.DateStr)"
    $BUSUser = $EFTLookup[$key]

    if ($BUSUser) {
        $MatchedRows.Add([PSCustomObject]@{
            FTP_Hostname = $dmz.FTPHost
            DMZ_Server   = $dmz.DMZServer
            EFT_Server   = $dmz.EFTServer
            BUS_ID       = $BUSUser
            Client_IP    = $dmz.ClientIP
            Date         = $dmz.DateStr
        })
    } else {
        $NoMatchRows.Add([PSCustomObject]@{
            FTP_Hostname = $dmz.FTPHost
            DMZ_Server   = $dmz.DMZServer
            EFT_Server   = $dmz.EFTServer
            Client_IP    = $dmz.ClientIP
            Date         = $dmz.DateStr
            Note         = "No BUS ID match on same date"
        })
    }
}
Write-Progress -Activity "Correlating" -Completed

Write-Host "  Matched   : $($MatchedRows.Count) unique IP+Date combos" -ForegroundColor Green
Write-Host "  Unmatched : $($NoMatchRows.Count) (external IPs / noise)" -ForegroundColor Yellow

# --- PHASE 4: BUILD SUMMARY --------------------------------------------------
Write-Host "`n=== PHASE 4: Building Summary ===" -ForegroundColor Yellow

# Unique customers = distinct BUS_ID + Client_IP per server
$SummaryRows = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($FTPHost in ($MatchedRows.FTP_Hostname | Select-Object -Unique | Sort-Object)) {
    $Recs = $MatchedRows | Where-Object { $_.FTP_Hostname -eq $FTPHost }

    $UniqueCombos  = $Recs | Select-Object BUS_ID, Client_IP -Unique
    $UniqueBUSIDs  = ($Recs.BUS_ID  | Select-Object -Unique).Count
    $UniqueIPs     = ($Recs.Client_IP | Select-Object -Unique).Count

    $DailyG   = $Recs | Group-Object Date
    $AvgDaily = [math]::Round((($DailyG | ForEach-Object {
        ($_.Group | Select-Object BUS_ID -Unique).Count
    }) | Measure-Object -Average).Average, 1)

    $WeeklyG   = $Recs | Group-Object { (Get-Date $_.Date).ToString('yyyy-WW') }
    $AvgWeekly = [math]::Round((($WeeklyG | ForEach-Object {
        ($_.Group | Select-Object BUS_ID -Unique).Count
    }) | Measure-Object -Average).Average, 1)

    $MonthlyG   = $Recs | Group-Object { (Get-Date $_.Date).ToString('yyyy-MM') }
    $AvgMonthly = [math]::Round((($MonthlyG | ForEach-Object {
        ($_.Group | Select-Object BUS_ID -Unique).Count
    }) | Measure-Object -Average).Average, 1)

    $SummaryRows.Add([PSCustomObject]@{
        FTP_Hostname              = $FTPHost
        DMZ_Server                = ($Recs | Select-Object -First 1).DMZ_Server
        EFT_Server                = ($Recs | Select-Object -First 1).EFT_Server
        Total_FTP_Events          = $Recs.Count
        Unique_BUS_IDs            = $UniqueBUSIDs
        Unique_Client_IPs         = $UniqueIPs
        Avg_Unique_BUS_Daily      = $AvgDaily
        Avg_Unique_BUS_Weekly     = $AvgWeekly
        Avg_Unique_BUS_Monthly    = $AvgMonthly
        Days_With_Activity        = $DailyG.Count
    })
}

# --- OUTPUT ------------------------------------------------------------------
Write-Host "`n=== RESULTS ===" -ForegroundColor Yellow
$SummaryRows | Format-Table -AutoSize

# Ensure output dir exists
if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir | Out-Null }

# Summary
$SummaryRows | Export-Csv -Path $SummaryCSV -NoTypeInformation -Encoding UTF8
Write-Host "Summary saved    : $SummaryCSV" -ForegroundColor Green

# Detail — deduplicated: one row per unique BUS_ID + Client_IP + Date
$MatchedRows |
    Sort-Object FTP_Hostname, BUS_ID, Date, Client_IP |
    Select-Object FTP_Hostname, DMZ_Server, EFT_Server, BUS_ID, Client_IP, Date |
    Export-Csv -Path $DetailCSV -NoTypeInformation -Encoding UTF8
Write-Host "Detail saved     : $DetailCSV" -ForegroundColor Green

# Unmatched IPs (noise/external) — useful for security review
if ($NoMatchRows.Count -gt 0) {
    $NoMatchRows | Sort-Object FTP_Hostname, Client_IP, Date |
        Export-Csv -Path $NoMatchCSV -NoTypeInformation -Encoding UTF8
    Write-Host "Unmatched saved  : $NoMatchCSV" -ForegroundColor Green
}

Write-Host "`nDone!" -ForegroundColor Cyan
