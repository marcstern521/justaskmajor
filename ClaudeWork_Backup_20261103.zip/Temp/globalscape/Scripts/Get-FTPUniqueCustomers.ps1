# =============================================================================
# Get-FTPUniqueCustomers.ps1
# Parses GlobalSCAPE DMZ Gateway DMZActivity logs across all gateway servers
# Reports unique FTP (port 21) client IPs with daily/weekly/monthly averages
# =============================================================================
# USAGE:
#   Run from your laptop/workstation — will prompt once for INUCN credentials.
#   .\Get-FTPUniqueCustomers.ps1
# =============================================================================

# --- CREDENTIALS -------------------------------------------------------------
Write-Host "=== FTP Unique Customer Report — Multi-Server ===" -ForegroundColor Cyan
Write-Host "Enter your INUCN domain credentials (e.g. INUCN\marc.stern)`n"
$Credential = Get-Credential -Message "Enter your INUCN domain credentials"
if (-not $Credential) { Write-Error "No credentials provided. Exiting."; exit 1 }

# --- SERVER LIST -------------------------------------------------------------
$Servers = @(
    @{ Name = "Dal-inftp02";       FTPHost = "ftp4.inucn.com";    Drive = "c"; LogDir = "Program Files\GlobalSCAPE\DMZ Gateway\logs" },
    @{ Name = "Dal-inftp03";       FTPHost = "ftp6.inucn.com";    Drive = "d"; LogDir = "Program Files\GlobalSCAPE\DMZ Gateway\logs" },
    @{ Name = "Dal-inftp05";       FTPHost = "ftp2.inucn.com";    Drive = "d"; LogDir = "Program Files\GlobalSCAPE\DMZ Gateway\logs" },
    @{ Name = "Lax-inftp02";       FTPHost = "ftp3.inucn.com";    Drive = "c"; LogDir = "Program Files\GlobalSCAPE\DMZ Gateway\logs" },
    @{ Name = "Fra-inftp01.ineur.eu"; FTPHost = "ftp1.incontact.eu"; Drive = "d"; LogDir = "Program Files\GlobalSCAPE\DMZ Gateway\logs" }
)

$LookbackDays = 30
$OutputDir    = "C:\Temp\globalscape"
$SummaryCSV   = "$OutputDir\FTP_UniqueCustomers_Summary.csv"
$DetailCSV    = "$OutputDir\FTP_UniqueCustomers_Detail.csv"

# --- HELPERS -----------------------------------------------------------------
$AuthedRoots = @{}

function Connect-UNC {
    param([string]$UNCRoot, [System.Management.Automation.PSCredential]$Cred)
    if ($AuthedRoots[$UNCRoot]) { return $true }
    & net use $UNCRoot /delete /yes 2>$null | Out-Null
    $out = & net use $UNCRoot /user:$($Cred.UserName) $($Cred.GetNetworkCredential().Password) 2>&1
    if ($LASTEXITCODE -eq 0) { $AuthedRoots[$UNCRoot] = $true; return $true }
    Write-Warning "    Auth failed for $UNCRoot`: $out"
    return $false
}

function Disconnect-All {
    foreach ($r in $AuthedRoots.Keys) {
        & net use $r /delete /yes 2>$null | Out-Null
    }
}

# --- MAIN --------------------------------------------------------------------
$AllRecords  = [System.Collections.Generic.List[PSCustomObject]]::new()
$CutoffDate  = (Get-Date).AddDays(-$LookbackDays)

foreach ($Server in $Servers) {

    $UNCRoot = "\\$($Server.Name)\$($Server.Drive)`$"
    $LogPath = "$UNCRoot\$($Server.LogDir)"

    Write-Host "`n=== $($Server.Name) ($($Server.FTPHost)) ===" -ForegroundColor Cyan
    Write-Host "    Log path: $LogPath"
    Write-Host "    Authenticating..." -NoNewline

    if (-not (Connect-UNC -UNCRoot $UNCRoot -Cred $Credential)) {
        Write-Host " FAILED" -ForegroundColor Red
        continue
    }
    Write-Host " OK" -ForegroundColor Green

    if (-not (Test-Path $LogPath)) {
        Write-Warning "    Log path not accessible after auth. Skipping."
        continue
    }

    $LogFiles = Get-ChildItem -Path $LogPath -Filter 'DMZActivity*.log' -File |
        Where-Object { $_.LastWriteTime -ge $CutoffDate -or $_.Name -eq 'DMZActivity.log' } |
        Sort-Object LastWriteTime

    if (-not $LogFiles) { Write-Warning "    No DMZActivity log files found."; continue }
    Write-Host "    Found $($LogFiles.Count) log file(s) to parse."

    $fc = 0
    foreach ($File in $LogFiles) {
        $fc++
        Write-Progress -Activity "Parsing $($Server.Name)" `
                       -Status "File $fc of $($LogFiles.Count): $($File.Name)" `
                       -PercentComplete (($fc / $LogFiles.Count) * 100)
        try {
            $fs     = [System.IO.FileStream]::new($File.FullName, [System.IO.FileMode]::Open,
                        [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
            $reader = [System.IO.StreamReader]::new($fs)
        } catch {
            Write-Warning "    Skipping $($File.Name): $_"
            continue
        }

        try {
            while ($null -ne ($Line = $reader.ReadLine())) {

                if ($Line -notlike '*granted+access+to+client*') { continue }

                $Parts = $Line -split '\s+'
                if ($Parts.Count -lt 8) { continue }

                $DateStr     = $Parts[0]
                $DestField   = $Parts[5]   # /x.x.x.x:PORT
                $ClientField = $Parts[7]   # /x.x.x.x:PORT

                if ($DestField   -notmatch ':(\d+)$') { continue }
                $Port = $Matches[1]
                if ($Port -ne '21') { continue }

                if ($ClientField -notmatch '^/(\d{1,3}(?:\.\d{1,3}){3})') { continue }
                $ClientIP = $Matches[1]

                try { $ParsedDate = [datetime]::ParseExact($DateStr, 'yyyy-MM-dd', $null) }
                catch { continue }

                if ($ParsedDate -lt $CutoffDate) { continue }

                $AllRecords.Add([PSCustomObject]@{
                    Server    = $Server.Name
                    FTPHost   = $Server.FTPHost
                    Date      = $ParsedDate
                    Week      = "W$(Get-Date $ParsedDate -UFormat '%V')-$(($ParsedDate).Year)"
                    Month     = $ParsedDate.ToString('yyyy-MM')
                    ClientIP  = $ClientIP
                })
            }
        } finally {
            $reader.Close(); $reader.Dispose()
        }
    }
    Write-Progress -Activity "Parsing $($Server.Name)" -Completed
    Write-Host "    Done." -ForegroundColor Green
}

# --- DISCONNECT --------------------------------------------------------------
Write-Host "`n=== Cleaning up network sessions ===" -ForegroundColor Cyan
Disconnect-All

# --- REPORT ------------------------------------------------------------------
if ($AllRecords.Count -eq 0) {
    Write-Warning "No FTP (port 21) records found across any server."
    exit
}

Write-Host "`n=== Building Report ===" -ForegroundColor Cyan

$SummaryRows = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($ServerName in ($AllRecords.Server | Select-Object -Unique)) {
    $Recs    = $AllRecords | Where-Object { $_.Server -eq $ServerName }
    $FTPHost = ($Recs | Select-Object -First 1).FTPHost

    $DailyG   = $Recs | Group-Object Date
    $WeeklyG  = $Recs | Group-Object Week
    $MonthlyG = $Recs | Group-Object Month

    $AvgDaily   = [math]::Round((($DailyG   | ForEach-Object { ($_.Group.ClientIP | Select-Object -Unique).Count }) | Measure-Object -Average).Average, 1)
    $AvgWeekly  = [math]::Round((($WeeklyG  | ForEach-Object { ($_.Group.ClientIP | Select-Object -Unique).Count }) | Measure-Object -Average).Average, 1)
    $AvgMonthly = [math]::Round((($MonthlyG | ForEach-Object { ($_.Group.ClientIP | Select-Object -Unique).Count }) | Measure-Object -Average).Average, 1)

    $SummaryRows.Add([PSCustomObject]@{
        Server                       = $ServerName
        FTP_Hostname                 = $FTPHost
        Data_From                    = ($Recs | Measure-Object -Property Date -Minimum).Minimum.ToString('yyyy-MM-dd')
        Data_To                      = ($Recs | Measure-Object -Property Date -Maximum).Maximum.ToString('yyyy-MM-dd')
        Total_FTP_Connection_Events  = $Recs.Count
        Total_Unique_Client_IPs      = ($Recs.ClientIP | Select-Object -Unique).Count
        Avg_Unique_IPs_Daily         = $AvgDaily
        Avg_Unique_IPs_Weekly        = $AvgWeekly
        Avg_Unique_IPs_Monthly       = $AvgMonthly
        Days_With_FTP_Activity       = $DailyG.Count
        Weeks_With_FTP_Activity      = $WeeklyG.Count
        Months_With_FTP_Activity     = $MonthlyG.Count
    })
}

Write-Host "`n=== FTP Unique Customer Report (Port 21 Only — Last 30 Days) ===" -ForegroundColor Yellow
$SummaryRows | Format-Table -AutoSize

$SummaryRows | Export-Csv -Path $SummaryCSV -NoTypeInformation -Encoding UTF8
Write-Host "Summary saved to : $SummaryCSV" -ForegroundColor Green

$AllRecords | Select-Object Server, FTPHost, Date, ClientIP |
    Sort-Object Server, Date, ClientIP |
    Export-Csv -Path $DetailCSV -NoTypeInformation -Encoding UTF8
Write-Host "Detail saved to  : $DetailCSV" -ForegroundColor Green
