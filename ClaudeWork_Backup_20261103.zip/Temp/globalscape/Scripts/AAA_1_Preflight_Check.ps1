# ============================================================
# AAA - Script 1 - Pre-Flight Check
# Targets: AAA-INEFT01.inucn.com (EFT)
#          
# Run BEFORE anything else - no changes made
# ============================================================

$EFTServer = 'AAA-INEFT01.inucn.com'
$ServiceName  = 'EFT Server Enterprise'
$InstallPath  = 'D:\Program Files (x86)\Globalscape\EFT Server Enterprise'
$ReportPath   = "C:\temp\globalscape\aaa_preflight_$(Get-Date -Format 'yyyyMMdd').csv"

$creds   = Get-Credential
$Results = @()

New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null

Write-Host "`n=== AAA Pre-Flight Check ===" -ForegroundColor Cyan

# --- EFT Server ---
Write-Host "`nChecking EFT: $EFTServer" -ForegroundColor Yellow
try {
    $data = Invoke-Command -ComputerName $EFTServer -Credential $creds -ErrorAction Stop -ScriptBlock {
        param($svcName, $installPath)

        $eft    = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                  Get-ItemProperty -EA SilentlyContinue |
                  Where-Object { $_.DisplayName -like '*EFT*' } |
                  Select-Object -First 1
        $dotnet = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -EA SilentlyContinue
        $svc    = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -EA SilentlyContinue
        $cDrive = Get-PSDrive C -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
        $dDrive = Get-PSDrive D -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
        $apPath = "$installPath\AdvancedProperties.json"

        [PSCustomObject]@{
            EFTVersion     = $eft.DisplayVersion
            ServiceStatus  = $svc.State
            ServiceAccount = $svc.StartName
            DotNetVersion  = $dotnet.Version
            DotNet48Ready  = ($dotnet.Version -ge '4.8')
            CDriveFreeGB   = $cDrive.FreeGB
            DDriveFreeGB   = if ($dDrive) { $dDrive.FreeGB } else { 'No D drive' }
            RAM            = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,2)
            OS             = (Get-CimInstance Win32_OperatingSystem).Caption
            APJsonExists   = (Test-Path $apPath)
            InstallPath    = $installPath
        }
    } -ArgumentList $ServiceName, $InstallPath

    Write-Host "  EFT Version:    $($data.EFTVersion)"
    Write-Host "  Service:        $ServiceName - $($data.ServiceStatus) / $($data.ServiceAccount)"
    Write-Host "  .NET:           $($data.DotNetVersion) $(if ($data.DotNet48Ready) {'✅'} else {'❌ NEEDS 4.8'})"
    Write-Host "  C: Free:        $($data.CDriveFreeGB) GB"
    Write-Host "  D: Free:        $($data.DDriveFreeGB) GB"
    Write-Host "  RAM:            $($data.RAM) GB"
    Write-Host "  OS:             $($data.OS)"
    Write-Host "  Install Path:   $($data.InstallPath)"
    Write-Host "  AP.json exists: $($data.APJsonExists)"

    $data | Add-Member -NotePropertyName Server -NotePropertyValue $EFTServer
    $data | Add-Member -NotePropertyName Role   -NotePropertyValue 'EFT'
    $Results += $data

} catch {
    Write-Host "  ❌ UNREACHABLE - $_" -ForegroundColor Red
}

# --- DMZ Server ---
# Write-Host "`nChecking DMZ: $DMZServer" -ForegroundColor Yellow
# try {
#    $dmz = Invoke-Command -ComputerName $DMZServer -Credential $creds -ErrorAction Stop -ScriptBlock {
#        $reg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
#        if (-not $reg) { $reg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
#        if (-not $reg) {
#            $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
#                Get-ItemProperty -EA SilentlyContinue |
#                Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
#                Select-Object -First 1
#        }
#        $svc    = Get-WmiObject Win32_Service -EA SilentlyContinue |
#                  Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
#                  Select-Object -First 1
#        $cDrive = Get-PSDrive C -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
#        $dDrive = Get-PSDrive D -EA SilentlyContinue | Select-Object @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}

#        [PSCustomObject]@{
 #           DMZVersion     = $reg.DisplayVersion
 #           ServiceName    = $svc.Name
 #           ServiceStatus  = $svc.State
 #           ServiceAccount = $svc.StartName
 #           CDriveFreeGB   = $cDrive.FreeGB
 #           DDriveFreeGB   = if ($dDrive) { $dDrive.FreeGB } else { 'No D drive' }
 #           OS             = (Get-CimInstance Win32_OperatingSystem).Caption
 #       }
 #   }

  #  Write-Host "  DMZ Version:    $($dmz.DMZVersion)"
  #  Write-Host "  Service:        $($dmz.ServiceName) - $($dmz.ServiceStatus) / $($dmz.ServiceAccount)"
  #  Write-Host "  C: Free:        $($dmz.CDriveFreeGB) GB"
  #  Write-Host "  D: Free:        $($dmz.DDriveFreeGB) GB"
  #  Write-Host "  OS:             $($dmz.OS)"

#    $dmz | Add-Member -NotePropertyName Server -NotePropertyValue $DMZServer
#    $dmz | Add-Member -NotePropertyName Role   -NotePropertyValue 'DMZ'
#    $Results += $dmz

# }catch {
 #   Write-Host "  ❌ UNREACHABLE - $_" -ForegroundColor Red
# }

# --- Export ---
$Results | Export-Csv -Path $ReportPath -NoTypeInformation
Write-Host "`n✅ Report saved to $ReportPath" -ForegroundColor Green

# --- Summary ---
Write-Host "`n=== Action Items ===" -ForegroundColor Cyan
Write-Host "  EFT ($EFTServer):"
Write-Host "    - Current version: 8.0.6.18"
Write-Host "    - Hop path: 8.1.0.16 > 8.2.0.46 > 8.2.1.408 > 8.3.0.410 > 8.3.2.565"
Write-Host "    - .NET 4.8: Already installed - no action needed ✅"
Write-Host "    - Installers needed in D:\temp\ on server"
Write-Host ""
# Write-Host "  DMZ ($DMZServer):"
# Write-Host "    - Current version: 3.5.0.35"
# Write-Host "    - Upgrade to 4.x - single hop"
# Write-Host "    - Upgrade AFTER EFT is complete and validated"
