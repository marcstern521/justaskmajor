# ============================================================
# AAA - Script 5 - DMZ Gateway Upgrade
# Target: AAA-INFTP01.inucn.com
# Path: 3.5.0.35 -> 4.x
# Run AFTER AAA-QWEFT01 EFT upgrade is complete and validated
# ============================================================

$TargetServer  = 'AAA-INFTP01.inucn.com'
$EFTServer     = 'AAA-QWEFT01.inucn.com'
$InstallerPath = 'D:\temp\dmz-gateway-windows-x86-64.exe'
$LogPath       = "C:\temp\globalscape\aaa_dmz_upgrade_$(Get-Date -Format 'yyyyMMdd').txt"
$creds         = Get-Credential

New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null
New-Item -Path $LogPath -ItemType File -Force | Out-Null

function Write-Log {
    param($msg, $color = 'White')
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $msg"
    Write-Host $entry -ForegroundColor $color
    Add-Content -Path $LogPath -Value $entry
}

Write-Log "=== DMZ Gateway Upgrade Started ===" Cyan
Write-Log "Target: $TargetServer"

# Check current DMZ version and service
$current = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    $reg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
    if (-not $reg) { $reg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
    if (-not $reg) {
        $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
            Get-ItemProperty -EA SilentlyContinue |
            Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
            Select-Object -First 1
    }
    $svc = Get-WmiObject Win32_Service -EA SilentlyContinue |
        Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
        Select-Object -First 1
    [PSCustomObject]@{
        Version        = $reg.DisplayVersion
        ServiceName    = $svc.Name
        ServiceStatus  = $svc.State
        ServiceAccount = $svc.StartName
    }
}

Write-Log "Current DMZ version: $($current.Version)"
Write-Log "Service: $($current.ServiceName) - $($current.ServiceStatus) / Account: $($current.ServiceAccount)"

# Check installer on remote server
$exists = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($p); Test-Path $p
} -ArgumentList $InstallerPath

if (-not $exists) {
    Write-Log "❌ DMZ installer not found at $InstallerPath on $TargetServer" Red
    Write-Log "   Run AAA_3_Push_Installers.ps1 first" Red
    exit
}

# Production confirmation
Write-Host "`n⚠️  PRODUCTION SERVER" -ForegroundColor Red
Write-Host "   Target:  $TargetServer (DMZ Gateway)" -ForegroundColor Yellow
Write-Host "   Current: $($current.Version)" -ForegroundColor Yellow
Write-Host "   Confirm EFT upgrade on $EFTServer is COMPLETE before proceeding" -ForegroundColor Yellow
$confirm = Read-Host "Type YES to begin DMZ upgrade"
if ($confirm -ne 'YES') { Write-Log "Cancelled by user" Yellow; exit }

Write-Log "⚠️  Note: Service account may reset to Local System during upgrade (currently: $($current.ServiceAccount))" Yellow

# Run installer
Write-Log "Running DMZ Gateway installer..."
Write-Log "NOTE: If it hangs - RDP in and run D:\temp\dmz-gateway-windows-x86-64.exe manually"
Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($path)
    Start-Process -FilePath $path -ArgumentList '/S' -Wait
} -ArgumentList $InstallerPath

# Wait
Write-Log "Waiting 45 seconds for service to start..."
Start-Sleep -Seconds 45

# Check post-upgrade service
$postUpgrade = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    $svc = Get-WmiObject Win32_Service -EA SilentlyContinue |
        Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or $_.PathName -like '*DMZ*' } |
        Select-Object -First 1
    [PSCustomObject]@{
        ServiceName    = $svc.Name
        ServiceStatus  = $svc.State
        ServiceAccount = $svc.StartName
    }
}

Write-Log "Post-upgrade service: $($postUpgrade.ServiceName) - $($postUpgrade.ServiceStatus)"

if ($postUpgrade.ServiceAccount -eq 'LocalSystem' -and $current.ServiceAccount -ne 'LocalSystem') {
    Write-Log "⚠️  Service account reset to LocalSystem - was $($current.ServiceAccount)" Yellow
    Write-Log "   Update service account if a specific account is required" Yellow
}

# Manual verification
Write-Host "`n================================================================" -ForegroundColor Magenta
Write-Host "  MANUAL STEP - DMZ Upgrade Complete" -ForegroundColor Magenta
Write-Host "================================================================" -ForegroundColor Magenta
Write-Host "  1. Confirm DMZ version in DMZ admin console on $TargetServer" -ForegroundColor White
Write-Host "  2. From EFT Admin Console on $EFTServer" -ForegroundColor White
Write-Host "     Go to Server > Gateway - confirm shows Connected" -ForegroundColor White
Write-Host "  3. WinSCP SFTP test on port 22 to $EFTServer" -ForegroundColor White
Write-Host "  4. Verify service account if it was not Local System before" -ForegroundColor White
Write-Host "================================================================`n" -ForegroundColor Magenta

$check = Read-Host "Type OK when verified or ABORT if issues"
if ($check -eq 'ABORT') {
    Write-Log "Issues reported post DMZ upgrade - investigate" Red
    Write-Log "Rollback: revert snapshot Pre-Globalscape-AAA-Upgrade in vCenter" Yellow
    exit
}

Write-Log "DMZ upgrade on $TargetServer confirmed ✅" Green
Write-Log "=== DMZ Gateway Upgrade Complete ===" Green
Write-Host "`n✅ AAA-INFTP01 DMZ upgrade done!" -ForegroundColor Green
Write-Host "Next: Run AAA_6_Apply_Cipher_Config.ps1" -ForegroundColor Cyan
