# ============================================================
# Script 5 - Apply New SSH Cipher Config
# Run AFTER EFT is on final version and validated
# NOTE: Requires InfoSec/Compliance approval before running
#       in lab or production
# ============================================================

$TargetServer = 'ENA-INEFT03.in.lab'   # Change per server
$creds        = Get-Credential
$APJsonPath   = 'D:\ProgramData\Globalscape\EFT Server\AdvancedProperties.json'
$BackupPath   = "D:\ProgramData\Globalscape\EFT Server\AdvancedProperties_backup_$(Get-Date -Format 'yyyyMMdd-HHmm').json"

# Approved cipher standard - pending InfoSec/Compliance sign-off
$ApprovedCiphers = "aes256-gcm@openssh.com,aes128-gcm@openssh.com,chacha20-poly1305@openssh.com,aes256-ctr,aes192-ctr,aes128-ctr"
$ApprovedKEX     = "curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp521,ecdh-sha2-nistp384,ecdh-sha2-nistp256,diffie-hellman-group16-sha512,diffie-hellman-group-exchange-sha256,diffie-hellman-group14-sha1"

Write-Host "`n⚠️  STOP - Confirm InfoSec and Compliance approval before running this script" -ForegroundColor Red
$approval = Read-Host "Type APPROVED to continue"
if ($approval -ne 'APPROVED') { Write-Host "Exiting - run after approvals received" Yellow; exit }

Write-Host "`n=== Applying Cipher Config on $TargetServer ===" -ForegroundColor Cyan

Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    param($apPath, $backupPath, $ciphers, $kex)

    # Backup
    if (Test-Path $apPath) {
        Copy-Item $apPath $backupPath -Force
        Write-Host "✅ Backed up to $backupPath"
    }

    # Load or create
    $ap = if (Test-Path $apPath) { Get-Content $apPath -Raw | ConvertFrom-Json } else { [PSCustomObject]@{} }

    # Apply approved settings
    $ap | Add-Member -NotePropertyName 'SftpClientCiphers'       -NotePropertyValue $ciphers -Force
    $ap | Add-Member -NotePropertyName 'SftpClientKexAlgorithms' -NotePropertyValue $kex     -Force

    # Disable weak algorithms
    $ap | Add-Member -NotePropertyName 'SFTP2_TripleDES' -NotePropertyValue $false -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_ARCFOUR'   -NotePropertyValue $false -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_MD5'       -NotePropertyValue $false -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_MD5_96'    -NotePropertyValue $false -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_SHA1'      -NotePropertyValue $false -Force
    $ap | Add-Member -NotePropertyName 'SFTP2_SHA1_96'   -NotePropertyValue $false -Force

    $ap | ConvertTo-Json -Depth 10 | Set-Content $apPath -Force
    Write-Host "✅ AdvancedProperties.json updated"

} -ArgumentList $APJsonPath, $BackupPath, $ApprovedCiphers, $ApprovedKEX

# Restart service
Write-Host "Restarting EFT service..." -ForegroundColor Yellow
Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    Restart-Service -Name 'EFT Server' -Force
    Start-Sleep -Seconds 10
    Write-Host "Service: $((Get-Service 'EFT Server').Status)"
}

Write-Host "`n✅ Done - run Script 6 to validate" -ForegroundColor Green
Write-Host "⚠️  Also manually add ssh-ed25519 and ecdsa-sha2-nistp256 host keys in EFT Admin Console > Site > SFTP Settings" -ForegroundColor Yellow
