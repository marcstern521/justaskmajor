# ============================================================
# Script 6 - Post Upgrade Validation - FIXED
# Fixes: version detection, service status, report path, DMZ service
# Run after full upgrade + cipher config applied
# Requires Nmap installed on management machine
# ============================================================

$EFTServers   = @('ENA-INEFT01.in.lab','ENA-INEFT03.in.lab')
$DMZServers   = @('ENA-INFTP01.in.lab','ENA-INFTP03.in.lab')
$creds        = Get-Credential
$NmapPath     = 'C:\Program Files (x86)\Nmap\nmap.exe'
$ReportPath   = "C:\temp\globalscape\post_upgrade_validation_$(Get-Date -Format 'yyyyMMdd').csv"
$TargetEFTVer = '8.3.2.565'
$Results      = @()

# Create output folder if needed
New-Item -Path 'C:\temp\globalscape' -ItemType Directory -Force | Out-Null

Write-Host "`n=== Post Upgrade Validation ===" -ForegroundColor Cyan

# --- EFT Servers ---
foreach ($server in $EFTServers) {
    Write-Host "`nValidating EFT: $server" -ForegroundColor Yellow

    try {
        $data = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {

            # Version from uninstall key (correct path for this estate)
            $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                Get-ItemProperty -EA SilentlyContinue |
                Where-Object { $_.DisplayName -like '*EFT*' } |
                Select-Object -First 1

            # Service status - use WMI to get string value
            $svc = Get-WmiObject Win32_Service -Filter "Name='EFT Server'" -EA SilentlyContinue

            [PSCustomObject]@{
                EFTVersion    = $reg.DisplayVersion
                ServiceStatus = $svc.State
            }
        }

        $versionOK = $data.EFTVersion -eq $TargetEFTVer
        $serviceOK = $data.ServiceStatus -eq 'Running'

        Write-Host "  Version: $(if ($data.EFTVersion) {$data.EFTVersion} else {'Check admin console'}) $(if ($versionOK) {'✅'} else {'⚠️ verify in admin console'})"
        Write-Host "  Service: $($data.ServiceStatus) $(if ($serviceOK) {'✅'} else {'❌'})"

    } catch {
        Write-Host "  ❌ Cannot connect" -ForegroundColor Red
        $data      = [PSCustomObject]@{ EFTVersion = 'UNREACHABLE'; ServiceStatus = 'UNREACHABLE' }
        $versionOK = $false
        $serviceOK = $false
    }

    # Nmap scan
    Write-Host "  Running Nmap SSH scan..."
    $nmapOut = & $NmapPath -p 22 --script ssh2-enum-algos $server 2>&1

    $hasEd25519 = [bool]($nmapOut -match 'ssh-ed25519')
    $hasEcdsa   = [bool]($nmapOut -match 'ecdsa-sha2-nistp256')
    $hasRsaSha2 = [bool]($nmapOut -match 'rsa-sha2-256')
    $hasCBC     = [bool]($nmapOut -match '-cbc')
    $has3DES    = [bool]($nmapOut -match '3des')
    $hasSHA1    = [bool]($nmapOut -match 'hmac-sha1[^-]|hmac-sha1$')
    $hasMD5     = [bool]($nmapOut -match 'hmac-md5')

    Write-Host "  ssh-ed25519:         $(if ($hasEd25519) {'✅'} else {'❌ MISSING'})"
    Write-Host "  ecdsa-sha2-nistp256: $(if ($hasEcdsa)   {'✅'} else {'❌ MISSING'})"
    Write-Host "  rsa-sha2-256:        $(if ($hasRsaSha2) {'✅'} else {'❌ MISSING'})"
    Write-Host "  CBC ciphers:         $(if ($hasCBC)     {'⚠️  Still present (intentional for now)'} else {'✅ Removed'})"
    Write-Host "  3des-cbc:            $(if ($has3DES)    {'⚠️  Still present (intentional for now)'} else {'✅ Removed'})"
    Write-Host "  SHA1 MACs:           $(if ($hasSHA1)    {'⚠️  Still present (intentional for now)'} else {'✅ Removed'})"
    Write-Host "  MD5 MACs:            $(if ($hasMD5)     {'❌ Still present'} else {'✅ Removed'})"

    # Pass = modern algorithms present + service running
    # CBC/3DES/SHA1 intentionally kept for now - not counted as fail
    $overallPass = ($serviceOK -and $hasEd25519 -and $hasEcdsa -and $hasRsaSha2 -and -not $hasMD5)

    $Results += [PSCustomObject]@{
        Server           = $server
        Role             = 'EFT'
        Version          = $data.EFTVersion
        ServiceRunning   = $serviceOK
        HasEd25519       = $hasEd25519
        HasEcdsa256      = $hasEcdsa
        HasRsaSha2       = $hasRsaSha2
        CBCPresent       = $hasCBC
        TripleDESPresent = $has3DES
        SHA1Present      = $hasSHA1
        MD5Removed       = -not $hasMD5
        OverallPass      = $overallPass
    }
}

# --- DMZ Servers ---
foreach ($server in $DMZServers) {
    Write-Host "`nValidating DMZ: $server" -ForegroundColor Yellow
    try {
        $svc = Invoke-Command -ComputerName $server -Credential $creds -ErrorAction Stop -ScriptBlock {

            # Try multiple registry paths for DMZ version
            $reg = Get-ItemProperty 'HKLM:\SOFTWARE\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue
            if (-not $reg) { $reg = Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE\DMZ Gateway' -EA SilentlyContinue }
            if (-not $reg) {
                $reg = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
                    Get-ItemProperty -EA SilentlyContinue |
                    Where-Object { $_.DisplayName -like '*DMZ*' -or $_.DisplayName -like '*Gateway*' } |
                    Select-Object -First 1
            }

            # Try multiple service name patterns
            $s = Get-WmiObject Win32_Service -EA SilentlyContinue |
                Where-Object { $_.Name -like '*DMZ*' -or $_.Name -like '*Gateway*' -or 
                               $_.Name -like '*globalscape*' -or $_.Name -like '*cftpstes*' -or
                               $_.PathName -like '*DMZ*' } |
                Select-Object -First 1

            # If still not found list all services for debugging
            if (-not $s) {
                $allSvcs = Get-WmiObject Win32_Service | Where-Object { $_.PathName -like '*globalscape*' -or $_.PathName -like '*DMZ*' } | Select-Object Name, State, PathName
                Write-Host "  DEBUG - Globalscape related services found:"
                $allSvcs | ForEach-Object { Write-Host "    $($_.Name) - $($_.State) - $($_.PathName)" }
            }

            [PSCustomObject]@{
                DMZVersion    = if ($reg) { $reg.DisplayVersion } else { 'Not found in registry' }
                ServiceName   = if ($s) { $s.Name } else { 'Service not detected' }
                ServiceStatus = if ($s) { $s.State } else { 'Unknown' }
            }
        }

        $serviceOK = $svc.ServiceStatus -eq 'Running'
        Write-Host "  DMZ Version: $(if ($svc.DMZVersion) {$svc.DMZVersion} else {'Check admin console'})"
        Write-Host "  Service:     $($svc.ServiceName) - $($svc.ServiceStatus) $(if ($serviceOK) {'✅'} else {'❌'})"

        $Results += [PSCustomObject]@{
            Server         = $server
            Role           = 'DMZ'
            Version        = $svc.DMZVersion
            ServiceName    = $svc.ServiceName
            ServiceRunning = $serviceOK
            OverallPass    = $serviceOK
        }

    } catch {
        Write-Host "  ❌ Cannot connect - $_" -ForegroundColor Red
        $Results += [PSCustomObject]@{
            Server = $server; Role = 'DMZ'; Version = 'UNREACHABLE'
            ServiceName = 'UNREACHABLE'; ServiceRunning = $false; OverallPass = $false
        }
    }
}

# --- Export ---
$Results | Export-Csv -Path $ReportPath -NoTypeInformation
Write-Host "`n✅ Report saved to $ReportPath" -ForegroundColor Green

# --- Summary ---
Write-Host "`n=== Summary ===" -ForegroundColor Cyan
$pass = ($Results | Where-Object { $_.OverallPass }).Count
$fail = ($Results | Where-Object { -not $_.OverallPass }).Count
Write-Host "  Passed: $pass / $($Results.Count)" -ForegroundColor Green

if ($fail -gt 0) {
    Write-Host "  Failed: $fail" -ForegroundColor Red
    $Results | Where-Object { -not $_.OverallPass } | ForEach-Object { Write-Host "    ❌ $($_.Server)" -ForegroundColor Red }
} else {
    Write-Host "`n✅ All servers passed - ready to present lab results!" -ForegroundColor Green
}

Write-Host "`nNOTE: CBC/3DES/SHA1 shown as warnings not failures - intentionally kept pending customer exception list approval" -ForegroundColor Yellow
