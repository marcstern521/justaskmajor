﻿# ============================================================
# Script 3 - Install .NET 4.8 on ENA-INEFT03
# Only needed on ENA-INEFT03 - ENA-INEFT01 already on 4.8
# ============================================================

$TargetServer = 'ENA-INEFT03.in.lab'
$creds        = Get-Credential

Write-Host "`n=== Installing .NET 4.8 on $TargetServer ===" -ForegroundColor Cyan

# Check current version
$current = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -EA SilentlyContinue).Version
}
Write-Host "Current .NET version: $current"

if ($current -ge '4.8') {
    Write-Host "✅ Already on .NET 4.8 - no action needed" -ForegroundColor Green
    exit
}

# Download and install on remote server
Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
    New-Item -ItemType Directory -Path 'D:\temp' -Force | Out-Null
    Write-Host "Downloading .NET 4.8..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/?linkid=2088631' -OutFile 'D:\temp\ndp48-web.exe' -UseBasicParsing
    Write-Host "Installing - this takes a few minutes..." -ForegroundColor Yellow
    Start-Process -FilePath 'D:\temp\ndp48-web.exe' -ArgumentList '/quiet /norestart /log D:\temp\dotnet48_install.log' -Wait
    Write-Host "Install complete"
}

# Reboot
Write-Host "`n⚠️  Reboot required to finalize .NET 4.8" -ForegroundColor Yellow
$reboot = Read-Host "Reboot $TargetServer now? (y/n)"
if ($reboot -eq 'y') {
    Restart-Computer -ComputerName $TargetServer -Credential $creds -Force
    Write-Host "Rebooting - wait ~2 minutes then verify version" -ForegroundColor Yellow
}

# Verify after reboot - run manually after server is back
Write-Host "`nAfter reboot run this to confirm:" -ForegroundColor Cyan
Write-Host 'Invoke-Command -ComputerName ENA-INEFT03.in.lab -Credential $creds -ScriptBlock { (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Version }'