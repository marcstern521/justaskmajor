# ============================================================
# GS - Script 2b - EC2 snapshots (use instead of GS_2 for AWS servers)
# Finds each instance by its Name tag, snapshots every attached EBS volume,
# tags them, and (by default) waits until they are all 'completed'.
# Needs AWS Tools for PowerShell:  Install-Module AWS.Tools.EC2
#
# Example:
#   .\GS_2b_Snapshot_EC2.ps1 -Name aaa-incdr01,aab-incdr01 -Region ap-southeast-2 -ProfileName <profile> -ChangeRef CHG0177747
#
# Rollback: stop the instance, detach the volumes, create new volumes from
# these snapshots, attach them on the same device names, start the instance.
# ============================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string[]]$Name,
    [Parameter(Mandatory)][string]$Region,
    [string]$ProfileName,
    [string]$ChangeRef = '',
    [switch]$NoWait
)

. "$PSScriptRoot\GS_Common.ps1"
Start-GSLog -Name 'ec2_snapshot'

if (-not (Get-Command New-EC2Snapshot -ErrorAction SilentlyContinue)) {
    throw 'AWS Tools for PowerShell not loaded. Run: Install-Module AWS.Tools.EC2 (or import AWSPowerShell.NetCore)'
}

$aws = @{ Region = $Region }
if ($ProfileName) { $aws.ProfileName = $ProfileName }

$SnapshotName = 'Pre-Globalscape-Upgrade-{0}' -f (Get-Date -Format 'yyyy-MM-dd')
Write-Log "=== EC2 snapshots ($Region) ===" Cyan

# --- Find instances (must match exactly one each) ---
$targets = @()
foreach ($n in $Name) {
    try {
        $res = Get-EC2Instance @aws -Filter @{ Name = 'tag:Name'; Values = "$n*" } -ErrorAction Stop
    } catch {
        Write-Log "Lookup failed for $n - $_" Red
        exit 1
    }
    $inst = @($res | ForEach-Object { if ($_.Instances) { $_.Instances } else { $_ } }) |
        Where-Object { "$($_.State.Name)" -ne 'terminated' }

    if ($inst.Count -ne 1) {
        Write-Log "$n matched $($inst.Count) instance(s) - need exactly 1. Check the Name tag / region / profile." Red
        $inst | ForEach-Object { Write-Log ("   {0}  {1}" -f $_.InstanceId, (($_.Tags | Where-Object Key -eq 'Name').Value)) Red }
        exit 1
    }
    $i    = $inst[0]
    $vols = @($i.BlockDeviceMappings | Where-Object { $_.Ebs } | ForEach-Object { $_.Ebs.VolumeId })
    Write-Log ("  {0} -> {1} ({2}) - {3} volume(s): {4}" -f $n, $i.InstanceId, $i.State.Name, $vols.Count, ($vols -join ', '))
    $targets += [pscustomobject]@{ Name = $n; InstanceId = $i.InstanceId; Volumes = $vols }
}

if (-not (Confirm-Typed "`nSnapshot $(($targets.Volumes).Count) volume(s) across $($targets.Count) instance(s) as '$SnapshotName'?" 'YES')) {
    Write-Log 'Exiting - no snapshots taken' Yellow
    exit 0
}

# --- Take snapshots ---
$snapIds = @()
$allGood = $true
foreach ($t in $targets) {
    foreach ($v in $t.Volumes) {
        try {
            $desc = ('{0} {1} {2} {3}' -f $SnapshotName, $t.Name, $t.InstanceId, $ChangeRef).Trim()
            $snap = New-EC2Snapshot @aws -VolumeId $v -Description $desc -ErrorAction Stop
            New-EC2Tag @aws -Resource $snap.SnapshotId -Tag @(
                @{ Key = 'Name';    Value = ('{0}-{1}' -f $SnapshotName, $t.Name) },
                @{ Key = 'Purpose'; Value = 'Globalscape upgrade rollback' }
            ) | Out-Null
            $snapIds += $snap.SnapshotId
            Write-Log "  $($t.Name) $v -> $($snap.SnapshotId) started" Green
        } catch {
            Write-Log "  $($t.Name) $v FAILED - $_" Red
            $allGood = $false
        }
    }
}

# --- Wait for completion ---
if ($snapIds.Count -gt 0 -and -not $NoWait) {
    Write-Log 'Waiting for snapshots to reach completed (Ctrl+C to stop waiting - they keep running)...' Yellow
    do {
        Start-Sleep -Seconds 30
        $state = @(Get-EC2Snapshot @aws -SnapshotId $snapIds)
        $done  = @($state | Where-Object { "$($_.State)" -eq 'completed' }).Count
        $err   = @($state | Where-Object { "$($_.State)" -eq 'error' })
        Write-Log ("  {0}/{1} completed  ({2})" -f $done, $snapIds.Count, (($state | ForEach-Object { $_.Progress }) -join ' '))
        if ($err.Count) { Write-Log "  $($err.Count) snapshot(s) in ERROR state" Red; $allGood = $false; break }
    } while ($done -lt $snapIds.Count)
}

if ($allGood) {
    Write-Log "Snapshots good. Name: $SnapshotName  IDs: $($snapIds -join ', ')" Green
    Write-Log 'Next: GS_5_EFT_Hop_Upgrade.ps1 inside the maintenance window' Cyan
} else {
    Write-Log 'One or more snapshots failed - DO NOT proceed until resolved' Red
}
