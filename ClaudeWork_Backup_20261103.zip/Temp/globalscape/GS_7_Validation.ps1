# ============================================================
# GS - Script 7 - Post-Upgrade Validation
# Checks EFT version/service, DMZ version/service, and (optionally) runs an
# Nmap ssh2-enum-algos scan. Scan target defaults to the DMZ Gateway when
# you give one (that is what customers connect to), else the EFT server.
# Nmap needs to be installed on the machine you run this from.
#
# Example:
#   .\GS_7_Validation.ps1 -EftServer aaa-ineft01 -DmzServer aaa-inftp01 -ChangeRef CHG0177747
# ============================================================
[CmdletBinding()]
param(
    [string[]]$EftServer,
    [string[]]$DmzServer,
    [string[]]$ScanTarget,
    [string]$NmapPath = 'C:\Program Files (x86)\Nmap\nmap.exe',
    [switch]$SkipNmap,
    [string]$ChangeRef = '',
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
if (-not $EftServer -and -not $DmzServer) { throw 'Give me at least one server: -EftServer and/or -DmzServer' }

$Credential = Get-GSCredential $Credential
Start-GSLog -Name 'validation'
if (-not $ScanTarget) { $ScanTarget = if ($DmzServer) { $DmzServer } else { $EftServer } }

$health = @()
$scans  = @()

Write-Log '=== Post-upgrade validation ===' Cyan

# --- EFT servers ---
foreach ($name in $EftServer) {
    $server = Resolve-GSHost $name $Domain
    Write-Log "Validating EFT: $server" Yellow
    try {
        $s = New-PSSession -ComputerName $server -Credential $Credential -ErrorAction Stop
        $i = Get-EFTInfo -Session $s
        Remove-PSSession $s
        $ver       = ConvertTo-GSVersion $i.Version
        $versionOK = ($ver -and $ver -ge $script:EFTTarget)
        $serviceOK = ($i.ServiceState -eq 'Running')
        $verText   = $i.Version
    } catch {
        Write-Log "  Cannot connect - $_" Red
        $verText = 'UNREACHABLE'; $versionOK = $false; $serviceOK = $false
    }
    Write-Log ("  Version: {0} {1}" -f $verText, $(if ($versionOK) { '[OK]' } else { '[CHECK] expected ' + $script:EFTTarget + ' - confirm in Admin Console title bar' }))
    Write-Log ("  Service: {0}" -f $(if ($serviceOK) { 'Running [OK]' } else { 'NOT running [FAIL]' }))
    $health += [pscustomobject]@{ Server = $server; Role = 'EFT'; Version = $verText; VersionOK = [bool]$versionOK; ServiceRunning = $serviceOK; Pass = ($versionOK -and $serviceOK) }
}

# --- DMZ servers ---
foreach ($name in $DmzServer) {
    $server = Resolve-GSHost $name $Domain
    Write-Log "Validating DMZ: $server" Yellow
    try {
        $s = New-PSSession -ComputerName $server -Credential $Credential -ErrorAction Stop
        $d = Get-DMZInfo -Session $s
        Remove-PSSession $s
        $ver       = ConvertTo-GSVersion $d.Version
        $versionOK = ($ver -and $ver -ge $script:DMZTarget)
        $serviceOK = ($d.ServiceState -eq 'Running')
        $verText   = $d.Version
    } catch {
        Write-Log "  Cannot connect - $_" Red
        $verText = 'UNREACHABLE'; $versionOK = $false; $serviceOK = $false
    }
    Write-Log ("  Version: {0} {1}" -f $verText, $(if ($versionOK) { '[OK]' } else { '[CHECK] expected 4.1.x - confirm in DMZ admin console' }))
    Write-Log ("  Service: {0}" -f $(if ($serviceOK) { 'Running [OK]' } else { 'NOT running [FAIL]' }))
    $health += [pscustomobject]@{ Server = $server; Role = 'DMZ'; Version = $verText; VersionOK = [bool]$versionOK; ServiceRunning = $serviceOK; Pass = ($versionOK -and $serviceOK) }
}

# --- Nmap SSH algorithm scan ---
if ($SkipNmap) {
    Write-Log 'Nmap scan skipped (-SkipNmap)' Yellow
} elseif (-not (Test-Path $NmapPath)) {
    Write-Log "Nmap not found at $NmapPath - scan skipped. Install it or pass -NmapPath." Yellow
} else {
    foreach ($name in $ScanTarget) {
        $target = Resolve-GSHost $name $Domain
        Write-Log "Nmap SSH scan on port 22: $target" Yellow
        $out = (& $NmapPath -p 22 --script ssh2-enum-algos $target 2>&1 | Out-String)

        $hasEd25519 = $out -match 'ssh-ed25519'
        $hasEcdsa   = $out -match 'ecdsa-sha2-nistp256'
        $hasRsaSha2 = $out -match 'rsa-sha2-256'
        $hasCBC     = $out -match '-cbc'
        $has3DES    = $out -match '3des'
        $hasSHA1    = $out -match 'hmac-sha1(?![\w-])'
        $hasMD5     = $out -match 'hmac-md5'

        Write-Log ("  ssh-ed25519:         {0}" -f $(if ($hasEd25519) { '[OK]' } else { '[MISSING] add host key in admin console' }))
        Write-Log ("  ecdsa-sha2-nistp256: {0}" -f $(if ($hasEcdsa)   { '[OK]' } else { '[MISSING] add host key in admin console' }))
        Write-Log ("  rsa-sha2-256:        {0}" -f $(if ($hasRsaSha2) { '[OK]' } else { '[MISSING]' }))
        Write-Log ("  CBC ciphers:         {0}" -f $(if ($hasCBC)  { 'present (ok only if kept for the customer exception list)' } else { 'removed' }))
        Write-Log ("  3des-cbc:            {0}" -f $(if ($has3DES) { 'present (ok only if kept for the customer exception list)' } else { 'removed' }))
        Write-Log ("  SHA1 MACs:           {0}" -f $(if ($hasSHA1) { 'present (ok only if kept for the customer exception list)' } else { 'removed' }))
        Write-Log ("  MD5 MACs:            {0}" -f $(if ($hasMD5)  { '[FAIL] still present - check AdvancedProperties.json' } else { 'removed [OK]' }))

        $scans += [pscustomobject]@{
            Target = $target; HasEd25519 = $hasEd25519; HasEcdsa256 = $hasEcdsa; HasRsaSha2 = $hasRsaSha2
            CBCPresent = $hasCBC; TripleDESPresent = $has3DES; SHA1Present = $hasSHA1; MD5Present = $hasMD5
            Pass = ($hasEd25519 -and $hasEcdsa -and $hasRsaSha2 -and -not $hasMD5)
        }
    }
}

# --- Export ---
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
$health | Export-Csv -Path (Join-Path $script:WorkDir "validation_health_$stamp.csv") -NoTypeInformation
if ($scans.Count) { $scans | Export-Csv -Path (Join-Path $script:WorkDir "validation_ssh_$stamp.csv") -NoTypeInformation }
Write-Log "Reports saved in $script:WorkDir" Green

# --- Summary ---
Write-Host "`n=== Validation summary ===" -ForegroundColor Cyan
$health | Format-Table Server, Role, Version, VersionOK, ServiceRunning, Pass -AutoSize
if ($scans.Count) { $scans | Format-Table Target, HasEd25519, HasEcdsa256, HasRsaSha2, MD5Present, Pass -AutoSize }

$failed = @($health | Where-Object { -not $_.Pass }) + @($scans | Where-Object { -not $_.Pass })
if ($failed.Count -eq 0) {
    Write-Log 'All checks passed' Green
    Write-Host "`nNext steps:" -ForegroundColor Cyan
    Write-Host '  1. If a customer is affected, have them test their connection' -ForegroundColor White
    Write-Host '  2. Share the Nmap output with SysSecOps / InfoSec' -ForegroundColor White
    Write-Host "  3. Update $(if ($ChangeRef) { $ChangeRef } else { 'the CR/task' }) with completion status" -ForegroundColor White
    Write-Host '  4. Confirm data-at-rest encryption is re-enabled if it was configured before' -ForegroundColor White
} else {
    Write-Log "$($failed.Count) check(s) failed - see above" Red
}
Write-Host "`nNOTE: CBC/3DES/SHA1 'present' is only expected while legacy algorithms are kept for the customer exception list." -ForegroundColor Yellow
