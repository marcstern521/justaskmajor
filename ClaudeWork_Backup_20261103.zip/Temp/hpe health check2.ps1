﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Weekly HPE OneView Health Check - dal-inovd01.inucn.com
.DESCRIPTION
    Connects to HPE OneView via REST API, checks server hardware, enclosures,
    Synergy frames, interconnects, and active alerts. Outputs a SNOW-ready
    summary and exits 0 (healthy) or 1 (issues found).
.PARAMETER Credential
    PSCredential for OneView (AD account). If omitted, prompts interactively.
.PARAMETER OutputPath
    Optional path to write the report as a .txt file.
.PARAMETER SkipSSLValidation
    Bypass SSL cert validation.
.PARAMETER ApiVersion
    HPE OneView API version to use. Default: 1600 (OneView 5.x+).
    Try 800, 1000, 1200, 1800, 2000 if you get 400/404 errors.
.EXAMPLE
    .\Invoke-OneViewHealthCheck.ps1 -SkipSSLValidation
.EXAMPLE
    .\Invoke-OneViewHealthCheck.ps1 -SkipSSLValidation -OutputPath C:\temp\oneview.txt
#>

[CmdletBinding()]
param(
    [Parameter()]
    [PSCredential]$Credential,

    [Parameter()]
    [string]$OutputPath,

    [Parameter()]
    [switch]$SkipSSLValidation,

    [Parameter()]
    [int]$ApiVersion = 1600
)

Set-StrictMode -Off
$ErrorActionPreference = 'Stop'

$OneViewHost = 'https://dal-inovd01.inucn.com'

# -- SSL BYPASS ----------------------------------------------------------------
if ($SkipSSLValidation) {
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
}

# -- CREDENTIALS ---------------------------------------------------------------
if (-not $Credential) {
    $Credential = Get-Credential -Message 'HPE OneView - Enter INUCN AD credentials (domain\username)'
}

# Split domain\user if provided
$userName = $Credential.UserName
$domain   = 'inucn'
if ($userName -match '^(.+)\\(.+)$') {
    $domain   = $Matches[1]
    $userName = $Matches[2]
}

# -- HELPERS -------------------------------------------------------------------
$script:AuthToken = $null

function Invoke-OVPost {
    param([string]$Path, [hashtable]$Body)
    $headers = @{ 'X-API-Version' = $ApiVersion; 'Content-Type' = 'application/json' }
    if ($script:AuthToken) { $headers['Auth'] = $script:AuthToken }
    $json = $Body | ConvertTo-Json -Depth 10
    return Invoke-RestMethod -Uri "$OneViewHost$Path" -Method POST -Headers $headers -Body $json
}

function Invoke-OVGet {
    param([string]$Path)
    $headers = @{ 'X-API-Version' = $ApiVersion; 'Auth' = $script:AuthToken }
    return Invoke-RestMethod -Uri "$OneViewHost$Path" -Method GET -Headers $headers
}

function Invoke-OVDelete {
    param([string]$Path)
    $headers = @{ 'X-API-Version' = $ApiVersion; 'Auth' = $script:AuthToken }
    Invoke-RestMethod -Uri "$OneViewHost$Path" -Method DELETE -Headers $headers | Out-Null
}

function Get-Icon {
    param([string]$Status)
    switch -Regex ($Status.ToLower()) {
        'ok|normal|online|active|enabled|running|healthy'  { return '[OK]'   }
        'warning|degraded|attention|minor'                  { return '[WARN]' }
        'critical|error|fail|offline|dead|unknown'          { return '[FAIL]' }
        default                                             { return '[INFO]' }
    }
}

function Format-Bytes {
    param([long]$Bytes)
    if ($Bytes -ge 1TB) { return '{0:N1} TB' -f ($Bytes / 1TB) }
    if ($Bytes -ge 1GB) { return '{0:N1} GB' -f ($Bytes / 1GB) }
    return '{0:N1} MB' -f ($Bytes / 1MB)
}

# -- REPORT SETUP --------------------------------------------------------------
$lines      = [System.Collections.Generic.List[string]]::new()
$issueCount = 0
$timestamp  = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

$lines.Add('=' * 70)
$lines.Add('  HPE ONEVIEW WEEKLY HEALTH CHECK')
$lines.Add("  Run    : $timestamp")
$lines.Add("  Target : $OneViewHost  (API v$ApiVersion)")
$lines.Add('  Scope  : Server Hardware | Enclosures | Synergy Frames | Alerts')
$lines.Add('=' * 70)

try {
    # -- AUTHENTICATE ----------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Authentication')
    $authBody = @{
        userName        = $userName
        password        = $Credential.GetNetworkCredential().Password
        authLoginDomain = $domain
    }
    $authResp = Invoke-OVPost -Path '/rest/login-sessions' -Body $authBody
    $script:AuthToken = $authResp.sessionID
    $lines.Add("|  [OK] Authenticated as $($Credential.UserName)")

    # -- ACTIVE ALERTS ---------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Active Alerts')
    try {
        $alertsResp = Invoke-OVGet -Path "/rest/alerts?filter=alertState='Active'&count=100&sort=created:desc"
        $alerts = $alertsResp.members
        $critical = @($alerts | Where-Object { $_.severity -eq 'Critical' })
        $warning  = @($alerts | Where-Object { $_.severity -eq 'Warning'  })

        $alertIcon = if ($critical.Count -gt 0) { $issueCount++; '[FAIL]' }
                     elseif ($warning.Count -gt 0) { $issueCount++; '[WARN]' }
                     else { '[OK]' }

        $lines.Add("|  $alertIcon $($alerts.Count) active alert(s) -- $($critical.Count) Critical | $($warning.Count) Warning")

        foreach ($al in ($critical | Select-Object -First 10)) {
            $res = if ($al.associatedResource) { $al.associatedResource.resourceName } else { 'Unknown' }
            $lines.Add("|    [CRIT] $res -- $($al.description)")
        }
        foreach ($al in ($warning | Select-Object -First 5)) {
            $res = if ($al.associatedResource) { $al.associatedResource.resourceName } else { 'Unknown' }
            $lines.Add("|    [WARN] $res -- $($al.description)")
        }
        if ($alerts.Count -gt 15) {
            $lines.Add("|    ... $($alerts.Count - 15) more alerts -- review OneView console")
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve alerts: $($_.Exception.Message)")
    }

    # -- SERVER HARDWARE -------------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Server Hardware')
    try {
        $hwResp = Invoke-OVGet -Path '/rest/server-hardware?start=0&count=500'
        $servers = $hwResp.members
        $srvOk   = @($servers | Where-Object { $_.status -eq 'OK' })
        $srvWarn = @($servers | Where-Object { $_.status -eq 'Warning'  })
        $srvCrit = @($servers | Where-Object { $_.status -eq 'Critical' })
        $srvOther = @($servers | Where-Object { $_.status -notin @('OK','Warning','Critical') })

        $hwIcon = if ($srvCrit.Count -gt 0) { $issueCount++; '[FAIL]' }
                  elseif ($srvWarn.Count -gt 0) { $issueCount++; '[WARN]' }
                  else { '[OK]' }

        $lines.Add("|  $hwIcon $($servers.Count) servers -- OK: $($srvOk.Count) | Warn: $($srvWarn.Count) | Critical: $($srvCrit.Count) | Other: $($srvOther.Count)")

        foreach ($s in $srvCrit) {
            $lines.Add("|    [FAIL] $($s.name) -- Status: $($s.status) | Power: $($s.powerState)")
        }
        foreach ($s in $srvWarn) {
            $lines.Add("|    [WARN] $($s.name) -- Status: $($s.status) | Power: $($s.powerState)")
        }
        foreach ($s in $srvOther | Where-Object { $_.status -notin @('Unknown') }) {
            $lines.Add("|    [INFO] $($s.name) -- Status: $($s.status)")
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve server hardware: $($_.Exception.Message)")
    }

    # -- ENCLOSURES (C7000) ----------------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Enclosures (C7000)')
    try {
        $encResp = Invoke-OVGet -Path '/rest/enclosures?start=0&count=100'
        $encs = $encResp.members
        if ($encs.Count -gt 0) {
            foreach ($enc in $encs) {
                $icon = Get-Icon -Status $enc.status
                if ($enc.status -notin @('OK','Normal')) { $issueCount++ }
                $lines.Add("|  $icon $($enc.name) -- Status: $($enc.status) | State: $($enc.state)")
            }
        } else {
            $lines.Add('|  [INFO] No C7000 enclosures found in this OneView instance')
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve enclosures: $($_.Exception.Message)")
    }

    # -- LOGICAL ENCLOSURES (SYNERGY) ------------------------------------------
    $lines.Add('')
    $lines.Add('+-- Synergy Frames (Logical Enclosures)')
    try {
        $leResp = Invoke-OVGet -Path '/rest/logical-enclosures?start=0&count=100'
        $les = $leResp.members
        if ($les.Count -gt 0) {
            foreach ($le in $les) {
                $icon = Get-Icon -Status $le.status
                if ($le.status -notin @('OK','Normal')) { $issueCount++ }
                $lines.Add("|  $icon $($le.name) -- Status: $($le.status) | State: $($le.enclosureGroupUri.Split('/')[-1])")
            }
        } else {
            $lines.Add('|  [INFO] No Synergy logical enclosures found')
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve logical enclosures: $($_.Exception.Message)")
    }

    # -- INTERCONNECTS (SYNERGY FABRIC) ----------------------------------------
    $lines.Add('')
    $lines.Add('+-- Interconnects (Synergy Fabric)')
    try {
        $icResp  = Invoke-OVGet -Path '/rest/interconnects?start=0&count=200'
        $ics     = $icResp.members
        $icBad   = @($ics | Where-Object { $_.status -notin @('OK','Normal') })
        $icIcon  = if ($icBad.Count -gt 0) { $issueCount++; '[WARN]' } else { '[OK]' }
        $lines.Add("|  $icIcon $($ics.Count) interconnects -- $($icBad.Count) not OK")
        foreach ($ic in $icBad) {
            $lines.Add("|    [WARN] $($ic.name) -- Status: $($ic.status) | State: $($ic.state)")
        }
    } catch {
        $lines.Add("|  [INFO] Could not retrieve interconnects: $($_.Exception.Message)")
    }

    # -- LOGOUT ----------------------------------------------------------------
    try { Invoke-OVDelete -Path '/rest/login-sessions' } catch {}

} catch {
    $issueCount++
    $lines.Add('')
    $lines.Add("[FAIL] Fatal error: $($_.Exception.Message)")
    $lines.Add('Check credentials, API version, and OneView reachability.')
}

# -- SUMMARY -------------------------------------------------------------------
$lines.Add('')
$lines.Add('=' * 70)
if ($issueCount -eq 0) {
    $lines.Add('  RESULT : ALL HEALTHY')
    $lines.Add('  ACTION : Safe to close SNOW tickets as "Closed Complete":')
    $lines.Add('           "Check Health of All Synergy Frames, hosts, and components through our Global OneView."')
    $lines.Add('           "Weekly Review Task - US Synergy Compute Health Check"')
    $lines.Add('           "Weekly Review Task - US C7000 Compute Health Check"')
} else {
    $lines.Add("  RESULT : $issueCount ISSUE(S) FOUND - Review flagged items above")
    $lines.Add('  ACTION : Investigate before closing. Escalate FAIL/CRIT items.')
}
$lines.Add("  Run by : $env:USERNAME on $env:COMPUTERNAME")
$lines.Add('=' * 70)

$report = $lines -join "`n"
Write-Output $report

if ($OutputPath) {
    $report | Out-File -FilePath $OutputPath -Encoding UTF8
    Write-Host "`nReport written to: $OutputPath" -ForegroundColor Cyan
}

exit $(if ($issueCount -eq 0) { 0 } else { 1 })