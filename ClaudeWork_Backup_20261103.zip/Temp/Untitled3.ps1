﻿Invoke-Command -ComputerName 'ENA-INEFT01.in.lab' -Credential $creds -ScriptBlock {
    # Check the service executable path
    $svc = Get-WmiObject Win32_Service -Filter "Name='EFT Server'" -EA SilentlyContinue
    Write-Host "Service path: $($svc.PathName)"
    
    # Also check uninstall registry for version
    Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
    Get-ItemProperty -EA SilentlyContinue |
    Where-Object { $_.DisplayName -like '*EFT*' -or $_.DisplayName -like '*Globalscape*' } |
    Select-Object DisplayName, DisplayVersion, InstallLocation
}