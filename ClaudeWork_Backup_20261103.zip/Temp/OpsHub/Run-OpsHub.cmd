@echo off
rem Starts Ops Hub without fighting execution policy. Double-click or run from cmd.
rem Run with  Run-OpsHub.cmd skipaws  to skip the AWS sign-in question. Other options (like -SnowLogin) are passed through.
cd /d "%~dp0"
powershell.exe -NoProfile -Command "Get-ChildItem -Recurse -File | Unblock-File" 2>nul
set SKIPAWS=
if /I "%~1"=="skipaws" (set SKIPAWS=1& shift)
if defined SKIPAWS goto start
set AWSQ=
set /p AWSQ=Sign in to AWS SSO first (ic-prod, ic-dev, uk-sov, eu-sov-fra, au-sov)? [Y/n]: 
if /I "%AWSQ%"=="n" goto start
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Connect-AwsSso.ps1"
echo.
:start
set SNOWQ=
set SNOWARGS=
set /p SNOWQ=Refresh the ticket queue from ServiceNow now (asks for your SNOW login)? [y/N]: 
if /I "%SNOWQ%"=="y" set SNOWARGS=-SnowLogin -RefreshOnStart
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-OpsHub.ps1" %SNOWARGS% %1 %2 %3 %4 %5
pause