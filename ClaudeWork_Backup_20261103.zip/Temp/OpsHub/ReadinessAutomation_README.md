# Readiness ticket automation (laptop)

Files (all in `C:\Temp\OpsHub`):
- `scripts\Invoke-ReadinessRun.ps1`: the runner. Read-only. Uses your existing check scripts unchanged.
- `data\readiness-queue.csv`: the 18 open readiness tickets as of Oct 16, with host, OS, role and notes. Six are marked Hold.
- Ops Hub tools added (restart Ops Hub to see them): **Readiness: plan**, **Readiness: run checks**, **Readiness: import pasted results**. Backup of the old list: `tools.json.bak-20261019`.

## What it does for each host
1. Looks it up: DNS, ports 22/445/3389/5985, and the EC2 instance if you allow SSM.
2. Picks a route:
   - **Linux, port 22 open:** SSH. One command sends the script, runs it with sudo, reads the CSV back and cleans up. 2 password prompts instead of 3. Use `-KeyFile` for none.
   - **EC2 with SSM** (only with `-AllowSsm`): runs the same script through SSM Run Command, no RDP and no password.
   - **Windows with WinRM open:** calls your Windows script remotely. Uses a domain login; if refused it drops to the next route.
   - **Anything else:** writes a paste bundle (`<host>-paste.txt`).
3. Parses the CSV and writes `Readiness-Summary-*.csv` and `Readiness-Notes-*.md` (a DRAFT case note per ticket, FAIL items listed, MANUAL items listed as still to confirm) in `C:\Temp\Readiness\<date>`.

It never closes or updates a ticket, never uses -AutoPatch or -AutoReboot, and a ticket with any FAIL is marked HOLD.

## Using it
```powershell
cd C:\Temp\OpsHub\scripts
.\Invoke-ReadinessRun.ps1 -Plan                                   # see the route for every ticket, runs nothing
.\Invoke-ReadinessRun.ps1 -Ticket SCTASK0156591,SCTASK0156583 -UserName patrol   # Linux over SSH
.\Invoke-ReadinessRun.ps1 -Ticket SCTASK0159790 -Via Bundle       # Windows batch: one paste bundle per host
.\Invoke-ReadinessRun.ps1 -ImportResult clipboard                 # after pasting a bundle on the server
```
**Paste bundle flow (Windows over RDP):** open `<host>-paste.txt`, copy the last line, paste it into an elevated PowerShell on the server, let it run, copy the one `READINESS-RESULT|...|END` line it prints back to your laptop clipboard, run the import command. Wrapped lines are fine.

## Windows from the laptop
The Sep 30 "Access is denied" came from using the laptop's own corp identity. With a domain login (asked once per domain) WinRM worked: 29 Windows hosts returned results on Oct 19. The WinRM activity was flagged by CSOC (INC5487641) because the payload is sent compressed and encoded, so get CSOC agreement before running it at scale. Hosts the laptop cannot reach (FedRAMP, UK Sov, lab) fall back to a paste bundle.

## Testing status (be aware)
**Proven on real servers:** WinRM with a domain login (29 hosts), report and note generation. **Tested only with stand-ins:** SSH, SSM, VMware, paste bundles. **Not yet proven:** a real Linux host over SSH, real SSM. Try `-Plan` first, then one Linux host, then one bundle, before running a batch.

## Decisions and approvals that unlock more
1. **SSM Run Command (ssm:SendCommand) from CloudOps.** This is the big one: it takes RDP out of every EC2 Windows ticket, including the 30 API servers on 0159800 and 0159790. Until then use bundles. Ask for read-only use of AWS-RunPowerShellScript / AWS-RunShellScript on the Systems role, and mention the script is read-only.
2. **SSH key** to the Linux hosts, to drop the password prompts.
3. **The Linux script still checks Cybereason.** The Windows script was moved to Cortex on Sep 30. Linux hosts will show a Cybereason FAIL until that line is updated.
4. **Run-as difference:** over SSM the Windows script runs as SYSTEM, not as you. Run one host both ways (RDP and SSM) once and compare before trusting SSM results for the AD/OU check.
5. **Queue to confirm:** role for ala-l38dwa01 (I set DWA from the name; my Oct 16 plan said WEB?), role API for the two API batches, the OS for oub-nweve01, eng-cmstg01 and ausya-lscol01 (detected from ports when reachable), and the LO200 hostnames (SCTASK0159794).
6. **SCTASK0156607 already has results.** dal-nwmcp01 (7 FAIL) and lax-nwmcp01 (8 FAIL) ran Sep 30 (`C:\Temp\linux-readiness`) and the ticket is still open. Those FAILs (GRUB password, SSH banner, session timeout, chrony source, firewalld) are real findings that need fixing or an exception before it can close.

## v2 (Oct 19 evening): Windows from the laptop, VMware, and OVERNIGHT mode
New routes, tried in order per host, Bundle last: **Ssm** (only with -AllowSsm) > **Ssh** (Linux) > **WinRM** (Windows, with a domain login) > **VMware** (Invoke-VMScript through VMware Tools, with -VCenters) > **Bundle**.
- **WinRM now uses a domain login** (asked once per domain, or -Credential). The script runs ON the server, so the AD lookup is local. The Sep 30 "Access is denied" was the laptop's own identity; if the domain login is refused too, the host falls to the next route.
- **SSH unattended**: with a login, the password goes to ssh via SSH_ASKPASS (OpenSSH 8.4+) and to sudo via stdin. Nothing is typed or put on a command line. If your Windows ssh is older and refuses, the error says so and the host falls to Bundle.
- **VMware**: needs PowerCLI, vCenter login and a guest login. No network path to the guest needed.
- **AWS facts** (read-only describe calls, signed-in profiles only): instance type, IPv6 present or not, EBS volume type/IOPS go into the notes for the MANUAL checks.
- **Output**: `Readiness-Paste-*.txt` is plain text, one block per ticket, headed OK to close after manual items / HOLD / NOT RUN. Paste it, check the MANUAL list, close yourself.

Tonight:
```powershell
cd C:\Temp\OpsHub\scripts
.\Invoke-ReadinessRun.ps1 -Plan                       # 1 minute, shows the route per host
.\Invoke-ReadinessRun.ps1 -Overnight                  # asks logins once, then runs everything it can
# optional: -VCenters eng-vmvce01.in.lab,lax-vmvce01.inucn.com  -AllowSsm (only after CloudOps approves)
```
Or use Ops Hub: **Readiness: OVERNIGHT run** (restart Ops Hub first).
Before you walk away: `aws sso login` for the profiles you want EC2 facts from (`.\Connect-AwsSso.ps1`), plugged in, on VPN, and accept SSH host keys once for the Linux hosts (ssh to each once), because unattended mode cannot answer the fingerprint prompt.

Not yet tested on a real laptop: SSH_ASKPASS on Windows, real WinRM with a domain login, PowerCLI Invoke-VMScript. Everything else ran end to end here on PowerShell 7 with stand-ins.
