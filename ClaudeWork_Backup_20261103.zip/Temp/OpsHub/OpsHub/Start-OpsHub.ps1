<#
.SYNOPSIS
  Ops Hub - local web app for the SysOps ticket queue (phase 1: read-only queue triage dashboard).

.DESCRIPTION
  Runs a small web server on http://localhost:8080 using only built-in PowerShell/.NET (nothing to install).
  Reads data\queue.json (snapshot), or refreshes it from ServiceNow, groups tickets into families using
  families.json, and shows what is automatable, blocked, change-gated, or aging.

  Phase 1 is READ-ONLY: it never changes a ticket or any system.
  Binds to localhost only. To host it on a server later, use -Bind and -AllowRemote (no login yet - put it
  behind your network controls or wait for the auth phase).

.EXAMPLE
  .\Start-OpsHub.ps1
  .\Start-OpsHub.ps1 -SnowLogin        # prompt for ServiceNow creds so the Refresh button can pull live data
  .\Start-OpsHub.ps1 -Port 9090 -NoBrowser
#>
[CmdletBinding()]
param(
    [int]$Port = 0,
    [string]$Bind = 'localhost',
    [switch]$AllowRemote,
    [switch]$SnowLogin,
    [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$WebDir = Join-Path $Root 'web'
$DataDir = Join-Path $Root 'data'
$Config = Get-Content (Join-Path $Root 'config.json') -Raw | ConvertFrom-Json
$Rules = Get-Content (Join-Path $Root 'families.json') -Raw | ConvertFrom-Json
if ($Port -le 0) { $Port = [int]$Config.port }
if ($Bind -notin 'localhost','127.0.0.1' -and -not $AllowRemote) {
    throw "Refusing to bind to '$Bind' without -AllowRemote. This version has no login - only expose it on a network you trust."
}
$script:SnowCred = $null
if ($SnowLogin) { $script:SnowCred = Get-Credential -Message "ServiceNow login for $($Config.instance) (kept in memory only)" }

function Log([string]$m) { Write-Host ("{0}  {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) }

# ---------------- data ----------------
function ConvertTo-Date([string]$s) {
    $d = [datetime]::MinValue
    foreach ($f in 'MM/dd/yyyy HH:mm:ss','M/d/yyyy h:mm:ss tt','M/d/yyyy H:mm:ss','yyyy-MM-dd HH:mm:ss') {
        if ([datetime]::TryParseExact($s, $f, [Globalization.CultureInfo]::InvariantCulture, 'None', [ref]$d)) { return $d }
    }
    if ([datetime]::TryParse($s, [Globalization.CultureInfo]::InvariantCulture, 'None', [ref]$d)) { return $d }
    return $null
}

function Read-Queue {
    $json = Join-Path $DataDir 'queue.json'
    $csv  = Join-Path $DataDir 'queue.csv'
    $useCsv = (Test-Path $csv) -and ((-not (Test-Path $json)) -or ((Get-Item $csv).LastWriteTime -gt (Get-Item $json).LastWriteTime))
    if ($useCsv) {
        $rows = @(Import-Csv $csv)
        if (-not $rows.Count) { throw 'queue.csv is empty' }
        $h = $rows[0].PSObject.Properties.Name
        $cNum  = $h | Where-Object { $_ -match '^number$' } | Select-Object -First 1
        $cDesc = $h | Where-Object { $_ -match 'short.?desc' } | Select-Object -First 1
        $cOpen = $h | Where-Object { $_ -match '^opened(_at)?$' } | Select-Object -First 1
        $cItem = $h | Where-Object { $_ -match 'request.?item|^item$' } | Select-Object -First 1
        if (-not ($cNum -and $cDesc)) { throw "queue.csv needs columns 'Number' and 'Short description' (and ideally 'Opened'). Found: $($h -join ', ')" }
        $t = foreach ($r in $rows) { [pscustomobject]@{ number = $r.$cNum; short_description = $r.$cDesc; opened_at = $(if ($cOpen) { $r.$cOpen } else { '' }); ritm = $(if ($cItem) { $r.$cItem } else { '' }) } }
        return [pscustomobject]@{ asOf = (Get-Item $csv).LastWriteTime.ToString('s'); source = 'CSV import (data\queue.csv)'; tickets = @($t) }
    }
    if (-not (Test-Path $json)) { throw 'No data yet: put a ServiceNow list export at data\queue.csv or use -SnowLogin and Refresh.' }
    return (Get-Content $json -Raw | ConvertFrom-Json)
}

function Get-Dashboard {
    $q = Read-Queue
    $now = Get-Date
    $stale = [int]$Config.staleDays
    $groups = @{}
    foreach ($t in @($q.tickets)) {
        $fam = $null
        foreach ($r in $Rules.rules) { if ($t.short_description -match $r.match) { $fam = $r; break } }
        if ($fam) { $key = $fam.name; $level = $fam.level; $note = $fam.note }
        else {
            $first = ($t.short_description -split ' - ')[0]
            $key = 'Other: ' + (($first -replace '\d+', '#').Trim())
            if ($key.Length -gt 70) { $key = $key.Substring(0, 70) }
            $level = 'manual'; $note = ''
        }
        $opened = ConvertTo-Date ([string]$t.opened_at)
        $age = $null; if ($opened) { $age = [int][math]::Floor(($now - $opened).TotalDays) }
        $item = [pscustomobject]@{ number = $t.number; description = $t.short_description; opened = $(if ($opened) { $opened.ToString('yyyy-MM-dd') } else { '' }); ageDays = $age; stale = [bool]($age -ne $null -and $age -ge $stale); ritm = $t.ritm }
        if (-not $groups.ContainsKey($key)) { $groups[$key] = [pscustomobject]@{ name = $key; level = $level; note = $note; tickets = (New-Object System.Collections.ArrayList) } }
        [void]$groups[$key].tickets.Add($item)
    }
    $fams = foreach ($g in $groups.Values) {
        $ages = @($g.tickets | Where-Object { $_.ageDays -ne $null } | ForEach-Object { $_.ageDays })
        [pscustomobject]@{
            name = $g.name; level = $g.level; note = $g.note
            count = $g.tickets.Count
            oldestDays = $(if ($ages.Count) { ($ages | Measure-Object -Maximum).Maximum } else { $null })
            staleCount = @($g.tickets | Where-Object { $_.stale }).Count
            tickets = @($g.tickets | Sort-Object { $_.ageDays } -Descending)
        }
    }
    $levelsOut = @{}
    foreach ($p in $Rules.levels.PSObject.Properties) { $levelsOut[$p.Name] = $p.Value }
    [pscustomobject]@{
        asOf = $q.asOf; source = $q.source; instance = $Config.instance; staleDays = $stale
        total = @($q.tickets).Count
        levels = $levelsOut
        families = @($fams)
    }
}

function Update-FromServiceNow {
    if (-not $script:SnowCred) {
        $csv = Join-Path $DataDir 'queue.csv'
        if (Test-Path $csv) { return @{ ok = $true; message = 'Reloaded from data\queue.csv' } }
        return @{ ok = $false; message = 'Not logged in to ServiceNow. Restart with -SnowLogin, or export the list view to data\queue.csv (Number, Short description, Opened).' }
    }
    $pair = '{0}:{1}' -f $script:SnowCred.UserName, $script:SnowCred.GetNetworkCredential().Password
    $hdr = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pair)); Accept = 'application/json' }
    $uri = "$($Config.instance)/api/now/table/sc_task?sysparm_query=$([uri]::EscapeDataString($Config.query))&sysparm_fields=number,short_description,opened_at,request_item&sysparm_display_value=true&sysparm_limit=1000"
    try { $r = Invoke-RestMethod -Uri $uri -Headers $hdr -Method Get }
    catch { return @{ ok = $false; message = "ServiceNow call failed: $($_.Exception.Message). If your org requires SSO/MFA for API access, use the CSV export route instead." } }
    $t = foreach ($x in $r.result) {
        $ri = ''; if ($x.request_item) { if ($x.request_item.display_value) { $ri = $x.request_item.display_value } else { $ri = [string]$x.request_item } }
        [pscustomobject]@{ number = $x.number; short_description = $x.short_description; opened_at = $x.opened_at; ritm = $ri }
    }
    $out = [pscustomobject]@{ asOf = (Get-Date).ToString('s'); source = 'ServiceNow (live)'; tickets = @($t) }
    $out | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $DataDir 'queue.json') -Encoding UTF8
    $csv = Join-Path $DataDir 'queue.csv'; if (Test-Path $csv) { Remove-Item $csv }   # live data wins
    return @{ ok = $true; message = "Loaded $(@($t).Count) tickets from ServiceNow" }
}

# ---------------- http ----------------
$mime = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.css' = 'text/css; charset=utf-8'; '.json' = 'application/json; charset=utf-8'; '.svg' = 'image/svg+xml'; '.ico' = 'image/x-icon' }
function Send([System.Net.HttpListenerResponse]$res, [int]$code, [string]$type, [byte[]]$bytes) {
    $res.StatusCode = $code; $res.ContentType = $type
    $res.Headers['Cache-Control'] = 'no-store'
    $res.Headers['X-Content-Type-Options'] = 'nosniff'
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes, 0, $bytes.Length); $res.OutputStream.Close()
}
function Send-Json($res, $obj, [int]$code = 200) {
    Send $res $code 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Depth 8 -Compress)))
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://${Bind}:$Port/")
try { $listener.Start() } catch { throw "Could not listen on port $Port ($($_.Exception.Message)). Try -Port 9090." }
$url = "http://${Bind}:$Port/"
Log "Ops Hub running at $url   (Ctrl+C to stop)"
if (-not $NoBrowser) { try { Start-Process $url } catch {} }

try {
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        $req = $ctx.Request; $res = $ctx.Response
        try {
            $path = $req.Url.AbsolutePath
            Log "$($req.HttpMethod) $path"
            if ($path -eq '/api/queue' -and $req.HttpMethod -eq 'GET') { Send-Json $res (Get-Dashboard) }
            elseif ($path -eq '/api/refresh' -and $req.HttpMethod -eq 'POST') { Send-Json $res (Update-FromServiceNow) }
            elseif ($path -eq '/api/health') { Send-Json $res @{ ok = $true; time = (Get-Date).ToString('s'); live = [bool]$script:SnowCred } }
            elseif ($req.HttpMethod -eq 'GET') {
                if ($path -eq '/') { $path = '/index.html' }
                $full = [IO.Path]::GetFullPath((Join-Path $WebDir ($path.TrimStart('/') -replace '/', [IO.Path]::DirectorySeparatorChar)))
                if (-not $full.StartsWith($WebDir, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $full -PathType Leaf)) {
                    Send $res 404 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Not found'))
                } else {
                    $ext = [IO.Path]::GetExtension($full).ToLower()
                    $ct = 'application/octet-stream'; if ($mime.ContainsKey($ext)) { $ct = $mime[$ext] }
                    Send $res 200 $ct ([IO.File]::ReadAllBytes($full))
                }
            }
            else { Send $res 405 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Method not allowed')) }
        } catch {
            Log "ERROR: $($_.Exception.Message)"
            try { Send-Json $res @{ ok = $false; error = $_.Exception.Message } 500 } catch {}
        }
    }
} finally { $listener.Stop(); $listener.Close() }
