# Ops Hub (phase 1: read-only queue triage)

Run (Windows PowerShell 5.1 or 7, nothing to install):

    .\Start-OpsHub.ps1                 # opens http://localhost:8080
    .\Start-OpsHub.ps1 -SnowLogin      # prompts for ServiceNow creds so Refresh pulls live data
    .\Start-OpsHub.ps1 -Port 9090 -NoBrowser

Data
- data\queue.json is a snapshot of the unassigned queue (218 tickets as of 2026-10-08).
- To refresh without API access: export the ServiceNow list view to data\queue.csv
  (columns Number, Short description, Opened). A newer CSV wins over the JSON.
- If your org forces SSO/MFA on the API, -SnowLogin will fail; use the CSV route.

Tuning
- families.json: ordered regex rules, first match wins. Levels: automate, assist, blocked, gated, manual.
  Unmatched tickets show as "Other: ...".
- config.json: instance, query, staleDays, port.

Safety
- Phase 1 never changes a ticket or a system. It only reads.
- Binds to localhost only. Hosting on a server later needs -Bind <host> -AllowRemote and, before
  sharing, an auth phase (no login yet).

Roadmap: terminations module (check, approve, clean up, work note), recurring-review evidence runner,
Pleasant quarterly review, server tools (readiness, iLO/AHS), email/Teams/alert digests.
