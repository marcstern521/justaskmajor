# Ops Hub demo steps (about 20-25 min)

## Before the meeting (tonight / 10 min in the morning)
1. On your laptop, open `C:\Temp\OpsHub`. Double-click `Run-OpsHub.cmd` (or `.\Start-OpsHub.ps1`). Browser opens on http://localhost:8080.
2. Refresh the queue so the data is current: `.\Start-OpsHub.ps1 -SnowLogin` (log in yourself), or use the last `data\queue.json`.
3. Tools > Setup > **Preflight**. Fix anything red now (AWS: `aws sso login`).
4. Have these ready: VPN/corp network, a server name you know is up, your own AD username.
5. Open these files in tabs: `Claude outputs\Active-in-Okta-2026-10-26.csv`, `README.md`, `SERVER.md`.
6. Do NOT demo anything under "Changes things" on production. Use dry runs only.

## Demo flow
1. **The problem (2 min).** Many recurring SysOps tickets, each with its own checklist, logins and tools. Ops Hub puts them in one place.
2. **Queue tab (4 min).** Show the families and automation levels (Automate now / Partly / Manual). Open Employee Terminations: term date, FUTURE flag, **Check this user**.
3. **Term check (3 min).** Click Check this user on your own account or 3-4 names. Show it searching inucn, in.lab and incmp. Reports tab: one-click summary and work-note draft.
4. **Reviews tab (4 min).** Open Rubrik or Nimble: baselines (do not re-flag), links, close rule, log to `review_log.csv`. Mention 27 review types and the Friday 2am weekly run.
5. **Tools tab (4 min).** Run Server reachability and Certificate expiry on two hosts. Show that it opens a PowerShell window, and credentials and MFA are typed there, never in the web page. Show a "Changes things" tool asking for a ticket number and typing RUN, then cancel at the prompt.
6. **Runs and audit (2 min).** Runs tab shows the live log. Download `audit.csv` to show user and time on every action.
7. **Okta termination reconciliation (3 min).** Open `Active-in-Okta-2026-10-26.csv`: HR emails vs SNOW tickets vs Okta export, 50 leavers still active. Explain the 30-day repeat.
8. **Safety model and gaps (2 min).** Read-only default, typed RUN, audit trail, no secrets in the page, localhost-only. Gaps: Okta API token pending, ssm:SendCommand pending, some tools untested.
9. **Ask (2 min).** Hosting, service account or job runner, and code review.

## If something breaks
- Page will not load: check the PowerShell window for a port error, then `.\Start-OpsHub.ps1 -Port 9090`.
- A tool fails: it prints raw output on purpose. Show it and say it is on the known-gaps list.
- No SNOW login: use the cached queue (`data\queue.json`).
- No AWS: skip the EC2 tools and say it needs `aws sso login`.

## Files to point at
- `README.md` - tabs, safety model, known gaps
- `SERVER.md` - moving it to a server (auth, readers/runners, service)
- `IDEAS.md` - what is next
- `scripts\` - the PowerShell tools
- `families.json`, `reviews.json`, `tools.json`, `snippets.json` - how to add a tool or review
- `data\audit.csv` - audit trail
