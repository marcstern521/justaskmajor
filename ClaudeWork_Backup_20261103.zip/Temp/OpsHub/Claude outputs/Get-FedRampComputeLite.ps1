<#
.SYNOPSIS
  READ-ONLY, no PowerCLI needed. Checks vCenter hosts and datastores through the vCenter REST API (vSphere 7.0 U2 or newer).
  Run it ON the FedRAMP jump server. Changes nothing.

.NOTES
  Covers: host connection/power state, datastore free space, cluster list.
  NOT covered (do in the vSphere Client): triggered alarms, vSAN Skyline Health / resync, OneView / iLO hardware alerts.
  Login = your FedRAMP vCenter account. The password is only typed at the prompt.
#>
param(
    [string]$VCenter = 'cul-vmvce01.incmp.com',
    [pscredential]$Credential,
    [int]$FreePctWarn = 15,
    [int]$MinDatastoreGB = 10,
    [string]$OutDir = 'C:\Temp\FedRampWeekly'
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if ($PSVersionTable.PSEdition -ne 'Core') {
    Add-Type -TypeDefinition 'using System.Net;using System.Security.Cryptography.X509Certificates;public class TrustAll:ICertificatePolicy{public bool CheckValidationResult(ServicePoint s,X509Certificate c,WebRequest r,int p){return true;}}' -ErrorAction SilentlyContinue
    [Net.ServicePointManager]::CertificatePolicy = New-Object TrustAll
}
if (-not $Credential) { $Credential = Get-Credential -Message "FedRAMP vCenter login for $VCenter (read-only is fine)" }
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -Force | Out-Null }
$base = "https://$VCenter"
$pair = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($Credential.UserName):$($Credential.GetNetworkCredential().Password)"))
$tok = Invoke-RestMethod -Method Post -Uri "$base/api/session" -Headers @{ Authorization = "Basic $pair" }
$pair = $null
$h = @{ 'vmware-api-session-id' = $tok }
$rows = New-Object System.Collections.Generic.List[object]
function Add-Row($type, $name, $detail, $status) { $rows.Add([pscustomobject]@{ Type = $type; Name = $name; Detail = $detail; Status = $status }) }
try {
    foreach ($x in @(Invoke-RestMethod -Uri "$base/api/vcenter/host" -Headers $h | Sort-Object name)) {
        $st = 'OK'
        if ($x.connection_state -eq 'MAINTENANCE') { $st = 'NOTE: Maintenance' }
        elseif ($x.connection_state -ne 'CONNECTED') { $st = "ISSUE: $($x.connection_state)" }
        elseif ($x.power_state -ne 'POWERED_ON') { $st = "ISSUE: $($x.power_state)" }
        Add-Row 'Host' $x.name "$($x.connection_state) / $($x.power_state)" $st
    }
    foreach ($d in @(Invoke-RestMethod -Uri "$base/api/vcenter/datastore" -Headers $h | Sort-Object name)) {
        $capGB = [math]::Round($d.capacity / 1GB, 0); $freeGB = [math]::Round($d.free_space / 1GB, 0)
        $pct = if ($d.capacity) { [math]::Round(100 * $d.free_space / $d.capacity, 1) } else { 0 }
        $st = 'OK'; if ($pct -lt $FreePctWarn -and $capGB -ge $MinDatastoreGB) { $st = "ISSUE: only $pct% free" }
        Add-Row 'Datastore' $d.name ("{0:N0} GB free of {1:N0} GB ({2}%) type={3}" -f $freeGB, $capGB, $pct, $d.type) $st
    }
    foreach ($c in @(Invoke-RestMethod -Uri "$base/api/vcenter/cluster" -Headers $h | Sort-Object name)) { Add-Row 'Cluster' $c.name "ha=$($c.ha_enabled) drs=$($c.drs_enabled)" 'LISTED' }
} finally { try { Invoke-RestMethod -Method Delete -Uri "$base/api/session" -Headers $h | Out-Null } catch {} }

$csv = Join-Path $OutDir ("FedRampWeeklyLite_{0}.csv" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
$rows | Export-Csv -NoTypeInformation -Path $csv
$issues = @($rows | Where-Object { $_.Status -like 'ISSUE*' })
Write-Host "`nHosts: $(@($rows | Where-Object Type -eq 'Host').Count)   Datastores: $(@($rows | Where-Object Type -eq 'Datastore').Count)   Issues: $($issues.Count)" -ForegroundColor Cyan
$issues | Format-Table Type, Name, Detail, Status -AutoSize -Wrap
Write-Host "Report: $csv" -ForegroundColor Green
Write-Host "`nStill to do by hand before closing: vSphere Client > Alarms, vSAN Skyline Health + resync, OneView/iLO alerts." -ForegroundColor Yellow
