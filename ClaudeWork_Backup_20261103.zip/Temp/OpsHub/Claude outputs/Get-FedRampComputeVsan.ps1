<#
.SYNOPSIS
  READ-ONLY weekly check for "Weekly Review Task - FedRAMP HPE Compute and vSAN". Run it ON the FedRAMP jump server.
  Changes nothing. Checks vCenter hosts, vSAN clusters (disk groups, resync, health), datastore space and triggered alarms.

.NOTES
  Needs VMware PowerCLI on the jump server (Install-Module VMware.PowerCLI -Scope CurrentUser, or use the copy that is already there).
  Login = your FedRAMP vCenter account (separate from AD). Read-only is enough. The password is only typed at the prompt.
  NOT covered (check by hand): OneView / iLO hardware alerts, vSAN Skyline Health detail pages.

.EXAMPLE
  .\Get-FedRampComputeVsan.ps1
  .\Get-FedRampComputeVsan.ps1 -VCenter cul-vmvce01.incmp.com -FreePctWarn 20
#>
param(
    [string]$VCenter = 'cul-vmvce01.incmp.com',
    [pscredential]$Credential,
    [int]$FreePctWarn = 15,
    [int]$MinDatastoreGB = 10,
    [string]$OutDir = 'C:\Temp\FedRampWeekly'
)
$ErrorActionPreference = 'Stop'
if (-not (Get-Module -ListAvailable -Name VMware.VimAutomation.Core)) { throw 'VMware PowerCLI not found on this server. Install-Module VMware.PowerCLI -Scope CurrentUser (or run it from a box that has it).' }
if (-not $Credential) { $Credential = Get-Credential -Message "FedRAMP vCenter login for $VCenter (read-only is fine)" }
Import-Module VMware.VimAutomation.Core
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false -ParticipateInCEIP $false | Out-Null
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -Force | Out-Null }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$rows = New-Object System.Collections.Generic.List[object]
function Add-Row($type, $name, $detail, $status) { $rows.Add([pscustomobject]@{ Type = $type; Name = $name; Detail = $detail; Status = $status }) }

Write-Host "Connecting to $VCenter ..." -ForegroundColor DarkGray
$null = Connect-VIServer -Server $VCenter -Credential $Credential
try {
    # ---- hosts
    foreach ($h in Get-VMHost | Sort-Object Name) {
        $st = 'OK'
        if ($h.ConnectionState -eq 'Maintenance') { $st = 'NOTE: Maintenance' }
        elseif ($h.ConnectionState -ne 'Connected') { $st = "ISSUE: $($h.ConnectionState)" }
        elseif ($h.PowerState -ne 'PoweredOn') { $st = "ISSUE: $($h.PowerState)" }
        $cpu = if ($h.CpuTotalMhz) { [int](100 * $h.CpuUsageMhz / $h.CpuTotalMhz) } else { 0 }
        $mem = if ($h.MemoryTotalGB) { [int](100 * $h.MemoryUsageGB / $h.MemoryTotalGB) } else { 0 }
        Add-Row 'Host' $h.Name "v$($h.Version) cpu=$cpu% mem=$mem% cluster=$($h.Parent.Name)" $st
    }
    # ---- vSAN (each part is optional: a missing cmdlet is reported, never hidden)
    foreach ($c in Get-Cluster | Sort-Object Name) {
        if (-not $c.VsanEnabled) { continue }
        try { $dg = @(Get-VsanDiskGroup -Cluster $c -ErrorAction Stop); Add-Row 'vSAN' $c.Name "$($dg.Count) disk group(s)" $(if ($dg.Count) { 'OK' } else { 'ISSUE: no disk groups' }) }
        catch { Add-Row 'vSAN' $c.Name "disk groups: could not read ($($_.Exception.Message.Split([char]10)[0]))" 'CHECK BY HAND' }
        try { $rs = @(Get-VsanResyncingComponent -Cluster $c -ErrorAction Stop); Add-Row 'vSAN' $c.Name "resyncing components: $($rs.Count)" $(if ($rs.Count -eq 0) { 'OK' } else { 'NOTE: resync running' }) }
        catch { Add-Row 'vSAN' $c.Name "resync: could not read ($($_.Exception.Message.Split([char]10)[0]))" 'CHECK BY HAND' }
        try {
            $hl = Test-VsanClusterHealth -Cluster $c -ErrorAction Stop
            $txt = ($hl | Out-String) -replace '\s+', ' '
            $bad = $txt -match '(?i)\b(red|failed|failure|yellow|warning)\b'
            Add-Row 'vSAN health' $c.Name $(if ($txt.Length -gt 200) { $txt.Substring(0, 200) } else { $txt }) $(if ($bad) { 'ISSUE: review health output' } else { 'OK' })
        } catch { Add-Row 'vSAN health' $c.Name "Test-VsanClusterHealth not available ($($_.Exception.Message.Split([char]10)[0])). Open vSAN Skyline Health in the vSphere client." 'CHECK BY HAND' }
    }
    # ---- datastores
    foreach ($d in Get-Datastore | Sort-Object Name) {
        $pct = if ($d.CapacityGB) { [math]::Round(100 * $d.FreeSpaceGB / $d.CapacityGB, 1) } else { 0 }
        $st = 'OK'
        if (-not $d.Accessible) { $st = 'ISSUE: not accessible' }
        elseif ($pct -lt $FreePctWarn -and $d.CapacityGB -ge $MinDatastoreGB) { $st = "ISSUE: only $pct% free" }
        Add-Row 'Datastore' $d.Name ("{0:N0} GB free of {1:N0} GB ({2}%)" -f $d.FreeSpaceGB, $d.CapacityGB, $pct) $st
    }
    # ---- triggered alarms (vCenter, datacenters, clusters, hosts, datastores)
    $ents = @(); $ents += Get-Datacenter; $ents += Get-Cluster; $ents += Get-VMHost; $ents += Get-Datastore
    foreach ($e in $ents) {
        foreach ($a in @($e.ExtensionData.TriggeredAlarmState)) {
            if (-not $a) { continue }
            $nm = try { (Get-View -Id $a.Alarm -Property Info.Name).Info.Name } catch { "$($a.Alarm)" }
            Add-Row 'Alarm' $e.Name "$nm ($($a.OverallStatus))" $(if ("$($a.OverallStatus)" -eq 'red') { 'ISSUE: red alarm' } else { 'ISSUE: yellow alarm' })
        }
    }
} finally { Disconnect-VIServer -Server $VCenter -Confirm:$false -ErrorAction SilentlyContinue }

$csv = Join-Path $OutDir "FedRampWeekly_${stamp}.csv"
$rows | Export-Csv -NoTypeInformation -Path $csv
$issues = @($rows | Where-Object { $_.Status -like 'ISSUE*' })
$byHand = @($rows | Where-Object { $_.Status -eq 'CHECK BY HAND' })
Write-Host ''
Write-Host "Hosts: $(@($rows | Where-Object Type -eq 'Host').Count)   Datastores: $(@($rows | Where-Object Type -eq 'Datastore').Count)   Issues: $($issues.Count)   Check by hand: $($byHand.Count)" -ForegroundColor Cyan
$issues | Format-Table Type, Name, Detail, Status -AutoSize -Wrap
$byHand | Format-Table Type, Name, Detail -AutoSize -Wrap
Write-Host "Report: $csv" -ForegroundColor Green
if ($issues.Count -eq 0 -and $byHand.Count -eq 0) {
    Write-Host "`nPaste-ready note (add your OneView/iLO result first):" -ForegroundColor Green
    Write-Host "FedRAMP HPE compute and vSAN reviewed $(Get-Date -Format 'yyyy-MM-dd'): vCenter $VCenter hosts connected, vSAN disk groups healthy with no resync, datastores have free space, no triggered alarms."
} else {
    Write-Host "`nDo NOT close yet: fix or explain the items above, and confirm OneView/iLO by hand." -ForegroundColor Yellow
}
