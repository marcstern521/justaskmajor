<#
.SYNOPSIS
  READ-ONLY. Reports Security event log retention on every Domain Controller of the domain you run it in:
  log mode (overwrite as needed / archive / never overwrite), max size, current size, oldest and newest event,
  how many days of events are actually in the log, and any GPO-set size/retention value.
  Changes nothing. No RSAT / AD module needed.

.EXAMPLE
  .\Get-DcSecurityLogRetention.ps1                       # DCs of the domain this machine is in
  .\Get-DcSecurityLogRetention.ps1 -DomainControllers dal-indco01.inucn.com,lax-indco01.inucn.com
  .\Get-DcSecurityLogRetention.ps1 -OutDir C:\Temp\DcLogRetention

.NOTES
  Uses the remote Event Log service (RPC), not WinRM. Run it from a machine that can reach the DCs
  (laptop for INUCN/INEUR, the INCMP jump servers for INCMP). Your account needs rights to read the Security log
  on the DC (Domain Admin / Event Log Readers / Security log rights). Run once per domain.
#>
param(
    [string[]]$DomainControllers,
    [string]$OutDir = 'C:\Temp\DcLogRetention'
)
$ErrorActionPreference = 'Continue'
if (-not $DomainControllers) {
    try {
        $dom = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
        $DomainControllers = @($dom.DomainControllers | ForEach-Object { $_.Name } | Sort-Object)
        $domName = $dom.Name
    } catch { throw "Could not find this machine's domain controllers: $($_.Exception.Message). Use -DomainControllers." }
} else { $domName = ($DomainControllers[0] -replace '^[^.]+\.', '') }
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -Force | Out-Null }
Write-Host "Domain $domName : $($DomainControllers.Count) DC(s)" -ForegroundColor Cyan

function Get-RegValue($comp, $subKey, $name) {
    try {
        $b = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $comp)
        $k = $b.OpenSubKey($subKey); if (-not $k) { return $null }
        return $k.GetValue($name)
    } catch { return $null }
}
function Convert-Mode($m) {
    switch ("$m") {
        'Circular'   { 'Overwrite events as needed (size-based)' }
        'AutoBackup' { 'Archive the log when full (no overwrite)' }
        'Retain'     { 'Do not overwrite events (manual clear)' }
        default      { "$m" }
    }
}

$rows = foreach ($dc in $DomainControllers) {
    $o = [ordered]@{ Domain = $domName; DC = $dc; Reachable = 'no'; LogMode = ''; Policy = ''; MaxSizeMB = ''; CurrentSizeMB = ''; Records = ''; OldestEvent = ''; NewestEvent = ''; DaysCovered = ''; GpoMaxSizeKB = ''; GpoRetention = ''; Error = '' }
    try {
        $log = Get-WinEvent -ListLog Security -ComputerName $dc -ErrorAction Stop
        $o.Reachable = 'yes'
        $o.LogMode = "$($log.LogMode)"; $o.Policy = Convert-Mode $log.LogMode
        $o.MaxSizeMB = [math]::Round($log.MaximumSizeInBytes / 1MB, 0)
        $o.CurrentSizeMB = [math]::Round($log.FileSize / 1MB, 0)
        $o.Records = $log.RecordCount
        try {
            $old = Get-WinEvent -LogName Security -ComputerName $dc -MaxEvents 1 -Oldest -ErrorAction Stop
            $new = Get-WinEvent -LogName Security -ComputerName $dc -MaxEvents 1 -ErrorAction Stop
            $o.OldestEvent = $old.TimeCreated.ToString('yyyy-MM-dd HH:mm'); $o.NewestEvent = $new.TimeCreated.ToString('yyyy-MM-dd HH:mm')
            $o.DaysCovered = [math]::Round(($new.TimeCreated - $old.TimeCreated).TotalDays, 1)
        } catch { $o.Error = "could not read events: $($_.Exception.Message.Split([char]10)[0])" }
        $gs = Get-RegValue $dc 'SOFTWARE\Policies\Microsoft\Windows\EventLog\Security' 'MaxSize'
        $gr = Get-RegValue $dc 'SOFTWARE\Policies\Microsoft\Windows\EventLog\Security' 'Retention'
        if ($null -ne $gs) { $o.GpoMaxSizeKB = $gs }
        if ($null -ne $gr) { $o.GpoRetention = $gr }
    } catch { $o.Error = $_.Exception.Message.Split([char]10)[0] }
    [pscustomobject]$o
}
$csv = Join-Path $OutDir ("DcSecurityLog_{0}_{1}.csv" -f ($domName -replace '[^A-Za-z0-9.-]', '_'), (Get-Date -Format 'yyyyMMdd-HHmm'))
$rows | Export-Csv -NoTypeInformation -Path $csv
$rows | Format-Table DC, LogMode, MaxSizeMB, CurrentSizeMB, OldestEvent, DaysCovered, Error -AutoSize -Wrap
Write-Host "Report: $csv" -ForegroundColor Green
$ok = @($rows | Where-Object { $_.Reachable -eq 'yes' -and $_.DaysCovered -ne '' })
if ($ok.Count) {
    $min = ($ok | Measure-Object DaysCovered -Minimum).Minimum; $max = ($ok | Measure-Object DaysCovered -Maximum).Maximum
    Write-Host "`nSummary for $domName : $($ok.Count) of $($rows.Count) DCs read. Events go back $min to $max days. Mode(s): $((($ok | Select -Expand Policy) | Sort -Unique) -join '; ')." -ForegroundColor Yellow
}
