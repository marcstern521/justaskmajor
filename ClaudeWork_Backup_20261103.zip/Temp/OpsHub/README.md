# Ops Hub v0.3

A local web app for the SysOps queue and the scripts we built together. Nothing to install: it is PowerShell + a browser.

## Start
Double-click `Run-OpsHub.cmd` (unblocks the files, bypasses execution policy for that one process only), or:

    .\Start-OpsHub.ps1                 # http://localhost:8080
    .\Start-OpsHub.ps1 -SnowLogin      # prompt for ServiceNow creds so Refresh pulls live data
    .\Start-OpsHub.ps1 -Port 9090 -NoBrowser -ReportDir D:\Reports

## Tabs
- **Queue** - 218-ticket triage by family and automation level. Aging, NEW-since-last-refresh, per-family work notes.
  Terminations show the term date (flags FUTURE dates so you do not act early) and a **Check this user** button that
  pre-fills the term check. Recurring-review tickets have a **Review** button.
- **Reviews** - 27 review types, including every monthly task we built as scheduled reminders: Rubrik, Cisco Intersight (4 accounts,
  leave tickets open), Nimble (duplicate handling), iLO (8 servers), LA 3PAR closure, Singapore ESXi/vSAN, ViaWest Lab, FedRAMP
  compute and Globalscape, AU Sov CA, SSL digest, DNS cleanup, Red Hat, and the Salesforce storage-eligibility report. Each shows
  its known baselines (do not re-flag), URLs, whether it needs a live login, and the close rule. Per-section findings feed the work
  note. A 'due' badge appears when it has not been logged this period. Log to `data\review_log.csv` as evidence.
- **Tools** - forms for the scripts in `scripts\`. Run opens a PowerShell window (credential/MFA prompts happen there).
  "Changes things" tools need a ticket/change number and you typing RUN, and the script still asks per item.
- **Snippets** - 45 copy-paste commands (Windows, AD, AWS, Linux, VMware, certs, iLO) with {{server}}/{{user}}/{{drive}}
  placeholders you fill once at the top.
- **Runs** - live log of every tool run (kept in `runs\`) and a download link for the audit trail (`data\audit.csv`).
- **Reports** - the CSVs the scripts write. Candidates files get checkboxes and **Save approved list**; TermCheck files get a
  one-click summary / work-note draft. ENABLED/FOUND are red, NotFound/OK green.
- **Digest** (header) - plain-text queue summary to copy or (if `teamsWebhook` is set in config.json) post to Teams.

## Test order (one at a time)
1. Tools > Setup > **Preflight** (shows what is missing: RSAT, AWS login, DC ports, ...).
2. **Server reachability** on two servers you know. 3. **Certificate expiry** on a couple of hosts.
4. **AD user lookup** on yourself. 5. **Term check** with 3-4 names. 6. **AWS: find EC2 / events** after `aws sso login`.
7. **iLO** Info then IML on one blade (AHS last). 8. **AD backup** and **vCenter health** (need repadmin / PowerCLI).
9. Reviews tab dry run on one ticket type. 10. INCMP dry run on cva-indco01.

## Files you may edit
- `families.json` - how tickets are grouped (regex, first match wins), level, note, work-note text, linked tool.
- `reviews.json` - checklist steps, links, OK text. Links are best guesses from your bookmarks; fix hostnames as needed.
- `tools.json` - add a tool = drop a script in `scripts\` + one entry. Parameters render as the form.
- `snippets.json` - add your own commands.
- `config.json` - instance, query, staleDays, port, analyst name, teamsWebhook, access (server mode).

## Safety model
- Read-only tabs never change anything. Tool runs are local (your laptop, your credentials, your console window).
- Change tools: ticket/change number required + typed RUN + the script's own confirm/WhatIf prompts.
- Every run, review log, approved list and Teams post is appended to `data\audit.csv` with user and time.
- Requests with a foreign Host header or without the `X-OpsHub` header are rejected (blocks drive-by web pages).
- No passwords pass through the web page. Scripts prompt in the console; transcripts can contain what is printed, so scripts never print secrets.

## Known gaps / untested
- Not yet run on your Windows PowerShell 5.1 (tested on PowerShell 7). Syntax-checked for both.
- Untested against real systems: iLO AHS download URL, repadmin output parser, vCenter health, AD lookup. Each prints raw
  output on failure so the fix is quick.
- ServiceNow API may require SSO/MFA; if `-SnowLogin` fails use the list-view CSV export to `data\queue.csv`.

See `SERVER.md` for sharing it and `IDEAS.md` for what is next.
