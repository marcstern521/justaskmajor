# Moving Ops Hub to a server (when you are ready to share)

Today it runs on your laptop bound to localhost. Sharing it is mostly config, but decide these first:

1. **Who can see it / who can run things.** Server mode uses Windows login (Kerberos/NTLM) and two lists in `config.json`:

       "access": { "readers": ["*"], "runners": ["INUCN\\marc.stern"] }

   Readers see queue, reviews, snippets, reports. Only runners can refresh, log reviews, save approved lists, post to Teams.
   (If `readers` is empty, only runners can get in.)
2. **Tool runs stay on your laptop.** They open a PowerShell window and use your credentials, so in server mode they are
   disabled unless you pass `-AllowRemoteRuns` (not recommended). The server hosts the dashboards; your laptop keeps the tools.
   Later phase: Rundeck/agent jobs so tools can run server-side with a service account.
3. **Data location.** `data\`, `runs\`, and the report folder should live on the server (not a user profile), with NTFS rights
   limited to the service account and admins.

## Run it
On the server (needs an URL ACL once, as admin):

    netsh http add urlacl url=http://+:8080/ user="INUCN\svc-opshub"
    .\Start-OpsHub.ps1 -Bind + -AllowRemote -WindowsAuth -NoBrowser

Run it as a service/scheduled task at startup (Task Scheduler: "Run whether user is logged on or not", action:
`powershell.exe -NoProfile -ExecutionPolicy Bypass -File D:\OpsHub\Start-OpsHub.ps1 -Bind + -AllowRemote -WindowsAuth -NoBrowser`).
Put it behind your internal DNS name and, ideally, an HTTPS reverse proxy (IIS ARR, nginx). HttpListener here is plain HTTP.

## Live ServiceNow on the server
-SnowLogin prompts interactively, which a service cannot do. Options: (a) a scheduled task on the laptop exports the queue CSV to
the server share each morning; (b) a ServiceNow integration user with read-only access to sc_task, credentials in a secured file
or vault; (c) the Power Automate flow you already run dropping a CSV/JSON. Pick (a) or (c) first: no stored credentials.

## Security notes
- No Internet exposure. Internal network only.
- The audit trail records the Windows user for every action.
- Review `config.json` (teamsWebhook is a secret): restrict the file permissions.
