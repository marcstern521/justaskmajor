<#
.SYNOPSIS
  Ops Hub - local web app for the SysOps ticket queue (phase 1: read-only queue triage dashboard).

.DESCRIPTION
  Runs a small web server on http://localhost:8080 using only built-in PowerShell/.NET (nothing to install).
  Reads data\queue.json (snapshot), or refreshes it from ServiceNow, groups tickets into families using
  families.json, and shows what is automatable, blocked, change-gated, or aging.

  The queue, reviews, snippets and reports tabs are read-only. Tools run your scripts in a visible PowerShell
  window; scripts that change things need typed confirmation here AND still ask in their console.
  Binds to localhost only. Server mode: -Bind <host> -AllowRemote -WindowsAuth (see README). Tool runs are disabled in
  server mode unless -AllowRemoteRuns.

.EXAMPLE
  .\Start-OpsHub.ps1
  .\Start-OpsHub.ps1 -SnowLogin        # prompt for ServiceNow creds so the Refresh button can pull live data
  .\Start-OpsHub.ps1 -Port 9090 -NoBrowser
#>
[CmdletBinding()]
param(
    [int]$Port = 0,
    [string]$Bind = 'localhost',
    [switch]$AllowRemote,
    [switch]$SnowLogin,
    [switch]$RefreshOnStart,     # pull the live ServiceNow queue as soon as Ops Hub starts (needs -SnowLogin)
    [switch]$NoBrowser,
    [string]$ReportDir = '',
    [switch]$WindowsAuth,        # require Windows login (Kerberos/NTLM); roles come from config.json access.runners / access.readers
    [switch]$AllowRemoteRuns,    # server mode only: allow tool runs on the server (they open a window ON the server)
    [switch]$InsecureNoAuth      # server mode without login (lab only)
)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$WebDir = Join-Path $Root 'web'
$DataDir = Join-Path $Root 'data'
$Config = Get-Content (Join-Path $Root 'config.json') -Raw | ConvertFrom-Json
$Rules = Get-Content (Join-Path $Root 'families.json') -Raw | ConvertFrom-Json
$Tools = Get-Content (Join-Path $Root 'tools.json') -Raw | ConvertFrom-Json
$Reviews = Get-Content (Join-Path $Root 'reviews.json') -Raw | ConvertFrom-Json
$SnippetsFile = Join-Path $Root 'snippets.json'
$ScriptsDir = Join-Path $Root 'scripts'
$RunsDir = Join-Path $Root 'runs'
$InputsDir = Join-Path $Root 'inputs'
foreach ($d in $RunsDir, $InputsDir) { if (-not (Test-Path $d)) { New-Item -ItemType Directory $d | Out-Null } }
if (-not $ReportDir) { $ReportDir = $Tools.reportDir }
$IsWin = ($PSVersionTable.PSVersion.Major -lt 6) -or $IsWindows
if ($Port -le 0) { $Port = [int]$Config.port }
if ($Bind -notin 'localhost','127.0.0.1' -and -not $AllowRemote) {
    throw "Refusing to bind to '$Bind' without -AllowRemote."
}
if ($AllowRemote -and -not $WindowsAuth -and -not $InsecureNoAuth) {
    throw 'Server mode needs -WindowsAuth (recommended) or -InsecureNoAuth (lab only).'
}
$ToolRunsEnabled = (-not $AllowRemote) -or $AllowRemoteRuns
$script:CurUser = "$env:USERDOMAIN\$env:USERNAME"
if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory $DataDir | Out-Null }
$script:SnowCred = $null
if ($SnowLogin) { $script:SnowCred = Get-Credential -Message "ServiceNow login for $($Config.instance) (kept in memory only)" }

function Log([string]$m) { Write-Host ("{0}  {1}" -f (Get-Date -Format 'HH:mm:ss'), $m) }

# ---------------- data ----------------
function ConvertTo-Date([string]$s) {
    $d = [datetime]::MinValue
    foreach ($f in 'MM/dd/yyyy HH:mm:ss','M/d/yyyy h:mm:ss tt','M/d/yyyy H:mm:ss','yyyy-MM-dd HH:mm:ss') {
        if ([datetime]::TryParseExact($s, $f, [Globalization.CultureInfo]::InvariantCulture, 'None', [ref]$d)) { return $d }
    }
    if ([datetime]::TryParse($s, [Globalization.CultureInfo]::InvariantCulture, 'None', [ref]$d)) { return $d }
    return $null
}

function Read-Queue {
    $json = Join-Path $DataDir 'queue.json'
    $csv  = Join-Path $DataDir 'queue.csv'
    $useCsv = (Test-Path $csv) -and ((-not (Test-Path $json)) -or ((Get-Item $csv).LastWriteTime -gt (Get-Item $json).LastWriteTime))
    if ($useCsv) {
        $rows = @(Import-Csv $csv)
        if (-not $rows.Count) { throw 'queue.csv is empty' }
        $h = $rows[0].PSObject.Properties.Name
        $cNum  = $h | Where-Object { $_ -match '^number$' } | Select-Object -First 1
        $cDesc = $h | Where-Object { $_ -match 'short.?desc' } | Select-Object -First 1
        $cOpen = $h | Where-Object { $_ -match '^opened(_at)?$' } | Select-Object -First 1
        $cItem = $h | Where-Object { $_ -match 'request.?item|^item$' } | Select-Object -First 1
        if (-not ($cNum -and $cDesc)) { throw "queue.csv needs columns 'Number' and 'Short description' (and ideally 'Opened'). Found: $($h -join ', ')" }
        $t = foreach ($r in $rows) { [pscustomobject]@{ number = $r.$cNum; short_description = $r.$cDesc; opened_at = $(if ($cOpen) { $r.$cOpen } else { '' }); ritm = $(if ($cItem) { $r.$cItem } else { '' }) } }
        return [pscustomobject]@{ asOf = (Get-Item $csv).LastWriteTime.ToString('s'); source = 'CSV import (data\queue.csv)'; tickets = @($t) }
    }
    if (-not (Test-Path $json)) { throw 'No data yet: put a ServiceNow list export at data\queue.csv or use -SnowLogin and Refresh.' }
    return (Get-Content $json -Raw | ConvertFrom-Json)
}

function Get-Dashboard {
    $q = Read-Queue
    $now = Get-Date
    $stale = [int]$Config.staleDays
    $groups = @{}
    $prevSet = $null
    $pf = Join-Path $DataDir 'queue.prev.json'
    if (Test-Path -LiteralPath $pf) { try { $pv = Get-Content -LiteralPath $pf -Raw | ConvertFrom-Json; $prevSet = @{}; foreach ($x in @($pv.tickets)) { $prevSet[[string]$x.number] = 1 } } catch { $prevSet = $null } }
    $newCount = 0
    foreach ($t in @($q.tickets)) {
        $fam = $null
        foreach ($r in $Rules.rules) { if ($t.short_description -match $r.match) { $fam = $r; break } }
        $tool = $null; $wn = $null
        if ($fam) { $key = $fam.name; $level = $fam.level; $note = $fam.note; $tool = $fam.tool; $wn = $fam.workNote }
        else {
            $first = ($t.short_description -split ' - ')[0]
            $key = 'Other: ' + (($first -replace '\d+', '#').Trim())
            if ($key.Length -gt 70) { $key = $key.Substring(0, 70) }
            $level = 'manual'; $note = ''
        }
        $reviewId = $null
        if ($key -like 'Recurring*' -or $key -like 'Pleasant Password quarterly*') {
            foreach ($rv in $Reviews.reviews) { if ($t.short_description -match "(?i)$($rv.match)") { $reviewId = $rv.id; break } }
        }
        $isNew = ($null -ne $prevSet) -and (-not $prevSet.ContainsKey([string]$t.number))
        if ($isNew) { $newCount++ }
        $opened = ConvertTo-Date ([string]$t.opened_at)
        $age = $null; if ($opened) { $age = [int][math]::Floor(($now - $opened).TotalDays) }
        $item = [pscustomobject]@{ number = $t.number; description = $t.short_description; opened = $(if ($opened) { $opened.ToString('yyyy-MM-dd') } else { '' }); ageDays = $age; stale = [bool]($age -ne $null -and $age -ge $stale); ritm = $t.ritm; review = $reviewId; isNew = $isNew }
        if (-not $groups.ContainsKey($key)) { $groups[$key] = [pscustomobject]@{ name = $key; level = $level; note = $note; tool = $tool; workNote = $wn; tickets = (New-Object System.Collections.ArrayList) } }
        [void]$groups[$key].tickets.Add($item)
    }
    $fams = foreach ($g in $groups.Values) {
        $ages = @($g.tickets | Where-Object { $_.ageDays -ne $null } | ForEach-Object { $_.ageDays })
        [pscustomobject]@{
            name = $g.name; level = $g.level; note = $g.note; tool = $g.tool; workNote = $g.workNote
            count = $g.tickets.Count
            oldestDays = $(if ($ages.Count) { ($ages | Measure-Object -Maximum).Maximum } else { $null })
            staleCount = @($g.tickets | Where-Object { $_.stale }).Count
            tickets = @($g.tickets | Sort-Object { $_.ageDays } -Descending)
        }
    }
    $levelsOut = @{}
    foreach ($p in $Rules.levels.PSObject.Properties) { $levelsOut[$p.Name] = $p.Value }
    [pscustomobject]@{
        asOf = $q.asOf; source = $q.source; instance = $Config.instance; staleDays = $stale
        total = @($q.tickets).Count
        newCount = $newCount
        hasPrev = ($null -ne $prevSet)
        levels = $levelsOut
        families = @($fams)
    }
}

function Update-FromServiceNow {
    if (-not $script:SnowCred) {
        $csv = Join-Path $DataDir 'queue.csv'
        if (Test-Path $csv) { return @{ ok = $true; message = 'Reloaded from data\queue.csv' } }
        return @{ ok = $false; message = 'Not logged in to ServiceNow. Restart with -SnowLogin, or export the list view to data\queue.csv (Number, Short description, Opened).' }
    }
    $pair = '{0}:{1}' -f $script:SnowCred.UserName, $script:SnowCred.GetNetworkCredential().Password
    $hdr = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pair)); Accept = 'application/json' }
    $uri = "$($Config.instance)/api/now/table/sc_task?sysparm_query=$([uri]::EscapeDataString($Config.query))&sysparm_fields=number,short_description,opened_at,request_item&sysparm_display_value=true&sysparm_limit=1000"
    try { $r = Invoke-RestMethod -Uri $uri -Headers $hdr -Method Get -TimeoutSec 45 }
    catch { return @{ ok = $false; message = "ServiceNow call failed or timed out after 45s: $($_.Exception.Message). Check VPN/proxy and that the account can use basic auth. If your org requires SSO/MFA for API access, use the CSV export route instead." } }
    $t = foreach ($x in $r.result) {
        $ri = ''; if ($x.request_item) { if ($x.request_item.display_value) { $ri = $x.request_item.display_value } else { $ri = [string]$x.request_item } }
        [pscustomobject]@{ number = $x.number; short_description = $x.short_description; opened_at = $x.opened_at; ritm = $ri }
    }
    $out = [pscustomobject]@{ asOf = (Get-Date).ToString('s'); source = 'ServiceNow (live)'; tickets = @($t) }
    $jf = Join-Path $DataDir 'queue.json'
    if (Test-Path -LiteralPath $jf) { Copy-Item -LiteralPath $jf -Destination (Join-Path $DataDir 'queue.prev.json') -Force }
    $out | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $DataDir 'queue.json') -Encoding UTF8
    $csv = Join-Path $DataDir 'queue.csv'; if (Test-Path $csv) { Remove-Item $csv }   # live data wins
    return @{ ok = $true; message = "Loaded $(@($t).Count) tickets from ServiceNow" }
}


# ---------------- tools / runs / reports ----------------
function Get-ToolList { $Tools.tools | ForEach-Object { $_ } }

function ConvertTo-Hashtable($o) { $h = @{}; if ($o) { foreach ($p in $o.PSObject.Properties) { $h[$p.Name] = $p.Value } }; $h }

function Start-ToolRun($body) {
    $tool = Get-ToolList | Where-Object { $_.id -eq $body.tool } | Select-Object -First 1
    if (-not $tool) { throw "Unknown tool '$($body.tool)'" }
    if ($tool.risk -eq 'change' -and "$($body.confirm)" -ne 'RUN') { throw "This tool changes things. Type RUN to confirm." }
    $ref = "$($body.ref)".Trim().ToUpper()
    if ($ref -and $ref -notmatch '^(CHG|SCTASK|RITM|INC|PRB|TASK|CTASK)\d{5,9}$') { throw "Ticket/change reference '$ref' is not a ServiceNow number (e.g. SCTASK0156751, CHG0141098)." }
    if ($tool.risk -eq 'change' -and -not $ref) { throw 'This tool changes things: enter the ticket or change number it is for (SCTASK / CHG / INC ...).' }
    $script = Join-Path $ScriptsDir $tool.script
    if (-not (Test-Path -LiteralPath $script)) { throw "Script missing: scripts\$($tool.script)" }
    $id = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $tool.id; $n = 1; while (Test-Path -LiteralPath (Join-Path $RunsDir ($id + '.json'))) { $n++; $id = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $tool.id + '-' + $n } 
    $vals = ConvertTo-Hashtable $body.values
    $runArgs = [ordered]@{}
    foreach ($p in $tool.params) {
        $v = $vals[$p.name]
        $has = ($null -ne $v) -and ("$v" -ne '')
        if (-not $has -and $p.required) { throw "'$($p.label)' is required" }
        if (-not $has) { continue }
        switch ($p.type) {
            'names' {
                $lines = @("$v" -split "[\r\n]+" | ForEach-Object { $_.Trim() } | Where-Object { $_ })
                if (-not $lines.Count) { throw "'$($p.label)' is empty" }
                if ($lines.Count -gt 2000) { throw 'Too many lines (max 2000)' }
                $csv = New-Object System.Collections.Generic.List[string]
                $csv.Add('EmployeeNumber,Name')
                foreach ($l in $lines) {
                    $num = ''; $nm = $l
                    if ($l -match '^(\d{3,})\s*[,;\t]\s*(.+)$') { $num = $Matches[1]; $nm = $Matches[2] }
                    $csv.Add(('"{0}","{1}"' -f $num, ($nm -replace '"', '""')))
                }
                $f = Join-Path $InputsDir "$id.csv"
                Set-Content -LiteralPath $f -Value $csv -Encoding UTF8
                $runArgs[$p.name] = $f
            }
            'list'   { $runArgs[$p.name] = @("$v" -split '[,;\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
            'switch' { if ([bool]$v) { $runArgs[$p.name] = $true } }
            'int'    { $runArgs[$p.name] = [int]$v }
            'select' { if ($p.options -notcontains "$v") { throw "'$($p.label)': '$v' is not an allowed value" }; $runArgs[$p.name] = "$v" }
            default  { if ("$v" -match '[\x00-\x1f]') { throw "'$($p.label)' has control characters" }; $runArgs[$p.name] = "$v" }
        }
    }
    $fixed = ConvertTo-Hashtable $tool.fixed
    foreach ($k in $fixed.Keys) { $runArgs[$k] = $fixed[$k] }   # fixed args always win
    $log = Join-Path $RunsDir "$id.log"
    $specFile = Join-Path $RunsDir "$id.json"
    [pscustomobject]@{ id = $id; tool = $tool.title; toolId = $tool.id; risk = $tool.risk; ref = $ref; script = $script; args = $runArgs; log = $log; created = (Get-Date).ToString('s') } |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $specFile -Encoding UTF8
    $runner = Join-Path $ScriptsDir '_Run.ps1'
    if ($IsWin) {
        $exe = (Get-Command powershell.exe).Source
        Start-Process $exe -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-NoExit', '-File', "`"$runner`"", '-RunFile', "`"$specFile`"") | Out-Null
    } else {
        $exe = (Get-Command pwsh).Source
        Start-Process $exe -ArgumentList @('-NoProfile', '-File', $runner, '-RunFile', $specFile) -RedirectStandardOutput "$specFile.out" -RedirectStandardError "$specFile.err" | Out-Null
    }
    Log "Started run $id"
    Write-Audit 'run' "$($tool.id) ref=$ref args=$(($runArgs.Keys | ForEach-Object { $_ }) -join ',')" $id
    @{ ok = $true; id = $id; message = $(if ($IsWin) { 'A PowerShell window opened. Answer any prompts there; progress shows on the Runs tab.' } else { 'Started in background.' }) }
}

function Get-RunStatus([string]$specFile) {
    $sf = [IO.Path]::ChangeExtension($specFile, '.status.json')
    if (Test-Path -LiteralPath $sf) { try { return (Get-Content -LiteralPath $sf -Raw | ConvertFrom-Json) } catch {} }
    [pscustomobject]@{ state = 'starting'; detail = ''; started = ''; finished = '' }
}
function Get-Runs {
    $files = @(Get-ChildItem -LiteralPath $RunsDir -Filter '*.json' | Where-Object { $_.Name -notlike '*.status.json' } | Sort-Object Name -Descending | Select-Object -First 40)
    @($files | ForEach-Object {
        $sp = Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json
        $st = Get-RunStatus $_.FullName
        [pscustomobject]@{ id = $sp.id; tool = $sp.tool; risk = $sp.risk; created = $sp.created; state = $st.state; detail = $st.detail; finished = $st.finished }
    })
}
function Get-RunDetail([string]$id) {
    if ($id -notmatch '^[\w\-]+$') { throw 'bad id' }
    $specFile = Join-Path $RunsDir "$id.json"
    if (-not (Test-Path -LiteralPath $specFile)) { throw 'run not found' }
    $sp = Get-Content -LiteralPath $specFile -Raw | ConvertFrom-Json
    $st = Get-RunStatus $specFile
    $log = ''
    if (Test-Path -LiteralPath $sp.log) {
        try { $fs = [IO.File]::Open($sp.log, 'Open', 'Read', 'ReadWrite'); $sr = New-Object IO.StreamReader($fs); $log = $sr.ReadToEnd(); $sr.Close() } catch { $log = "(log busy: $($_.Exception.Message))" }
    }
    $lines = @($log -split "\r?\n"); if ($lines.Count -gt 400) { $lines = $lines[($lines.Count - 400)..($lines.Count - 1)] }
    @{ id = $id; tool = $sp.tool; state = $st.state; detail = $st.detail; log = ($lines -join "`n") }
}
function Get-Reports {
    if (-not (Test-Path -LiteralPath $ReportDir)) { return @() }
    @(Get-ChildItem -LiteralPath $ReportDir -Filter '*.csv' | Sort-Object LastWriteTime -Descending | Select-Object -First 100 |
        ForEach-Object { [pscustomobject]@{ name = $_.Name; modified = $_.LastWriteTime.ToString('s'); kb = [math]::Round($_.Length / 1KB, 1) } })
}
function Get-Report([string]$name) {
    if ($name -ne [IO.Path]::GetFileName($name) -or $name -notlike '*.csv') { throw 'bad name' }
    $f = Join-Path $ReportDir $name
    if (-not (Test-Path -LiteralPath $f)) { throw 'report not found' }
    $rows = @(Import-Csv -LiteralPath $f)
    $cols = @(); if ($rows.Count) { $cols = @($rows[0].PSObject.Properties.Name) }
    @{ name = $name; total = $rows.Count; columns = $cols; rows = @($rows | Select-Object -First 3000) }
}
function Read-Body($req) {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8); $t = $sr.ReadToEnd(); $sr.Close()
    if ($t) { $t | ConvertFrom-Json } else { $null }
}


# ---------------- audit / access / reviews / digest ----------------
function Write-Audit([string]$action, [string]$detail, [string]$ref = '') {
    try {
        [pscustomobject]@{ time = (Get-Date).ToString('s'); user = $script:CurUser; action = $action; detail = $detail; ref = $ref } |
            Export-Csv -LiteralPath (Join-Path $DataDir 'audit.csv') -Append -NoTypeInformation -Encoding UTF8
    } catch { Log "audit write failed: $($_.Exception.Message)" }
}
function Test-Role([string]$role) {
    if (-not $WindowsAuth) { return $true }
    $list = @($Config.access.$role)
    if ($list -contains '*') { return $true }
    foreach ($x in $list) { if ($x -and ($script:CurUser -ieq $x)) { return $true } }
    return $false
}
function Assert-Runner { if (-not (Test-Role 'runners')) { throw "User '$($script:CurUser)' is not in access.runners (config.json)." } }

function Get-ReviewLog([int]$max = 300) {
    $f = Join-Path $DataDir 'review_log.csv'
    if (-not (Test-Path -LiteralPath $f)) { return @() }
    @(Import-Csv -LiteralPath $f | Select-Object -Last $max)
}
function Add-ReviewLog($b) {
    Assert-Runner
    $rv = $Reviews.reviews | Where-Object { $_.id -eq $b.review } | Select-Object -First 1
    if (-not $rv) { throw "Unknown review '$($b.review)'" }
    $tickets = @($b.tickets | Where-Object { $_ -match '^[A-Z]{3,6}\d{5,9}$' })
    if (-not $tickets.Count) { $tickets = @('') }
    $res = "$($b.result)"; if ($res -notin 'OK', 'EXCEPTION') { throw 'result must be OK or EXCEPTION' }
    $note = "$($b.note)"; if ($note.Length -gt 4000) { $note = $note.Substring(0, 4000) }
    $now = (Get-Date).ToString('s')
    foreach ($tk in $tickets) {
        [pscustomobject]@{ time = $now; user = $script:CurUser; review = $rv.id; title = $rv.title; ticket = $tk; result = $res; note = $note } |
            Export-Csv -LiteralPath (Join-Path $DataDir 'review_log.csv') -Append -NoTypeInformation -Encoding UTF8
    }
    Write-Audit 'review' "$($rv.id) $res" ($tickets -join ' ')
    @{ ok = $true; message = "Logged $($tickets.Count) ticket(s) for $($rv.title)" }
}
function Get-ReviewsInfo {
    $log = Get-ReviewLog
    $last = @{}
    foreach ($r in $log) { $last[$r.review] = @{ time = $r.time; user = $r.user; result = $r.result; ticket = $r.ticket } }
    @{ analyst = $Config.analyst; reviews = @($Reviews.reviews); last = $last; recent = @($log | Select-Object -Last 40) }
}

function Get-Digest {
    $d = Get-Dashboard
    $lv = @{}; foreach ($f in $d.families) { if (-not $lv.ContainsKey($f.level)) { $lv[$f.level] = 0 }; $lv[$f.level] += $f.count }
    $stale = ($d.families | Measure-Object staleCount -Sum).Sum
    $L = New-Object System.Collections.Generic.List[string]
    $L.Add(("Ops queue digest - {0}" -f (Get-Date -Format 'ddd yyyy-MM-dd HH:mm')))
    $newTxt = ''; if ($d.hasPrev) { $newTxt = "  |  new since last refresh: $($d.newCount)" }
    $L.Add("Unassigned: $($d.total)$newTxt  |  aging >= $($d.staleDays)d: $stale")
    $L.Add(("Automate now: {0}  |  Partly automatable: {1}  |  Blocked: {2}  |  Needs change/window: {3}  |  Manual/other: {4}" -f [int]$lv['automate'], [int]$lv['assist'], [int]$lv['blocked'], [int]$lv['gated'], [int]$lv['manual']))
    $L.Add('')
    $L.Add('Largest families:')
    foreach ($f in ($d.families | Sort-Object count -Descending | Select-Object -First 8)) { $L.Add(("  {0,3}  {1}  [{2}]  oldest {3}d" -f $f.count, $f.name, $f.level, $f.oldestDays)) }
    $L.Add('')
    $L.Add('Oldest open tickets:')
    $all = foreach ($f in $d.families) { foreach ($t in $f.tickets) { $t } }
    foreach ($t in ($all | Where-Object { $_.ageDays -ne $null } | Sort-Object ageDays -Descending | Select-Object -First 8)) {
        $desc = $t.description; if ($desc.Length -gt 80) { $desc = $desc.Substring(0, 80) + '...' }
        $L.Add(("  {0}  {1}d  {2}" -f $t.number, $t.ageDays, $desc))
    }
    $auto = @($d.families | Where-Object { $_.level -eq 'automate' } | Sort-Object count -Descending)
    if ($auto.Count) { $L.Add(''); $L.Add('Quick wins today: ' + (($auto | ForEach-Object { "$($_.name) ($($_.count))" }) -join '; ')) }
    ($L -join "`n")
}
function Send-Teams($b) {
    Assert-Runner
    if (-not $Config.teamsWebhook) { throw 'No teamsWebhook set in config.json' }
    if ("$($b.confirm)" -ne 'POST') { throw 'Type POST to confirm sending to Teams.' }
    $txt = (Get-Digest) -replace "`n", "`n`n"
    $null = Invoke-RestMethod -Uri $Config.teamsWebhook -Method Post -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes((@{ text = $txt } | ConvertTo-Json)))
    Write-Audit 'teams' 'digest posted'
    @{ ok = $true; message = 'Digest posted to Teams.' }
}
function Save-Approved($b) {
    Assert-Runner
    $items = @($b.sams)
    if (-not $items.Count) { throw 'Nothing selected' }
    $rows = foreach ($i in $items) {
        $sam = "$($i.sam)"; if ($i -is [string]) { $sam = $i }
        if ($sam -notmatch '^[\w\.\-\$]{1,64}$') { throw "Bad account name '$sam'" }
        [pscustomobject]@{ SamAccountName = $sam; Domain = "$($i.domain)" }
    }
    if (-not (Test-Path -LiteralPath $ReportDir)) { New-Item -ItemType Directory $ReportDir | Out-Null }
    $f = Join-Path $ReportDir ("Approved_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $rows | Export-Csv -LiteralPath $f -NoTypeInformation -Encoding UTF8
    Write-Audit 'approved-list' "$(@($rows).Count) accounts" $f
    @{ ok = $true; path = $f; count = @($rows).Count; message = "Saved $(@($rows).Count) accounts" }
}
function Get-AuditText {
    $f = Join-Path $DataDir 'audit.csv'
    if (Test-Path -LiteralPath $f) { [IO.File]::ReadAllText($f) } else { 'time,user,action,detail,ref' }
}

# ---------------- http ----------------
$mime = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.css' = 'text/css; charset=utf-8'; '.json' = 'application/json; charset=utf-8'; '.svg' = 'image/svg+xml'; '.ico' = 'image/x-icon' }
function Send([System.Net.HttpListenerResponse]$res, [int]$code, [string]$type, [byte[]]$bytes) {
    $res.StatusCode = $code; $res.ContentType = $type
    $res.Headers['Cache-Control'] = 'no-store'
    $res.Headers['X-Content-Type-Options'] = 'nosniff'
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes, 0, $bytes.Length); $res.OutputStream.Close()
}
function Send-Json($res, $obj, [int]$code = 200) {
    Send $res $code 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Depth 8 -Compress)))
}

$listener = New-Object System.Net.HttpListener
if ($WindowsAuth) { $listener.AuthenticationSchemes = [System.Net.AuthenticationSchemes]::IntegratedWindowsAuthentication }
$started = $false; $firstPort = $Port
for ($try = 0; $try -lt 15 -and -not $started; $try++) {
    $listener = New-Object System.Net.HttpListener
    if ($WindowsAuth) { $listener.AuthenticationSchemes = [System.Net.AuthenticationSchemes]::IntegratedWindowsAuthentication }
    $listener.Prefixes.Add("http://${Bind}:$Port/")
    try { $listener.Start(); $started = $true }
    catch { Write-Host "Port $Port is busy - trying $($Port + 1)..." -ForegroundColor Yellow; $Port++ }
}
if (-not $started) { throw "No free port between $firstPort and $($Port - 1). Close the other Ops Hub window or use -Port <n>." }
$url = "http://${Bind}:$Port/"
Log "Mode: $(if ($AllowRemote) { 'SERVER' } else { 'local' })  auth: $(if ($WindowsAuth) { 'Windows' } else { 'none (localhost)' })  tool runs: $ToolRunsEnabled"
# ---- queue freshness on startup ----
$qf = Join-Path $DataDir 'queue.json'
if ($RefreshOnStart) {
    if ($script:SnowCred) {
        Log 'Refreshing the queue from ServiceNow...'
        $rf = Update-FromServiceNow
        if ($rf.ok) { Log $rf.message } else { Write-Host "  Refresh FAILED: $($rf.message)" -ForegroundColor Yellow; Write-Host '  Showing the last saved queue. Use the CSV export route (data\queue.csv) if the API needs SSO/MFA.' -ForegroundColor Yellow }
    } else { Write-Host '  -RefreshOnStart needs -SnowLogin (ServiceNow credentials). Skipped.' -ForegroundColor Yellow }
}
if (Test-Path -LiteralPath $qf) {
    $qAge = [int]((Get-Date) - (Get-Item -LiteralPath $qf).LastWriteTime).TotalHours
    if ($qAge -ge 4) { Write-Host "  NOTE: the ticket queue is $qAge hours old. Ticket counts may not match ServiceNow." -ForegroundColor Yellow }
}
Log "Ops Hub running at $url   (Ctrl+C to stop)"
if (-not $NoBrowser) { try { Start-Process $url } catch {} }

try {
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        $req = $ctx.Request; $res = $ctx.Response
        try {
            $path = $req.Url.AbsolutePath
            $script:CurUser = "$env:USERDOMAIN\$env:USERNAME"
            if ($ctx.User -and $ctx.User.Identity -and $ctx.User.Identity.IsAuthenticated) { $script:CurUser = $ctx.User.Identity.Name }
            Log "$($script:CurUser) $($req.HttpMethod) $path"
            if (-not (Test-Role 'readers') -and -not (Test-Role 'runners')) { Send $res 403 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Not authorised')); continue }
            if (-not $AllowRemote -and $req.Headers['Host'] -notmatch '^(localhost|127\.0\.0\.1)(:\d+)?$') { Send $res 403 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Bad host header')); continue }
            if ($req.HttpMethod -eq 'POST' -and $req.Headers['X-OpsHub'] -ne '1') { Send $res 403 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Missing X-OpsHub header')); continue }
            if ($path -eq '/api/queue' -and $req.HttpMethod -eq 'GET') { Send-Json $res (Get-Dashboard) }
            elseif ($path -eq '/api/refresh' -and $req.HttpMethod -eq 'POST') { Assert-Runner; Send-Json $res (Update-FromServiceNow) }
            elseif ($path -eq '/api/config' -and $req.HttpMethod -eq 'GET') { Send-Json $res @{ analyst = $Config.analyst; user = $script:CurUser; canRun = (Test-Role 'runners'); toolRuns = $ToolRunsEnabled; teams = [bool]$Config.teamsWebhook; remote = [bool]$AllowRemote; windowsAuth = [bool]$WindowsAuth; reportDir = $ReportDir; instance = $Config.instance } }
            elseif ($path -eq '/api/reviews' -and $req.HttpMethod -eq 'GET') { Send-Json $res (Get-ReviewsInfo) }
            elseif ($path -eq '/api/reviewlog' -and $req.HttpMethod -eq 'POST') { Send-Json $res (Add-ReviewLog (Read-Body $req)) }
            elseif ($path -eq '/api/snippets' -and $req.HttpMethod -eq 'GET') { Send $res 200 'application/json; charset=utf-8' ([IO.File]::ReadAllBytes($SnippetsFile)) }
            elseif ($path -eq '/api/digest' -and $req.HttpMethod -eq 'GET') { Send-Json $res @{ text = (Get-Digest) } }
            elseif ($path -eq '/api/teams' -and $req.HttpMethod -eq 'POST') { Send-Json $res (Send-Teams (Read-Body $req)) }
            elseif ($path -eq '/api/approved' -and $req.HttpMethod -eq 'POST') { Send-Json $res (Save-Approved (Read-Body $req)) }
            elseif ($path -eq '/api/audit' -and $req.HttpMethod -eq 'GET') { Send $res 200 'text/csv; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes((Get-AuditText))) }
            elseif ($path -eq '/api/tools' -and $req.HttpMethod -eq 'GET') { Send-Json $res @{ groups = $Tools.groups; tools = @(Get-ToolList); reportDir = $ReportDir; windows = $IsWin } }
            elseif ($path -eq '/api/run' -and $req.HttpMethod -eq 'POST') { Assert-Runner; if (-not $ToolRunsEnabled) { throw 'Tool runs are disabled in server mode (use -AllowRemoteRuns).' }; Send-Json $res (Start-ToolRun (Read-Body $req)) }
            elseif ($path -eq '/api/runs' -and $req.HttpMethod -eq 'GET') { Send-Json $res @{ runs = @(Get-Runs) } }
            elseif ($path -eq '/api/run' -and $req.HttpMethod -eq 'GET') { Send-Json $res (Get-RunDetail $req.QueryString['id']) }
            elseif ($path -eq '/api/reports' -and $req.HttpMethod -eq 'GET') { Send-Json $res @{ dir = $ReportDir; reports = @(Get-Reports) } }
            elseif ($path -eq '/api/report' -and $req.HttpMethod -eq 'GET') { Send-Json $res (Get-Report $req.QueryString['name']) }
            elseif ($path -eq '/api/health') { Send-Json $res @{ ok = $true; time = (Get-Date).ToString('s'); live = [bool]$script:SnowCred } }
            elseif ($req.HttpMethod -eq 'GET') {
                if ($path -eq '/') { $path = '/index.html' }
                $full = [IO.Path]::GetFullPath((Join-Path $WebDir ($path.TrimStart('/') -replace '/', [IO.Path]::DirectorySeparatorChar)))
                if (-not $full.StartsWith($WebDir, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $full -PathType Leaf)) {
                    Send $res 404 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Not found'))
                } else {
                    $ext = [IO.Path]::GetExtension($full).ToLower()
                    $ct = 'application/octet-stream'; if ($mime.ContainsKey($ext)) { $ct = $mime[$ext] }
                    Send $res 200 $ct ([IO.File]::ReadAllBytes($full))
                }
            }
            else { Send $res 405 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Method not allowed')) }
        } catch {
            Log "ERROR: $($_.Exception.Message)"
            try { Send-Json $res @{ ok = $false; error = $_.Exception.Message } 500 } catch {}
        }
    }
} finally { $listener.Stop(); $listener.Close() }