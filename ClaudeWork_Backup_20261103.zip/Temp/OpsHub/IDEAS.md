# Ideas and roadmap (nothing here is built yet unless it says so)

Ordered roughly by value for effort, with change-management and production safety in mind.

## Next builds
1. **Terminations wizard (end to end).** Ticket -> parse the Mass Upload attachment -> term check -> tick candidates ->
   approved list -> dry run -> real run -> work note + closing text. The pieces exist; this chains them with the term-date guard
   and an "outstanding by system" tracker per SCTASK. No CR needed, but ticket ref is enforced and audited.
2. **Pleasant quarterly review automation.** Read the user/role grid on both servers (the Claude-in-Chrome approach worked), diff
   against last quarter's saved snapshot and against AD enabled state: output "departed users still in Pleasant" + "role changes".
3. **ServiceNow write-back with a safety latch.** Add work note + close for a whole recurring family in one confirmed batch
   (preview, per-ticket checkbox, "type CLOSE"). Needs API access that survives your SSO/MFA setup.
4. **Production readiness helper.** Type the server name -> exact RDP/SSM steps and the right script from C:\Temp, then
   collect the output file and attach/summarise it. Keeps the "give me the ticket, get the command" workflow you prefer.
5. **EC2 scheduled-event pipeline.** The events tool exists; add the email (Graph) and NOC Teams webhook steps, a daily run, and
   a "new event since yesterday" diff, plus a reboot request template for owners. Reboot itself stays a CR/approved action.
6. **Certificate tracker.** Host list + CA export -> nightly expiry scan -> trend, owner, renewal ticket suggestions; feeds the
   daily SSL review.

## Operational safety (change management)
- **Maintenance-window guard:** change tools refuse to run outside a calendar window or without a CHG number (CHG lookup via ServiceNow).
- **Blast-radius limits:** max N objects per run unless a second person approves (two-person rule for deletes).
- **Rollback records:** every change tool writes a restore file (groups removed, previous OU, old description) like Move-TermAccounts does.
- **Dry-run first:** make "dry run then real run on the same input" the only path in the UI for change tools.
- **Kill switch:** a read-only mode flag in config.json that disables every change tool instantly.

## Reporting and alerting
- **Morning brief feed:** the digest endpoint is ready; point the Power Automate 6:30 briefing at it (server mode).
- **Aging nudges:** items over 30 days get a Teams reminder to their group; "unassigned > 24h" alert.
- **Weekly evidence pack:** all reviews logged this week -> one CSV/PDF for audit (FedRAMP/PCI friendly).
- **Trend charts:** queue size by family over time, review completion on time, mean time to close.
- **Alert-noise report:** top recurring BMC/xMatters alerts that never lead to action -> candidates for tuning.

## More tools worth adding
- **Fleet stale-profile report** (from your profile-cleanup idea): read-only inventory across InfraTools regions, then per-server
  removal via the same script you already use in FedRAMP.
- **Disk expansion helper:** read EBS/VMDK size, compute target, print the approved-change steps and the OS-side commands; verify after.
- **Rapid7 / vulnerability triage:** group the UK Sov / AUSOV / Red Hat CVE tickets by package, show affected asset count, link patch groups.
- **Linux patching tracker:** hosts by pending security updates + reboot-needed (via SSM when SendCommand is approved).
- **Cortex XDR rollout status** per cluster tier (replacement for Cybereason/Sophos), with exceptions list.
- **DNS / IPAM lookups** (SolarWinds IPAM, NetBox) in one search box next to the server reachability tool.
- **Royal TS sync:** surface your Sync-vSphere-RoyalTS output here ("open in Royal TS" links).
- **Meeting-notes capture:** one button to turn a meeting transcript into a ticket work note / Confluence draft.

## Team and sharing
- Read-only dashboards for the team and your manager; runner role for the SysOps group.
- Onboarding: the Reviews checklists and Snippets double as a training path for new teammates (pairs with the onboarding videos).
- Per-person saved variables in Snippets and a shared "favorite commands" list.
- Rundeck integration (sua-rnaut01 already exists) so tools can run server-side with a service account and approvals.
