﻿<#
.SYNOPSIS
    Production Ready Check automation for Windows servers, based on:
      - "Production Ready Checks 2026" (Confluence 3466788937) - CURRENT, authored by Marc Stern, Aug 2026
      - "Production Ready Checks - old" (Confluence 15777362) - superseded, kept for cross-reference only

.DESCRIPTION
    Run this ON the target server (elevated PowerShell), or against a remote
    target via -ComputerName if WinRM/CredSSP is set up for that domain.

    This does NOT try to auto-close the ServiceNow ticket. It produces a
    PASS / FAIL / MANUAL report you review before closing.

    NOTE: Infratools BAD Automation already has a "RunClusterValidation" flow
    (https://infratools.inucn.com/BADAutomation/RunClusterValidation) per the
    2026 doc. This script is meant as an independent/supplementary on-box
    check, not a replacement for whatever that automation already covers -
    worth comparing notes on overlap before leaning on this exclusively.

.PARAMETER ComputerName
    Target server. Defaults to localhost (run directly on the box).

.PARAMETER Role
    Server role - drives which scheduled-task / group checks apply.
    One of: COR, DWA, MED, WEB, API, BIT, WFO, AGM, AGT, IVR, MEI, MEA, Other
    (AGM/AGT/IVR/MEI/MEA are the documented LogReaderSVC-failure-ok-to-skip roles.)

.PARAMETER RequestedName
    The server name from the build request, to diff against actual AD name.
    Optional - skip if you don't have it handy.

.PARAMETER FedRAMP
    Switch. Set this for FedRAMP-scoped COR/API servers (DoD root cert check).

.PARAMETER ClusterSide
    A or B - only relevant for COR servers (FS_DiskUsed should be enabled on
    B side, disabled on A side per the checklist).

.PARAMETER OutCsv
    Optional path to also write the results as CSV.

.PARAMETER AutoPatch
    Switch. If the last-patched date is older than -PatchThresholdDays (default
    90), trigger a Windows Update scan/download/install via the Windows Update
    Agent COM API (works against WSUS if that's how updates are managed here).
    OFF by default - this is the one check in this script that changes the box.
    Only use it inside an approved maintenance window / with a CR in hand for
    Production and PCI/FedRAMP-scoped servers - this script doesn't check
    change-control state for you.

.PARAMETER PatchThresholdDays
    Age in days that triggers -AutoPatch. Default 90 (separate from the 30-day
    threshold the report itself flags as FAIL).

.PARAMETER AutoReboot
    Switch. If -AutoPatch installs updates that need a reboot, reboot
    immediately instead of just reporting that one is pending. OFF by default.

.EXAMPLE
    .\ProdReadinessCheck-Windows.ps1 -Role COR -ClusterSide B -RequestedName UKLOA-26DWA01

.EXAMPLE
    .\ProdReadinessCheck-Windows.ps1 -ComputerName newcor01 -Role COR -FedRAMP -ClusterSide A -OutCsv .\report.csv
#>

[CmdletBinding()]
param(
    [string]$ComputerName = $env:COMPUTERNAME,
    [ValidateSet("COR","DWA","MED","WEB","API","BIT","WFO","AGM","AGT","IVR","MEI","MEA","ASR","CDR","Other")]
    [string]$Role = "Other",
    [string]$RequestedName,
    [switch]$FedRAMP,
    [ValidateSet("A","B")]
    [string]$ClusterSide,
    [string]$OutCsv,
    [switch]$AutoPatch,
    [int]$PatchThresholdDays = 90,
    [switch]$AutoReboot
)

# Roles where the checklist explicitly says LogReaderSVC failure is OK to skip
$LogReaderExceptionRoles = @("AGM","AGT","IVR","MEI","MEA")

$results = New-Object System.Collections.Generic.List[object]

function Add-Result {
    param($Item, $Status, $Detail)
    $results.Add([pscustomobject]@{
        Item   = $Item
        Status = $Status   # PASS / FAIL / MANUAL / SKIP
        Detail = $Detail
    })
}

$remote = ($ComputerName -ne $env:COMPUTERNAME) -and ($ComputerName -ne "localhost")

function Invoke-Target {
    param([scriptblock]$ScriptBlock, [object[]]$ArgumentList = @())
    if ($remote) {
        Invoke-Command -ComputerName $ComputerName -ScriptBlock $ScriptBlock -ArgumentList $ArgumentList -ErrorAction Stop
    } else {
        & $ScriptBlock @ArgumentList
    }
}

Write-Host "=== Production Ready Check: $ComputerName (Role: $Role) ===" -ForegroundColor Cyan

# ---------------------------------------------------------------------------
# 1. Active Directory Audit
# ---------------------------------------------------------------------------
# Prefer the RSAT ActiveDirectory module if it happens to be installed, but
# don't require it - fall back to a raw ADSI/LDAP lookup (System.DirectoryServices),
# which works on any domain-joined box with no extra install, using whatever
# domain credentials the current session already has.
function Get-ADComputerInfo {
    param([string]$Name)
    if (Get-Command Get-ADComputer -ErrorAction SilentlyContinue) {
        $c = Get-ADComputer -Identity $Name -Properties CanonicalName, Name -ErrorAction Stop
        return [pscustomobject]@{ Name = $c.Name; DistinguishedName = $c.DistinguishedName; CanonicalName = $c.CanonicalName; Source = "Get-ADComputer" }
    }
    $searcher = New-Object System.DirectoryServices.DirectorySearcher
    $searcher.Filter = "(&(objectCategory=computer)(cn=$Name))"
    $searcher.PropertiesToLoad.AddRange(@("cn","distinguishedName")) | Out-Null
    $found = $searcher.FindOne()
    if (-not $found) { throw "No computer object found for '$Name' via ADSI/LDAP search" }
    $dn = [string]$found.Properties["distinguishedname"][0]
    # Turn "CN=host,OU=Servers,OU=Prod,DC=inucn,DC=com" into "inucn.com/Prod/Servers"
    # (reversed OU order, DCs joined into a dotted domain) - same shape as CanonicalName.
    $parts = $dn -split '(?<!\\),'
    $ouParts = $parts | Where-Object { $_ -match '^OU=' } | ForEach-Object { $_ -replace '^OU=','' }
    $dcParts = $parts | Where-Object { $_ -match '^DC=' } | ForEach-Object { $_ -replace '^DC=','' }
    [array]::Reverse($ouParts)
    $canonical = (@(($dcParts -join '.')) + $ouParts) -join '/'
    return [pscustomobject]@{ Name = [string]$found.Properties["cn"][0]; DistinguishedName = $dn; CanonicalName = $canonical; Source = "ADSI/LDAP" }
}

try {
    $adComp = Get-ADComputerInfo -Name $ComputerName
    if ($RequestedName) {
        if ($adComp.Name -eq $RequestedName) {
            Add-Result "AD - Name matches build request" "PASS" "AD name '$($adComp.Name)' matches requested '$RequestedName' (via $($adComp.Source))"
        } else {
            Add-Result "AD - Name matches build request" "FAIL" "AD name '$($adComp.Name)' does NOT match requested '$RequestedName' - confirm this is documented/expected"
        }
    } else {
        Add-Result "AD - Name matches build request" "MANUAL" "No -RequestedName supplied; AD name is '$($adComp.Name)' - compare manually"
    }
    Add-Result "AD - Organizational Unit" "MANUAL" "Location: $($adComp.CanonicalName) (via $($adComp.Source)) - confirm this is the correct OU for this role/domain"
} catch {
    Add-Result "AD - Computer object lookup" "FAIL" "Could not resolve AD/OU location for '$ComputerName': $($_.Exception.Message) - if this box isn't domain-joined or can't reach a DC, that's expected; otherwise investigate"
}

# ---------------------------------------------------------------------------
# 1b. IPv6 disabled (new item in the 2026 checklist)
# ---------------------------------------------------------------------------
try {
    $ipv6Bindings = Invoke-Target {
        Get-NetAdapterBinding -ComponentID ms_tcpip6 -ErrorAction Stop
    }
    $enabled = $ipv6Bindings | Where-Object { $_.Enabled -eq $true }
    if ($enabled) {
        Add-Result "IPv6 not enabled" "FAIL" "IPv6 binding still enabled on: $($enabled.Name -join ', ')"
    } else {
        Add-Result "IPv6 not enabled" "PASS" "IPv6 binding disabled on all adapters"
    }
} catch {
    Add-Result "IPv6 not enabled" "MANUAL" "Could not query adapter bindings: $($_.Exception.Message) - check Network Adapter properties directly"
}

# ---------------------------------------------------------------------------
# 2. Time zone (checked twice in the source doc - AD audit + internal audit)
# ---------------------------------------------------------------------------
try {
    $tz = Invoke-Target { Get-TimeZone }
    if ($tz.Id -eq "Mountain Standard Time") {
        Add-Result "Time zone = Mountain Time" "PASS" $tz.Id
    } else {
        Add-Result "Time zone = Mountain Time" "FAIL" "Current: $($tz.Id) - expected Mountain Standard Time"
    }
} catch {
    Add-Result "Time zone = Mountain Time" "FAIL" "Could not read time zone: $($_.Exception.Message)"
}

# ---------------------------------------------------------------------------
# 3. Patch recency (last patched within 30 days)
# ---------------------------------------------------------------------------
try {
    $lastHotfix = Invoke-Target { Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1 }
    if ($lastHotfix -and $lastHotfix.InstalledOn) {
        $age = (Get-Date) - $lastHotfix.InstalledOn
        if ($age.Days -le 30) {
            Add-Result "Last patched within 30 days" "PASS" "Last hotfix $($lastHotfix.HotFixID) installed $($lastHotfix.InstalledOn) ($($age.Days)d ago)"
        } else {
            Add-Result "Last patched within 30 days" "FAIL" "Last hotfix $($lastHotfix.InstalledOn) is $($age.Days) days ago"

            if ($AutoPatch -and $age.Days -gt $PatchThresholdDays) {
                Write-Host "AutoPatch: $($age.Days)d since last patch exceeds -PatchThresholdDays ($PatchThresholdDays). Triggering Windows Update..." -ForegroundColor Yellow
                Write-Host "AutoPatch: make sure this is happening inside an approved maintenance window / CR before it runs unattended." -ForegroundColor Yellow
                try {
                    $wuResult = Invoke-Target {
                        param($doReboot)
                        $session = New-Object -ComObject Microsoft.Update.Session
                        $searcher = $session.CreateUpdateSearcher()
                        $search = $searcher.Search("IsInstalled=0 and IsHidden=0 and Type='Software'")
                        if ($search.Updates.Count -eq 0) {
                            return [pscustomobject]@{ Count = 0; ResultCode = $null; RebootRequired = $false }
                        }
                        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
                        foreach ($u in $search.Updates) { $coll.Add($u) | Out-Null }
                        $downloader = $session.CreateUpdateDownloader()
                        $downloader.Updates = $coll
                        $downloader.Download() | Out-Null
                        $installer = $session.CreateUpdateInstaller()
                        $installer.Updates = $coll
                        $installResult = $installer.Install()
                        if ($installResult.RebootRequired -and $doReboot) {
                            Restart-Computer -Force
                        }
                        return [pscustomobject]@{ Count = $coll.Count; ResultCode = $installResult.ResultCode; RebootRequired = $installResult.RebootRequired }
                    } -ArgumentList @($AutoReboot.IsPresent)

                    if ($wuResult.Count -eq 0) {
                        Add-Result "AutoPatch - Windows Update scan/install" "MANUAL" "No applicable updates found by the Windows Update Agent search - if this box is WSUS-managed, confirm it's checking in against the right WSUS group/GPO"
                    } else {
                        $rebootNote = if ($wuResult.RebootRequired) { if ($AutoReboot) { "reboot triggered" } else { "REBOOT PENDING - not triggered (-AutoReboot not set)" } } else { "no reboot required" }
                        Add-Result "AutoPatch - Windows Update scan/install" "MANUAL" "Installed $($wuResult.Count) update(s), ResultCode=$($wuResult.ResultCode), $rebootNote - re-run this script after reboot to confirm patch age now passes"
                    }
                } catch {
                    Add-Result "AutoPatch - Windows Update scan/install" "FAIL" "AutoPatch attempt failed: $($_.Exception.Message)"
                }
            } elseif ($AutoPatch) {
                Add-Result "AutoPatch - Windows Update scan/install" "SKIP" "$($age.Days)d since last patch is under -PatchThresholdDays ($PatchThresholdDays) - not triggering an unscheduled patch run for a shorter-than-threshold gap"
            }
        }
    } else {
        Add-Result "Last patched within 30 days" "MANUAL" "Get-HotFix returned no InstalledOn dates - check WSUS/patch history directly"
    }
} catch {
    Add-Result "Last patched within 30 days" "FAIL" "Could not query hotfixes: $($_.Exception.Message)"
}

# ---------------------------------------------------------------------------
# 4. Windows licensing status
# ---------------------------------------------------------------------------
try {
    $lic = Invoke-Target {
        Get-CimInstance SoftwareLicensingProduct -Filter "ApplicationID='55c92734-d682-4d71-983e-d6ec3f16059f' AND PartialProductKey IS NOT NULL"
    }
    $licensed = $lic | Where-Object { $_.LicenseStatus -eq 1 }
    if ($licensed) {
        Add-Result "Windows licensing status" "PASS" "LicenseStatus=Licensed ($($licensed.Name))"
    } else {
        Add-Result "Windows licensing status" "FAIL" "No product reports LicenseStatus=Licensed - send back to Systems Engineering to activate"
    }
} catch {
    Add-Result "Windows licensing status" "MANUAL" "Could not query licensing via CIM: $($_.Exception.Message) - try 'slmgr /dlv' directly"
}

# ---------------------------------------------------------------------------
# 5. AV / security services
# ---------------------------------------------------------------------------
$expectedServices = @(
    @{ Name = "ir_agent"; Label = "Rapid7 Insight Agent" }
)

# Cybereason is being replaced by Cortex XDR (per Marc, 2026-09-30) - the fleet
# migration is in progress, so this checks for Cortex rather than assuming
# either product is the baseline. Cortex XDR's Windows agent typically shows up
# as a "cyserver"/"Cortex" or legacy "Traps"/"Cyvera" service depending on
# version - matching broadly since the exact service name isn't confirmed yet.
$cortexNamePatterns = @("*cortex*","*paloalto*","*palo alto*","*traps*","*cyvera*","cyserver")

try {
    $allServices = Invoke-Target { Get-Service }

    foreach ($svc in $expectedServices) {
        $match = $allServices | Where-Object { $_.Name -like $svc.Name -or $_.DisplayName -like $svc.Name }
        if ($match) {
            $running = $match | Where-Object { $_.Status -eq "Running" }
            if ($running) {
                Add-Result "AV service - $($svc.Label)" "PASS" "Found and Running: $($match.Name -join ', ')"
            } else {
                Add-Result "AV service - $($svc.Label)" "FAIL" "Installed but not Running: $($match.Name -join ', ') (Status: $($match.Status -join ', '))"
            }
        } else {
            Add-Result "AV service - $($svc.Label)" "FAIL" "Not found on server"
        }
    }

    $sophos = $allServices | Where-Object { $_.Name -like "*Sophos*" -or $_.DisplayName -like "*Sophos*" }
    if ($sophos) {
        Add-Result "No Sophos services installed" "FAIL" "Found Sophos service(s): $($sophos.Name -join ', ')"
    } else {
        Add-Result "No Sophos services installed" "PASS" "None found"
    }

    $cortex = $allServices | Where-Object {
        $svcName = $_.Name; $svcDisplay = $_.DisplayName
        $cortexNamePatterns | Where-Object { $svcName -like $_ -or $svcDisplay -like $_ }
    }
    if ($cortex) {
        $cortexRunning = $cortex | Where-Object { $_.Status -eq "Running" }
        if ($cortexRunning) {
            Add-Result "AV service - Cortex XDR" "PASS" "Found and Running: $($cortex.Name -join ', ')"
        } else {
            Add-Result "AV service - Cortex XDR" "FAIL" "Found but not Running: $($cortex.Name -join ', ') (Status: $($cortex.Status -join ', '))"
        }
    } else {
        Add-Result "AV service - Cortex XDR" "FAIL" "No Cortex-pattern service found - either this box hasn't been migrated from Cybereason yet, or Cortex agent naming doesn't match the patterns this script looks for ($($cortexNamePatterns -join ', ')). Confirm in the Cortex console and update the patterns if the real service name differs."
    }

    if ($Role -in @("COR","DWA","MED","WEB","API","BIT","AGM","AGT","IVR","MEI","MEA")) {
        $logReader = $allServices | Where-Object { $_.Name -eq "LogReaderSVC" }
        if ($logReader -and $logReader.Status -eq "Running") {
            Add-Result "inContact Log Reader Service (LogReaderSVC)" "PASS" "Installed and Running"
        } elseif ($Role -in $LogReaderExceptionRoles) {
            Add-Result "inContact Log Reader Service (LogReaderSVC)" "SKIP" "Not found/running, but $Role is on the documented exception list - LogReaderSVC failure is OK to skip for this build type"
        } else {
            Add-Result "inContact Log Reader Service (LogReaderSVC)" "FAIL" "Not found or not running"
        }
    }
} catch {
    Add-Result "AV / security services" "FAIL" "Could not query services: $($_.Exception.Message)"
}

# ---------------------------------------------------------------------------
# 6. Scheduled tasks (role dependent)
# ---------------------------------------------------------------------------
function Test-ScheduledTaskHealthy {
    param([string]$TaskName)
    try {
        $task = Invoke-Target { param($n) Get-ScheduledTask -TaskName $n -ErrorAction Stop } -ArgumentList $TaskName
        $info = Invoke-Target { param($n) Get-ScheduledTaskInfo -TaskName $n -ErrorAction Stop } -ArgumentList $TaskName
        return [pscustomobject]@{ Found = $true; State = $task.State; LastResult = $info.LastTaskResult; LastRun = $info.LastRunTime }
    } catch {
        return [pscustomobject]@{ Found = $false; State = $null; LastResult = $null; LastRun = $null }
    }
}

if ($Role -eq "COR") {
    $fsDiskUsed = Test-ScheduledTaskHealthy -TaskName "FS_DiskUsed"
    if ($fsDiskUsed.Found) {
        $expectedEnabled = ($ClusterSide -eq "B")
        $isEnabled = ($fsDiskUsed.State -ne "Disabled")
        if (-not $ClusterSide) {
            Add-Result "FS_DiskUsed scheduled task" "MANUAL" "Task found (State: $($fsDiskUsed.State)) - pass -ClusterSide A|B to auto-validate enable/disable expectation"
        } elseif ($isEnabled -eq $expectedEnabled) {
            Add-Result "FS_DiskUsed scheduled task ($ClusterSide side)" "PASS" "State=$($fsDiskUsed.State), matches expectation for $ClusterSide side"
        } else {
            Add-Result "FS_DiskUsed scheduled task ($ClusterSide side)" "FAIL" "State=$($fsDiskUsed.State) - expected enabled on B side only, disabled on A side"
        }
        Add-Result "FS_DiskUsed log files (D:\Proj\LogFiles\FS_DiskUsed)" "MANUAL" "Log into server and confirm log files are being written"
    } else {
        Add-Result "FS_DiskUsed scheduled task" "FAIL" "Task not found"
    }
    Add-Result "PacketCapture scheduled task" "SKIP" "Per source doc: 'Bryan is working on this' - not yet a defined check"
    Add-Result "TempDB/SQL data/tx log disks on GP3 16000 IOPS" "MANUAL" "Confirm in AWS console: disks backing TempDB, SQL data files and transaction logs are GP3 EBS with 16,000 IOPS and sufficient throughput"
}

if ($Role -eq "DWA") {
    Add-Result "TempDB/SQL data/tx log disks on GP3 16000 IOPS" "MANUAL" "Confirm in AWS console: disks backing TempDB, SQL data files and transaction logs are GP3 EBS with 16,000 IOPS and sufficient throughput"
}

if ($Role -in @("COR","DWA","MED","WEB","API","BIT")) {
    # LogZipper has been migrating from a scheduled task to an Infratools-installed
    # Windows SERVICE (per NOC VA27 readiness findings / "LogZipper Service Install
    # Via Infratools", Sep 2026) - check both and pass if either is healthy.
    $logZipperTask = Test-ScheduledTaskHealthy -TaskName "LogZipper"
    $logZipperSvc = $allServices | Where-Object { $_.Name -like "*LogZipper*" -or $_.DisplayName -like "*LogZipper*" }

    $taskOk = $logZipperTask.Found -and ($logZipperTask.State -ne "Disabled")
    $svcOk = $logZipperSvc -and ($logZipperSvc | Where-Object { $_.Status -eq "Running" })

    if ($svcOk) {
        Add-Result "LogZipper" "PASS" "LogZipper service found and Running: $($logZipperSvc.Name -join ', ')"
    } elseif ($taskOk) {
        Add-Result "LogZipper" "PASS" "LogZipper scheduled task found, State=$($logZipperTask.State) (service not found - confirm this cluster hasn't been migrated to the service yet)"
    } elseif ($logZipperSvc) {
        Add-Result "LogZipper" "FAIL" "LogZipper service found but not Running: $($logZipperSvc.Name -join ', ') (Status: $($logZipperSvc.Status -join ', '))"
    } elseif ($logZipperTask.Found) {
        Add-Result "LogZipper" "FAIL" "Scheduled task is Disabled - checklist requires enabled on both sides"
    } else {
        Add-Result "LogZipper" "FAIL" "Neither a LogZipper service nor scheduled task was found"
    }
    Add-Result "LogZipper log files (D:\Proj\LogFiles\LogZipper)" "MANUAL" "Confirm log files are being written"
}

# ---------------------------------------------------------------------------
# 7. Local group memberships
# ---------------------------------------------------------------------------
$expectedAdmins = @("_Infratools","BMCAdmins","patrol","bmc_discovery","insqladmins","SysDeploy")
if ($Role -eq "WFO") {
    $expectedAdmins += @("NICE_Admins","WFO App Ops","Server_NICEServers_RemoteDesktopUsers")
}

try {
    $admins = Invoke-Target { Get-LocalGroupMember -Group "Administrators" -ErrorAction Stop } |
        ForEach-Object { ($_.Name -split '\\')[-1] }

    $missing = $expectedAdmins | Where-Object { $_ -notin $admins }
    if (-not $missing) {
        Add-Result "Administrators group membership" "PASS" "All expected members present: $($expectedAdmins -join ', ')"
    } else {
        # Get-LocalGroupMember only returns DIRECT members - it doesn't expand
        # nested domain/global groups. A name can be "missing" here and still be
        # effectively present if it's nested inside one of the other domain
        # groups already on this box (Domain Admins, a role group, etc.) via
        # GPO Restricted Groups. Report MANUAL, not FAIL, so this isn't read as
        # a hard defect - confirm via effective access rather than this flat list.
        Add-Result "Administrators group membership" "MANUAL" "Not directly listed: $($missing -join ', '). Current direct members: $($admins -join ', '). Note: this only shows direct membership - a missing name can still have access via a nested domain group (GPO Restricted Groups) that doesn't expand here. Confirm effective access before treating as a gap."
    }
} catch {
    Add-Result "Administrators group membership" "FAIL" "Could not query group: $($_.Exception.Message)"
}

if ($Role -eq "MED") {
    try {
        $rdu = Invoke-Target { Get-LocalGroupMember -Group "Remote Desktop Users" -ErrorAction Stop } |
            ForEach-Object { ($_.Name -split '\\')[-1] }
        $expectedRdu = @("Role_MediaEngineer","Voice Eng")
        $missingRdu = $expectedRdu | Where-Object { $_ -notin $rdu }
        if (-not $missingRdu) {
            Add-Result "Remote Desktop Users group (MED)" "PASS" "Expected members present"
        } else {
            Add-Result "Remote Desktop Users group (MED)" "FAIL" "Missing: $($missingRdu -join ', ')"
        }
    } catch {
        Add-Result "Remote Desktop Users group (MED)" "FAIL" "Could not query group: $($_.Exception.Message)"
    }
}

# Sophos is retired per Marc (2026-09-30) - no longer part of the standard
# build, so the SophosAdministrator group requirement in the 2026 doc is stale.
# Not checking it. The "No Sophos services installed" check above still stands
# (confirming no leftover install), just not this AD group membership one.
Add-Result "SophosAdministrator group membership" "SKIP" "Sophos retired - this checklist line is stale, not checking"

# ---------------------------------------------------------------------------
# 8. Group Policy (manual review - no fixed expected GPO list documented)
# ---------------------------------------------------------------------------
Add-Result "Group Policy Details" "MANUAL" "Run 'gpresult /r' or 'gpresult /h report.html' on the server and review applied GPOs"

# ---------------------------------------------------------------------------
# 9. WEB server specifics
# ---------------------------------------------------------------------------
if ($Role -eq "WEB") {
    try {
        $iisUser = Invoke-Target { Get-LocalUser -Name "IISinSideWS" -ErrorAction Stop }
        Add-Result "IISinSideWS local user exists" "PASS" "Enabled: $($iisUser.Enabled)"
    } catch {
        Add-Result "IISinSideWS local user exists" "FAIL" "User not found: $($_.Exception.Message)"
    }
    Add-Result "IISinSideWS password matches Pleasant" "MANUAL" "Verify manually against Pleasant Password entry"
    Add-Result "inSideWS IIS AppPool recycle settings" "MANUAL" "Confirm PrivateMemory limit (~5GB) and nightly staggered recycle schedule (TimeSpan[] array) in IIS Manager / applicationHost.config"
}

# ---------------------------------------------------------------------------
# 10. FedRAMP DoD root certs (COR/API only)
# ---------------------------------------------------------------------------
if ($FedRAMP -and $Role -in @("COR","API")) {
    try {
        $dodCerts = Invoke-Target { Get-ChildItem Cert:\LocalMachine\Root | Where-Object { $_.Subject -like "*DoD*" -or $_.Issuer -like "*DoD*" } }
        if ($dodCerts) {
            Add-Result "DoD Trust Root Certificates installed" "PASS" "$($dodCerts.Count) DoD cert(s) found in LocalMachine\Root"
        } else {
            Add-Result "DoD Trust Root Certificates installed" "FAIL" "No DoD certs found - install via InstallRoot 5.5 (see SOP CHG0030915)"
        }
    } catch {
        Add-Result "DoD Trust Root Certificates installed" "FAIL" "Could not query cert store: $($_.Exception.Message)"
    }
}

# ---------------------------------------------------------------------------
# 11. Items that are inherently manual / portal-based
# ---------------------------------------------------------------------------
Add-Result "InfraWatch tagging + dashboard validation" "MANUAL" "Tag server in Infratools (Configuration > Tag Servers), then confirm Availability/Status/Disk/Uptime sections in InfraWatch dashboard"
if ($Role -in @("ASR","CDR")) {
    Add-Result "File Retention settings (ASR/CDR)" "MANUAL" "Confirm against https://nice-ce-cxone-prod.atlassian.net/wiki/spaces/IN/pages/15777267/File+Retention"
}
Add-Result "Cortex XDR console status" "MANUAL" "Confirm server shows healthy/connected in the Cortex XDR console (not just local service state) - Cybereason is being retired fleet-wide in favor of Cortex per Marc, 2026-09-30"
Add-Result "Cluster added to Authorized Assemblies list" "SKIP" "Only relevant for a brand-new cluster, not a routine per-server check - see https://nice-ce-cxone-prod.atlassian.net/wiki/display/IN/Update+Authorized+Assemblies+for+New+Clusters if this is a new cluster"

# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
Write-Host ""
$results | Format-Table -AutoSize -Wrap

$fails = ($results | Where-Object Status -eq "FAIL").Count
$manual = ($results | Where-Object Status -eq "MANUAL").Count
$pass = ($results | Where-Object Status -eq "PASS").Count

Write-Host ""
Write-Host "Summary: $pass PASS / $fails FAIL / $manual MANUAL" -ForegroundColor $(if ($fails -gt 0) { "Red" } else { "Yellow" })

if ($OutCsv) {
    $results | Export-Csv -Path $OutCsv -NoTypeInformation
    Write-Host "Results written to $OutCsv"
}