<#
.SYNOPSIS  READ-ONLY quick reachability check for one or more servers (DNS, ping, common ports, optional uptime).
.EXAMPLE   .\Test-ServerReach.ps1 -Computers lax-inapp01,10.1.2.3 -Uptime
#>
param(
    [Parameter(Mandatory)][string[]]$Computers,
    [int[]]$Ports = @(22, 80, 135, 443, 445, 3389, 5985, 5986, 10001),
    [switch]$Uptime,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Continue'
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
function Test-Port([string]$h, [int]$p) {
    $c = New-Object Net.Sockets.TcpClient
    try { $a = $c.BeginConnect($h, $p, $null, $null); $ok = $a.AsyncWaitHandle.WaitOne(1500) -and $c.Connected; return $ok } catch { return $false } finally { $c.Close() }
}
$rows = foreach ($raw in $Computers) {
    $h = $raw.Trim(); if (-not $h) { continue }
    $ip = ''; try { $ip = (([Net.Dns]::GetHostAddresses($h) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1).IPAddressToString) } catch {}
    $ping = ''; try { $ping = (New-Object Net.NetworkInformation.Ping).Send($h, 1500).Status } catch { $ping = 'error' }
    $open = @(); foreach ($p in $Ports) { if (Test-Port $h $p) { $open += $p } }
    $up = ''
    if ($Uptime -and $open -contains 135) {
        try { $os = Get-CimInstance Win32_OperatingSystem -ComputerName $h -ErrorAction Stop; $up = "{0:N1} days (boot {1})" -f ((Get-Date) - $os.LastBootUpTime).TotalDays, $os.LastBootUpTime } catch { $up = "n/a: $($_.Exception.Message.Split("`n")[0])" }
    }
    [pscustomobject]@{ Computer = $h; IP = $ip; Ping = $ping; OpenPorts = ($open -join ' '); Uptime = $up }
}
$rows | Format-Table -AutoSize
$out = Join-Path $OutDir ("Reach_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green