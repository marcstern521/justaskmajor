<#
.SYNOPSIS
  Pull data from an HPE iLO (4/5/6) over the network: health summary, IML/IEL events, or the Active Health System (.ahs) file.
  READ-ONLY. Run from a machine that can reach the iLO management network (not the server's OS IP).

.EXAMPLE
  .\Get-HpeAhsLog.ps1 -Ilo ilo-lax-blade01.example.com -Mode Info
  .\Get-HpeAhsLog.ps1 -Ilo 10.1.2.3 -Mode IML
  .\Get-HpeAhsLog.ps1 -Ilo 10.1.2.3 -Mode AHS -Days 7
.NOTES
  AHS download uses the iLO /ahsdata endpoint with a Redfish session token. Not tested against your iLOs yet -
  if AHS fails, the console shows the HTTP status; Info and IML are plain Redfish and usually work first try.
#>
param(
    [Parameter(Mandatory)][string]$Ilo,
    [ValidateSet('Info', 'IML', 'AHS')][string]$Mode = 'Info',
    [int]$Days = 7,
    [pscredential]$Credential,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
if (-not $Credential) { $Credential = Get-Credential -Message "iLO login for $Ilo" }
# iLO uses self-signed certs
$core = $PSVersionTable.PSVersion.Major -ge 6
if (-not $core) {
    Add-Type 'using System.Net;using System.Security.Cryptography.X509Certificates;public class TrustAll:ICertificatePolicy{public bool CheckValidationResult(ServicePoint s,X509Certificate c,WebRequest r,int p){return true;}}' -ErrorAction SilentlyContinue
    [Net.ServicePointManager]::CertificatePolicy = New-Object TrustAll
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}
$base = "https://$Ilo"
$common = @{}; if ($core) { $common.SkipCertificateCheck = $true }
$body = @{ UserName = $Credential.UserName; Password = $Credential.GetNetworkCredential().Password } | ConvertTo-Json
$login = Invoke-WebRequest @common -Uri "$base/redfish/v1/SessionService/Sessions/" -Method Post -Body $body -ContentType 'application/json' -UseBasicParsing
$token = $login.Headers['X-Auth-Token']; if ($token -is [array]) { $token = $token[0] }
$sessionUri = $login.Headers['Location']; if ($sessionUri -is [array]) { $sessionUri = $sessionUri[0] }
$hdr = @{ 'X-Auth-Token' = $token }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$safe = $Ilo -replace '[^\w\.-]', '_'
try {
    switch ($Mode) {
        'Info' {
            $s = Invoke-RestMethod @common -Uri "$base/redfish/v1/Systems/1/" -Headers $hdr
            $o = [pscustomobject]@{ Model = $s.Model; Serial = $s.SerialNumber; SKU = $s.SKU; Host = $s.HostName; Power = $s.PowerState; Health = $s.Status.Health; State = $s.Status.State; BIOS = $s.BiosVersion; Memory_GB = $s.MemorySummary.TotalSystemMemoryGiB; MemHealth = $s.MemorySummary.Status.HealthRollup; CPUs = $s.ProcessorSummary.Count; CpuHealth = $s.ProcessorSummary.Status.HealthRollup }
            $o | Format-List
            $out = Join-Path $OutDir "iLO_Info_${safe}_$stamp.csv"; $o | Export-Csv $out -NoTypeInformation
        }
        'IML' {
            $entries = @(); $uri = "$base/redfish/v1/Systems/1/LogServices/IML/Entries/"
            while ($uri -and $entries.Count -lt 500) {
                $r = Invoke-RestMethod @common -Uri $uri -Headers $hdr
                $entries += @($r.Members)
                $uri = $null; if ($r.'Members@odata.nextLink') { $uri = "$base$($r.'Members@odata.nextLink'.'@odata.id')" }
            }
            $rows = $entries | ForEach-Object { [pscustomobject]@{ Created = $_.Created; Severity = $_.Severity; Message = $_.Message; Class = $_.Oem.Hpe.Class; Code = $_.Oem.Hpe.Code; Repaired = $_.Oem.Hpe.Repaired; Count = $_.Oem.Hpe.Count } } | Sort-Object Created -Descending
            $rows | Select-Object -First 25 | Format-Table -AutoSize -Wrap
            $out = Join-Path $OutDir "iLO_IML_${safe}_$stamp.csv"; $rows | Export-Csv $out -NoTypeInformation
        }
        'AHS' {
            $to = Get-Date; $from = $to.AddDays(-$Days)
            $f = $from.ToString('yyyy-MM-dd'); $t = $to.ToString('yyyy-MM-dd')
            $out = Join-Path $OutDir "iLO_AHS_${safe}_$stamp.ahs"
            $uri = "$base/ahsdata/HP_${safe}_$stamp.ahs?from=$f&to=$t&downloadAll=0"
            Write-Host "Downloading AHS $f..$t (can take a few minutes)..." -ForegroundColor Cyan
            Invoke-WebRequest @common -Uri $uri -Headers $hdr -OutFile $out -UseBasicParsing
            Write-Host ("{0:N1} MB" -f ((Get-Item $out).Length / 1MB))
            Write-Host 'Attach the .ahs file to the HPE case, or open it in the AHS Viewer (ahsv.hpe.com).' -ForegroundColor Yellow
        }
    }
    Write-Host "Saved: $out" -ForegroundColor Green
} finally {
    if ($sessionUri) { try { Invoke-RestMethod @common -Uri $sessionUri -Headers $hdr -Method Delete | Out-Null } catch {} }
}
