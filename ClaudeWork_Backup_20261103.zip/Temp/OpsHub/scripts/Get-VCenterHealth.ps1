<#
.SYNOPSIS  READ-ONLY vCenter health snapshot for the weekly compute/vSAN checks: host state, CPU/mem, datastores low on space, triggered alarms.
.EXAMPLE   .\Get-VCenterHealth.ps1 -VCenter lax-vmvce01.inucn.com
           .\Get-VCenterHealth.ps1 -VCenter eng-vmvce01.in.lab -FreePctWarn 20
.NOTES     Needs VMware PowerCLI (Install-Module VMware.PowerCLI -Scope CurrentUser). vSAN detail: open the vSAN Skyline Health page; this tool only flags host/datastore/alarm issues.
#>
param(
    [Parameter(Mandatory)][string]$VCenter,
    [pscredential]$Credential,
    [int]$FreePctWarn = 15,
    [int]$MinDatastoreGB = 10,
    [switch]$ShowAll,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Stop'
if (-not (Get-Module -ListAvailable -Name VMware.VimAutomation.Core)) { throw 'VMware PowerCLI not installed: Install-Module VMware.PowerCLI -Scope CurrentUser' }
if (-not $Credential) { $Credential = Get-Credential -Message "vCenter login for $VCenter" }
Write-Host 'Loading VMware PowerCLI (the first load can take 1-2 minutes)...' -ForegroundColor DarkGray
Import-Module VMware.VimAutomation.Core
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false -ParticipateInCEIP $false | Out-Null
Write-Host "Connecting to $VCenter ..." -ForegroundColor DarkGray
$null = Connect-VIServer -Server $VCenter -Credential $Credential
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
$rows = New-Object System.Collections.Generic.List[object]
$alarmNames = @{}
try {
    foreach ($h in Get-VMHost) {
        $st = 'OK'
        if ($h.ConnectionState -eq 'Maintenance') { $st = 'NOTE: Maintenance' } elseif ($h.ConnectionState -ne 'Connected') { $st = "ISSUE: $($h.ConnectionState)" } elseif ($h.PowerState -ne 'PoweredOn') { $st = "ISSUE: $($h.PowerState)" }
        $cpuPct = ''; $memPct = ''
        if ($h.CpuTotalMhz) { $cpuPct = [math]::Round(100 * $h.CpuUsageMhz / $h.CpuTotalMhz) }
        if ($h.MemoryTotalGB) { $memPct = [math]::Round(100 * $h.MemoryUsageGB / $h.MemoryTotalGB) }
        $rows.Add([pscustomobject]@{ Type = 'Host'; Name = $h.Name; Detail = "v$($h.Version) cpu=$cpuPct% mem=$memPct% cluster=$($h.Parent.Name)"; Status = $st })
    }
    foreach ($d in (Get-Datastore | Sort-Object Name, CapacityGB -Unique)) {
        $pct = 0; if ($d.CapacityGB) { $pct = [math]::Round(100 * $d.FreeSpaceGB / $d.CapacityGB, 1) }
        $st = 'OK'; if ($d.CapacityGB -le $MinDatastoreGB) { $st = 'SKIP: tiny/boot datastore' } elseif ($pct -lt $FreePctWarn) { $st = "ISSUE: only $pct% free" }
        $rows.Add([pscustomobject]@{ Type = 'Datastore'; Name = $d.Name; Detail = ("{0:N0} GB free of {1:N0} GB ({2}%)" -f $d.FreeSpaceGB, $d.CapacityGB, $pct); Status = $st })
    }
    foreach ($e in @(Get-View -ViewType HostSystem -Property Name, TriggeredAlarmState) + @(Get-View -ViewType ClusterComputeResource -Property Name, TriggeredAlarmState) + @(Get-View -ViewType Datastore -Property Name, TriggeredAlarmState)) {
        foreach ($a in @($e.TriggeredAlarmState)) {
            if (-not $a) { continue }
            if (-not $alarmNames.ContainsKey([string]$a.Alarm)) { $alarmNames[[string]$a.Alarm] = (Get-View -Id $a.Alarm -Property Info.Name).Info.Name }
            $an = $alarmNames[[string]$a.Alarm]
            $rows.Add([pscustomobject]@{ Type = 'Alarm'; Name = $e.Name; Detail = "$an (since $($a.Time))"; Status = "ISSUE: $($a.OverallStatus)" })
        }
    }
} finally { Disconnect-VIServer -Server $VCenter -Confirm:$false -ErrorAction SilentlyContinue }
Write-Host ''
$cnt = @($rows | Group-Object Type, @{ e = { ($_.Status -split ':')[0] } } | Sort-Object Name)
Write-Host '--- Summary ---' -ForegroundColor Cyan
$rows | Group-Object Type | ForEach-Object {
    $t = $_.Name
    $ok = @($_.Group | Where-Object { $_.Status -eq 'OK' }).Count
    $is = @($_.Group | Where-Object { $_.Status -like 'ISSUE*' }).Count
    $nt = @($_.Group | Where-Object { $_.Status -like 'NOTE*' -or $_.Status -like 'SKIP*' }).Count
    Write-Host ("{0,-10} OK {1,-5} ISSUE {2,-5} note/skipped {3}" -f $t, $ok, $is, $nt)
}
$al = @($rows | Where-Object { $_.Type -eq 'Alarm' })
if ($al.Count) {
    Write-Host "`n--- Alarms grouped by name (count, worst status) ---" -ForegroundColor Cyan
    $al | Group-Object { ($_.Detail -replace ' \(since.*$', '') } | Sort-Object Count -Descending | ForEach-Object {
        $worst = if (@($_.Group | Where-Object { $_.Status -like '*red*' }).Count) { 'red' } else { 'yellow' }
        Write-Host ("{0,4}  {1,-7} {2}" -f $_.Count, $worst, $_.Name)
    }
}
$show = if ($ShowAll) { $rows } else { @($rows | Where-Object { $_.Status -like 'ISSUE*' -and $_.Type -ne 'Alarm' }) }
Write-Host "`n--- Host / datastore issues ($(@($show).Count)) ---" -ForegroundColor Cyan
$show | Sort-Object Type, Name | Format-Table Type, Name, Detail, Status -AutoSize -Wrap
$bad = @($rows | Where-Object { $_.Status -like 'ISSUE*' }).Count
if ($bad) { Write-Host "$bad issue(s) found. Full list incl. every alarm is in the CSV. Maintenance hosts and tiny boot datastores are noted, not counted." -ForegroundColor Yellow } else { Write-Host 'No host, datastore or alarm issues found.' -ForegroundColor Green }
$out = Join-Path $OutDir ("VCenter_{0}_{1}.csv" -f ($VCenter -replace '[^\w\.-]', '_'), (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green