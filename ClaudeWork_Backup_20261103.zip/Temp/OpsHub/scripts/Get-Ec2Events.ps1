<#
.SYNOPSIS  READ-ONLY: list pending AWS scheduled events (reboot / retirement / maintenance) per profile and region.
.EXAMPLE   .\Get-Ec2Events.ps1 -Profiles ic-prod,ic-dev -Regions us-west-2,us-east-1
#>
param(
    [string[]]$Profiles = @('ic-prod', 'ic-dev', 'ic-staging', 'ic-test', 'ic-perf', 'ic-ops', 'ic-prod-east3', 'ic-prod-jo1', 'ic-prod-za', 'ic-ops-acaea', 'uk-sov', 'uk-sov2', 'eu-sov-fra', 'eu-sov-ie', 'au-sov'),
    [string[]]$Regions = @(),   # blank = each account's own regions
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ProfileRegions = @{
    'ic-prod' = @('us-west-2','us-east-1'); 'ic-dev' = @('us-west-2','us-east-1'); 'ic-staging' = @('us-west-2','us-east-1'); 'ic-test' = @('us-west-2','us-east-1')
    'ic-perf' = @('us-west-2','us-east-1'); 'ic-ops' = @('us-west-2','us-east-1'); 'ic-prod-east3' = @('us-east-1')
    'ic-prod-jo1' = @('ap-northeast-3'); 'ic-prod-za' = @('af-south-1'); 'ic-ops-acaea' = @('me-central-1')
    'uk-sov' = @('eu-west-2'); 'uk-sov2' = @('eu-west-2'); 'eu-sov-fra' = @('eu-central-1'); 'eu-sov-ie' = @('eu-west-1'); 'au-sov' = @('ap-southeast-2')
}
$ErrorActionPreference = 'Continue'
if (-not (Get-Command aws -ErrorAction SilentlyContinue)) { throw 'aws CLI not found' }
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
$rows = New-Object System.Collections.Generic.List[object]
foreach ($p in $Profiles) {
    $null = (& aws sts get-caller-identity --profile $p --output json 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) { $rows.Add([pscustomobject]@{ Profile = $p; Region = ''; InstanceId = ''; Name = ''; Code = ''; NotBefore = ''; NotAfter = ''; Description = ''; Status = "UNCHECKED - aws sso login --profile $p" }); Write-Warning "$p not logged in"; continue }
    $regionList = if ($Regions.Count) { $Regions } elseif ($ProfileRegions.ContainsKey($p)) { $ProfileRegions[$p] } else { @((& aws configure get region --profile $p 2>$null)) }
    foreach ($r in $regionList) {
        $raw = (& aws ec2 describe-instance-status --profile $p --region $r --output json 2>&1 | Out-String)
        if ($LASTEXITCODE -ne 0) { $rows.Add([pscustomobject]@{ Profile = $p; Region = $r; InstanceId = ''; Name = ''; Code = ''; NotBefore = ''; NotAfter = ''; Description = ''; Status = "UNCHECKED - $($raw.Trim().Split("`n")[0])" }); continue }
        $hits = New-Object System.Collections.Generic.List[object]
        foreach ($s in @(($raw | ConvertFrom-Json).InstanceStatuses)) {
            foreach ($e in @($s.Events)) {
                if (-not $e) { continue }
                if ($e.Description -match '^\[(Completed|Canceled)\]') { continue }
                $hits.Add([pscustomobject]@{ Id = $s.InstanceId; Code = $e.Code; NotBefore = $e.NotBefore; NotAfter = $e.NotAfter; Desc = $e.Description })
            }
        }
        $names = @{}
        if ($hits.Count) {
            $ids = @($hits | ForEach-Object { $_.Id } | Select-Object -Unique)
            $d = (& aws ec2 describe-instances --profile $p --region $r --instance-ids @ids --output json 2>&1 | Out-String)
            if ($LASTEXITCODE -eq 0) { foreach ($res in @(($d | ConvertFrom-Json).Reservations)) { foreach ($i in @($res.Instances)) { $names[$i.InstanceId] = ($i.Tags | Where-Object { $_.Key -eq 'Name' } | Select-Object -First 1).Value } } }
        }
        foreach ($h in $hits) { $rows.Add([pscustomobject]@{ Profile = $p; Region = $r; InstanceId = $h.Id; Name = $names[$h.Id]; Code = $h.Code; NotBefore = $h.NotBefore; NotAfter = $h.NotAfter; Description = $h.Desc; Status = 'EVENT' }) }
        if (-not $hits.Count) { $rows.Add([pscustomobject]@{ Profile = $p; Region = $r; InstanceId = ''; Name = ''; Code = ''; NotBefore = ''; NotAfter = ''; Description = ''; Status = 'checked - none' }) }
    }
}
$rows | Format-Table -AutoSize -Wrap
$out = Join-Path $OutDir ("Ec2Events_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green
