<#
.SYNOPSIS  READ-ONLY self-check: is this laptop/server ready to run the Ops Hub tools? Run this first.
.EXAMPLE   .\Test-OpsPreflight.ps1
           .\Test-OpsPreflight.ps1 -AwsProfiles ic-prod,ic-dev,uk-sov
#>
param(
    [string[]]$AwsProfiles = @('ic-prod', 'ic-dev', 'ic-staging', 'ic-test', 'ic-perf', 'ic-ops', 'ic-prod-east3', 'ic-prod-jo1', 'ic-prod-za', 'ic-ops-acaea', 'uk-sov', 'uk-sov2', 'eu-sov-fra', 'eu-sov-ie', 'au-sov'),
    [string]$InucnDc = '10.244.88.62',
    [string]$LabDc = '172.20.34.100',
    [string[]]$Https = @('niceincontact.service-now.com:443', 'infratools.inucn.com:443', 'lax-vmvce01.inucn.com:443', 'dal-insys01.inucn.com:10001', 'infratools.in.lab:443', 'eng-vmvce01.in.lab:443', 'oua-vmvce01.inopslab.com:443'),
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Continue'
$rows = New-Object System.Collections.Generic.List[object]
function Add-Row([string]$Check, [string]$Status, [string]$Detail = '') { $rows.Add([pscustomobject]@{ Check = $Check; Status = $Status; Detail = $Detail }) }
function Test-Port([string]$h, [int]$p) {
    $c = New-Object Net.Sockets.TcpClient
    try { $a = $c.BeginConnect($h, $p, $null, $null); return ($a.AsyncWaitHandle.WaitOne(2500) -and $c.Connected) } catch { return $false } finally { $c.Close() }
}
Add-Row 'PowerShell version' 'OK' "$($PSVersionTable.PSVersion) ($($PSVersionTable.PSEdition))"
$ep = (Get-ExecutionPolicy -List | ForEach-Object { "$($_.Scope)=$($_.ExecutionPolicy)" }) -join '; '
Add-Row 'Execution policy' 'INFO' $ep
if (Get-Module -ListAvailable -Name ActiveDirectory) { Add-Row 'AD module (RSAT)' 'OK' '' } else { Add-Row 'AD module (RSAT)' 'MISSING' 'Needed for term/AD tools. Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0' }
if (Get-Module -ListAvailable -Name VMware.VimAutomation.Core) { Add-Row 'VMware PowerCLI' 'OK' '' } else { Add-Row 'VMware PowerCLI' 'MISSING' 'Only needed for the vCenter health tool. Install-Module VMware.PowerCLI -Scope CurrentUser' }
$aws = Get-Command aws -ErrorAction SilentlyContinue
if (-not $aws) { Add-Row 'AWS CLI' 'MISSING' 'Needed for AWS tools' }
else {
    $v = (& aws --version 2>&1 | Out-String).Trim(); Add-Row 'AWS CLI' 'OK' $v
    foreach ($p in $AwsProfiles) {
        $o = (& aws sts get-caller-identity --profile $p --output json 2>&1 | Out-String)
        if ($LASTEXITCODE -eq 0) { Add-Row "AWS profile $p" 'OK' ((($o | ConvertFrom-Json).Arn)) }
        else { Add-Row "AWS profile $p" 'LOGIN NEEDED' "aws sso login --profile $p" }
    }
}
foreach ($d in @(@('inucn DC', $InucnDc), @('in.lab DC', $LabDc))) {
    foreach ($pt in 389, 9389) { if (Test-Port $d[1] $pt) { Add-Row "$($d[0]) $($d[1]):$pt" 'OK' '' } else { Add-Row "$($d[0]) $($d[1]):$pt" 'UNREACHABLE' 'AD tools need 9389 (ADWS) from this machine' } }
}
foreach ($h in $Https) {
    $hp = $h.Split(':'); $port = 443; if ($hp.Count -gt 1) { $port = [int]$hp[1] }
    if (Test-Port $hp[0] $port) { Add-Row "Reach $h" 'OK' '' } else { Add-Row "Reach $h" 'UNREACHABLE' 'DNS/VPN/firewall' }
}
try { if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }; $t = Join-Path $OutDir 'opshub_write_test.tmp'; 'x' | Set-Content $t; Remove-Item $t; Add-Row 'Report folder writable' 'OK' $OutDir } catch { Add-Row 'Report folder writable' 'FAILED' $_.Exception.Message }
$rows | Format-Table -AutoSize -Wrap
$bad = @($rows | Where-Object { $_.Status -in 'MISSING', 'UNREACHABLE', 'FAILED', 'LOGIN NEEDED' }).Count
try { $out = Join-Path $OutDir ("Preflight_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss')); $rows | Export-Csv $out -NoTypeInformation; Write-Host "Report: $out" } catch {}
if ($bad) { Write-Host "$bad item(s) need attention. Tools that depend on them will fail until fixed." -ForegroundColor Yellow } else { Write-Host 'All checks passed.' -ForegroundColor Green }
