<#
.SYNOPSIS  Signs in to the AWS SSO profiles Ops Hub uses. Only prompts for profiles that are not already logged in.
.EXAMPLE   .\Connect-AwsSso.ps1
.EXAMPLE   .\Connect-AwsSso.ps1 -Profiles ic-prod,uk-sov
#>
[CmdletBinding()]
param([string[]]$Profiles = @('ic-prod', 'ic-dev', 'ic-staging', 'ic-test', 'ic-perf', 'ic-ops', 'ic-prod-east3', 'ic-prod-jo1', 'ic-prod-za', 'ic-ops-acaea', 'uk-sov', 'uk-sov2', 'eu-sov-fra', 'eu-sov-ie', 'au-sov'))

$ErrorActionPreference = 'Continue'
if (-not (Get-Command aws -ErrorAction SilentlyContinue)) { Write-Host 'AWS CLI not found. Install it first.' -ForegroundColor Red; return }

# All profiles share one SSO session ('nice'), so ONE browser approval signs in every account.
$null = & aws sts get-caller-identity --profile $Profiles[0] --output json 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[login] SSO session 'nice' - a browser window will open; approve it once, then come back here" -ForegroundColor Yellow
    & aws sso login --sso-session nice
}

$ok = 0; $fail = @()
foreach ($p in $Profiles) {
    $null = & aws sts get-caller-identity --profile $p --output json 2>&1
    if ($LASTEXITCODE -eq 0) { Write-Host "[ok]    $p already signed in" -ForegroundColor Green; $ok++; continue }
    Write-Host "[login] $p - a browser window will open; approve it, then come back here" -ForegroundColor Yellow
    & aws sso login --profile $p
    $null = & aws sts get-caller-identity --profile $p --output json 2>&1
    if ($LASTEXITCODE -eq 0) { Write-Host "[ok]    $p signed in" -ForegroundColor Green; $ok++ }
    else { Write-Host "[FAIL]  $p could not sign in" -ForegroundColor Red; $fail += $p }
}
Write-Host ''
Write-Host "AWS profiles signed in: $ok of $($Profiles.Count)" -ForegroundColor Cyan
if ($fail.Count) { Write-Host "Failed: $($fail -join ', ')  (run: aws sso login --profile <name>)" -ForegroundColor Red }
