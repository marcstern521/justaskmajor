<#
.SYNOPSIS
    READ-ONLY server count report: Windows vs Linux per region, for AWS (EC2) and VMware (vCenter), grouped by
    Sov regions, Prod, FedRAMP and Lab.

.DESCRIPTION
    AWS    describe-instances only (no changes), for every signed-in SSO profile in the table below. Terminated
           instances are ignored. Windows is decided by the instance's PlatformDetails; everything else counts as Linux.
    VMware PowerCLI against the vCenters listed in data\vcenters.csv (Server,Category,Label). Templates are ignored.
           Windows / Linux come from the guest OS type VMware reports; anything else (appliances etc.) shows as Other.
           Counts are per cluster, so one vCenter that covers several sites (for example SGP inside the prod vCenter)
           is still broken out.
    Anything it could not check (profile not signed in, vCenter unreachable) is listed at the end, never counted as zero.

    Output (default C:\Temp\Inventory\yyyyMMdd): Inventory-Summary.csv, Inventory-AWS-Detail.csv,
    Inventory-VMware-Detail.csv and Inventory-Report.md (the table to paste into an email).

.PARAMETER NoAws          Skip AWS.
.PARAMETER NoVmware       Skip VMware.
.PARAMETER AwsProfiles    Limit to these profiles (default: all in the table).
.PARAMETER VCenterFile    CSV of vCenters. Default ..\data\vcenters.csv (created with the known vCenters on first run).
.PARAMETER Credential     One login for every vCenter (otherwise asked once per domain).
.PARAMETER AllRegions     AWS: scan every enabled region, not just each account's usual ones.
.EXAMPLE   .\Get-ServerInventory.ps1
.EXAMPLE   .\Get-ServerInventory.ps1 -NoVmware -AwsProfiles uk-sov,uk-sov2,eu-sov-fra,eu-sov-ie,au-sov
#>
[CmdletBinding()]
param(
    [switch]$NoAws,
    [switch]$NoVmware,
    [string[]]$AwsProfiles,
    [string]$VCenterFile,
    [string[]]$VCenter,
    [string]$Category = 'Prod',
    [string]$Label,
    [string]$Tag,
    [pscredential]$Credential,
    [switch]$AllRegions,
    [string]$OutDir
)
$ErrorActionPreference = 'Continue'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$isWin = ($env:OS -eq 'Windows_NT')
if (-not $VCenterFile) { $VCenterFile = Join-Path (Join-Path (Split-Path -Parent $here) 'data') 'vcenters.csv' }
if (-not $OutDir) { $OutDir = Join-Path $(if ($isWin) { 'C:\Temp\Inventory' } else { Join-Path ([IO.Path]::GetTempPath()) 'Inventory' }) (Get-Date -Format 'yyyyMMdd') }
if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }

# AWS profile -> category, label, regions. Add a row here for any account that is missing (for example a FedRAMP account).
$AwsMap = [ordered]@{
    'ic-prod'       = @{ Cat = 'Prod';       Label = 'Prod US (ic-prod)';          Regions = @('us-west-2', 'us-east-1') }
    'ic-prod-east3' = @{ Cat = 'Prod';       Label = 'Prod US East 3';             Regions = @('us-east-1') }
    'ic-prod-jo1'   = @{ Cat = 'Prod';       Label = 'Prod Japan (Osaka)';         Regions = @('ap-northeast-3') }
    'ic-prod-za'    = @{ Cat = 'Prod';       Label = 'Prod South Africa';          Regions = @('af-south-1') }
    'ic-ops-acaea'  = @{ Cat = 'Prod';       Label = 'Ops Middle East (ACAEA/B)';  Regions = @('me-central-1') }
    'uk-sov'        = @{ Cat = 'Sov UK 1';     Label = 'UK Sov 1';                   Regions = @('eu-west-2') }
    'uk-sov2'       = @{ Cat = 'Sov UK 2';     Label = 'UK Sov 2';                   Regions = @('eu-west-2') }
    'eu-sov-fra'    = @{ Cat = 'Sov EU';     Label = 'EU Sov Frankfurt';           Regions = @('eu-central-1') }
    'eu-sov-ie'     = @{ Cat = 'Sov EU';     Label = 'EU Sov Ireland';             Regions = @('eu-west-1') }
    'au-sov'        = @{ Cat = 'Sov AU';     Label = 'AU Sov';                     Regions = @('ap-southeast-2') }
    'ic-staging'    = @{ Cat = 'Lab';        Label = 'Staging';                    Regions = @('us-west-2', 'us-east-1') }
    'ic-test'       = @{ Cat = 'Lab';        Label = 'Test';                       Regions = @('us-west-2', 'us-east-1') }
    'ic-dev'        = @{ Cat = 'Lab';        Label = 'Dev';                        Regions = @('us-west-2', 'us-east-1') }
    'ic-perf'       = @{ Cat = 'Lab';        Label = 'Perf';                       Regions = @('us-west-2', 'us-east-1') }
    'ic-compliance-prod' = @{ Cat = 'FedRAMP'; Label = 'Compliance (FedRAMP) prod';   Regions = @('us-east-1', 'us-west-2') }
    'ic-ops'        = @{ Cat = 'Lab';        Label = 'Ops';                        Regions = @('us-west-2', 'us-east-1') }
}
$CatOrder = @('Prod', 'FedRAMP', 'Sov UK 1', 'Sov UK 2', 'Sov EU', 'Sov AU', 'Lab')

$summary = New-Object System.Collections.Generic.List[object]
$awsDetail = New-Object System.Collections.Generic.List[object]
$vmDetail = New-Object System.Collections.Generic.List[object]
$notChecked = New-Object System.Collections.Generic.List[string]

function SumOf($rows,$prop){ $t=0; foreach($r in @($rows)){ $t+=[int]$r.$prop }; $t }
function Add-Summary {
    param($Source, $Cat, $Scope, $Region, $Win, $Lin, $Oth, $Off)
    $summary.Add([pscustomobject]@{ Category = $Cat; Source = $Source; Scope = $Scope; Region = $Region; Windows = $Win; Linux = $Lin; Other = $Oth; Stopped = $Off; Total = ($Win + $Lin + $Oth + $Off) })
}

# ----------------------------------------------------------------------------------------------- AWS
if (-not $NoAws) {
    if (-not (Get-Command aws -ErrorAction SilentlyContinue)) { $notChecked.Add('AWS: aws CLI not found') }
    else {
        $profiles = if ($AwsProfiles) { $AwsProfiles } else { @($AwsMap.Keys) }
        foreach ($p in $profiles) {
            $m = $AwsMap[$p]
            if (-not $m) { $m = @{ Cat = 'Other'; Label = $p; Regions = @() } }
            $null = & aws sts get-caller-identity --profile $p --output json 2>&1
            if ($LASTEXITCODE -ne 0) { $notChecked.Add("AWS $p ($($m.Label)): not signed in. Run .\Connect-AwsSso.ps1 -Profiles $p"); Write-Host "[skip] $p not signed in" -ForegroundColor Yellow; continue }
            $regions = @($m.Regions)
            if ($AllRegions -or -not $regions.Count) {
                $rt = (& aws ec2 describe-regions --profile $p --query 'Regions[].RegionName' --output json 2>$null | Out-String)
                if ($LASTEXITCODE -eq 0 -and $rt.Trim()) { $regions = @($rt.Trim() -split '[\s,\[\]"]+' | Where-Object { $_ -match '^[a-z]{2}(-[a-z]+)+-\d$' }) }
            }
            foreach ($r in $regions) {
                Write-Host "AWS $p / $r ..." -ForegroundColor DarkGray
                $q = "Reservations[].Instances[].{Id:InstanceId,Name:Tags[?Key=='Name']|[0].Value,Plat:PlatformDetails,State:State.Name,Type:InstanceType}"
                $txt = (& aws ec2 describe-instances --profile $p --region $r --query $q --output json 2>&1 | Out-String)
                if ($LASTEXITCODE -ne 0) { $notChecked.Add("AWS $p / ${r}: $(($txt.Trim() -split "`n")[0])"); continue }
                $items = @(); if ($txt.Trim()) { $parsed = $txt | ConvertFrom-Json; $items = @(); foreach ($e in $parsed) { if ($e -is [System.Array]) { $items += $e } else { $items += $e } } }
                $win = 0; $lin = 0; $off = 0
                foreach ($i in $items) {
                    if (-not $i -or $i.State -eq 'terminated') { continue }
                    $os = if ("$($i.Plat)" -match 'Windows') { 'Windows' } else { 'Linux' }
                    $awsDetail.Add([pscustomobject]@{ Category = $m.Cat; Account = $p; Label = $m.Label; Region = $r; Name = $i.Name; InstanceId = $i.Id; OS = $os; PlatformDetails = $i.Plat; State = $i.State; Type = $i.Type })
                    if ($i.State -eq 'running') { if ($os -eq 'Windows') { $win++ } else { $lin++ } } else { $off++ }
                }
                Add-Summary 'AWS' $m.Cat $m.Label $r $win $lin 0 $off
            }
        }
    }
}

# ----------------------------------------------------------------------------------------------- VMware
if (-not $NoVmware) {
    if (-not $VCenter -and -not (Test-Path -LiteralPath $VCenterFile)) {
        $dir = Split-Path -Parent $VCenterFile
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        @('Server,Category,Label',
            'lax-vmvce01.inucn.com,Prod,Prod vCenter (LAX/DAL and other sites)',
            'eng-vmvce01.in.lab,Lab,Lab (eng / ViaWest)',
            'oua-vmvce01.inopslab.com,Lab,Ops Lab',
            'cul-vmvce01.incmp.com,FedRAMP,FedRAMP (Culpeper / Miami)') | Set-Content -LiteralPath $VCenterFile -Encoding UTF8
        Write-Host "Created $VCenterFile with the known vCenters. Add rows for the Sov and any other vCenters (Server,Category,Label) and run again." -ForegroundColor Yellow
    }
    $vcs = if ($VCenter) { @($VCenter | ForEach-Object { [pscustomobject]@{ Server = $_; Category = $Category; Label = $(if ($Label) { $Label } else { $_ }) } }) } else { @(Import-Csv -LiteralPath $VCenterFile | Where-Object { $_.Server }) }
    if ($vcs.Count) {
        if (-not (Get-Module -ListAvailable -Name VMware.VimAutomation.Core)) { $notChecked.Add('VMware: PowerCLI not installed (Install-Module VMware.PowerCLI -Scope CurrentUser)') }
        else {
            Write-Host 'Loading VMware PowerCLI (the first load can take 1-2 minutes)...' -ForegroundColor DarkGray
            Import-Module VMware.VimAutomation.Core
            $null = Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false -ParticipateInCEIP $false
            $creds = @{}
            foreach ($vc in $vcs) {
                $dom = if ($vc.Server -match '\.(.+)$') { $Matches[1].ToLower() } else { 'default' }
                $cred = $Credential
                if (-not $cred) {
                    if (-not $creds.ContainsKey($dom)) { try { $creds[$dom] = Get-Credential -Message "vCenter login for $dom (used for $($vc.Server) and other vCenters in that domain). Cancel to skip." } catch { $creds[$dom] = $null } }
                    $cred = $creds[$dom]
                }
                if (-not $cred) { $notChecked.Add("VMware $($vc.Server): no login supplied"); continue }
                $conn = $null
                try { $conn = Connect-VIServer -Server $vc.Server -Credential $cred -ErrorAction Stop }
                catch { $notChecked.Add("VMware $($vc.Server): $(($_.Exception.Message -split "`n")[0])"); continue }
                try {
                    Write-Host "VMware $($vc.Server) ..." -ForegroundColor DarkGray
                    $hostCluster = @{}
                    $clusterName = @{}
                    foreach ($c in Get-View -Server $conn -ViewType ClusterComputeResource -Property Name, Host) { foreach ($h in $c.Host) { $hostCluster[$h.Value] = $c.Name } }
                    $hostName = @{}
                    foreach ($h in Get-View -Server $conn -ViewType HostSystem -Property Name) { $hostName[$h.MoRef.Value] = $h.Name }
                    $vms = Get-View -Server $conn -ViewType VirtualMachine -Property Name, Config.GuestId, Config.GuestFullName, Config.Template, Runtime.PowerState, Runtime.Host, Guest.GuestFamily
                    $groups = @{}
                    foreach ($v in $vms) {
                        if ($v.Config -and $v.Config.Template) { continue }
                        $gid = "$($v.Config.GuestId)"; $gfn = "$($v.Config.GuestFullName)"; $fam = "$($v.Guest.GuestFamily)"
                        $os = if ($gid -match '^windows' -or $gfn -match 'Windows' -or $fam -eq 'windowsGuest') { 'Windows' }
                        elseif ($gid -match 'rhel|centos|ubuntu|sles|suse|oracle|debian|amazon|rocky|alma|photon|linux|other.*linux' -or $gfn -match 'Linux|Red Hat|CentOS|Ubuntu|SUSE|Oracle|Debian|Photon' -or $fam -eq 'linuxGuest') { 'Linux' }
                        else { 'Other' }
                        $on = ("$($v.Runtime.PowerState)" -eq 'poweredOn')
                        $hostRef = if ($v.Runtime.Host) { $v.Runtime.Host.Value } else { '' }
                        $cl = if ($hostRef -and $hostCluster.ContainsKey($hostRef)) { $hostCluster[$hostRef] } else { '(no cluster)' }
                        $vmDetail.Add([pscustomobject]@{ Category = $vc.Category; vCenter = $vc.Server; Cluster = $cl; Name = $v.Name; OS = $os; GuestOS = $gfn; PowerState = "$($v.Runtime.PowerState)" })
                        if (-not $groups.ContainsKey($cl)) { $groups[$cl] = @{ W = 0; L = 0; O = 0; X = 0 } }
                        if (-not $on) { $groups[$cl].X++ } elseif ($os -eq 'Windows') { $groups[$cl].W++ } elseif ($os -eq 'Linux') { $groups[$cl].L++ } else { $groups[$cl].O++ }
                    }
                    foreach ($cl in ($groups.Keys | Sort-Object)) { Add-Summary 'VMware' $vc.Category "$($vc.Label) [$($vc.Server)]" $cl $groups[$cl].W $groups[$cl].L $groups[$cl].O $groups[$cl].X }
                } catch { $notChecked.Add("VMware $($vc.Server): $(($_.Exception.Message -split "`n")[0])") }
                finally { try { Disconnect-VIServer -Server $conn -Confirm:$false -ErrorAction SilentlyContinue } catch {} }
            }
        }
    }
}

# ----------------------------------------------------------------------------------------------- report
$summary | Export-Csv -LiteralPath (Join-Path $OutDir ("Inventory-Summary{0}.csv" -f $(if ($Tag) {"-$Tag"}))) -NoTypeInformation
if ($awsDetail.Count) { $awsDetail | Export-Csv -LiteralPath (Join-Path $OutDir ("Inventory-AWS-Detail{0}.csv" -f $(if ($Tag) {"-$Tag"}))) -NoTypeInformation }
if ($vmDetail.Count) { $vmDetail | Export-Csv -LiteralPath (Join-Path $OutDir ("Inventory-VMware-Detail{0}.csv" -f $(if ($Tag) {"-$Tag"}))) -NoTypeInformation }

$md = New-Object System.Collections.Generic.List[string]
$md.Add("# Server count by region (Windows / Linux), AWS and VMware"); $md.Add("Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm'). Running / powered-on servers only in the Windows, Linux and Other columns; Stopped is shown separately.")
$md.Add('')
$cats = @($CatOrder) + @($summary | Select-Object -ExpandProperty Category -Unique | Where-Object { $CatOrder -notcontains $_ })
$grand = @{ W = 0; L = 0; O = 0; X = 0 }
foreach ($cat in $cats) {
    $rows = @($summary | Where-Object { $_.Category -eq $cat })
    if (-not $rows.Count) { continue }
    $md.Add("## $cat"); $md.Add('')
    $md.Add('| Source | Scope | Region / cluster | Windows | Linux | Other | Stopped |'); $md.Add('|---|---|---|--:|--:|--:|--:|')
    foreach ($r in ($rows | Sort-Object Source, Scope, Region)) { $md.Add("| $($r.Source) | $($r.Scope) | $($r.Region) | $($r.Windows) | $($r.Linux) | $($r.Other) | $($r.Stopped) |") }
    foreach ($src in 'AWS', 'VMware') {
        $s = @($rows | Where-Object { $_.Source -eq $src })
        if ($s.Count) { $md.Add("| **$src subtotal** | | | **$((SumOf ($s) 'Windows'))** | **$((SumOf ($s) 'Linux'))** | **$((SumOf ($s) 'Other'))** | **$((SumOf ($s) 'Stopped'))** |") }
    }
    $md.Add('')
    $grand.W += (SumOf ($rows) 'Windows'); $grand.L += (SumOf ($rows) 'Linux'); $grand.O += (SumOf ($rows) 'Other'); $grand.X += (SumOf ($rows) 'Stopped')
}
$md.Add("## Grand total"); $md.Add('')
$md.Add("Windows $($grand.W), Linux $($grand.L), Other $($grand.O), Stopped $($grand.X)."); $md.Add('')
if ($notChecked.Count) {
    $md.Add('## NOT CHECKED (these are gaps, not zeros)'); $md.Add('')
    foreach ($n in $notChecked) { $md.Add("- $n") }
    $md.Add('')
}
$md.Add('Note: an instance or VM that is in both AWS and VMware inventories is not possible, but servers can appear in a lab vCenter and the same name in AWS after a migration. Counts are not de-duplicated by name.')
Set-Content -LiteralPath (Join-Path $OutDir ("Inventory-Report{0}.md" -f $(if ($Tag) {"-$Tag"}))) -Value $md -Encoding UTF8

Write-Host ''; Write-Host '=== Totals by category ===' -ForegroundColor Cyan
($summary | Group-Object Category | ForEach-Object { [pscustomobject]@{ Category = $_.Name; Windows = (SumOf ($_.Group) 'Windows'); Linux = (SumOf ($_.Group) 'Linux'); Other = (SumOf ($_.Group) 'Other'); Stopped = (SumOf ($_.Group) 'Stopped') } } | Format-Table -AutoSize | Out-String -Width 200) | Write-Host
if ($notChecked.Count) { Write-Host "NOT CHECKED ($($notChecked.Count)):" -ForegroundColor Yellow; $notChecked | ForEach-Object { Write-Host "  $_" -ForegroundColor Yellow } }
Write-Host "Report : $(Join-Path $OutDir ("Inventory-Report{0}.md" -f $(if ($Tag) {"-$Tag"})))" -ForegroundColor Green
Write-Host "Summary: $(Join-Path $OutDir ("Inventory-Summary{0}.csv" -f $(if ($Tag) {"-$Tag"})))" -ForegroundColor Green
