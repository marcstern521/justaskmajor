<#
.SYNOPSIS  READ-ONLY: find EC2 instances by name fragment, private IP or instance id across SSO profiles and regions.
.EXAMPLE   .\Find-Ec2.ps1 -Query aoa-c62bit01,10.1.2.3 -Profiles ic-prod,ic-dev -Regions us-west-2,us-east-1
           Run aws sso login --profile X first. UNCHECKED rows are NOT "not found".
#>
param(
    [Parameter(Mandatory)][string[]]$Query,
    [string[]]$Profiles = @('ic-prod', 'ic-dev', 'ic-staging', 'ic-test', 'ic-perf', 'ic-ops', 'ic-prod-east3', 'ic-prod-jo1', 'ic-prod-za', 'ic-ops-acaea', 'uk-sov', 'uk-sov2', 'eu-sov-fra', 'eu-sov-ie', 'au-sov'),
    [string[]]$Regions = @(),   # blank = each account's own regions
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ProfileRegions = @{
    'ic-prod' = @('us-west-2','us-east-1'); 'ic-dev' = @('us-west-2','us-east-1'); 'ic-staging' = @('us-west-2','us-east-1'); 'ic-test' = @('us-west-2','us-east-1')
    'ic-perf' = @('us-west-2','us-east-1'); 'ic-ops' = @('us-west-2','us-east-1'); 'ic-prod-east3' = @('us-east-1')
    'ic-prod-jo1' = @('ap-northeast-3'); 'ic-prod-za' = @('af-south-1'); 'ic-ops-acaea' = @('me-central-1')
    'uk-sov' = @('eu-west-2'); 'uk-sov2' = @('eu-west-2'); 'eu-sov-fra' = @('eu-central-1'); 'eu-sov-ie' = @('eu-west-1'); 'au-sov' = @('ap-southeast-2')
}
$ErrorActionPreference = 'Continue'
if (-not (Get-Command aws -ErrorAction SilentlyContinue)) { throw 'aws CLI not found' }
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
$rows = New-Object System.Collections.Generic.List[object]
foreach ($p in $Profiles) {
    $null = (& aws sts get-caller-identity --profile $p --output json 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) { $rows.Add([pscustomobject]@{ Profile = $p; Region = ''; Query = ''; InstanceId = ''; Name = ''; State = ''; Type = ''; PrivateIp = ''; Launched = ''; Status = "UNCHECKED - aws sso login --profile $p" }); Write-Warning "$p not logged in"; continue }
    $regionList = if ($Regions.Count) { $Regions } elseif ($ProfileRegions.ContainsKey($p)) { $ProfileRegions[$p] } else { @((& aws configure get region --profile $p 2>$null)) }
    foreach ($r in $regionList) {
        foreach ($q in $Query) {
            $q = $q.Trim(); if (-not $q) { continue }
            if ($q -match '^i-[0-9a-f]+$') { $flt = @('--instance-ids', $q) }
            elseif ($q -match '^\d{1,3}(\.\d{1,3}){3}$') { $flt = @('--filters', "Name=private-ip-address,Values=$q") }
            else { $flt = @('--filters', "Name=tag:Name,Values=*$q*") }
            $raw = (& aws ec2 describe-instances --profile $p --region $r @flt --output json 2>&1 | Out-String)
            if ($LASTEXITCODE -ne 0) {
                if ($raw -match 'InvalidInstanceID') { continue }
                $rows.Add([pscustomobject]@{ Profile = $p; Region = $r; Query = $q; InstanceId = ''; Name = ''; State = ''; Type = ''; PrivateIp = ''; Launched = ''; Status = "UNCHECKED - $($raw.Trim().Split("`n")[0])" }); continue
            }
            foreach ($res in @(($raw | ConvertFrom-Json).Reservations)) {
                foreach ($i in @($res.Instances)) {
                    $nm = ($i.Tags | Where-Object { $_.Key -eq 'Name' } | Select-Object -First 1).Value
                    $rows.Add([pscustomobject]@{ Profile = $p; Region = $r; Query = $q; InstanceId = $i.InstanceId; Name = $nm; State = $i.State.Name; Type = $i.InstanceType; PrivateIp = $i.PrivateIpAddress; Launched = $i.LaunchTime; Status = 'FOUND' })
                }
            }
        }
    }
}
if (-not @($rows | Where-Object { $_.Status -eq 'FOUND' }).Count) { Write-Host 'No instances matched (see UNCHECKED rows for profiles/regions that could not be searched).' -ForegroundColor Yellow }
$rows | Format-Table -AutoSize -Wrap
$out = Join-Path $OutDir ("Ec2Find_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green
