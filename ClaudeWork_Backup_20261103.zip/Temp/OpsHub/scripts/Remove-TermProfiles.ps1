<#
.SYNOPSIS
  Find (and optionally remove) Windows user profiles of terminated INCMP users on the jump servers.

.DESCRIPTION
  DEFAULT = REPORT ONLY. Looks up each user's SID in AD (works even after the account was moved/disabled),
  then queries Win32_UserProfile on each jump server and lists matching profiles.
  -Remove deletes them via the profile API (folder + registry entry). Supports -WhatIf.
  Skips profiles that are currently loaded (user logged on) and says so.
  Also reports leftover C:\Users\<name>* folders that have no profile entry (orphans); -RemoveOrphans deletes those.

  RUN THIS BEFORE any -DeleteAccount (needs the AD account to resolve the SID).
  Run from cva-indco01 (or any host inside INCMP that can reach the jump servers).

.EXAMPLE
  .\Remove-TermProfiles.ps1 -ApprovedList C:\Temp\approved_incmp.csv
  .\Remove-TermProfiles.ps1 -ApprovedList C:\Temp\approved_incmp.csv -Remove -WhatIf
  .\Remove-TermProfiles.ps1 -ApprovedList C:\Temp\approved_incmp.csv -Remove -Confirm:$false
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)] [string]$ApprovedList,
    [string[]]$Computers = @('cva-injmp01.incmp.com','cva-injmp02.incmp.com','cvb-injmp01.incmp.com','cvb-injmp02.incmp.com'),
    [string]$OutDir = 'C:\Temp\TermCheck',
    [switch]$Remove,
    [switch]$RemoveOrphans,
    [switch]$Size,                 # compute folder sizes (slow on big profiles)
    [pscredential]$Credential
)
$ErrorActionPreference = 'Stop'
Import-Module ActiveDirectory
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -WhatIf:$false | Out-Null }
if (-not (Test-Path -LiteralPath $ApprovedList)) { throw "Approved list not found on THIS machine: $ApprovedList" }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$out = Join-Path $OutDir "Profiles_$stamp.csv"

# --- SIDs ---
$users = @(Import-Csv $ApprovedList | ForEach-Object { "$($_.SamAccountName)".Trim() } | Where-Object { $_ })
$sidMap = @{}
foreach ($u in $users) {
    $a = Get-ADUser -Filter "SamAccountName -eq '$u'" -ErrorAction SilentlyContinue
    if ($a) { $sidMap[$a.SID.Value] = $u } else { Write-Warning "No AD account for $u - cannot resolve SID (will still check for orphan folders)" }
}
Write-Host "Resolved $($sidMap.Count) of $($users.Count) SIDs" -ForegroundColor Cyan

$rows = New-Object System.Collections.Generic.List[object]
foreach ($c in $Computers) {
    $sess = $null
    try {
        $p = @{ ComputerName = $c; ErrorAction = 'Stop' }; if ($Credential) { $p.Credential = $Credential }
        $sess = New-CimSession @p
        $profiles = @(Get-CimInstance -CimSession $sess -ClassName Win32_UserProfile | Where-Object { $sidMap.ContainsKey($_.SID) })
    } catch {
        Write-Warning "$c UNREACHABLE: $($_.Exception.Message)"
        $rows.Add([pscustomobject]@{ Computer = $c; User = ''; Path = ''; LastUse = ''; Loaded = ''; SizeMB = ''; Action = 'UNREACHABLE' })
        continue
    }
    foreach ($pr in $profiles) {
        $sz = ''
        if ($Size) {
            $unc = "\\$c\" + ($pr.LocalPath -replace '^([A-Za-z]):', '$1$')
            try { $sz = [math]::Round((Get-ChildItem -LiteralPath $unc -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1MB, 1) } catch {}
        }
        $action = 'FOUND (report only)'
        if ($pr.Loaded) { $action = 'SKIPPED - profile loaded (user logged on?)' }
        elseif ($Remove) {
            if ($PSCmdlet.ShouldProcess("$c : $($sidMap[$pr.SID]) ($($pr.LocalPath))", 'Remove user profile')) {
                try { Remove-CimInstance -InputObject $pr -CimSession $sess; $action = 'REMOVED' } catch { $action = "FAILED: $($_.Exception.Message)" }
            } else { $action = 'WhatIf' }
        }
        $rows.Add([pscustomobject]@{ Computer = $c; User = $sidMap[$pr.SID]; Path = $pr.LocalPath; LastUse = $pr.LastUseTime; Loaded = $pr.Loaded; SizeMB = $sz; Action = $action })
    }
    # orphan folders (folder exists, no profile entry)
    foreach ($u in $users) {
        $has = $profiles | Where-Object { $sidMap[$_.SID] -eq $u }
        if ($has) { continue }
        $dirs = @(Get-ChildItem "\\$c\c$\Users" -Directory -Force -Filter "$u*" -ErrorAction SilentlyContinue)
        foreach ($d in $dirs) {
            $action = 'ORPHAN FOLDER (no profile entry)'
            if ($RemoveOrphans -and $PSCmdlet.ShouldProcess("$c : $($d.FullName)", 'Delete orphan profile folder')) {
                try { Remove-Item -LiteralPath $d.FullName -Recurse -Force; $action = 'ORPHAN REMOVED' } catch { $action = "ORPHAN FAILED: $($_.Exception.Message)" }
            }
            $rows.Add([pscustomobject]@{ Computer = $c; User = $u; Path = $d.FullName; LastUse = $d.LastWriteTime; Loaded = ''; SizeMB = ''; Action = $action })
        }
    }
    if ($sess) { Remove-CimSession $sess }
}
$rows | Export-Csv $out -NoTypeInformation -WhatIf:$false
if ($rows.Count) { $rows | Format-Table -AutoSize -Wrap } else { Write-Host 'No profiles or orphan folders found on any server.' -ForegroundColor Green }
Write-Host "`nReport: $out" -ForegroundColor Green
$rows | Group-Object Action | Select-Object Count, Name | Format-Table -AutoSize
