<#
.SYNOPSIS
  For already-DISABLED terminated accounts: remove group memberships and move to the Terminated OU.
  Works from the Candidates_*.csv that Check-TermUsers.ps1 wrote (use the one you reviewed).

.DESCRIPTION
  - Acts only on rows where Domain = -DomainLabel AND Enabled = False. Enabled accounts are SKIPPED (never disabled here).
  - Logs every group removed (DN) to a CSV so memberships can be restored if needed.
  - Supports -WhatIf. Edit the Candidates CSV first to delete any row you do not want touched.

.EXAMPLE
  .\Move-TermAccounts.ps1 -CandidatesCsv C:\Temp\TermCheck\Candidates_20261008_103301.csv -DomainLabel inucn `
      -Server 10.244.88.62 -Credential $cred -TerminatedOuDN 'OU=TerminatedUsers,DC=inucn,DC=com' -WhatIf
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)] [string]$CandidatesCsv,
    [Parameter(Mandatory)] [string]$DomainLabel,      # value of the 'Domain' column: inucn | in.lab
    [Parameter(Mandatory)] [string]$Server,           # DC IP or FQDN
    [Parameter(Mandatory)] [string]$TerminatedOuDN,
    [pscredential]$Credential,
    [string]$Ticket = 'SCTASK0156751',
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Stop'
Import-Module ActiveDirectory
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -WhatIf:$false | Out-Null }
if (-not (Test-Path -LiteralPath $CandidatesCsv)) { throw "Not found on THIS machine: $CandidatesCsv" }
$base = @{ Server = $Server }; if ($Credential) { $base.Credential = $Credential }

$target = Get-ADObject @base -Identity $TerminatedOuDN
Write-Host "Target OU: $($target.DistinguishedName)" -ForegroundColor Cyan

$rows = @(Import-Csv $CandidatesCsv | Where-Object { $_.Domain -eq $DomainLabel })
Write-Host "$($rows.Count) candidate rows for $DomainLabel" -ForegroundColor Cyan
$log = New-Object System.Collections.Generic.List[object]

foreach ($r in $rows) {
    $sam = $r.SamAccountName
    if ("$($r.Enabled)" -ne 'False') {
        $log.Add([pscustomobject]@{ User = $sam; Result = 'SKIPPED'; Detail = 'account is ENABLED - not touched'; GroupsRemoved = '' }); continue
    }
    try {
        $u = Get-ADUser @base -Filter "SamAccountName -eq '$sam'" -Properties MemberOf, Description
        if (-not $u) { $log.Add([pscustomobject]@{ User = $sam; Result = 'SKIPPED'; Detail = 'not found'; GroupsRemoved = '' }); continue }
        if ($u.Enabled) { $log.Add([pscustomobject]@{ User = $sam; Result = 'SKIPPED'; Detail = 'now ENABLED - not touched'; GroupsRemoved = '' }); continue }
        if ($u.DistinguishedName -like "*,$TerminatedOuDN") { $log.Add([pscustomobject]@{ User = $sam; Result = 'SKIPPED'; Detail = 'already in target OU'; GroupsRemoved = '' }); continue }

        $groups = @($u.MemberOf)
        foreach ($g in $groups) {
            if ($PSCmdlet.ShouldProcess($sam, "Remove from group $g")) {
                Remove-ADGroupMember @base -Identity $g -Members $u.DistinguishedName -Confirm:$false
            }
        }
        $desc = ("$($u.Description) | TERM $Ticket $(Get-Date -f yyyy-MM-dd)").Trim(' |')
        if ($PSCmdlet.ShouldProcess($sam, 'Update description')) { Set-ADUser @base -Identity $u.DistinguishedName -Description $desc }
        if ($PSCmdlet.ShouldProcess($sam, "Move to $TerminatedOuDN")) { Move-ADObject @base -Identity $u.DistinguishedName -TargetPath $TerminatedOuDN }
        $log.Add([pscustomobject]@{ User = $sam; Result = 'OK'; Detail = "from $($u.DistinguishedName)"; GroupsRemoved = ($groups -join ' ; ') })
    } catch {
        $log.Add([pscustomobject]@{ User = $sam; Result = 'FAILED'; Detail = $_.Exception.Message; GroupsRemoved = '' })
        Write-Warning "$sam : $($_.Exception.Message)"
    }
}
$out = Join-Path $OutDir ("MoveTerm_{0}_{1}.csv" -f $DomainLabel, (Get-Date -Format 'yyyyMMdd_HHmmss'))
$log | Export-Csv $out -NoTypeInformation -WhatIf:$false
$log | Group-Object Result | Select-Object Count, Name | Format-Table -AutoSize
Write-Host "Log (includes groups removed, for restore): $out" -ForegroundColor Green
