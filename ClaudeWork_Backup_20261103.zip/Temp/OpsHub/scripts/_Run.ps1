﻿# Ops Hub runner: runs one tool script in this console with a transcript + status file. Not meant to be run by hand.
param([Parameter(Mandatory)][string]$RunFile)
$ErrorActionPreference = 'Stop'
# Fix: a Windows PowerShell 5.1 window started from PowerShell 7 inherits PS7's PSModulePath, so built-in modules
# (Microsoft.PowerShell.Security etc.) fail to load. Rebuild the module path for 5.1 only.
if ($PSVersionTable.PSEdition -eq 'Desktop') {
    $keep = @($env:PSModulePath -split ';' | Where-Object { $_ -and $_ -notmatch '\\PowerShell\\7' -and $_ -notmatch '\\WindowsApps\\' })
    $sys = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\Modules'
    $usr = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'WindowsPowerShell\Modules'
    $env:PSModulePath = (@($usr, "$env:ProgramFiles\WindowsPowerShell\Modules", $sys) + $keep | Select-Object -Unique) -join ';'
    foreach ($m in 'Microsoft.PowerShell.Management','Microsoft.PowerShell.Utility','Microsoft.PowerShell.Security') { try { Import-Module $m -ErrorAction Stop } catch {} }
}
$spec = Get-Content -LiteralPath $RunFile -Raw | ConvertFrom-Json
$statusFile = [IO.Path]::ChangeExtension($RunFile, '.status.json')
function Set-State([string]$state, [string]$detail = '') {
    [pscustomobject]@{ state = $state; detail = $detail; started = $script:started; finished = $(if ($state -eq 'running') { '' } else { (Get-Date).ToString('s') }) } |
        ConvertTo-Json | Set-Content -LiteralPath $statusFile -Encoding UTF8
}
$script:started = (Get-Date).ToString('s')
# Credential prompts in THIS console (Windows PowerShell 5.1 Get-Credential pops a GUI that often hides behind other windows).
# Optional: a login can be saved on THIS PC. It is encrypted with Windows DPAPI (Export-Clixml), so only your Windows
# account on this machine can read it. To forget all saved logins, delete the folder %LOCALAPPDATA%\OpsHub\creds
function global:Get-Credential {
    param([string]$Message, [string]$UserName, [pscredential]$Credential)
    if ($Credential) { return $Credential }
    $dir = Join-Path $env:LOCALAPPDATA 'OpsHub\creds'
    $key = ($Message -replace '[^A-Za-z0-9.]+', '_').Trim('_'); if ($key.Length -gt 60) { $key = $key.Substring(0, 60) }
    $file = if ($key) { Join-Path $dir "$key.xml" } else { $null }
    if ($file -and (Test-Path $file)) {
        try {
            $saved = Import-Clixml -LiteralPath $file
            Write-Host ">> Using saved login $($saved.UserName)  (to forget it, delete $file)" -ForegroundColor Green
            return $saved
        } catch { Write-Host ">> Saved login could not be read, asking again." -ForegroundColor DarkYellow }
    }
    if ($Message) { Write-Host ">> $Message" -ForegroundColor Yellow }
    Write-Host '   (leave username blank to skip)' -ForegroundColor DarkGray
    $u = Read-Host '   Username (DOMAIN\user)'
    if ([string]::IsNullOrWhiteSpace($u)) { return $null }
    $pw = Read-Host '   Password' -AsSecureString
    $cred = New-Object System.Management.Automation.PSCredential($u, $pw)
    if ($file) {
        $save = Read-Host '   Save this login on this PC for next time? Encrypted for your Windows account only. [y/N]'
        if ($save -match '^(y|yes)$') {
            try {
                if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
                $cred | Export-Clixml -LiteralPath $file
                Write-Host "   Saved. Delete $file to forget it." -ForegroundColor Green
            } catch { Write-Host "   Could not save: $($_.Exception.Message)" -ForegroundColor Red }
        }
    }
    $cred
}
$splat = @{}
foreach ($p in $spec.args.PSObject.Properties) { $v = $p.Value; if ($v -is [System.Array]) { $v = @($v) }; $splat[$p.Name] = $v }
try { Start-Transcript -LiteralPath $spec.log -Force | Out-Null } catch {}
$Host.UI.RawUI.WindowTitle = "Ops Hub - $($spec.tool)"
Write-Host "=== Ops Hub run $($spec.id): $($spec.tool)  ticket/change: $($spec.ref) ===" -ForegroundColor Cyan
Write-Host ("Script: {0}`nArgs:   {1}`n" -f $spec.script, (($splat.GetEnumerator() | ForEach-Object { "-$($_.Key) $($_.Value -join ',')" }) -join ' '))
Set-State 'running'
try {
    & $spec.script @splat
    Set-State 'done'
    Write-Host "`n=== finished OK. You can close this window. ===" -ForegroundColor Green
} catch {
    Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red
    Set-State 'failed' $_.Exception.Message
} finally { try { Stop-Transcript | Out-Null } catch {} }