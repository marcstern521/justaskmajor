<#
.SYNOPSIS
  Health summary for several iLOs with ONE login prompt. READ-ONLY.
  Stops at the first login failure so a wrong password can't lock the account on every iLO.
.EXAMPLE
  .\Get-IloBatch.ps1
  .\Get-IloBatch.ps1 -Ilos 172.23.12.118,172.23.12.119
#>
param(
    [string[]]$Ilos = @('172.21.11.129','172.23.5.23','172.23.5.24','172.23.5.20','172.23.5.21','172.23.5.22','172.23.12.118','172.23.12.119'),
    [pscredential]$Credential,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
if (-not $Credential) { $Credential = Get-Credential -Message "iLO login for batch ($($Ilos.Count) hosts)" }
if (-not $Credential) { Write-Warning 'No login given.'; return }
$one = Join-Path $PSScriptRoot 'Get-HpeAhsLog.ps1'
$rows = New-Object System.Collections.Generic.List[object]
foreach ($ip in $Ilos) {
    Write-Host ">> $ip" -ForegroundColor Cyan
    $before = Get-Date
    try {
        & $one -Ilo $ip -Mode Info -Credential $Credential -OutDir $OutDir *>$null
        $safe = $ip -replace '[^\w\.-]', '_'
        $f = Get-ChildItem $OutDir -Filter "iLO_Info_${safe}_*.csv" | Where-Object LastWriteTime -ge $before | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $d = Import-Csv $f.FullName
        $rows.Add([pscustomobject]@{ iLO = $ip; Model = $d.Model; Serial = $d.Serial; Power = $d.Power; Health = $d.Health; Mem = $d.MemHealth; CPU = $d.CpuHealth; BIOS = $d.BIOS; Result = 'OK' })
    } catch {
        $m = $_.Exception.Message.Split("`n")[0].Trim()
        $rows.Add([pscustomobject]@{ iLO = $ip; Model = ''; Serial = ''; Power = ''; Health = ''; Mem = ''; CPU = ''; BIOS = ''; Result = "FAILED - $m" })
        Write-Warning "$ip : $m"
        if ($m -match '401|Unauthorized|credential|login') { Write-Warning 'Login problem: stopping so the account is not locked out. Remaining hosts not tried.'; break }
    }
}
$rows | Format-Table -AutoSize | Out-String -Width 250 | Write-Host
$out = Join-Path $OutDir ("iLO_Batch_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green
$bad = @($rows | Where-Object { $_.Result -ne 'OK' -or $_.Health -ne 'OK' -or $_.Mem -ne 'OK' -or $_.CPU -ne 'OK' }).Count
if ($bad) { Write-Host "$bad iLO(s) need a look (failed or not OK)." -ForegroundColor Yellow } else { Write-Host 'All iLOs report OK.' -ForegroundColor Green }