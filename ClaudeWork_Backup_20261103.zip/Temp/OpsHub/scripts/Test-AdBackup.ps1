<#
.SYNOPSIS  READ-ONLY: last AD backup time per domain controller (repadmin /showbackup). Covers the weekly
           "AD Backup Validation" review tickets (INUCN / FedRAMP / AU Sov).
.EXAMPLE   .\Test-AdBackup.ps1 -DomainControllers dal-indco01.inucn.com,lax-indco01.inucn.com -MaxAgeDays 7
.NOTES     Needs rights to query the DC. If a DC shows PARSE?, the raw repadmin text is printed so the parser can be adjusted.
#>
param(
    [Parameter(Mandatory)][string[]]$DomainControllers,
    [int]$MaxAgeDays = 7,
    [switch]$UseCurrentLogon,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Continue'
if (-not (Get-Command repadmin -ErrorAction SilentlyContinue)) { throw 'repadmin not found (install RSAT AD DS tools).' }
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
$rows = New-Object System.Collections.Generic.List[object]
$authArgs = @()
if (-not $UseCurrentLogon) {
    $u = Read-Host 'Username for the DCs (e.g. INUCN\marc.stern; blank = use my current Windows logon)'
    if (-not [string]::IsNullOrWhiteSpace($u)) { $authArgs = @("/u:$u", '/pw:*') }   # repadmin asks for the password itself
}
foreach ($dc in $DomainControllers) {
    $raw = (& repadmin /showbackup $dc @authArgs 2>&1 | Out-String)
    $nc = ''; $found = $false
    foreach ($line in ($raw -split "\r?\n")) {
        if ($line -match '^\s*((DC|CN)=[^\s]+)\s*$') { $nc = $Matches[1]; continue }
        if ($nc -and $line -match '(?i)backup') {
            $d = [datetime]::MinValue
            $m = [regex]::Match($line, '\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}|\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}:\d{2}(\s*[AP]M)?')
            if ($m.Success -and [datetime]::TryParse($m.Value, [Globalization.CultureInfo]::InvariantCulture, 'None', [ref]$d)) {
                $age = [math]::Round(((Get-Date) - $d).TotalDays, 1); $found = $true
                $st = 'OK'; if ($age -gt $MaxAgeDays) { $st = 'STALE' }
                $rows.Add([pscustomobject]@{ DC = $dc; NamingContext = $nc; LastBackup = $d.ToString('s'); AgeDays = $age; Status = $st })
            }
        }
    }
    if (-not $found) {
        $rows.Add([pscustomobject]@{ DC = $dc; NamingContext = ''; LastBackup = ''; AgeDays = ''; Status = 'PARSE? / no backup info' })
        Write-Host "---- raw repadmin output for $dc ----" -ForegroundColor Yellow; Write-Host $raw
    }
}
$rows | Format-Table -AutoSize
$out = Join-Path $OutDir ("AdBackup_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green