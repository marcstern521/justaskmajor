<#
.SYNOPSIS
    Combines the Inventory-Summary*.csv files into one AWS vs VMware table (Windows / Linux side by side).
    Read-only: only reads CSVs. Output: Inventory-AwsVsVmware.md and .csv in the same folder.
.PARAMETER Path   Folder (searched for Inventory-Summary*.csv) or specific CSV files. Default: newest date folder under C:\Temp\Inventory.
.EXAMPLE  .\Get-InventoryCompare.ps1
.EXAMPLE  .\Get-InventoryCompare.ps1 -Path C:\Temp\Inventory\20261021, D:\from-jumpbox\Inventory-Summary-fedcul.csv
#>
param([string[]]$Path, [string]$OutDir)
$root = if ($env:OS -eq 'Windows_NT') { 'C:\Temp\Inventory' } else { Join-Path ([IO.Path]::GetTempPath()) 'Inventory' }
if (-not $Path) { $Path = @((Get-ChildItem -LiteralPath $root -Directory | Sort-Object Name -Descending | Select-Object -First 1).FullName) }
$files = foreach ($p in $Path) { if (Test-Path -LiteralPath $p -PathType Container) { Get-ChildItem -LiteralPath $p -Filter 'Inventory-Summary*.csv' } else { Get-Item -LiteralPath $p } }
if (-not $files) { throw "No Inventory-Summary*.csv found in: $($Path -join ', ')" }
if (-not $OutDir) { $OutDir = Split-Path -Parent @($files)[0].FullName }
Write-Host "Reading $(@($files).Count) file(s):" -ForegroundColor Cyan; $files | ForEach-Object { Write-Host "  $($_.FullName)" }
$rows = foreach ($f in $files) { Import-Csv -LiteralPath $f.FullName }
$order = @('Prod', 'FedRAMP', 'Sov UK', 'Sov EU', 'Sov AU', 'Lab')
function S($r, $src, $prop) { $t = 0; foreach ($x in @($r | Where-Object { $_.Source -eq $src })) { $t += [int]$x.$prop }; $t }
function Line($name, $r) {
    $aw = S $r 'AWS' 'Windows'; $al = S $r 'AWS' 'Linux'; $vw = S $r 'VMware' 'Windows'; $vl = S $r 'VMware' 'Linux'
    [pscustomobject]@{ Group = $name; AWS_Windows = $aw; AWS_Linux = $al; VMware_Windows = $vw; VMware_Linux = $vl; Total_Windows = $aw + $vw; Total_Linux = $al + $vl; Stopped = (S $r 'AWS' 'Stopped') + (S $r 'VMware' 'Stopped'); Other_VMware = (S $r 'VMware' 'Other') }
}
$cats = @($order) + @($rows.Category | Select-Object -Unique | Where-Object { $order -notcontains $_ })
$catLines = foreach ($c in $cats) { $r = @($rows | Where-Object { $_.Category -eq $c }); if ($r.Count) { Line $c $r } }
$total = Line 'ALL' $rows
$detail = foreach ($c in $cats) { foreach ($g in (@($rows | Where-Object { $_.Category -eq $c }) | Group-Object { if ($_.Source -eq 'AWS') { $_.Scope } else { $_.Scope } })) { $l = Line "$c | $($g.Name)" $g.Group; $l } }
$all = @($catLines) + @($total)
$all | Export-Csv -LiteralPath (Join-Path $OutDir 'Inventory-AwsVsVmware.csv') -NoTypeInformation
$md = @('# Server counts: AWS vs VMware (running / powered on)', '', "Built $(Get-Date -Format 'yyyy-MM-dd HH:mm') from $(@($files).Count) file(s).", '',
    '| Environment | AWS Win | AWS Linux | VMware Win | VMware Linux | Total Win | Total Linux | Stopped |', '|---|--:|--:|--:|--:|--:|--:|--:|')
foreach ($l in $all) { $n = if ($l.Group -eq 'ALL') { '**TOTAL**' } else { $l.Group }; $md += "| $n | $($l.AWS_Windows) | $($l.AWS_Linux) | $($l.VMware_Windows) | $($l.VMware_Linux) | $($l.Total_Windows) | $($l.Total_Linux) | $($l.Stopped) |" }
$md += ''; $md += '## By account / site'; $md += ''
$md += '| Environment | Account / site | AWS Win | AWS Linux | VMware Win | VMware Linux |'; $md += '|---|---|--:|--:|--:|--:|'
foreach ($c in $cats) { foreach ($g in (@($rows | Where-Object { $_.Category -eq $c }) | Group-Object Scope | Sort-Object Name)) { $l = Line $g.Name $g.Group; $md += "| $c | $($g.Name) | $($l.AWS_Windows) | $($l.AWS_Linux) | $($l.VMware_Windows) | $($l.VMware_Linux) |" } }
if (($all | Measure-Object Other_VMware -Sum).Sum -gt 0) { $md += ''; $md += "VMware 'Other' (appliances / unrecognised guests), not in Windows or Linux: $(($all | Where-Object Group -eq 'ALL').Other_VMware)" }
$md += ''; $md += 'A category with 0 for VMware (or AWS) usually means that source was not run yet, not that it has none.'
Set-Content -LiteralPath (Join-Path $OutDir 'Inventory-AwsVsVmware.md') -Value $md -Encoding UTF8
$all | Format-Table Group, AWS_Windows, AWS_Linux, VMware_Windows, VMware_Linux, Total_Windows, Total_Linux, Stopped -AutoSize | Out-String -Width 200 | Write-Host
Write-Host "Saved: $(Join-Path $OutDir 'Inventory-AwsVsVmware.md')" -ForegroundColor Green
