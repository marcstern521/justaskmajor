<#
.SYNOPSIS
  Check, and optionally recreate, the FS_DiskUsed scheduled task on one or more COR servers.

.DESCRIPTION
  Default = DRY RUN (read only). Shows task state, last result, run-as user, and whether
  D:\Proj\FS_DiskUsed\FS_DiskUsed.exe exists. Nothing is changed.
  With -Apply: backs up the current task XML, deletes the task, recreates it from FS_DiskUsed.xml,
  and (with -RunNow) starts it and reports the result.

  Run it ON the server (RDP) or from a peer box with -ComputerName (WinRM).
  The task runs as a service/user account with a password. By default it reuses the account
  the existing task already uses and asks you for that password. The account in the XML file
  (a person's SID) is NOT reused.

.EXAMPLE
  .\Repair-FsDiskUsedTask.ps1                       # local, dry run
  .\Repair-FsDiskUsedTask.ps1 -Apply -RunNow        # local, fix it
  .\Repair-FsDiskUsedTask.ps1 -ComputerName AOB-C30COR01,AOB-C29COR01          # check two hosts
  .\Repair-FsDiskUsedTask.ps1 -ComputerName AOB-C30COR01 -Apply -RunNow
#>
[CmdletBinding()]
param(
  [string[]]$ComputerName,
  [string]$TaskXml = 'C:\Temp\OpsHub\data\FS_DiskUsed.xml',
  [string]$TaskName = 'FS_DiskUsed',
  [string]$RunAsUser,
  [pscredential]$Credential,
  [string]$BackupDir = 'C:\Temp\FS_DiskUsed-backup',
  [switch]$Apply,
  [switch]$RunNow
)

if (-not (Test-Path $TaskXml)) { throw "Task XML not found: $TaskXml (use -TaskXml)" }
$xmlText = Get-Content -Path $TaskXml -Raw
if (-not (Test-Path $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null }

# ---- runs on the target (local or remote) ----
$block = {
  param($xmlText, $taskName, $runAsUser, $plainPw, $apply, $runNow)
  $out = [ordered]@{ Host = $env:COMPUTERNAME; Exists = $false; State = ''; RunAs = ''; LastRun = ''; LastResult = ''
                     ExePresent = $false; Action = 'none'; Note = ''; BackupXml = '' }
  $out.ExePresent = Test-Path 'D:\Proj\FS_DiskUsed\FS_DiskUsed.exe'

  $t = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if ($t) {
    $info = Get-ScheduledTaskInfo -TaskName $taskName
    $out.Exists = $true; $out.State = [string]$t.State; $out.RunAs = $t.Principal.UserId
    $out.LastRun = [string]$info.LastRunTime; $out.LastResult = [string]$info.LastTaskResult
  }

  if (-not $apply) { $out.Action = 'dry-run'; return [pscustomobject]$out }

  if (-not $out.ExePresent) { $out.Action = 'skipped'; $out.Note = 'D:\Proj\FS_DiskUsed\FS_DiskUsed.exe missing - not touching the task'; return [pscustomobject]$out }
  $user = if ($runAsUser) { $runAsUser } elseif ($out.RunAs) { $out.RunAs } else { $null }
  if (-not $user -or -not $plainPw) { $out.Action = 'skipped'; $out.Note = 'No run-as user/password available'; return [pscustomobject]$out }

  if ($t) { $out.BackupXml = (Export-ScheduledTask -TaskName $taskName) }
  try {
    if ($t) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop }
    Register-ScheduledTask -TaskName $taskName -Xml $xmlText -User $user -Password $plainPw -ErrorAction Stop | Out-Null
    $out.Action = 'recreated'
    if ($runNow) {
      Start-ScheduledTask -TaskName $taskName
      Start-Sleep -Seconds 20
      $i = Get-ScheduledTaskInfo -TaskName $taskName
      $out.State = [string](Get-ScheduledTask -TaskName $taskName).State
      $out.LastRun = [string]$i.LastRunTime; $out.LastResult = [string]$i.LastTaskResult
      $out.Note = 'Started. Result 267009 = still running (normal for a long job), 0 = ok'
    }
  } catch {
    $out.Action = 'FAILED'; $out.Note = $_.Exception.Message
    if ($out.BackupXml -and -not (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue)) {
      $out.Note += ' | task was deleted - restore with the backup XML'
    }
  }
  [pscustomobject]$out
}

# ---- password only if we are changing something ----
$pw = $null
if ($Apply) {
  if (-not $Credential) { $Credential = Get-Credential -Message 'Run-as account + password for the FS_DiskUsed task' -UserName $RunAsUser }
  $RunAsUser = $Credential.UserName
  $pw = $Credential.GetNetworkCredential().Password
}

$targets = if ($ComputerName) { $ComputerName } else { @($null) }
$results = foreach ($c in $targets) {
  try {
    if ($c) { Invoke-Command -ComputerName $c -ScriptBlock $block -ArgumentList $xmlText,$TaskName,$RunAsUser,$pw,[bool]$Apply,[bool]$RunNow -ErrorAction Stop }
    else    { & $block $xmlText $TaskName $RunAsUser $pw ([bool]$Apply) ([bool]$RunNow) }
  } catch {
    [pscustomobject]@{ Host = $c; Action = 'FAILED'; Note = $_.Exception.Message }
  }
}

# save backups locally, then show the summary
foreach ($r in $results) {
  if ($r.BackupXml) {
    $f = Join-Path $BackupDir ("{0}-{1:yyyyMMdd-HHmmss}.xml" -f $r.Host, (Get-Date))
    $r.BackupXml | Out-File -FilePath $f -Encoding unicode
    Write-Host "Backup saved: $f" -ForegroundColor DarkGray
  }
}
$results | Select-Object Host,Exists,State,RunAs,LastRun,LastResult,ExePresent,Action,Note | Format-Table -AutoSize -Wrap
if (-not $Apply) { Write-Host 'Dry run only. Add -Apply to delete and recreate the task.' -ForegroundColor Yellow }
