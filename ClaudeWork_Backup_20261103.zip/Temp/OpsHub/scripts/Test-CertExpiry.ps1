<#
.SYNOPSIS  READ-ONLY: connect to host:port list over TLS and report certificate expiry. For SSL-expiry review tickets.
.EXAMPLE   .\Test-CertExpiry.ps1 -Targets www.example.com,lax-infra01.inucn.com:8443 -WarnDays 45
#>
param(
    [Parameter(Mandatory)][string[]]$Targets,
    [int]$WarnDays = 45,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Continue'
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
$rows = foreach ($t in $Targets) {
    $t = $t.Trim(); if (-not $t) { continue }
    $h = $t; $port = 443; if ($t -match '^(.+):(\d+)$') { $h = $Matches[1]; $port = [int]$Matches[2] }
    $r = [ordered]@{ Target = "${h}:$port"; Subject = ''; Issuer = ''; NotAfter = ''; DaysLeft = ''; SANs = ''; Status = '' }
    $tcp = New-Object Net.Sockets.TcpClient
    try {
        $ar = $tcp.BeginConnect($h, $port, $null, $null)
        if (-not $ar.AsyncWaitHandle.WaitOne(5000)) { throw 'connect timeout' }
        $tcp.EndConnect($ar)
        $ssl = New-Object Net.Security.SslStream($tcp.GetStream(), $false, ([Net.Security.RemoteCertificateValidationCallback]{ $true }))
        $ssl.AuthenticateAsClient($h)
        $c = New-Object Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
        $days = [math]::Floor(($c.NotAfter - (Get-Date)).TotalDays)
        $san = ''; $ext = $c.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.17' } | Select-Object -First 1
        if ($ext) { $san = ($ext.Format($false) -replace 'DNS Name=', '') }
        $r.Subject = $c.Subject; $r.Issuer = $c.Issuer; $r.NotAfter = $c.NotAfter.ToString('yyyy-MM-dd'); $r.DaysLeft = $days; $r.SANs = $san
        if ($days -lt 0) { $r.Status = 'EXPIRED' } elseif ($days -le $WarnDays) { $r.Status = 'EXPIRING' } else { $r.Status = 'OK' }
        $ssl.Dispose()
    } catch { $r.Status = "UNREACHABLE: $($_.Exception.Message.Split("`n")[0])" }
    finally { $tcp.Close() }
    [pscustomobject]$r
}
$rows | Sort-Object { if ($_.DaysLeft -is [int] -or $_.DaysLeft -is [long]) { $_.DaysLeft } else { -9999 } } | Format-Table Target, NotAfter, DaysLeft, Status, Subject -AutoSize
$out = Join-Path $OutDir ("Certs_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green
