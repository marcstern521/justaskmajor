<#
.SYNOPSIS
    READ-ONLY Windows/Linux VM counts per datacenter from one vCenter, no PowerCLI needed (vSphere REST API, vCenter 7+).
    Writes Inventory-Summary-<Tag>.csv (same format as Get-ServerInventory.ps1) for Get-InventoryCompare.ps1.
.EXAMPLE
    .\Get-VcenterCountsRest.ps1 -VCenter cul-vmvce01.incmp.com -Category FedRAMP -Label 'FedRAMP' -Tag fedramp
#>
param([Parameter(Mandatory)][string]$VCenter, [string]$Category = 'FedRAMP', [string]$Label, [string]$Tag = 'rest', [pscredential]$Credential, [string]$OutDir)
if (-not $Label) { $Label = $VCenter }
if (-not $Credential) { $Credential = Get-Credential -Message "vCenter login for $VCenter" }
if (-not $OutDir) { $OutDir = Join-Path 'C:\Temp\Inventory' (Get-Date -Format 'yyyyMMdd') }
if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }
$ps7 = $PSVersionTable.PSVersion.Major -ge 7
if (-not $ps7) {
    Add-Type 'using System.Net;using System.Security.Cryptography.X509Certificates;public class TrustAll3:ICertificatePolicy{public bool CheckValidationResult(ServicePoint s,X509Certificate c,WebRequest r,int p){return true;}}'
    [Net.ServicePointManager]::CertificatePolicy = New-Object TrustAll3
    [Net.ServicePointManager]::SecurityProtocol = 'Tls12'
}
$base = "https://$VCenter"
$skip = @{}; if ($ps7) { $skip.SkipCertificateCheck = $true }
$pair = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($Credential.UserName):$($Credential.GetNetworkCredential().Password)"))
$tok = Invoke-RestMethod -Method Post -Uri "$base/api/session" -Headers @{ Authorization = "Basic $pair" } @skip
$h = @{ 'vmware-api-session-id' = $tok }
$rows = @()
try {
    $dcs = @(Invoke-RestMethod -Uri "$base/api/vcenter/datacenter" -Headers $h @skip)
    foreach ($dc in $dcs) {
        $vms = Invoke-RestMethod -Uri "$base/api/vcenter/vm?datacenters=$($dc.datacenter)" -Headers $h @skip
        $n = ($vms | Measure-Object).Count
        Write-Host "$($dc.name): $n VMs, reading guest OS..." -ForegroundColor Cyan
        $w = 0; $l = 0; $o = 0; $x = 0; $i = 0
        foreach ($v in $vms) {
            $i++; if ($i % 100 -eq 0) { Write-Host "  $i / $n" -ForegroundColor DarkGray }
            if ($v.power_state -ne 'POWERED_ON') { $x++; continue }
            $g = ''; try { $g = (Invoke-RestMethod -Uri "$base/api/vcenter/vm/$($v.vm)" -Headers $h @skip).guest_OS } catch {}
            if ($g -match 'WINDOWS') { $w++ } elseif ($g -match 'RHEL|CENTOS|UBUNTU|SLES|SUSE|ORACLE|DEBIAN|AMAZON|ROCKY|ALMA|PHOTON|LINUX') { $l++ } else { $o++ }
        }
        $rows += [pscustomobject]@{ Category = $Category; Source = 'VMware'; Scope = "$Label [$VCenter]"; Region = $dc.name; Windows = $w; Linux = $l; Other = $o; Stopped = $x; Total = $w + $l + $o + $x }
    }
} finally { try { Invoke-RestMethod -Method Delete -Uri "$base/api/session" -Headers $h @skip | Out-Null } catch {} }
$f = Join-Path $OutDir "Inventory-Summary-$Tag.csv"
$rows | Export-Csv -LiteralPath $f -NoTypeInformation
$rows | Format-Table -AutoSize | Out-String | Write-Host
Write-Host "Saved $f" -ForegroundColor Green
