<#
.SYNOPSIS
  READ-ONLY monthly Okta inactive-user review (Standard + Gov). Changes nothing in Okta.

.DESCRIPTION
  Pulls all ACTIVE users, works out days since last login, and buckets them using the draft
  Account Security Thresholds Standard (Okta standard user: 30 disable / 90 permissions / 180 delete):
     Never logged in (created more than 30 days ago)
     30-89 days   -> disable candidates
     90-179 days  -> remove-permissions candidates
     180+ days    -> delete candidates
  Also flags AD-backed users (provider ACTIVE_DIRECTORY), because deactivating those flows to AD.
  Needs an Okta API token with READ-ONLY admin rights. The token is only typed into the prompt,
  held in memory, and never saved.

  Output: C:\Temp\OktaReview\<date>\Okta-Inactive-<org>.csv and Okta-Inactive-Summary.md

.EXAMPLE
  .\Get-OktaInactiveUsers.ps1                      # both orgs, prompts for each token
  .\Get-OktaInactiveUsers.ps1 -Org gov -Days 30
  .\Get-OktaInactiveUsers.ps1 -ExcludeLike 'svc-*','break*'

  Tip: Okta rate-limit warnings were seen on nicecxone-gov, so run this off-peak. The script backs off on 429s.
#>
[CmdletBinding()]
param(
  [ValidateSet('standard', 'gov', 'both')][string]$Org = 'both',
  [int]$Days = 30,
  [string[]]$ExcludeLike = @('svc*', 'service*', 'srv*', 'break*glass*'),
  [string]$OutRoot = 'C:\Temp\OktaReview'
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$orgs = @{ standard = 'https://nicecxone.okta.com'; gov = 'https://nicecxone-gov.okta.com' }
$run = if ($Org -eq 'both') { 'standard', 'gov' } else { , $Org }
$outDir = Join-Path $OutRoot (Get-Date -Format 'yyyyMMdd'); New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$now = Get-Date; $summary = @()

function Get-OktaPages($url, $hdr) {
  while ($url) {
    try { $r = Invoke-WebRequest -Uri $url -Headers $hdr -UseBasicParsing -TimeoutSec 120 }
    catch {
      $resp = $_.Exception.Response
      if ($resp -and [int]$resp.StatusCode -eq 429) {
        $reset = 0; try { $reset = [int]$resp.Headers['X-Rate-Limit-Reset'] } catch {}
        $wait = if ($reset) { [Math]::Max(5, $reset - [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds() + 2) } else { 30 }
        Write-Host "  rate limited, waiting $wait s..." -ForegroundColor Yellow; Start-Sleep -Seconds $wait; continue
      }
      throw
    }
    ($r.Content | ConvertFrom-Json) | ForEach-Object { $_ }
    $url = $null
    $link = $r.Headers['Link']; if ($link -is [array]) { $link = $link -join ',' }
    if ($link -match '<([^>]+)>;\s*rel="next"') { $url = $Matches[1] }
  }
}

foreach ($o in $run) {
  $base = $orgs[$o]
  Write-Host "`n== Okta $o ($base) ==" -ForegroundColor Cyan
  $sec = Read-Host "API token for $o (read-only; input hidden)" -AsSecureString
  $tok = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
  $hdr = @{ Authorization = "SSWS $tok"; Accept = 'application/json' }
  $q = [uri]::EscapeDataString('status eq "ACTIVE"')
  $rows = New-Object System.Collections.Generic.List[object]; $n = 0
  foreach ($u in (Get-OktaPages "$base/api/v1/users?search=$q&limit=200" $hdr)) {
    $n++; if ($n % 1000 -eq 0) { Write-Host "  $n users read..." -ForegroundColor DarkGray }
    $login = "$($u.profile.login)"
    if ($ExcludeLike | Where-Object { $login -like $_ }) { continue }
    $last = if ($u.lastLogin) { [datetime]$u.lastLogin } else { $null }
    $created = [datetime]$u.created
    if ($last) { $d = [int]($now - $last).TotalDays; $bucket = if ($d -ge 180) { '180+ delete' } elseif ($d -ge 90) { '90-179 remove perms' } elseif ($d -ge $Days) { "$Days-89 disable" } else { $null } }
    else { $d = $null; $bucket = if (($now - $created).TotalDays -gt $Days) { 'never logged in' } else { $null } }
    if (-not $bucket) { continue }
    $rows.Add([pscustomobject]@{
        Login = $login; Name = "$($u.profile.firstName) $($u.profile.lastName)"; Email = "$($u.profile.email)"
        Title = "$($u.profile.title)"; Dept = "$($u.profile.department)"; Manager = "$($u.profile.manager)"
        LastLogin = if ($last) { $last.ToString('yyyy-MM-dd') } else { '' }; DaysInactive = $d; Bucket = $bucket
        Created = $created.ToString('yyyy-MM-dd'); PasswordChanged = if ($u.passwordChanged) { ([datetime]$u.passwordChanged).ToString('yyyy-MM-dd') } else { '' }
        Provider = "$($u.credentials.provider.type)"
      })
  }
  $tok = $null
  $csv = Join-Path $outDir "Okta-Inactive-$o.csv"
  $rows | Sort-Object Bucket, @{ e = { if ($_.DaysInactive -eq $null) { 99999 } else { $_.DaysInactive } }; Descending = $true } | Export-Csv -NoTypeInformation -Path $csv
  Write-Host "  $n active users read, $($rows.Count) inactive -> $csv" -ForegroundColor Green
  $g = $rows | Group-Object Bucket | Sort-Object Name
  $summary += "## Okta $o - $n active users, $($rows.Count) inactive`n"
  $summary += "| Bucket | Users | AD-backed |`n|---|--:|--:|"
  foreach ($x in $g) { $summary += "| $($x.Name) | $($x.Count) | $(@($x.Group | Where-Object Provider -eq 'ACTIVE_DIRECTORY').Count) |" }
  $summary += "`nCSV: $csv`n"
}
$md = Join-Path $outDir 'Okta-Inactive-Summary.md'
("# Okta inactive user review - $(Get-Date -Format 'yyyy-MM-dd')`n`nThresholds (draft standard): 30 disable / 90 remove permissions / 180 delete. Excluded logins like: $($ExcludeLike -join ', ').`nThis report is read-only. Nothing was changed in Okta.`n`n" + ($summary -join "`n")) | Set-Content -Path $md -Encoding UTF8
Write-Host "`nSummary: $md" -ForegroundColor Green
