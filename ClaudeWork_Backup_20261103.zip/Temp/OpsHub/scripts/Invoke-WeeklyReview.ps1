﻿<#
.SYNOPSIS
    READ-ONLY weekly infrastructure review runner. Meant for Friday 02:00. For every review in the config it runs the check,
    decides CLEAN / ATTENTION / ERROR / NOT CONFIGURED, and writes a paste-ready ticket note. It never closes or changes a ticket
    and never changes anything on a device.

.DESCRIPTION
    Check types (set "type" in data\weekly-review.json):
      ilo          HPE iLO health (wraps Get-IloBatch.ps1)
      adbackup     AD backup age per DC (wraps Test-AdBackup.ps1, current Windows logon)
      backupshare  Backup share freshness (wraps Test-BackupShare.ps1)
      vcenter      vCenter host / datastore / alarm snapshot (wraps Get-VCenterHealth.ps1)
      pure1        Pure1 fleet health (wraps Invoke-Pure1HealthCheck.ps1, needs PowerShell 7 = pwsh)
      oneview      HPE OneView REST: active critical/warning alerts, server hardware, enclosures, interconnects
      nimble       Nimble REST (port 5392): arrays, controllers, disks, shelves, alerts
      rubrik       Rubrik CDM REST: cluster nodes, disks, recent failed events
      note         Fixed text (for example a decommissioned array: nothing to check)
    A check with no hosts in the config shows NOT CONFIGURED (never "OK").

    Logins are saved once with -SetupCredentials (encrypted with Windows DPAPI for YOUR Windows account on THIS PC, same as Ops Hub).
    The unattended run never prompts. A check whose login is missing is reported as SKIPPED - NO LOGIN.

    Output: C:\Temp\WeeklyReview\yyyyMMdd\Weekly-Review-Summary.md, Weekly-Review-Notes.md (one note per ticket), raw evidence per check.

.PARAMETER Site      laptop | fedramp | all. Checks in the config carry a "site" tag, because a PC that can see FedRAMP often cannot see prod, and vice versa. Default all.
.PARAMETER Only      Run only these check ids.   .PARAMETER Skip   Skip these check ids.
.PARAMETER SetupCredentials   Ask for (and save) the logins the selected checks need, then exit.
.PARAMETER Register  Create a Windows scheduled task: Fridays 02:00, wakes the PC, runs as you while logged on.
.PARAMETER Discover  Also save the field names the REST APIs return, so the checks can be adjusted on the first run.
.EXAMPLE   .\Invoke-WeeklyReview.ps1 -SetupCredentials -Site laptop
.EXAMPLE   .\Invoke-WeeklyReview.ps1 -Site laptop
.EXAMPLE   .\Invoke-WeeklyReview.ps1 -Only oneview,nimble-prod -Discover
#>
[CmdletBinding()]
param(
    [string]$ConfigFile,
    [ValidateSet('laptop', 'fedramp', 'all')][string]$Site = 'all',
    [string[]]$Only,
    [string[]]$Skip,
    [switch]$SetupCredentials,
    [switch]$Register,
    [switch]$Discover,
    [string]$OutRoot = 'C:\Temp\WeeklyReview',
    [string]$ScriptsDir
)
$ErrorActionPreference = 'Continue'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $ScriptsDir) { $ScriptsDir = $here }
if (-not $ConfigFile) { $ConfigFile = Join-Path (Join-Path (Split-Path -Parent $here) 'data') 'weekly-review.json' }
$isWin = ($env:OS -eq 'Windows_NT')
$credDir = if ($isWin) { Join-Path $env:LOCALAPPDATA 'OpsHub\weekly' } else { Join-Path ([IO.Path]::GetTempPath()) 'OpsHub-weekly' }
$ps7 = $PSVersionTable.PSVersion.Major -ge 7
if (-not $ps7) {
    try { Add-Type 'using System.Net;using System.Security.Cryptography.X509Certificates;public class TrustAllW:ICertificatePolicy{public bool CheckValidationResult(ServicePoint s,X509Certificate c,WebRequest r,int p){return true;}}' } catch {}
    try { [Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllW; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
}

# ------------------------------------------------------------------------------------------------ config
if (-not (Test-Path -LiteralPath $ConfigFile)) {
    $dir = Split-Path -Parent $ConfigFile
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    @'
{
  "note": "One entry per weekly review. 'match' is text from the ticket title. 'site' is laptop or fedramp (which PC can reach it). Leave hosts empty until known: the check then shows NOT CONFIGURED, never OK.",
  "checks": [
    { "id": "ilo", "title": "iLO review NWV / ROS / EMS", "match": "Log in via ILO", "type": "ilo", "site": "laptop", "cred": "ilo",
      "hosts": ["172.21.11.129","172.23.5.23","172.23.5.24","172.23.5.20","172.23.5.21","172.23.5.22","172.23.12.118","172.23.12.119"],
      "ticketList": "fra-epros01, lax-emcore01, lax-emcore02, lax-emdbs01, lax-emdbs02, lax-emdbs03, lax-epnwv01, lax-epros01" },
    { "id": "ad-uksov", "title": "UK Sov AD backups", "match": "UK Sovreign region AD Backups", "type": "adbackup", "site": "laptop", "hosts": [], "maxAgeDays": 7 },
    { "id": "ad-fedramp", "title": "FedRAMP AD backup validation", "match": "FedRAMP AD Backup", "type": "adbackup", "site": "fedramp", "hosts": [], "maxAgeDays": 7 },
    { "id": "globalscape-fedramp", "title": "CDR Globalscape config backup (FedRAMP)", "match": "Globalscape Config Backup", "type": "backupshare", "site": "fedramp", "hosts": [], "share": "Backups", "maxAgeDays": 7 },
    { "id": "vcenter-fedramp", "title": "FedRAMP HPE compute and vSAN", "match": "FedRAMP HPE Compute", "type": "vcenter", "site": "fedramp", "cred": "vcenter-incmp", "hosts": ["cul-vmvce01.incmp.com"],
      "manualNote": "vSAN Skyline Health and OneView/iLO hardware are not covered by this check." },
    { "id": "vcenter-viawest", "title": "ViaWest lab compute", "match": "ViaWest Lab Compute", "type": "vcenter", "site": "laptop", "cred": "vcenter-inlab", "hosts": ["eng-vmvce01.in.lab"] },
    { "id": "pure1", "title": "Pure1 array health (all sites)", "match": "Pure1 Portal", "type": "pure1", "site": "laptop", "cred": "pure1" },
    { "id": "oneview", "title": "Synergy frames / hosts / components (Global OneView)", "match": "Synergy Frames", "type": "oneview", "site": "laptop", "cred": "oneview", "hosts": [] },
    { "id": "nimble-prod", "title": "US Production Nimble arrays", "match": "US Production Nimble", "type": "nimble", "site": "laptop", "cred": "nimble", "hosts": ["dal-nimb01.inucn.com","lax-nimb02.inucn.com"] },
    { "id": "nimble-opslab", "title": "Ops Lab Nimble array", "match": "Ops Lab Nimble", "type": "nimble", "site": "laptop", "cred": "nimble-lab", "hosts": [] },
    { "id": "rubrik", "title": "LA and Dallas Rubrik nodes", "match": "Rubrik Nodes", "type": "rubrik", "site": "laptop", "cred": "rubrik", "hosts": [] },
    { "id": "3par", "title": "LA 3PAR storage array health", "match": "3PAR", "type": "note", "site": "laptop",
      "text": "The LA 3PAR array has been decommissioned, so there is no hardware left to review. Nothing to check. Closing. (Suggest removing this recurring task.)" }
  ]
}
'@ | Set-Content -LiteralPath $ConfigFile -Encoding UTF8
    Write-Host "Created $ConfigFile. Fill in the empty host lists (OneView, Rubrik, Ops Lab Nimble, AD DCs, FedRAMP share servers) when known." -ForegroundColor Yellow
}
$cfg = Get-Content -LiteralPath $ConfigFile -Raw | ConvertFrom-Json
$checks = @($cfg.checks)
if ($Only) { $checks = @($checks | Where-Object { $Only -contains $_.id }) }
if ($Skip) { $checks = @($checks | Where-Object { $Skip -notcontains $_.id }) }
if ($Site -ne 'all') { $checks = @($checks | Where-Object { $_.site -eq $Site }) }

# ------------------------------------------------------------------------------------------------ credentials
function Get-CredFile($name) { Join-Path $credDir (($name -replace '[^A-Za-z0-9._-]', '_') + '.xml') }
function Get-SavedCred($name) {
    $f = Get-CredFile $name
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    try { Import-Clixml -LiteralPath $f } catch { $null }
}
function Save-NewCred($name, $what) {
    Write-Host ""; Write-Host ">> $what  (saved as '$name')" -ForegroundColor Yellow
    Write-Host '   Leave the username blank to skip.' -ForegroundColor DarkGray
    $u = Read-Host '   Username'
    if ([string]::IsNullOrWhiteSpace($u)) { return }
    $pw = Read-Host '   Password (or API token)' -AsSecureString
    if (-not (Test-Path -LiteralPath $credDir)) { New-Item -ItemType Directory -Path $credDir -Force | Out-Null }
    (New-Object System.Management.Automation.PSCredential($u, $pw)) | Export-Clixml -LiteralPath (Get-CredFile $name)
    Write-Host "   Saved. Delete $(Get-CredFile $name) to forget it." -ForegroundColor Green
}
$credHelp = @{
    'ilo' = 'iLO login (used for all weekly iLOs)'; 'vcenter-incmp' = 'FedRAMP vCenter login (INCMP, read-only is enough)'; 'vcenter-inlab' = 'in.lab vCenter login (read-only is enough)'
    'pure1' = "Pure1 API token. Username: 'token'. Password: the token (Pure1 > Administration > API Registration)"
    'oneview' = 'OneView READ-ONLY account (same account the OneView MCP server uses)'; 'nimble' = 'Nimble read-only login (prod arrays)'; 'nimble-lab' = 'Nimble read-only login (Ops Lab array)'
    'rubrik' = "Rubrik CDM login (read-only role). Or username 'token' and password = a CDM API token"
}
if ($SetupCredentials) {
    $need = @($checks | Where-Object { $_.cred } | ForEach-Object { $_.cred } | Select-Object -Unique)
    foreach ($n in $need) {
        $have = Get-SavedCred $n
        if ($have) { $a = Read-Host "'$n' already saved for $($have.UserName). Replace? [y/N]"; if ($a -notmatch '^(y|yes)$') { continue } }
        Save-NewCred $n $(if ($credHelp.ContainsKey($n)) { $credHelp[$n] } else { "Login for $n" })
    }
    Write-Host "`nDone. Run .\Invoke-WeeklyReview.ps1 -Site $Site to test, then -Register to schedule it." -ForegroundColor Green
    return
}

# ------------------------------------------------------------------------------------------------ register
if ($Register) {
    if (-not $isWin) { throw 'Register only works on Windows.' }
    $ps = (Get-Command pwsh -ErrorAction SilentlyContinue); $exe = if ($ps) { $ps.Source } else { (Get-Command powershell).Source }
    $argLine = "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Path)`" -Site $Site"
    $act = New-ScheduledTaskAction -Execute $exe -Argument $argLine
    $trg = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Friday -At 2:00AM
    $set = New-ScheduledTaskSettingsSet -WakeToRun -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 3)
    Register-ScheduledTask -TaskName "OpsHub Weekly Review ($Site)" -Action $act -Trigger $trg -Settings $set -Description 'Read-only weekly infrastructure review. Writes ticket notes to C:\Temp\WeeklyReview.' -Force | Out-Null
    Write-Host "Scheduled: Fridays 02:00, runs as you while you are logged on (lock the PC, do not sign out or shut down). Logins must already be saved with -SetupCredentials." -ForegroundColor Green
    return
}

# ------------------------------------------------------------------------------------------------ helpers
$today = Get-Date -Format 'yyyy-MM-dd'
$outDir = Join-Path $OutRoot (Get-Date -Format 'yyyyMMdd')
if (-not (Test-Path -LiteralPath $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
$results = New-Object System.Collections.Generic.List[object]

function Invoke-Api {
    param([string]$Method = 'GET', [string]$Uri, [hashtable]$Headers = @{}, $Body, [string]$ContentType = 'application/json')
    $a = @{ Uri = $Uri; Method = $Method; Headers = $Headers; TimeoutSec = 180; ErrorAction = 'Stop' }
    if ($null -ne $Body) { $a.Body = $Body; $a.ContentType = $ContentType }
    if ($ps7) { $a.SkipCertificateCheck = $true }
    try { Invoke-RestMethod @a }
    catch {
        # keep the server's own error text (OneView/Rubrik/Nimble put the real reason in the response body)
        $d = ''; try { if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $d = ($_.ErrorDetails.Message -replace '\s+', ' ') } } catch {}
        if ($d.Length -gt 300) { $d = $d.Substring(0, 300) }
        if ($d) { throw "$($_.Exception.Message.Split([char]10)[0]) | server said: $d" } else { throw }
    }
}
$badWords = '^(critical|error|failed|failure|fail|fault|faulted|degraded|offline|down|missing|unavailable|unhealthy|not ?ok|disconnected|lost|unknown)$'
function Get-BadStates($items, [string]$kind) {
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($i in @($items)) {
        if ($null -eq $i) { continue }
        $name = ''
        foreach ($p in 'name', 'hostname', 'serverName', 'model', 'ipAddress', 'id', 'uri') { if ($i.PSObject.Properties[$p] -and "$($i.$p)") { $name = "$($i.$p)"; break } }
        foreach ($p in $i.PSObject.Properties) {
            if ($p.Name -match '^(status|state|health|healthStatus|health_status|raid_state|array_status|eventStatus|op_state)$' -and "$($p.Value)" -match $badWords) {
                $found.Add("$kind $name : $($p.Name) = $($p.Value)")
            }
        }
    }
    , $found
}
function Save-Evidence($id, $text) { $f = Join-Path $outDir "$id-evidence.txt"; $text | Set-Content -LiteralPath $f -Encoding UTF8; $f }
function Save-Keys($id, $tag, $obj) {
    if (-not $Discover -or $null -eq $obj) { return }
    $first = @($obj)[0]; if ($null -eq $first) { return }
    $names = ($first.PSObject.Properties | ForEach-Object { $_.Name }) -join ', '
    Add-Content -LiteralPath (Join-Path $outDir "$id-discover.txt") -Value "$tag : $names"
}
function Add-Result($c, $verdict, $lines, $evidence, $scope) {
    $lines = @($lines)
    $note = switch ($verdict) {
        'CLEAN' { "Completed the weekly review on $today. $scope Everything came back healthy: no failures, critical alerts or stale items found. Closing." }
        'ATTENTION' { "Completed the weekly review on $today. $scope Found $($lines.Count) item(s) that need a look:`n" + (($lines | Select-Object -First 25 | ForEach-Object { "- $_" }) -join "`n") + "`nLeaving this open until these are checked." }
        'NOTE' { "$($c.text)" }
        default { "Weekly review NOT completed by automation ($verdict): $($lines -join '; '). Needs a manual check." }
    }
    if ($c.manualNote -and $verdict -eq 'CLEAN') { $note += "`nNot covered by automation: $($c.manualNote)" }
    if ($c.ticketList -and $verdict -in 'CLEAN', 'ATTENTION') { $note += "`nHosts reviewed: $($c.ticketList)" }
    $results.Add([pscustomobject]@{ Id = $c.id; Title = $c.title; Match = $c.match; Verdict = $verdict; Count = $lines.Count; Lines = $lines; Note = $note; Evidence = $evidence })
    $col = switch ($verdict) { 'CLEAN' { 'Green' } 'NOTE' { 'Green' } 'ATTENTION' { 'Yellow' } default { 'Red' } }
    Write-Host ("[{0,-14}] {1}" -f $verdict, $c.title) -ForegroundColor $col
}
function Invoke-Wrapped($scriptName, [hashtable]$args2) {
    $p = Join-Path $ScriptsDir $scriptName
    if (-not (Test-Path -LiteralPath $p)) { return @{ Ok = $false; Text = "$scriptName not found in $ScriptsDir" } }
    try { $t = (& $p @args2 *>&1 | Out-String); @{ Ok = $true; Text = $t } } catch { @{ Ok = $false; Text = $_.Exception.Message } }
}
function Get-Ws($text) { ($text -split "`r?`n" | Where-Object { $_ -match '\S' } | Select-Object -Last 40) -join "`n" }

# ------------------------------------------------------------------------------------------------ check types
function Test-OneView($c) {
    $lines = @(); $ev = @(); $okCount = 0
    foreach ($h in @($c.hosts)) {
        $base = if ($h -match '^https?://') { $h.TrimEnd('/') } else { "https://$h" }
        $cr = Get-SavedCred $c.cred
        try {
            try { $v = Invoke-Api -Uri "$base/rest/version" -Headers @{} } catch { throw "step rest/version: $($_.Exception.Message.Split("`n")[0])" }
            $ver = "$($v.currentVersion)"
            $loginBody = @{ userName = $cr.UserName; password = $cr.GetNetworkCredential().Password; loginMsgAck = $true } | ConvertTo-Json
            $login = $null; $tried = @()
            foreach ($tv in @($ver, "$($v.minimumVersion)", '3800', '3000', '2000') | Where-Object { $_ } | Select-Object -Unique) {
                try { $login = Invoke-Api -Method POST -Uri "$base/rest/login-sessions" -Headers @{ 'X-API-Version' = $tv } -Body $loginBody; $ver = $tv; break }
                catch { $tried += "v$tv -> $($_.Exception.Message.Split("`n")[0])" }
            }
            if (-not $login) { throw "step login-sessions failed for every API version tried (appliance says current=$($v.currentVersion) min=$($v.minimumVersion)): $($tried -join '; ')" }
            $hdr = @{ 'Auth' = $login.sessionID; 'X-API-Version' = $ver }
            try {
                foreach ($ep in @(@{ T = 'server-hardware'; U = '/rest/server-hardware?start=0&count=500' }, @{ T = 'enclosure'; U = '/rest/enclosures?start=0&count=200' }, @{ T = 'interconnect'; U = '/rest/interconnects?start=0&count=200' }, @{ T = 'logical-interconnect'; U = '/rest/logical-interconnects?start=0&count=200' }, @{ T = 'sas-interconnect'; U = '/rest/sas-interconnects?start=0&count=200' })) {
                    try {
                        $r = Invoke-Api -Uri ($base + $ep.U) -Headers $hdr
                        $m = @($r.members); Save-Keys $c.id "$h $($ep.T)" $m
                        $bad = Get-BadStates $m "$h $($ep.T)"
                        foreach ($b in $bad) { $lines += $b }
                        foreach ($x in $m) { if ("$($x.status)" -in 'Warning') { $nm = "$($x.name)"; $lines += "$h $($ep.T) $nm : status = Warning" } }
                        $ev += "$h $($ep.T): $($m.Count) object(s)"; $okCount += $m.Count
                    } catch { if ("$($_.Exception.Message)" -notmatch '404|Not Found') { $lines += "$h $($ep.T): could not read ($($_.Exception.Message.Split("`n")[0]))" } }
                }
                $al = Invoke-Api -Uri "$base/rest/alerts?start=0&count=500&filter=%22alertState%3D%27Active%27%22" -Headers $hdr
                $am = @($al.members); Save-Keys $c.id "$h alerts" $am
                $act = @($am | Where-Object { "$($_.severity)" -in 'Critical', 'Warning' -and "$($_.alertState)" -eq 'Active' })
                foreach ($a in $act) { $res = ''; if ($a.associatedResource) { $res = "$($a.associatedResource.resourceName)" }; $lines += "$h alert [$($a.severity)] $res : $("$($a.description)".Substring(0, [math]::Min(140, "$($a.description)".Length)))" }
                $ev += "$h active alerts total: $($am.Count), critical/warning: $($act.Count)"
            } finally { try { Invoke-Api -Method DELETE -Uri "$base/rest/login-sessions" -Headers $hdr | Out-Null } catch {} }
        } catch { $lines += "$h : ERROR $($_.Exception.Message.Split("`n")[0])" }
    }
    $f = Save-Evidence $c.id ($ev + '' + $lines)
    $err = @($lines | Where-Object { $_ -match ': ERROR |could not read' })
    $v = if ($err.Count -and $okCount -eq 0) { 'ERROR' } elseif ($lines.Count) { 'ATTENTION' } else { 'CLEAN' }
    Add-Result $c $v $lines $f "Checked OneView ($(@($c.hosts) -join ', ')): active alerts, server hardware, enclosures and interconnects ($okCount objects)."
}
function Test-Nimble($c) {
    $lines = @(); $ev = @(); $okCount = 0
    foreach ($h in @($c.hosts)) {
        $base = if ($h -match '^https?://') { $h.TrimEnd('/') } else { "https://${h}:5392" }
        $cr = Get-SavedCred $c.cred
        try {
            $t = Invoke-Api -Method POST -Uri "$base/v1/tokens" -Body (@{ data = @{ username = $cr.UserName; password = $cr.GetNetworkCredential().Password } } | ConvertTo-Json)
            $hdr = @{ 'X-Auth-Token' = "$($t.data.session_token)" }
            try {
                foreach ($ep in 'arrays/detail', 'controllers/detail', 'disks/detail', 'shelves/detail', 'alerts') {
                    try {
                        $r = Invoke-Api -Uri "$base/v1/$ep" -Headers $hdr
                        $m = @($r.data); Save-Keys $c.id "$h $ep" $m
                        $okCount += $m.Count
                        $bad = Get-BadStates $m "$h $($ep -replace '/detail','')"
                        foreach ($b in $bad) { $lines += $b }
                        if ($ep -eq 'alerts') {
                            foreach ($a in $m) { if (("$($a.severity)" -match 'crit|warn|error') -and ("$($a.acknowledged)" -ne 'True')) { $lines += "$h alert [$($a.severity)] : $("$($a.description)$($a.message)".Substring(0, [math]::Min(140, "$($a.description)$($a.message)".Length)))" } }
                        }
                        $ev += "$h ${ep}: $($m.Count) object(s)"
                    } catch { if ("$($_.Exception.Message)" -notmatch '404|Not Found') { $lines += "$h ${ep}: could not read ($($_.Exception.Message.Split("`n")[0]))" } }
                }
            } finally { try { Invoke-Api -Method DELETE -Uri "$base/v1/tokens" -Headers $hdr | Out-Null } catch {} }
        } catch { $lines += "$h : ERROR $($_.Exception.Message.Split("`n")[0])" }
    }
    $f = Save-Evidence $c.id ($ev + '' + $lines)
    $err = @($lines | Where-Object { $_ -match ': ERROR ' })
    $v = if ($err.Count -and $okCount -eq 0) { 'ERROR' } elseif ($lines.Count) { 'ATTENTION' } else { 'CLEAN' }
    Add-Result $c $v $lines $f "Checked Nimble ($(@($c.hosts) -join ', ')): array and controller state, disks, shelves and unacknowledged alerts ($okCount objects)."
}
function Test-Rubrik($c) {
    $lines = @(); $ev = @(); $okCount = 0
    foreach ($h in @($c.hosts)) {
        $base = if ($h -match '^https?://') { $h.TrimEnd('/') } else { "https://$h" }
        $cr = Get-SavedCred $c.cred
        try {
            if ($cr.UserName -eq 'token') { $tok = $cr.GetNetworkCredential().Password }
            else {
                $pair = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($cr.UserName):$($cr.GetNetworkCredential().Password)"))
                $s = Invoke-Api -Method POST -Uri "$base/api/v1/session" -Headers @{ Authorization = "Basic $pair" } -Body '{}'
                $tok = "$($s.token)"
            }
            $hdr = @{ Authorization = "Bearer $tok" }
            $me = Invoke-Api -Uri "$base/api/v1/cluster/me" -Headers $hdr
            $ev += "$h cluster $($me.name) version $($me.version)"
            foreach ($ep in @(@{ T = 'node'; U = '/api/internal/node' }, @{ T = 'disk'; U = '/api/internal/cluster/me/disk' }, @{ T = 'event'; U = '/api/v1/event?status=Failure&limit=100' })) {
                try {
                    $r = Invoke-Api -Uri ($base + $ep.U) -Headers $hdr
                    $m = @($r.data); Save-Keys $c.id "$h $($ep.T)" $m
                    $okCount += $m.Count
                    if ($ep.T -eq 'event') {
                        $cut = (Get-Date).AddDays(-7)
                        foreach ($e in $m) { $d = [datetime]::MinValue; if ([datetime]::TryParse("$($e.time)", [ref]$d) -and $d -lt $cut) { continue }; $lines += "$h failed event $($e.time) : $("$($e.eventName)$($e.eventType)$($e.message)".Substring(0, [math]::Min(140, "$($e.eventName)$($e.eventType)$($e.message)".Length)))" }
                    } else { foreach ($b in (Get-BadStates $m "$h $($ep.T)")) { $lines += $b } }
                    $ev += "$h $($ep.T): $($m.Count) object(s)"
                } catch { if ("$($_.Exception.Message)" -notmatch '404|Not Found') { $lines += "$h $($ep.T): could not read ($($_.Exception.Message.Split("`n")[0]))" } }
            }
        } catch { $lines += "$h : ERROR $($_.Exception.Message.Split("`n")[0])" }
    }
    $f = Save-Evidence $c.id ($ev + '' + $lines)
    $err = @($lines | Where-Object { $_ -match ': ERROR ' })
    $v = if ($err.Count -and $okCount -eq 0) { 'ERROR' } elseif ($lines.Count) { 'ATTENTION' } else { 'CLEAN' }
    Add-Result $c $v $lines $f "Checked Rubrik ($(@($c.hosts) -join ', ')): cluster nodes, disks and failed events in the last 7 days ($okCount objects)."
}
function Test-Wrapped($c) {
    switch ($c.type) {
        'ilo' {
            $cr = Get-SavedCred $c.cred; if (-not $cr) { Add-Result $c 'SKIPPED - NO LOGIN' @("no saved login '$($c.cred)'; run -SetupCredentials") $null ''; return }
            $r = Invoke-Wrapped 'Get-IloBatch.ps1' @{ Ilos = @($c.hosts); Credential = $cr; OutDir = $outDir }
            $f = Save-Evidence $c.id $r.Text
            if (-not $r.Ok) { Add-Result $c 'ERROR' @($r.Text) $f ''; return }
            if ($r.Text -match 'All iLOs report OK') { Add-Result $c 'CLEAN' @() $f "Checked $(@($c.hosts).Count) iLOs (power, health, memory, CPU, BIOS)." }
            elseif ($r.Text -match 'need a look') { Add-Result $c 'ATTENTION' @(($r.Text -split "`r?`n" | Where-Object { $_ -match 'FAILED|Warning|Critical|Degraded|WARNING' } | Select-Object -First 20)) $f "Checked $(@($c.hosts).Count) iLOs." }
            else { Add-Result $c 'ERROR' @('could not read the iLO result', (Get-Ws $r.Text)) $f '' }
        }
        'adbackup' {
            $r = Invoke-Wrapped 'Test-AdBackup.ps1' @{ DomainControllers = @($c.hosts); MaxAgeDays = [int]$c.maxAgeDays; UseCurrentLogon = $true; OutDir = $outDir }
            $f = Save-Evidence $c.id $r.Text
            if (-not $r.Ok) { Add-Result $c 'ERROR' @($r.Text) $f ''; return }
            $csv = Get-ChildItem -LiteralPath $outDir -Filter 'AdBackup_*.csv' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if (-not $csv) { Add-Result $c 'ERROR' @('no result file', (Get-Ws $r.Text)) $f ''; return }
            $rows = @(Import-Csv -LiteralPath $csv.FullName)
            $bad = @($rows | Where-Object { $_.Status -ne 'OK' })
            if ($bad.Count) { Add-Result $c 'ATTENTION' @($bad | ForEach-Object { "$($_.DC) $($_.NamingContext): $($_.Status) (last backup $($_.LastBackup), $($_.AgeDays) days)" }) $f "Checked $($rows.Count) AD backup records on $(@($c.hosts).Count) DC(s)." }
            else { Add-Result $c 'CLEAN' @() $f "Checked AD backups on $(@($c.hosts) -join ', '): newest within $($c.maxAgeDays) days." }
        }
        'backupshare' {
            $a = @{ Servers = @($c.hosts); MaxAgeDays = [int]$c.maxAgeDays; OutDir = $outDir }; if ($c.share) { $a.Share = $c.share }
            $cr = if ($c.cred) { Get-SavedCred $c.cred } else { $null }; if ($cr) { $a.Credential = $cr }
            $r = Invoke-Wrapped 'Test-BackupShare.ps1' $a
            $f = Save-Evidence $c.id $r.Text
            if (-not $r.Ok) { Add-Result $c 'ERROR' @($r.Text) $f ''; return }
            if ($r.Text -match 'within the age limit') { Add-Result $c 'CLEAN' @() $f "Checked backup freshness on $(@($c.hosts) -join ', ') (limit $($c.maxAgeDays) days)." }
            elseif ($r.Text -match 'need a look') { Add-Result $c 'ATTENTION' @(($r.Text -split "`r?`n" | Where-Object { $_ -match 'STALE|EMPTY|UNCHECKED' } | Select-Object -First 20)) $f '' }
            else { Add-Result $c 'ERROR' @('could not read the backup share result', (Get-Ws $r.Text)) $f '' }
        }
        'vcenter' {
            $cr = Get-SavedCred $c.cred; if (-not $cr) { Add-Result $c 'SKIPPED - NO LOGIN' @("no saved login '$($c.cred)'; run -SetupCredentials") $null ''; return }
            $lines = @(); $okAll = $true; $txt = ''
            foreach ($h in @($c.hosts)) {
                $r = Invoke-Wrapped 'Get-VCenterHealth.ps1' @{ VCenter = $h; Credential = $cr; OutDir = $outDir }
                $txt += "=== $h ===`n$($r.Text)`n"
                if (-not $r.Ok) { $lines += "$h : ERROR $($r.Text)"; $okAll = $false }
                elseif ($r.Text -match 'issue\(s\) found') { $lines += "$h : " + (($r.Text -split "`r?`n" | Where-Object { $_ -match 'issue\(s\) found' } | Select-Object -First 1).Trim()); $lines += @($r.Text -split "`r?`n" | Where-Object { $_ -cmatch 'ISSUE' } | Select-Object -First 15 | ForEach-Object { $_.Trim() }) }
                elseif ($r.Text -notmatch 'No host, datastore or alarm issues found') { $lines += "$h : could not read the result"; $okAll = $false }
            }
            $f = Save-Evidence $c.id $txt
            if ($lines.Count) { Add-Result $c $(if (-not $okAll) { 'ERROR' } else { 'ATTENTION' }) $lines $f "Checked vCenter ($(@($c.hosts) -join ', ')): hosts, datastores and alarms." }
            else { Add-Result $c 'CLEAN' @() $f "Checked vCenter ($(@($c.hosts) -join ', ')): host state, datastore space and triggered alarms." }
        }
        'pure1' {
            $cr = Get-SavedCred $c.cred; if (-not $cr) { Add-Result $c 'SKIPPED - NO LOGIN' @("no saved token '$($c.cred)'; run -SetupCredentials") $null ''; return }
            $pw = Get-Command pwsh -ErrorAction SilentlyContinue; if (-not $pw) { Add-Result $c 'ERROR' @('PowerShell 7 (pwsh) not found; the Pure1 script needs it') $null ''; return }
            $rep = Join-Path $outDir 'pure1-report.txt'
            $null = & $pw.Source -NoProfile -File (Join-Path $ScriptsDir 'Invoke-Pure1HealthCheck.ps1') -ApiToken $cr.GetNetworkCredential().Password -OutputPath $rep 2>&1
            $code = $LASTEXITCODE
            $txt = if (Test-Path -LiteralPath $rep) { Get-Content -LiteralPath $rep -Raw } else { '' }
            if ($code -eq 0 -and $txt) { Add-Result $c 'CLEAN' @() $rep 'Checked Pure1 health and alerts for every registered array (Dubai, Abu Dhabi, Mumbai, Hyderabad, Culpeper, Miami, EU/UK/AU Sovereign, Ops Lab).' }
            elseif ($txt -match '\[FAIL\] Fatal error') { Add-Result $c 'ERROR' @(($txt -split "`r?`n" | Where-Object { $_ -match 'Fatal error|API token' } | Select-Object -First 3)) $rep '' }
            elseif ($code -eq 1 -and $txt) { Add-Result $c 'ATTENTION' @(($txt -split "`r?`n" | Where-Object { $_ -match '\S' -and $_ -notmatch '^\s*(=|\+--)' } | Select-Object -First 25)) $rep '' }
            else { Add-Result $c 'ERROR' @("Pure1 check failed (exit $code)") $rep '' }
        }
    }
}

# ------------------------------------------------------------------------------------------------ run
Write-Host "Weekly review $today  (site: $Site, $($checks.Count) check(s))" -ForegroundColor Cyan
foreach ($c in $checks) {
    try {
        if ($c.type -eq 'note') { Add-Result $c 'NOTE' @() $null ''; continue }
        $needsHosts = $c.type -in 'oneview', 'nimble', 'rubrik', 'adbackup', 'backupshare', 'vcenter', 'ilo'
        if ($needsHosts -and -not @($c.hosts).Count) { Add-Result $c 'NOT CONFIGURED' @('no hosts listed in the config for this check') $null ''; continue }
        if ($c.type -in 'oneview', 'nimble', 'rubrik') {
            if (-not (Get-SavedCred $c.cred)) { Add-Result $c 'SKIPPED - NO LOGIN' @("no saved login '$($c.cred)'; run -SetupCredentials") $null ''; continue }
        }
        switch ($c.type) { 'oneview' { Test-OneView $c } 'nimble' { Test-Nimble $c } 'rubrik' { Test-Rubrik $c } default { Test-Wrapped $c } }
    } catch { Add-Result $c 'ERROR' @($_.Exception.Message) $null '' }
}

# ------------------------------------------------------------------------------------------------ report
$md = New-Object System.Collections.Generic.List[string]
$md.Add("# Weekly review - $today"); $md.Add('')
$ready = @($results | Where-Object { $_.Verdict -in 'CLEAN', 'NOTE' })
$md.Add("**$($ready.Count) of $($results.Count) ready to close.** Needs attention: $(@($results | Where-Object Verdict -eq 'ATTENTION').Count). Not done by automation: $(@($results | Where-Object { $_.Verdict -notin 'CLEAN','NOTE','ATTENTION' }).Count)."); $md.Add('')
$md.Add('| Review | Ticket title contains | Result | Items |'); $md.Add('|---|---|---|--:|')
foreach ($r in $results) { $md.Add("| $($r.Title) | $($r.Match) | $($r.Verdict) | $($r.Count) |") }
$md.Add(''); $md.Add('Ready to close = the note below can be pasted as-is. ATTENTION means do not close; the items are listed. Anything else was NOT checked.')
Set-Content -LiteralPath (Join-Path $outDir 'Weekly-Review-Summary.md') -Value $md -Encoding UTF8
$nt = New-Object System.Collections.Generic.List[string]
$nt.Add("# Ticket notes - $today"); $nt.Add('')
foreach ($r in ($results | Sort-Object { switch ($_.Verdict) { 'CLEAN' { 0 } 'NOTE' { 0 } 'ATTENTION' { 1 } default { 2 } } })) {
    $nt.Add("## [$($r.Verdict)] $($r.Title)  (ticket title contains: $($r.Match))"); $nt.Add(''); $nt.Add($r.Note); $nt.Add('')
}
Set-Content -LiteralPath (Join-Path $outDir 'Weekly-Review-Notes.md') -Value $nt -Encoding UTF8
Write-Host ''; Write-Host "$($ready.Count) of $($results.Count) ready to close." -ForegroundColor Green
Write-Host "Summary: $(Join-Path $outDir 'Weekly-Review-Summary.md')"; Write-Host "Notes  : $(Join-Path $outDir 'Weekly-Review-Notes.md')"
