﻿<#
.SYNOPSIS  READ-ONLY: search one or more AD domains for a person (sam, display name, mail, UPN) and show status.
           Handy for password-reset, new-user duplicate checks, and "is this account locked/disabled?" tickets.
.EXAMPLE   .\Find-AdUser.ps1 -Query jsmith,'Maria Lopez'
           .\Find-AdUser.ps1 -Query jsmith -Targets 'inucn=10.244.88.62','in.lab=172.20.34.100'
           .\Find-AdUser.ps1 -Query jsmith -Targets 'incmp=incmp.com' -UseCurrentLogon     # on cva-indco01
#>
param(
    [Parameter(Mandatory)][string[]]$Query,
    [string[]]$Targets = @('inucn=10.244.88.62', 'in.lab=172.20.34.100'),
    [switch]$UseCurrentLogon,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Stop'
Import-Module ActiveDirectory
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
function Esc([string]$s) { ($s -replace '\\', '\5c' -replace '\*', '\2a' -replace '\(', '\28' -replace '\)', '\29').Trim() }
$props = 'LockedOut', 'PasswordExpired', 'PasswordLastSet', 'LastLogonDate', 'mail', 'Manager', 'MemberOf', 'Department', 'Title', 'Description', 'whenCreated'
$rows = New-Object System.Collections.Generic.List[object]
foreach ($t in $Targets) {
    $label, $srv = $t -split '=', 2
    $p = @{ Server = $srv }
    if (-not $UseCurrentLogon) { $p.Credential = Get-Credential -Message "Credentials for $label ($srv)" }
    foreach ($q in $Query) {
        $e = Esc $q
        $f = "(&(objectCategory=person)(objectClass=user)(|(sAMAccountName=*$e*)(displayName=*$e*)(mail=*$e*)(userPrincipalName=*$e*)(cn=*$e*)))"
        try { $hits = @(Get-ADUser @p -LDAPFilter $f -Properties $props -ResultSetSize 50) }
        catch { $rows.Add([pscustomobject]@{ Domain = $label; Query = $q; Sam = ''; Name = ''; Enabled = ''; Locked = ''; Note = "ERROR: $($_.Exception.Message)" }); continue }
        if (-not $hits.Count) { $rows.Add([pscustomobject]@{ Domain = $label; Query = $q; Sam = ''; Name = ''; Enabled = ''; Locked = ''; Note = 'NotFound' }); continue }
        foreach ($h in $hits) {
            $ou = ($h.DistinguishedName -split ',', 2)[1]
            $rows.Add([pscustomobject]@{
                Domain = $label; Query = $q; Sam = $h.SamAccountName; Name = $h.Name; Enabled = $h.Enabled; Locked = $h.LockedOut
                PwExpired = $h.PasswordExpired; PwLastSet = $h.PasswordLastSet; LastLogon = $h.LastLogonDate; Mail = $h.mail
                Title = $h.Title; Dept = $h.Department; Groups = @($h.MemberOf).Count; Created = $h.whenCreated; OU = $ou; Note = ''
            })
        }
    }
}
$rows | Format-Table Domain, Query, Sam, Name, Enabled, Locked, PwExpired, LastLogon, OU, Note -AutoSize -Wrap
$out = Join-Path $OutDir ("AdUser_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green