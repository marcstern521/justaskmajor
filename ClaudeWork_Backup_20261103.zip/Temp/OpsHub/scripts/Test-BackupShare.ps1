<#
.SYNOPSIS  READ-ONLY: checks how fresh the backups are on an INSYS backup share (for example \\lax-insys01\Backups = E:\Backups).
           Lists each top-level backup folder with its newest file, date and age, and flags anything older than the limit.
.EXAMPLE   .\Test-BackupShare.ps1 -Servers dal-insys01.inucn.com,lax-insys01.inucn.com
           .\Test-BackupShare.ps1 -Servers dal-insys01.inucn.com -MaxAgeDays 30 -Depth 3
.NOTES     Only reads file names and dates. Nothing is copied, changed or deleted.
           Enter the login for the server's domain (for example marc.stern@inucn.com). Ops Hub can remember it on this PC.
#>
param(
    [Parameter(Mandatory)][string[]]$Servers,
    [string]$Share = 'Backups',
    [int]$MaxAgeDays = 7,
    [int]$Depth = 6,
    [string[]]$ExpandFolders = @('DC','ca-backup','CA-Backup','CA'),   # these top-level folders are split one level down (one row per DC)
    [pscredential]$Credential,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Continue'
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
$rows = New-Object System.Collections.Generic.List[object]
$now = Get-Date

function Add-Row($server, $folder, $file, $when, $status, $count) {
    $age = ''; if ($when) { $age = [math]::Round(($now - $when).TotalDays, 1) }
    $rows.Add([pscustomobject]@{ Server = $server; Folder = $folder; Newest = $file; Modified = $(if ($when) { $when.ToString('yyyy-MM-dd HH:mm') } else { '' }); AgeDays = $age; Files = $count; Status = $status })
}

foreach ($s in $Servers) {
    $unc = "\\$s\$Share"
    $cred = $Credential
    if (-not $cred) { $cred = Get-Credential -Message "Backup share login for $s" }
    $drive = 'bk' + [guid]::NewGuid().ToString('N').Substring(0, 6)
    Write-Host ">> $unc" -ForegroundColor Cyan
    try {
        if ($cred) { $null = New-PSDrive -Name $drive -PSProvider FileSystem -Root $unc -Credential $cred -ErrorAction Stop; $root = "${drive}:\" }
        else { if (-not (Test-Path -LiteralPath $unc)) { throw "Cannot reach $unc" }; $root = $unc }
    } catch {
        Add-Row $s '' '' $null ("UNCHECKED - " + $_.Exception.Message.Split("`n")[0].Trim()) ''
        Write-Warning "$s : $($_.Exception.Message.Split("`n")[0].Trim())"
        continue
    }
    try {
        $top = @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction Stop)
        $targets = New-Object System.Collections.Generic.List[object]
        foreach ($d in $top) {
            if ($ExpandFolders -contains $d.Name) {
                $kids = @(Get-ChildItem -LiteralPath $d.FullName -Directory -ErrorAction SilentlyContinue)
                if ($kids.Count) { foreach ($k in $kids) { $targets.Add([pscustomobject]@{ Label = "$($d.Name)\$($k.Name)"; Path = $k.FullName }) }; continue }
            }
            $targets.Add([pscustomobject]@{ Label = $d.Name; Path = $d.FullName })
        }
        foreach ($t in $targets) {
            Write-Host "   scanning $($t.Label) ..." -ForegroundColor DarkGray
            $files = @(Get-ChildItem -LiteralPath $t.Path -File -Recurse -Depth $Depth -ErrorAction SilentlyContinue)
            if (-not $files.Count) { Add-Row $s $t.Label '' $null "EMPTY (no files within $Depth levels)" 0; continue }
            $n = $files | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            $rel = $n.DirectoryName.Substring($t.Path.Length).TrimStart('\')
            $name = if ($rel) { "$rel\$($n.Name)" } else { $n.Name }
            $st = 'OK'; if (($now - $n.LastWriteTime).TotalDays -gt $MaxAgeDays) { $st = "STALE (> $MaxAgeDays days)" }
            Add-Row $s $t.Label $name $n.LastWriteTime $st $files.Count
        }
        $loose = @(Get-ChildItem -LiteralPath $root -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
        if ($loose.Count) { Add-Row $s '(files in share root)' $loose[0].Name $loose[0].LastWriteTime 'INFO' $loose.Count }
    } catch {
        Add-Row $s '' '' $null ("UNCHECKED - " + $_.Exception.Message.Split("`n")[0].Trim()) ''
    } finally {
        if ($cred) { try { Remove-PSDrive -Name $drive -Force -ErrorAction Stop } catch { } }
    }
}

$rows | Format-Table Server, Folder, Newest, Modified, AgeDays, Files, Status -AutoSize | Out-String -Width 250 | Write-Host
$out = Join-Path $OutDir ("BackupShare_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green
$stale = @($rows | Where-Object { $_.Status -like 'STALE*' -or $_.Status -like 'EMPTY*' -or $_.Status -like 'UNCHECKED*' }).Count
if ($stale) { Write-Host "$stale folder(s) need a look (STALE / EMPTY / UNCHECKED). Do not read UNCHECKED as OK." -ForegroundColor Yellow } else { Write-Host 'All backup folders are within the age limit.' -ForegroundColor Green }