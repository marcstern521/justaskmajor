﻿#!/usr/bin/env bash
#
# Production Ready Check automation for Linux servers, based on:
#   - "Linux Hardening Checklist"          (Confluence 16848831, CIS-based, current)
#   - "Production Ready Checks - Linux"    (Confluence 368281930, Marc Stern, older/simpler)
#
# Run this ON the target server (as root, or with sudo). It does NOT try to
# auto-close the ServiceNow ticket, and it does NOT change anything by default
# - it produces a PASS / FAIL / MANUAL / SKIP report you review before closing.
#
# NOTE: Infratools BAD Automation already has a "RunClusterValidation" flow
# (https://infratools.inucn.com/BADAutomation/RunClusterValidation) per the
# "Production Ready Checks 2026" doc. This script is meant as an independent/
# supplementary on-box check, not a replacement for whatever that automation
# already covers - worth comparing notes on overlap.
#
# Usage:
#   sudo ./ProdReadinessCheck-Linux.sh [-r ROLE] [-d DOMAIN] [-c] [-o outfile.csv]
#
#   -r ROLE     Server role tag, purely informational in this script (Linux
#               checklist items are mostly OS-level, not role-specific like
#               the Windows one). Free text, e.g. COR, WEB, API, ASR, CDR.
#   -d DOMAIN   Domain/environment tag, purely informational (e.g. US-Prod,
#               FedRAMP, UK-Sov) - shown in the report header.
#   -c          Also check for the CIS/Rapid7 "auditd compatibility mode"
#               config files (off by default since it's an involved,
#               environment-specific check - see item list below).
#   -o FILE     Write results as CSV to FILE in addition to stdout.
#
# Example:
#   sudo ./ProdReadinessCheck-Linux.sh -r COR -d "US-Prod" -o report.csv

set -uo pipefail

ROLE="Other"
DOMAIN=""
CHECK_AUDITD=0
OUT_CSV=""

while getopts "r:d:co:h" opt; do
    case "$opt" in
        r) ROLE="$OPTARG" ;;
        d) DOMAIN="$OPTARG" ;;
        c) CHECK_AUDITD=1 ;;
        o) OUT_CSV="$OPTARG" ;;
        h)
            grep '^#' "$0" | sed 's/^#//'
            exit 0
            ;;
        *) echo "Unknown option"; exit 1 ;;
    esac
done

RESULTS=()   # each entry: "Item|Status|Detail"

add_result() {
    local item="$1" status="$2" detail="$3"
    RESULTS+=("${item}|${status}|${detail}")
}

have_cmd() { command -v "$1" >/dev/null 2>&1; }

# Detect distro family for the few checks that branch on it
DISTRO_FAMILY="unknown"
if have_cmd rpm && have_cmd yum; then
    DISTRO_FAMILY="rhel"
elif have_cmd dpkg && have_cmd apt-get; then
    DISTRO_FAMILY="debian"
fi

echo "=== Production Ready Check: $(hostname) (Role: $ROLE${DOMAIN:+, Domain: $DOMAIN}) ==="
echo ""

# ---------------------------------------------------------------------------
# 1. Subscription / patchable state (RHEL: subscription-manager; else apt/yum)
# ---------------------------------------------------------------------------
if [ "$DISTRO_FAMILY" = "rhel" ]; then
    if have_cmd subscription-manager; then
        SUB_STATUS=$(subscription-manager status 2>/dev/null | grep -i "Overall Status" || true)
        if echo "$SUB_STATUS" | grep -qi "Current"; then
            add_result "RHEL subscription registered/current" "PASS" "$SUB_STATUS"
        else
            add_result "RHEL subscription registered/current" "FAIL" "${SUB_STATUS:-subscription-manager status did not report Current} - register with subscription-manager (creds in Pleasant)"
        fi
    else
        add_result "RHEL subscription registered/current" "MANUAL" "subscription-manager not found - confirm this box doesn't need one (Amazon Linux, etc.)"
    fi
else
    add_result "Package manager can reach update repos" "MANUAL" "Non-RHEL system - confirm apt/yum update source is reachable (no subscription-manager equivalent check here)"
fi

# ---------------------------------------------------------------------------
# 2. Fully patched
# ---------------------------------------------------------------------------
if [ "$DISTRO_FAMILY" = "rhel" ]; then
    UPDATE_COUNT=$( (yum check-update 2>/dev/null || true) | grep -Ev '^(Loaded plugins|$|Last metadata|Obsoleting|Security:)' | grep -Ec '^\S+\.\S+' )
    if [ "$UPDATE_COUNT" -eq 0 ]; then
        add_result "System fully patched (yum check-update)" "PASS" "No pending updates"
    else
        add_result "System fully patched (yum check-update)" "FAIL" "$UPDATE_COUNT package(s) pending - run yum update and reboot"
    fi
elif [ "$DISTRO_FAMILY" = "debian" ]; then
    apt-get -s upgrade >/tmp/.prodready_apt_sim 2>/dev/null || true
    UPDATE_COUNT=$(grep -c '^Inst ' /tmp/.prodready_apt_sim 2>/dev/null || echo 0)
    rm -f /tmp/.prodready_apt_sim
    if [ "$UPDATE_COUNT" -eq 0 ]; then
        add_result "System fully patched (apt-get -s upgrade)" "PASS" "No pending updates"
    else
        add_result "System fully patched (apt-get -s upgrade)" "FAIL" "$UPDATE_COUNT package(s) pending - run apt-get update && apt-get upgrade and reboot"
    fi
else
    add_result "System fully patched" "MANUAL" "Unknown package manager - check for pending updates manually"
fi

# ---------------------------------------------------------------------------
# 3. Core dumps restricted (/etc/security/limits.conf)
# ---------------------------------------------------------------------------
LIMITS_FILE="/etc/security/limits.conf"
if [ -f "$LIMITS_FILE" ]; then
    if grep -Eq '^\*\s+hard\s+core\s+0' "$LIMITS_FILE" && grep -Eq '^\*\s+soft\s+core\s+0' "$LIMITS_FILE"; then
        add_result "Core dumps restricted" "PASS" "* soft core 0 / * hard core 0 present in $LIMITS_FILE"
    else
        add_result "Core dumps restricted" "FAIL" "Expected '* soft core 0' and '* hard core 0' lines not found in $LIMITS_FILE"
    fi
else
    add_result "Core dumps restricted" "MANUAL" "$LIMITS_FILE not found"
fi

# ---------------------------------------------------------------------------
# 4. Unused services disabled (FTP, DNS, LDAP, SMB, DHCP, NFS, SNMP, etc.)
# ---------------------------------------------------------------------------
UNUSED_SVC_PATTERNS=(vsftpd named bind9 slapd smb nmb dhcpd nfs-server snmpd)
FOUND_ACTIVE=()
if have_cmd systemctl; then
    for svc in "${UNUSED_SVC_PATTERNS[@]}"; do
        if systemctl is-active --quiet "$svc" 2>/dev/null; then
            FOUND_ACTIVE+=("$svc")
        fi
    done
    if [ "${#FOUND_ACTIVE[@]}" -eq 0 ]; then
        add_result "Unused services (FTP/DNS/LDAP/SMB/DHCP/NFS/SNMP) disabled" "PASS" "None of the commonly-unused services are active"
    else
        add_result "Unused services (FTP/DNS/LDAP/SMB/DHCP/NFS/SNMP) disabled" "FAIL" "Active and likely should be reviewed: ${FOUND_ACTIVE[*]}"
    fi
else
    add_result "Unused services disabled" "MANUAL" "systemctl not found - review active services manually"
fi

# ---------------------------------------------------------------------------
# 5. NTP via Chrony, synced to ntp.inucn.com
# ---------------------------------------------------------------------------
if have_cmd chronyc; then
    CHRONY_ACTIVE=0
    if have_cmd systemctl; then
        systemctl is-active --quiet chronyd 2>/dev/null && CHRONY_ACTIVE=1
        systemctl is-active --quiet chrony 2>/dev/null && CHRONY_ACTIVE=1
    fi
    TRACKING=$(chronyc tracking 2>/dev/null || true)
    SOURCES=$(chronyc sources -v 2>/dev/null || true)
    if [ "$CHRONY_ACTIVE" -eq 1 ] && echo "$SOURCES" | grep -qi "inucn.com"; then
        LEAP=$(echo "$TRACKING" | grep -i "Leap status" || true)
        add_result "Chrony running + synced to ntp.inucn.com" "PASS" "Chrony active, ntp.inucn.com in sources. $LEAP"
    elif [ "$CHRONY_ACTIVE" -eq 1 ]; then
        add_result "Chrony running + synced to ntp.inucn.com" "FAIL" "Chrony is running but ntp.inucn.com not found in 'chronyc sources -v' - check /etc/chrony.conf server line"
    else
        add_result "Chrony running + synced to ntp.inucn.com" "FAIL" "chronyc present but chronyd/chrony service not active"
    fi
else
    add_result "Chrony installed and synced to ntp.inucn.com" "FAIL" "chrony not installed - install and point at ntp.inucn.com per checklist"
fi

# ---------------------------------------------------------------------------
# 6. sudoers configured (delegate admin access via sudo, not shared root)
# ---------------------------------------------------------------------------
if [ -f /etc/sudoers ]; then
    SUDOERS_USERS=$(grep -Ev '^\s*#|^\s*$' /etc/sudoers | grep -Ec 'ALL=\(ALL' || true)
    if [ "$SUDOERS_USERS" -gt 0 ]; then
        add_result "sudo configured for admin delegation" "PASS" "$SUDOERS_USERS rule(s) found in /etc/sudoers granting ALL=(ALL)-style access"
    else
        add_result "sudo configured for admin delegation" "MANUAL" "No obvious ALL=(ALL) rules found - review /etc/sudoers and /etc/sudoers.d/ manually (visudo)"
    fi
else
    add_result "sudo configured for admin delegation" "MANUAL" "/etc/sudoers not found"
fi
add_result "Named user accounts (no shared root logins)" "MANUAL" "Confirm against Pleasant Password - each admin should have their own account, root password restricted to Systems group"

# ---------------------------------------------------------------------------
# 7. Firewall disabled (network firewall is provisioned upstream)
# ---------------------------------------------------------------------------
if have_cmd systemctl; then
    if systemctl is-active --quiet firewalld 2>/dev/null; then
        add_result "firewalld disabled" "FAIL" "firewalld is active - checklist expects it disabled (network firewall handles this)"
    elif systemctl is-enabled --quiet firewalld 2>/dev/null; then
        add_result "firewalld disabled" "FAIL" "firewalld is not running but still enabled at boot"
    else
        add_result "firewalld disabled" "PASS" "firewalld not active and not enabled"
    fi
else
    add_result "firewalld disabled" "MANUAL" "systemctl not found - check firewall service manually"
fi

# ---------------------------------------------------------------------------
# 8. SSH banner configured
# ---------------------------------------------------------------------------
SSHD_CONFIG="/etc/ssh/sshd_config"
BANNER_FILE="/etc/ssh/banner.txt"
if [ -f "$BANNER_FILE" ] && grep -q "^!!WARNING!!$\|WARNING" "$BANNER_FILE" 2>/dev/null; then
    BANNER_OK_FILE=1
else
    BANNER_OK_FILE=0
fi
if [ -f "$SSHD_CONFIG" ] && grep -Eq '^\s*Banner\s+' "$SSHD_CONFIG"; then
    BANNER_LINE=$(grep -E '^\s*Banner\s+' "$SSHD_CONFIG" | tail -1)
    if [ "$BANNER_OK_FILE" -eq 1 ]; then
        add_result "SSH login banner configured" "PASS" "$BANNER_LINE, and banner file contains the standard warning text"
    else
        add_result "SSH login banner configured" "FAIL" "$BANNER_LINE points somewhere, but banner file/content wasn't found at $BANNER_FILE with expected warning text - verify path/content"
    fi
else
    add_result "SSH login banner configured" "FAIL" "No 'Banner' directive found in $SSHD_CONFIG"
fi

# ---------------------------------------------------------------------------
# 9. SSH ClientAliveInterval / ClientAliveCountMax (15 min session timeout)
# ---------------------------------------------------------------------------
if [ -f "$SSHD_CONFIG" ]; then
    CAI=$(grep -E '^\s*ClientAliveInterval\s+' "$SSHD_CONFIG" | awk '{print $2}' | tail -1)
    CACM=$(grep -E '^\s*ClientAliveCountMax\s+' "$SSHD_CONFIG" | awk '{print $2}' | tail -1)
    if [ "${CAI:-0}" -eq 300 ] 2>/dev/null && [ "${CACM:-0}" -eq 3 ] 2>/dev/null; then
        add_result "SSH session timeout (ClientAliveInterval/CountMax)" "PASS" "ClientAliveInterval=300, ClientAliveCountMax=3 (~15 min timeout)"
    else
        add_result "SSH session timeout (ClientAliveInterval/CountMax)" "FAIL" "Found ClientAliveInterval=${CAI:-unset}, ClientAliveCountMax=${CACM:-unset} - expected 300 and 3"
    fi
else
    add_result "SSH session timeout (ClientAliveInterval/CountMax)" "MANUAL" "$SSHD_CONFIG not found"
fi

# ---------------------------------------------------------------------------
# 10. GRUB2 password set
# ---------------------------------------------------------------------------
GRUB_USER_CFG="/boot/grub2/user.cfg"
if [ -f "$GRUB_USER_CFG" ]; then
    if grep -q "GRUB2_PASSWORD=grub.pbkdf2.sha512" "$GRUB_USER_CFG" 2>/dev/null; then
        add_result "GRUB2 password set" "PASS" "GRUB2_PASSWORD hash present in $GRUB_USER_CFG"
    else
        add_result "GRUB2 password set" "FAIL" "$GRUB_USER_CFG exists but no GRUB2_PASSWORD hash found"
    fi
else
    add_result "GRUB2 password set" "FAIL" "$GRUB_USER_CFG not found - run 'grub2-setpassword' per checklist (24+ char password, stored in Pleasant)"
fi

# ---------------------------------------------------------------------------
# 11. Rapid7 Insight Agent (ir_agent)
# ---------------------------------------------------------------------------
if have_cmd systemctl; then
    if systemctl is-active --quiet ir_agent 2>/dev/null; then
        IR_VERSION=""
        if [ -d /opt/rapid7/ir_agent ]; then
            IR_VERSION=$(find /opt/rapid7/ir_agent -maxdepth 1 -name "ir_agent-*" 2>/dev/null | head -1)
        fi
        add_result "Rapid7 Insight Agent (ir_agent) running" "PASS" "ir_agent active${IR_VERSION:+ ($IR_VERSION)}"
    else
        add_result "Rapid7 Insight Agent (ir_agent) running" "FAIL" "ir_agent service not active"
    fi
else
    add_result "Rapid7 Insight Agent (ir_agent) running" "MANUAL" "systemctl not found - run 'service ir_agent status' manually"
fi

# ---------------------------------------------------------------------------
# 12. auditd compatibility mode for Rapid7 (optional, -c flag - involved/config-file check)
# ---------------------------------------------------------------------------
if [ "$CHECK_AUDITD" -eq 1 ]; then
    AUDITD_OK=1
    AUDITD_NOTES=()
    if have_cmd systemctl && systemctl is-active --quiet auditd 2>/dev/null; then
        AUDITD_NOTES+=("auditd active")
    else
        AUDITD_OK=0
        AUDITD_NOTES+=("auditd not active")
    fi
    if auditctl -l 2>/dev/null | grep -q "key=execve"; then
        AUDITD_NOTES+=("execve rule (key=execve) present")
    else
        AUDITD_OK=0
        AUDITD_NOTES+=("execve rule (key=execve) NOT found - add to /etc/audit/rules.d/audit.rules")
    fi
    AGENT_CONF="/opt/rapid7/ir_agent/components/insight_agent/common/audit.conf"
    if [ -f "$AGENT_CONF" ] && grep -q '"auditd-compatibility-mode":true' "$AGENT_CONF" 2>/dev/null; then
        AUDITD_NOTES+=("audit.conf compatibility-mode flag present")
    else
        AUDITD_OK=0
        AUDITD_NOTES+=("$AGENT_CONF missing or compatibility-mode flag not set")
    fi
    if [ "$AUDITD_OK" -eq 1 ]; then
        add_result "auditd Rapid7 compatibility mode" "PASS" "${AUDITD_NOTES[*]}"
    else
        add_result "auditd Rapid7 compatibility mode" "FAIL" "${AUDITD_NOTES[*]}"
    fi
else
    add_result "auditd Rapid7 compatibility mode" "SKIP" "Pass -c to run this check (involved, config-file-based - see Linux Hardening Checklist for full procedure)"
fi

# ---------------------------------------------------------------------------
# 13. AV installed - Cybereason
# ---------------------------------------------------------------------------
if have_cmd systemctl; then
    CYBER_UNITS=$(systemctl list-units --all 2>/dev/null | grep -i cyber || true)
    CYBER_ACTIVE=$(echo "$CYBER_UNITS" | grep -i "active" || true)
    if [ -n "$CYBER_ACTIVE" ]; then
        add_result "Cybereason AV installed and running" "PASS" "$(echo "$CYBER_ACTIVE" | head -3 | tr '\n' '; ')"
    elif [ -n "$CYBER_UNITS" ]; then
        add_result "Cybereason AV installed and running" "FAIL" "Cybereason unit(s) found but none active: $(echo "$CYBER_UNITS" | head -3 | tr '\n' '; ')"
    else
        add_result "Cybereason AV installed and running" "FAIL" "No Cybereason systemd units found"
    fi
else
    add_result "Cybereason AV installed and running" "MANUAL" "systemctl not found - run 'systemctl | grep -i cyber' manually"
fi
add_result "Cybereason shows healthy in Cybereason portal" "MANUAL" "Confirm in the Cybereason console, not just local service state"

# ---------------------------------------------------------------------------
# 14. Licensing
# ---------------------------------------------------------------------------
add_result "OS licensing valid" "MANUAL" "Confirm subscription/licensing status is valid for this distro (RHEL subscription status covered above; other distros - confirm per vendor)"

# ---------------------------------------------------------------------------
# 15. Patrol login capability
# ---------------------------------------------------------------------------
if id patrol >/dev/null 2>&1 || getent passwd | grep -qi '^patrol:'; then
    add_result "Patrol account present" "PASS" "A 'patrol' account exists locally - confirm you can actually log in with it"
else
    add_result "Can log in with Patrol" "MANUAL" "No local 'patrol' account found - confirm Patrol access is via AD/LDAP group instead, and test login"
fi

# ---------------------------------------------------------------------------
# 16. iLO/iDRAC DNS documented (physical hosts only - not applicable to VMs/cloud)
# ---------------------------------------------------------------------------
add_result "iLO/iDRAC DNS documented" "MANUAL" "Only applicable to physical hardware - confirm iLO/iDRAC DNS entry exists and is documented if this is bare metal"

# ---------------------------------------------------------------------------
# 17. Notify Linux team of new server (one-time, new-build only)
# ---------------------------------------------------------------------------
add_result "Linux Admins notified of new server" "SKIP" "One-time step for brand-new builds only (email linuxadmins@nice.com) - not a recurring readiness check item"

# ---------------------------------------------------------------------------
# 18. Build request field verification (role/location/name/OS/CPU/RAM/etc.)
# ---------------------------------------------------------------------------
add_result "Build request matches (role/location/name/OS/CPU/RAM/drives/etc.)" "MANUAL" "Compare against the build request Excel attached to the ticket"

# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
echo ""
printf "%-55s %-8s %s\n" "ITEM" "STATUS" "DETAIL"
printf "%-55s %-8s %s\n" "-----------------------------------------------------" "--------" "------"

PASS_COUNT=0
FAIL_COUNT=0
MANUAL_COUNT=0
SKIP_COUNT=0

for row in "${RESULTS[@]}"; do
    IFS='|' read -r item status detail <<< "$row"
    printf "%-55s %-8s %s\n" "$item" "$status" "$detail"
    case "$status" in
        PASS) PASS_COUNT=$((PASS_COUNT+1)) ;;
        FAIL) FAIL_COUNT=$((FAIL_COUNT+1)) ;;
        MANUAL) MANUAL_COUNT=$((MANUAL_COUNT+1)) ;;
        SKIP) SKIP_COUNT=$((SKIP_COUNT+1)) ;;
    esac
done

echo ""
echo "Summary: ${PASS_COUNT} PASS / ${FAIL_COUNT} FAIL / ${MANUAL_COUNT} MANUAL / ${SKIP_COUNT} SKIP"

if [ -n "$OUT_CSV" ]; then
    {
        echo "Item,Status,Detail"
        for row in "${RESULTS[@]}"; do
            IFS='|' read -r item status detail <<< "$row"
            item_csv=$(echo "$item" | sed 's/"/""/g')
            detail_csv=$(echo "$detail" | sed 's/"/""/g')
            echo "\"$item_csv\",\"$status\",\"$detail_csv\""
        done
    } > "$OUT_CSV"
    echo "Results written to $OUT_CSV"
fi