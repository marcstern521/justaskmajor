﻿<#
.SYNOPSIS
  READ-ONLY: find IAM users (and their access keys) for the terminated people, across AWS SSO profiles.

.DESCRIPTION
  For each profile: aws sts get-caller-identity (must be logged in), then ONE `aws iam list-users`
  and match against first.last variants / email local parts built from the Name column of the CSV.
  Any profile that is not logged in or lacks iam:ListUsers shows as UNCHECKED - never read that as clean.
  Does NOT delete anything. Remove IAM users via Infratools (Modify/Restore AWS IAM User) or the console.

.EXAMPLE
  aws sso login --profile ic-prod
  .\Check-AwsUsers.ps1 -Profiles ic-prod,ic-dev,uk-sov,eu-sov-fra,au-sov
#>
param(
    [string]$InputFile = 'C:\Temp\bolivia_177.csv',
    [string[]]$Profiles = @('ic-prod','ic-dev','uk-sov','eu-sov-fra','au-sov'),
    [string]$OutDir = 'C:\Temp\TermCheck'
)
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
if (-not (Get-Command aws -ErrorAction SilentlyContinue)) { throw 'aws CLI not found in PATH' }

function Strip-Accents([string]$t) {
    $n = $t.Normalize([Text.NormalizationForm]::FormD)
    (-join ($n.ToCharArray() | Where-Object { [Globalization.CharUnicodeInfo]::GetUnicodeCategory($_) -ne 'NonSpacingMark' }))
}
function Get-Cands([string]$Name) {
    $clean = (Strip-Accents $Name) -replace "[^A-Za-z\- ']", ' ' -replace '\s+', ' '
    $t = @($clean.Trim().ToLower().Split(' ') | Where-Object { $_ })
    $c = New-Object System.Collections.Generic.List[string]
    if ($t.Count -ge 2) {
        $f = $t[0]
        foreach ($l in @($t[-1], $(if ($t.Count -ge 3) { $t[-2] }), $(if ($t.Count -ge 3) { $t[1] })) | Where-Object { $_ }) { $x = "$f.$l"; if (-not $c.Contains($x)) { $c.Add($x) } }
        $c.Add(($t -join ''))
    }
    @($c)
}
$people = Import-Csv $InputFile | ForEach-Object { $nm = "$($_.Name)".Trim(); if ($nm) { [pscustomobject]@{ Name = $nm; Cands = Get-Cands $nm } } }
Write-Host "Loaded $($people.Count) names" -ForegroundColor Cyan

$rows = New-Object System.Collections.Generic.List[object]
foreach ($p in $Profiles) {
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $id = (& aws sts get-caller-identity --profile $p --output json 2>&1 | Out-String)
    $ok = ($LASTEXITCODE -eq 0)
    if (-not $ok) {
        $ErrorActionPreference = $eap
        Write-Warning "$p : not logged in / not configured  ->  aws sso login --profile $p"
        $rows.Add([pscustomobject]@{ Profile = $p; IamUser = ''; Matches = ''; Created = ''; PwLastUsed = ''; AccessKeys = ''; Status = 'UNCHECKED - not logged in' }); continue
    }
    $acct = ($id | ConvertFrom-Json).Account
    $raw = (& aws iam list-users --profile $p --output json 2>&1 | Out-String)
    $rc = $LASTEXITCODE; $ErrorActionPreference = $eap
    if ($rc -ne 0) {
        Write-Warning "$p ($acct): list-users failed: $($raw.Trim().Split("`n")[0])"
        $rows.Add([pscustomobject]@{ Profile = "$p ($acct)"; IamUser = ''; Matches = ''; Created = ''; PwLastUsed = ''; AccessKeys = ''; Status = 'UNCHECKED - no iam:ListUsers permission' }); continue
    }
    $users = @(($raw | ConvertFrom-Json).Users)
    Write-Host "$p ($acct): $($users.Count) IAM users" -ForegroundColor DarkGray
    $found = 0
    foreach ($u in $users) {
        $un = $u.UserName.ToLower(); $local = ($un -split '@')[0]
        $m = $people | Where-Object { ($_.Cands -contains $un) -or ($_.Cands -contains $local) } | Select-Object -First 1
        if (-not $m) { continue }
        $found++
        $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
        $keysRaw = (& aws iam list-access-keys --user-name $u.UserName --profile $p --output json 2>&1 | Out-String)
        $ErrorActionPreference = $eap
        $keys = ''
        try { $k = @(($keysRaw | ConvertFrom-Json).AccessKeyMetadata); $keys = ($k | ForEach-Object { "$($_.AccessKeyId):$($_.Status)" }) -join ' ; ' } catch { $keys = 'could not list' }
        $rows.Add([pscustomobject]@{ Profile = "$p ($acct)"; IamUser = $u.UserName; Matches = $m.Name; Created = $u.CreateDate; PwLastUsed = $u.PasswordLastUsed; AccessKeys = $keys; Status = 'FOUND' })
    }
    if (-not $found) { $rows.Add([pscustomobject]@{ Profile = "$p ($acct)"; IamUser = ''; Matches = ''; Created = ''; PwLastUsed = ''; AccessKeys = ''; Status = 'checked - none' }) }
}
$out = Join-Path $OutDir ("Aws_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$rows | Export-Csv $out -NoTypeInformation
$rows | Format-Table -AutoSize -Wrap
Write-Host "Report: $out" -ForegroundColor Green
Write-Host 'FOUND rows: review the match (name-based), then remove via Infratools > Modify/Restore AWS IAM User or the console. UNCHECKED rows are NOT clean.'