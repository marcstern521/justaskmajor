<#
.SYNOPSIS
  AD termination for ONE domain per run: find the people, you review, then DISABLE (never delete).
  Use for inucn.com, in.lab and ineur.eu from your laptop, and for incmp.com (FedRAMP) from cva-indco01.

.DESCRIPTION
  Per approved user it does, in this order:  1) saves a rollback record  2) disables the account
  3) sets Description to "Terminated <date> <ticket>"  4) removes group memberships (not the primary group)
  5) moves the account to the Terminated Users OU.
  It NEVER deletes accounts, mailboxes, profiles or tokens. Dry run unless -Execute.

  STEP 1  Find:     -NamesFile  -> writes Candidates_<domain>_<stamp>.csv  (read-only). Open it, delete any row that is
                    wrong or not approved, and fix any person with several matches.
  STEP 2  Dry run:  -ApprovedCsv <the reviewed file>                       (shows exactly what would change)
  STEP 3  Execute:  -ApprovedCsv <file> -Execute -Ticket <SCTASK/CHG>      (asks you to type DISABLE)

  Rollback record: C:\Temp\TermAD\Rollback_<domain>_<stamp>.csv has each account's old state, OU and full group list.

.EXAMPLE  (laptop)
  .\Disable-TermAdUsers.ps1 -Domain inucn.com -NamesFile C:\Temp\term-names-20261103.csv
  .\Disable-TermAdUsers.ps1 -Domain inucn.com -ApprovedCsv C:\Temp\TermAD\Candidates_inucn.com_<stamp>.csv
  .\Disable-TermAdUsers.ps1 -Domain inucn.com -ApprovedCsv <same file> -Execute -Ticket SCTASK0000000

.EXAMPLE  (FedRAMP, run ON cva-indco01 with your own logon)
  .\Disable-TermAdUsers.ps1 -Domain incmp.com -UseCurrentLogon -NamesFile C:\Temp\term-names-20261103.csv

.NOTES
  Needs the ActiveDirectory module (RSAT). Prompts for a login unless -UseCurrentLogon.
  INCMP accounts are often named first.last-###### so the finder also looks for that pattern.
  AuthLite tokens (INCMP): this script only LISTS who has an INCMP account in AuthLite_Users_<stamp>.csv. You remove the
  tokens by hand in Token Manager on cva-indco01, as the Confluence page says.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('inucn.com','in.lab','ineur.eu','incmp.com')][string]$Domain,
    [string]$NamesFile,                 # step 1: CSV with a Name column, or a text file with one "First Last" per line
    [string]$ApprovedCsv,               # step 2/3: the reviewed Candidates file
    [string]$Server,                    # DC name or IP; defaults to the known DC for inucn.com / in.lab
    [switch]$UseCurrentLogon,
    [string]$TerminatedOuDN,            # exact DN if the OU is not found by name
    [string]$TerminatedOuName = 'Terminated Users',
    [switch]$Execute,
    [string]$Ticket,
    [string]$OutDir = 'C:\Temp\TermAD'
)
$ErrorActionPreference = 'Stop'
Import-Module ActiveDirectory
if (-not $NamesFile -and -not $ApprovedCsv) { throw 'Give -NamesFile (find) or -ApprovedCsv (dry run / execute).' }
# Your laptop authenticates to these DCs by IP (same ones Find-AdUser and Ops Hub use). Domain-name lookups fail with 'Authentication failed'.
$dcMap = @{ 'inucn.com' = '10.244.88.62'; 'in.lab' = '172.20.34.100'; 'ineur.eu' = 'mun-indco01.ineur.eu' }
# Name alternatives if the IP will not authenticate: -Server lax-indco01.inucn.com | ena-indco01.in.lab | mun-indco01.ineur.eu
if (-not $Server) { $Server = $(if ($dcMap.ContainsKey($Domain)) { $dcMap[$Domain] } else { $Domain }) }
if (-not $Server -or ($Domain -eq 'ineur.eu' -and $Server -eq 'ineur.eu')) { Write-Host 'Tip: for ineur.eu pass -Server <a DC IP or name, e.g. a mun/fra DC> if the domain name will not authenticate.' -ForegroundColor Yellow }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$base = @{ Server = $Server }
if (-not $UseCurrentLogon) { $base.Credential = (Get-Credential -Message "Login for $Domain") }
function Esc([string]$s) { ($s -replace '\\', '\5c' -replace '\*', '\2a' -replace '\(', '\28' -replace '\)', '\29' -replace "'", "''").Trim() }
$props = 'Enabled','MemberOf','Description','mail','LastLogonDate','Title','Department','whenCreated'

# ---------------- STEP 1: FIND ----------------
if ($NamesFile) {
    $names = @()
    if ($NamesFile -match '\.csv$') { $names = @(Import-Csv -LiteralPath $NamesFile | ForEach-Object { $_.Name } | Where-Object { $_ }) }
    else { $names = @(Get-Content -LiteralPath $NamesFile | Where-Object { $_.Trim() }) }
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($n in $names) {
        $n = $n.Trim()
        $parts = ($n -replace "'", '' -replace '\.', '') -split '\s+'
        $first = Esc $parts[0]; $last = Esc $parts[-1]; $full = Esc $n
        $rest = Esc (($parts | Select-Object -Skip 1) -join '')     # "Junaid P C" -> Junaid.PC
        $f = "(DisplayName -eq '$full') -or (Name -eq '$full') -or (GivenName -eq '$first' -and Surname -eq '$last') -or (SamAccountName -like '$first.$last*') -or (SamAccountName -like '$first.$rest*') -or (mail -like '$first.$last@*') -or (mail -like '$first.$rest@*') -or (UserPrincipalName -like '$first.$last@*') -or (UserPrincipalName -like '$first.$rest@*')"
        $hits = @(Get-ADUser @base -Filter $f -Properties $props)
        if (-not $hits.Count) { $rows.Add([pscustomobject]@{ Approve = 'N'; InputName = $n; Domain = $Domain; Sam = ''; DisplayName = ''; Enabled = ''; Mail = ''; LastLogon = ''; Title = ''; Groups = ''; DN = ''; Note = 'NO MATCH in this domain' }); continue }
        foreach ($u in $hits) {
            $rows.Add([pscustomobject]@{
                Approve = $(if ($hits.Count -eq 1) { 'Y' } else { 'N' }); InputName = $n; Domain = $Domain; Sam = $u.SamAccountName; DisplayName = $u.DisplayName
                Enabled = $u.Enabled; Mail = $u.mail; LastLogon = $u.LastLogonDate; Title = $u.Title; Groups = @($u.MemberOf).Count
                DN = $u.DistinguishedName; Note = $(if ($hits.Count -gt 1) { "MULTIPLE matches ($($hits.Count)): set Approve=Y only on the right one" } elseif (-not $u.Enabled) { 'Already disabled' } else { '' })
            })
        }
    }
    $out = Join-Path $OutDir "Candidates_${Domain}_$stamp.csv"
    $rows | Export-Csv $out -NoTypeInformation -Encoding UTF8
    $rows | Format-Table Approve, InputName, Sam, Enabled, Groups, Note -AutoSize
    Write-Host "Saved: $out" -ForegroundColor Green
    Write-Host 'Open it, make sure Approve is Y only for the right accounts (or delete the other rows), then run with -ApprovedCsv.' -ForegroundColor Cyan
    if ($Domain -eq 'incmp.com') {
        $al = Join-Path $OutDir "AuthLite_Users_$stamp.csv"
        $rows | Where-Object { $_.Sam } | Select-Object InputName, Sam, DN | Export-Csv $al -NoTypeInformation -Encoding UTF8
        Write-Host "AuthLite list (remove tokens by hand in Token Manager on cva-indco01): $al" -ForegroundColor Cyan
    }
    return
}

# ---------------- STEP 2/3: DRY RUN / EXECUTE ----------------
$todo = @(Import-Csv -LiteralPath $ApprovedCsv | Where-Object { $_.DN -and $_.Approve -eq 'Y' -and $_.Domain -eq $Domain })
if (-not $todo.Count) { throw "No approved rows for $Domain in $ApprovedCsv (need Approve=Y, a DN, and Domain=$Domain)." }
if ($Execute -and -not $Ticket) { throw 'Add -Ticket (SCTASK/CHG number) so the account Description and the log show why.' }

# Terminated OU
$termOu = $null
if ($TerminatedOuDN) { $termOu = Get-ADObject @base -Identity $TerminatedOuDN }
else { $termOu = Get-ADObject @base -Filter "Name -eq '$TerminatedOuName' -or Name -eq 'TerminatedUsers'" | Where-Object ObjectClass -in 'organizationalUnit','container' | Select-Object -First 1 }
if (-not $termOu) { throw "Terminated Users OU not found in $Domain. Re-run with -TerminatedOuDN '<exact DN>'." }
Write-Host "Domain: $Domain   Server: $Server   Terminated OU: $($termOu.DistinguishedName)" -ForegroundColor Cyan
Write-Host ("{0} approved account(s). Mode: {1}" -f $todo.Count, $(if ($Execute) { 'EXECUTE' } else { 'DRY RUN' })) -ForegroundColor Cyan

# resolve and show first
$plan = foreach ($r in $todo) {
    try {
        $u = Get-ADUser @base -Identity $r.DN -Properties $props
        [pscustomobject]@{ Row = $r; User = $u; Error = '' }
    } catch { [pscustomobject]@{ Row = $r; User = $null; Error = $_.Exception.Message } }
}
$plan | ForEach-Object {
    if ($_.User) { Write-Host ("  {0,-28} enabled={1}  groups={2}  OU={3}" -f $_.User.SamAccountName, $_.User.Enabled, @($_.User.MemberOf).Count, ($_.User.DistinguishedName -replace '^CN=[^,]+,','')) }
    else { Write-Host ("  NOT FOUND: {0} ({1})" -f $_.Row.DN, $_.Error) -ForegroundColor Red }
}
if (-not $Execute) { Write-Host "`nDRY RUN: nothing changed. Add -Execute -Ticket <number> to disable these accounts." -ForegroundColor Yellow; return }

$ans = Read-Host "Type DISABLE to disable $(@($plan | Where-Object User).Count) account(s) in $Domain"
if ($ans -cne 'DISABLE') { Write-Host 'Cancelled. Nothing changed.' -ForegroundColor Yellow; return }

# rollback record FIRST. Abort if it cannot be written.
$rbFile = Join-Path $OutDir "Rollback_${Domain}_$stamp.csv"
$plan | Where-Object User | ForEach-Object {
    $u = $_.User
    [pscustomobject]@{ Domain = $Domain; Sam = $u.SamAccountName; OriginalDN = $u.DistinguishedName; WasEnabled = $u.Enabled; Description = $u.Description
                       Groups = (@($u.MemberOf) -join ';'); LoggedAt = (Get-Date).ToString('s'); Ticket = $Ticket }
} | Export-Csv $rbFile -NoTypeInformation -Encoding UTF8
if (-not (Test-Path $rbFile)) { throw 'Could not write the rollback file. Stopping before any change.' }
Write-Host "Rollback record: $rbFile" -ForegroundColor Green

$log = New-Object System.Collections.Generic.List[object]
foreach ($p in $plan) {
    if (-not $p.User) { $log.Add([pscustomobject]@{ Sam = $p.Row.Sam; Disabled = ''; GroupsRemoved = ''; Moved = ''; Result = "NOT FOUND: $($p.Error)" }); continue }
    $u = $p.User; $sam = $u.SamAccountName
    $dis = ''; $grp = 0; $mv = ''; $err = @()
    try { if ($u.Enabled) { Disable-ADAccount @base -Identity $u.DistinguishedName; $dis = 'Disabled' } else { $dis = 'Was already disabled' } } catch { $err += "disable: $($_.Exception.Message)"; $dis = 'FAILED' }
    try { $old = if ($u.Description) { " (was: $($u.Description))" } else { '' }; Set-ADUser @base -Identity $u.DistinguishedName -Description ("Terminated {0} {1}{2}" -f (Get-Date -Format 'yyyy-MM-dd'), $Ticket, $old) } catch { $err += "description: $($_.Exception.Message)" }
    foreach ($g in @($u.MemberOf)) {
        try { Remove-ADGroupMember @base -Identity $g -Members $u.DistinguishedName -Confirm:$false; $grp++ } catch { $err += "group $g : $($_.Exception.Message)" }
    }
    try { Move-ADObject @base -Identity $u.DistinguishedName -TargetPath $termOu.DistinguishedName; $mv = 'Moved' } catch { $err += "move: $($_.Exception.Message)"; $mv = 'FAILED' }
    $log.Add([pscustomobject]@{ Sam = $sam; Disabled = $dis; GroupsRemoved = $grp; Moved = $mv; Result = $(if ($err.Count) { $err -join ' | ' } else { 'OK' }) })
    Write-Host ("  {0,-28} {1}  groups removed {2}  {3}" -f $sam, $dis, $grp, $mv)
}
$logFile = Join-Path $OutDir "Result_${Domain}_$stamp.csv"
$log | Export-Csv $logFile -NoTypeInformation -Encoding UTF8
$bad = @($log | Where-Object { $_.Result -ne 'OK' })
Write-Host ("`nDone. {0} account(s) processed, {1} with a problem. Log: {2}" -f $log.Count, $bad.Count, $logFile) -ForegroundColor $(if ($bad.Count) { 'Yellow' } else { 'Green' })
