# ============================================================
# GS - Script 9 - Inventory audit (read-only)
# Compares the versions on the Confluence page "Globalscape Inventory and Versions"
# with what is actually installed on each server (registry DisplayVersion).
# The page's server list and versions are in Globalscape_Inventory_Expected.csv
# (same folder). Edit the CSV if the page changes. Fqdn column is optional - use it
# for servers that are not in the default domain (sovereign, FedRAMP, lab, ...).
# Manual column = yes: the script does not touch that server (MFA / not reachable) and
# lists it for a manual check on the box instead.
#
# Example:
#   .\GS_9_Inventory_Audit.ps1                                  # everything in the CSV
#   .\GS_9_Inventory_Audit.ps1 -Only sgp-incdr01,ty6-incdr01    # a few servers
#   .\GS_9_Inventory_Audit.ps1 -Only ausya-incdr01 -Domain cxsov1.uk -Credential (Get-Credential)
# ============================================================
[CmdletBinding()]
param(
    [string]$InventoryCsv = "$PSScriptRoot\Globalscape_Inventory_Expected.csv",
    [string[]]$Only,
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
if (-not (Test-Path $InventoryCsv)) { throw "Inventory CSV not found: $InventoryCsv" }

$rows = @(Import-Csv $InventoryCsv)
if ($Only) { $rows = @($rows | Where-Object { $Only -contains $_.Server }) }
if ($rows.Count -eq 0) { throw 'No servers to check (check -Only against the CSV)' }

$Credential = Get-GSCredential $Credential
Start-GSLog -Name 'inventory_audit'
Write-Log "=== Inventory audit: $($rows.Count) server(s) ===" Cyan

$report = @()
$n = 0
foreach ($r in $rows) {
    $n++
    $fqdn = if ($r.Fqdn) { $r.Fqdn } else { Resolve-GSHost $r.Server $Domain }
    Write-Log "[$n/$($rows.Count)] $($r.Server) ($($r.Role))"
    if ($r.Manual -eq 'yes') {
        Write-Log '   MANUAL REVIEW (MFA / not reachable from here) - skipped' Yellow
        $report += [pscustomobject]@{
            Server = $r.Server; Role = $r.Role; PageVersion = $r.Expected; ActualVersion = ''
            Status = 'MANUAL REVIEW'; Edition = ''; Service = ''; Note = 'check on the server'
        }
        continue
    }
    $actual = $null; $edition = ''; $state = ''; $note = ''
    try {
        $s = New-PSSession -ComputerName $fqdn -Credential $Credential -ErrorAction Stop
        if ($r.Role -eq 'DMZ') { $i = Get-DMZInfo -Session $s; $edition = 'DMZ Gateway' }
        else                   { $i = Get-EFTInfo -Session $s; $edition = "$($i.AppName)" }
        Remove-PSSession $s
        $actual = "$($i.Version)"; $state = "$($i.ServiceState)"
    } catch {
        $note = "$($_.Exception.Message)" -replace '\s+', ' '
        if ($note.Length -gt 90) { $note = $note.Substring(0, 90) + '...' }
    }

    $exp = ConvertTo-GSVersion $r.Expected
    $act = ConvertTo-GSVersion $actual
    $status =
        if     ($null -eq $actual -and $note) { 'UNREACHABLE' }
        elseif (-not $act)                    { 'VERSION UNREADABLE' }
        elseif (-not $exp)                    { 'NOT LISTED ON PAGE' }
        elseif ($exp -eq $act)                { 'Match' }
        else                                  { 'MISMATCH' }

    $color = if ($status -eq 'Match') { 'Green' } elseif ($status -eq 'MISMATCH') { 'Red' } else { 'Yellow' }
    Write-Log ("   page: {0,-10} actual: {1,-10} {2} {3}" -f $r.Expected, $actual, $status, $note) $color
    $report += [pscustomobject]@{
        Server = $r.Server; Role = $r.Role; PageVersion = $r.Expected; ActualVersion = $actual
        Status = $status; Edition = $edition; Service = $state; Note = $note
    }
}

$csv = Join-Path $script:WorkDir ('inventory_audit_{0}.csv' -f (Get-Date -Format 'yyyyMMdd-HHmm'))
$report | Export-Csv -Path $csv -NoTypeInformation
Write-Host ''
$report | Format-Table Server, Role, PageVersion, ActualVersion, Status, Edition -AutoSize

Write-Host '=== Summary ===' -ForegroundColor Cyan
$report | Group-Object Status | Sort-Object Name | ForEach-Object { '{0,-20} {1}' -f $_.Name, $_.Count }

$fix = @($report | Where-Object { $_.Status -in 'MISMATCH', 'NOT LISTED ON PAGE' })
if ($fix.Count) {
    Write-Host "`nPage needs updating:" -ForegroundColor Yellow
    $fix | ForEach-Object { '  {0}: page says "{1}", actual {2}' -f $_.Server, $_.PageVersion, $_.ActualVersion }
}
$man = @($report | Where-Object { $_.Status -eq 'MANUAL REVIEW' })
if ($man.Count) {
    Write-Host "`nManual review - RDP to each, run the snippet below, and note the version:" -ForegroundColor Yellow
    $man | ForEach-Object { '  {0}  (page says: {1})' -f $_.Server, $(if ($_.PageVersion) { $_.PageVersion } else { 'not listed' }) }
    Write-Host @'

  $u = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
  Get-ChildItem $u -ErrorAction SilentlyContinue | Get-ItemProperty -ErrorAction SilentlyContinue |
      Where-Object { $_.DisplayName -like '*EFT*' -or $_.DisplayName -like '*DMZ Gateway*' } | Select-Object DisplayName, DisplayVersion
  Get-CimInstance Win32_Service | Where-Object { $_.Name -like 'EFT Server*' -or $_.DisplayName -like '*DMZ*' } | Select-Object Name, State, PathName
  $env:COMPUTERNAME
'@ -ForegroundColor Gray
}
$bad = @($report | Where-Object { $_.Status -in 'UNREACHABLE', 'VERSION UNREADABLE' })
if ($bad.Count) {
    Write-Host "`nCould not verify (different domain / credentials / firewall?):" -ForegroundColor Yellow
    $bad | ForEach-Object { '  {0}  {1}' -f $_.Server, $_.Note }
    Write-Host "Re-run those with -Only <names> and the right -Domain / -Credential, or add an Fqdn to the CSV." -ForegroundColor Yellow
}
Write-Log "Report saved to $csv" Green
