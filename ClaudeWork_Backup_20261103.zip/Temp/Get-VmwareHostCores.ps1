<#
.SYNOPSIS
  READ-ONLY. For each vCenter, lists every ESXi host that runs Windows VMs (Ativa excluded) with its PHYSICAL socket and
  core counts, then totals per cluster and per vCenter. Changes nothing.

.DESCRIPTION
  Needs VMware PowerCLI on the machine you run it from (the laptop has it; the FedRAMP jump server does not unless you copy
  the module folder there). Login: prod = your INUCN login, FedRAMP = your FedRAMP vCenter account. Passwords are only typed at the prompt.

  - Physical cores = sockets x cores per socket as the host reports them (hyper-threads NOT counted).
  - "Has Windows" = at least one non-template VM whose guest OS is Windows (use -PoweredOnOnly to count only powered-on VMs).
  - Ativa is excluded by matching -ExcludePattern (regex, default 'ativa') against datacenter, cluster and host name.
    Excluded hosts are written to their own CSV so you can confirm the match is right.
  - LicensableCores is INFORMATION ONLY, using the usual Windows Server per-core rule (8 per processor, 16 per host minimum).
    Confirm the rule and any datacenter-edition or Software Assurance terms with your licensing owner.

.EXAMPLE
  .\Get-VmwareHostCores.ps1
  .\Get-VmwareHostCores.ps1 -VCenter lax-vmvce01.inucn.com
  .\Get-VmwareHostCores.ps1 -VCenter cul-vmvce01.incmp.com -PoweredOnOnly
  .\Get-VmwareHostCores.ps1 -ExcludePattern 'ativa|ativ'
#>
param(
    [string[]]$VCenter = @('lax-vmvce01.inucn.com', 'cul-vmvce01.incmp.com'),
    [string]$ExcludePattern = 'ativa',
    [switch]$PoweredOnOnly,
    [string]$OutDir = 'C:\Temp\VmwareCores'
)
$ErrorActionPreference = 'Stop'
if (-not (Get-Module -ListAvailable -Name VMware.VimAutomation.Core)) {
    throw 'VMware PowerCLI not found here. Run this from the laptop, or copy the VMware.* module folders to this server (Install-Module VMware.PowerCLI -Scope CurrentUser).'
}
Import-Module VMware.VimAutomation.Core
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope Session -Confirm:$false -ParticipateInCEIP $false | Out-Null
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -Force | Out-Null }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$all = New-Object System.Collections.Generic.List[object]

foreach ($vc in $VCenter) {
    Write-Host "`n=== $vc ===" -ForegroundColor Cyan
    $cred = Get-Credential -Message "Login for $vc (read-only is fine)"
    try { $null = Connect-VIServer -Server $vc -Credential $cred -ErrorAction Stop }
    catch { Write-Warning "Could not connect to $vc : $($_.Exception.Message.Split([char]10)[0])"; continue }
    try {
        # one call for all VMs, grouped by host
        $views = Get-View -ViewType VirtualMachine -Property Name, Runtime.Host, Runtime.PowerState, Config.Template, Config.GuestId, Config.GuestFullName
        $byHost = @{}
        foreach ($v in $views) {
            if (-not $v.Config -or $v.Config.Template -or -not $v.Runtime.Host) { continue }
            $isWin = ("$($v.Config.GuestId)" -match '^windows') -or ("$($v.Config.GuestFullName)" -match 'Windows')
            $k = $v.Runtime.Host.Value
            if (-not $byHost.ContainsKey($k)) { $byHost[$k] = @{ WinTotal = 0; WinOn = 0; OtherTotal = 0 } }
            if ($isWin) {
                $byHost[$k].WinTotal++
                if ("$($v.Runtime.PowerState)" -eq 'poweredOn') { $byHost[$k].WinOn++ }
            } else { $byHost[$k].OtherTotal++ }
        }
        foreach ($dc in (Get-Datacenter | Sort-Object Name)) {
            foreach ($h in (Get-VMHost -Location $dc | Sort-Object Name)) {
                $ci = $h.ExtensionData.Hardware.CpuInfo
                $sockets = [int]$ci.NumCpuPackages
                $cores = [int]$ci.NumCpuCores
                $threads = [int]$ci.NumCpuThreads
                $perSocket = if ($sockets) { [int]($cores / $sockets) } else { 0 }
                $cluster = ''
                if ($h.Parent -and $h.Parent.GetType().Name -match 'Cluster') { $cluster = $h.Parent.Name }
                $c = $byHost[$h.ExtensionData.MoRef.Value]
                $winTotal = if ($c) { $c.WinTotal } else { 0 }
                $winOn = if ($c) { $c.WinOn } else { 0 }
                $other = if ($c) { $c.OtherTotal } else { 0 }
                $hasWin = if ($PoweredOnOnly) { $winOn -gt 0 } else { $winTotal -gt 0 }
                $isAtiva = ("$($dc.Name)|$cluster|$($h.Name)" -match $ExcludePattern)
                $status = if ($isAtiva) { 'EXCLUDED (Ativa)' } elseif (-not $hasWin) { 'No Windows VMs' } else { 'INCLUDED' }
                $lic = if ($sockets) { [math]::Max(16, $sockets * [math]::Max(8, $perSocket)) } else { 0 }
                $all.Add([pscustomobject]@{
                    vCenter = $vc; Datacenter = $dc.Name; Cluster = $cluster; Host = $h.Name
                    Status = $status; State = "$($h.ConnectionState)"
                    Model = $h.Model; CpuModel = ($h.ProcessorType -replace '\s+', ' ')
                    Sockets = $sockets; CoresPerSocket = $perSocket; PhysicalCores = $cores; Threads = $threads
                    LicensableCores = $lic
                    WindowsVMs = $winTotal; WindowsVMsPoweredOn = $winOn; OtherVMs = $other
                    ESXi = "$($h.Version) build $($h.Build)"
                })
            }
        }
        Write-Host ("Read {0} host(s)." -f @($all | Where-Object vCenter -eq $vc).Count) -ForegroundColor DarkGray
    }
    finally { Disconnect-VIServer -Server $vc -Confirm:$false -ErrorAction SilentlyContinue }
}

if (-not $all.Count) { throw 'No hosts were read. Check the connection errors above.' }
$f1 = Join-Path $OutDir "VmwareHostCores_All_$stamp.csv"
$f2 = Join-Path $OutDir "VmwareHostCores_Included_$stamp.csv"
$f3 = Join-Path $OutDir "VmwareHostCores_ExcludedAtiva_$stamp.csv"
$f4 = Join-Path $OutDir "VmwareHostCores_ByCluster_$stamp.csv"
$inc = @($all | Where-Object Status -eq 'INCLUDED')
$all | Export-Csv -NoTypeInformation -Path $f1
$inc | Export-Csv -NoTypeInformation -Path $f2
@($all | Where-Object Status -like 'EXCLUDED*') | Export-Csv -NoTypeInformation -Path $f3
$byCluster = $inc | Group-Object vCenter, Datacenter, Cluster | ForEach-Object {
    $g = $_.Group
    [pscustomobject]@{
        vCenter = $g[0].vCenter; Datacenter = $g[0].Datacenter; Cluster = $g[0].Cluster; Hosts = $g.Count
        Sockets = ($g | Measure-Object Sockets -Sum).Sum
        PhysicalCores = ($g | Measure-Object PhysicalCores -Sum).Sum
        LicensableCores = ($g | Measure-Object LicensableCores -Sum).Sum
        WindowsVMs = ($g | Measure-Object WindowsVMs -Sum).Sum
    }
} | Sort-Object vCenter, Datacenter, Cluster
$byCluster | Export-Csv -NoTypeInformation -Path $f4

Write-Host "`nPer cluster (hosts with Windows VMs, Ativa excluded):" -ForegroundColor Cyan
$byCluster | Format-Table vCenter, Cluster, Hosts, Sockets, PhysicalCores, LicensableCores, WindowsVMs -AutoSize
Write-Host 'Per vCenter:' -ForegroundColor Cyan
$inc | Group-Object vCenter | ForEach-Object {
    $g = $_.Group
    [pscustomobject]@{
        vCenter = $_.Name; Hosts = $g.Count
        Sockets = ($g | Measure-Object Sockets -Sum).Sum
        PhysicalCores = ($g | Measure-Object PhysicalCores -Sum).Sum
        LicensableCores = ($g | Measure-Object LicensableCores -Sum).Sum
    }
} | Format-Table -AutoSize
$ex = @($all | Where-Object Status -like 'EXCLUDED*'); $nw = @($all | Where-Object Status -eq 'No Windows VMs')
Write-Host ("Excluded as Ativa: {0} host(s). Hosts with no Windows VMs: {1}. Hosts not connected: {2}." -f $ex.Count, $nw.Count, @($all | Where-Object { $_.State -ne 'Connected' }).Count) -ForegroundColor Yellow
Write-Host "Check which clusters were treated as Ativa: $f3" -ForegroundColor Yellow
Write-Host "`nFiles:`n  $f2`n  $f4`n  $f1`n  $f3" -ForegroundColor Green
