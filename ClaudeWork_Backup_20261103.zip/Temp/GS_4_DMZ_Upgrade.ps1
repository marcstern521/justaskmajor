# ============================================================
# GS - Script 4 - DMZ Gateway Upgrade
# Runbook order: DMZ Gateway FIRST, then the paired EFT server
# (Fortra support guidance). Single hop to 4.x.
#
# Example:
#   .\GS_4_DMZ_Upgrade.ps1 -DmzServer aaa-inftp01 -EftServer aaa-ineft01 -ChangeRef CHG0177747
# ============================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$DmzServer,
    [string]$EftServer = '(paired EFT server)',
    [string]$ChangeRef = '',
    [string]$InstallerName = 'dmz-gateway-windows-x86-64.exe',
    [string]$RemoteDir = 'D:\temp',
    [int]$InstallTimeoutMinutes = 30,
    [switch]$Force,
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
$Credential = Get-GSCredential $Credential
$Target     = Resolve-GSHost $DmzServer $Domain
$Installer  = '{0}\{1}' -f $RemoteDir.TrimEnd('\'), $InstallerName
Start-GSLog -Name ('dmz_upgrade_{0}' -f ($DmzServer -split '\.')[0])

Write-Log '=== DMZ Gateway upgrade started ===' Cyan
Write-Log "Target: $Target   Change: $ChangeRef"

$s = New-PSSession -ComputerName $Target -Credential $Credential -ErrorAction Stop

# --- Pre-checks ---
$before = Get-DMZInfo -Session $s
$ver    = ConvertTo-GSVersion $before.Version
Write-Log "Current DMZ version: $($before.Version)"
Write-Log "Service: $($before.ServiceName) - $($before.ServiceState) / account $($before.ServiceAccount)"

if (-not $before.ServiceName) { Write-Log 'DMZ Gateway service not found - is this the right server?' Red; exit 1 }
if ($ver -and $ver -ge $script:DMZTarget -and -not $Force) {
    Write-Log "Already on $($before.Version) - nothing to do (use -Force to reinstall)" Yellow
    exit 0
}

$exists = Invoke-Command -Session $s -ScriptBlock { param($p) Test-Path $p } -ArgumentList $Installer
if (-not $exists) {
    Write-Log "Installer not found at $Installer on $Target - run GS_3_Push_Installers.ps1 first" Red
    exit 1
}

# --- Confirm ---
Write-Host "`n*** PRODUCTION SERVER ***" -ForegroundColor Red
Write-Host "   Target:  $Target (DMZ Gateway), currently $($before.Version)" -ForegroundColor Yellow
Write-Host '   Before you type YES:' -ForegroundColor Yellow
Write-Host '     - Snapshot taken (GS_2) and CR window is active' -ForegroundColor Yellow
Write-Host '     - Task Manager shows NO active transfers' -ForegroundColor Yellow
Write-Host '     - DMZ admin interface is closed' -ForegroundColor Yellow
if (-not (Confirm-Typed 'Begin DMZ upgrade?' 'YES')) { Write-Log 'Cancelled by user' Yellow; exit 0 }

# --- Install ---
Write-Log 'Running DMZ Gateway installer (silent)...'
Write-Log "If it hangs: kill the process in Task Manager, RDP in and run $Installer manually without /S"
$r = Invoke-GSInstaller -Session $s -Path $Installer -InstallerArgs '/S' -TimeoutMinutes $InstallTimeoutMinutes
if ($r.TimedOut) {
    Write-Log "Installer still running after $InstallTimeoutMinutes minutes - NOT killed. RDP in, check Task Manager, kill it and run manually." Red
    exit 1
}
Write-Log "Installer exit code: $($r.ExitCode)"

# --- Post-install ---
Start-Sleep -Seconds 15
$running = Wait-GSService -Session $s -Name $before.ServiceName -TimeoutSec 180
$after   = Get-DMZInfo -Session $s
Write-Log "Post-upgrade: version $($after.Version), service $($after.ServiceName) - $($after.ServiceState)" $(if ($running) { 'Green' } else { 'Red' })
if (-not $running) { Write-Log 'DMZ service is not Running - check Services.msc / event log before going further' Red }

if ($after.ServiceAccount -ne $before.ServiceAccount) {
    Write-Log "Service account CHANGED: was '$($before.ServiceAccount)', now '$($after.ServiceAccount)' - set it back in Services.msc" Yellow
}

# --- Manual verification (runbook: Post-DMZ Upgrade Checklist) ---
Write-Host "`n================================================================" -ForegroundColor Magenta
Write-Host '  MANUAL STEP - DMZ upgrade validation' -ForegroundColor Magenta
Write-Host '================================================================' -ForegroundColor Magenta
Write-Host "  1. DMZ service Running, version confirmed in admin console on $Target" -ForegroundColor White
Write-Host '  2. Service account is correct (not accidentally reset to Local System)' -ForegroundColor White
Write-Host "  3. On $EftServer in EFT Admin Console: Server > Gateway shows Connected" -ForegroundColor White
Write-Host "  4. WinSCP SFTP test connection on port 22 works end to end" -ForegroundColor White
Write-Host "================================================================`n" -ForegroundColor Magenta

if ((Read-Host 'Type OK when verified, or ABORT if there are issues') -eq 'ABORT') {
    Write-Log 'Issues reported after DMZ upgrade - investigate' Red
    Write-Log 'Rollback: revert snapshot Pre-Globalscape-Upgrade-<date> in vCenter (EC2: restore from EBS snapshot/AMI)' Yellow
    exit 1
}

Remove-PSSession $s
Write-Log "DMZ upgrade on $Target confirmed" Green
Write-Log "Next: GS_5_EFT_Hop_Upgrade.ps1 -EftServer <paired EFT> -DmzServer $DmzServer" Cyan
