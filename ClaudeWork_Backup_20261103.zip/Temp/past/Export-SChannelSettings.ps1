﻿#
# ===================================================================
# Purpose:           Export Registry Settings for TLS 1.0, 1.1, 1.2, SSLv2 & SSLv3
# Parameters:        
# Called From:       Manual or from Get-TLS_SSLVersions Script
# User Account:      
# Author:            Bryan Grider
# Notes:             
#                    
# Revision:
#             Created:           7/22/2020
# ===================================================================
#


#region Notes
#    Get the following Registry values and Export
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client\DisabledByDefault
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server\DisabledByDefault

#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client\DisabledByDefault
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server\DisabledByDefault

#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client\DisabledByDefault
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server\DisabledByDefault

#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client\DisabledByDefault
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server\DisabledByDefault

#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client\DisabledByDefault
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server\Enabled
#    SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server\DisabledByDefault

#    SOFTWARE\Microsoft\.NETFramework\v2.0.50727\SchUseStrongCrypto
#    SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v2.0.50727\SchUseStrongCrypto
#    SOFTWARE\Microsoft\.NETFramework\v4.0.30319\SchUseStrongCrypto
#    SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v4.0.30319\SchUseStrongCrypto
#endregion


Function GetItemProperty($RegPath)
{
    $Key = Get-ItemProperty $RegPath -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    If (($Key -eq "") -or ($Key -eq $null))
    {
        Return "Does Not Exist"
    }
    Else
    {
        Return $Key
    }
}

Function KeyExist($Key)
{
    If (($Key -eq "") -or ($Key -eq $null) -or ($Key -eq "Does Not Exist"))
    {
        Return $false
    }
    Else
    {
        Return $True
    }
}

$SSLv2 = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0'
$SSLv3 = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0'
$TLS10 = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0'
$TLS11 = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1'
$TLS12 = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2'
$SSLv2Client = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client'
$SSLv2Server = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server'
$SSLv3Client = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client'
$SSLv3Server = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server'
$TLS10Client = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client'
$TLS10Server = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server'
$TLS11Client = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client'
$TLS11Server = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server'
$TLS12Client = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client'
$TLS12Server = GetItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server'
$Net20_x86 = GetItemProperty 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v2.0.50727'
$Net20_x64 = GetItemProperty 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v2.0.50727'
$Net40_x86 = GetItemProperty 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319'
$Net40_x64 = GetItemProperty 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v4.0.30319'
$NetVersion = GetItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full\1033'

$SChannel = New-Object psobject -Property @{
    Computer = $env:COMPUTERNAME
    SSLv2 = $SSLv2
    SSLv2Client_Enabled = If(KeyExist $SSLv2Client.Enabled) { $SSLv2Client.Enabled } Else { "Does Not Exist" }
    SSLv2Client_DisabledByDefault = If(KeyExist $SSLv2Client.DisabledByDefault) { $SSLv2Client.DisabledByDefault } Else { "Does Not Exist" }
    SSLv2Server_Enabled = If(KeyExist $SSLv2Server.Enabled) { $SSLv2Server.Enabled } Else { "Does Not Exist" }
    SSLv2Server_DisabledByDefault = If(KeyExist $SSLv2Server.DisabledByDefault) { $SSLv2Server.DisabledByDefault } Else { "Does Not Exist" }
    SSLv3 = $SSLv3
    SSLv3Client_Enabled = If(KeyExist $SSLv3Client.Enabled) { $SSLv3Client.Enabled } Else { "Does Not Exist" }
    SSLv3Client_DisabledByDefault = If(KeyExist $SSLv3Client.DisabledByDefault) { $SSLv3Client.DisabledByDefault } Else { "Does Not Exist" }
    SSLv3Server_Enabled = If(KeyExist $SSLv3Server.Enabled) { $SSLv3Server.Enabled } Else { "Does Not Exist" }
    SSLv3Server_DisabledByDefault = If(KeyExist $SSLv3Server.DisabledByDefault) { $SSLv3Server.DisabledByDefault } Else { "Does Not Exist" }
    TLS10 = $TLS10
    TLS10Client_Enabled = If(KeyExist $TLS10Client.Enabled) { $TLS10Client.Enabled } Else { "Does Not Exist" }
    TLS10Client_DisabledByDefault = If(KeyExist $TLS10Client.DisabledByDefault) { $TLS10Client.DisabledByDefault } Else { "Does Not Exist" }
    TLS10Server_Enabled = If(KeyExist $TLS10Server.Enabled) { $TLS10Server.Enabled } Else { "Does Not Exist" }
    TLS10Server_DisabledByDefault = If(KeyExist $TLS10Server.DisabledByDefault) { $TLS10Server.DisabledByDefault } Else { "Does Not Exist" }
    TLS11 = $TLS11
    TLS11Client_Enabled = If(KeyExist $TLS11Client.Enabled) { $TLS11Client.Enabled } Else { "Does Not Exist" }
    TLS11Client_DisabledByDefault = If(KeyExist $TLS11Client.DisabledByDefault) { $TLS11Client.DisabledByDefault } Else { "Does Not Exist" }
    TLS11Server_Enabled = If(KeyExist $TLS11Server.Enabled) { $TLS11Server.Enabled } Else { "Does Not Exist" }
    TLS11Server_DisabledByDefault = If(KeyExist $TLS11Server.DisabledByDefault) { $TLS11Server.DisabledByDefault } Else { "Does Not Exist" }
    TLS12 = $TLS12
    TLS12Client_Enabled = If(KeyExist $TLS12Client.Enabled) { $TLS12Client.Enabled } Else { "Does Not Exist" }
    TLS12Client_DisabledByDefault = If(KeyExist $TLS12Client.DisabledByDefault) { $TLS12Client.DisabledByDefault } Else { "Does Not Exist" }
    TLS12Server_Enabled = If(KeyExist $TLS12Server.Enabled) { $TLS12Server.Enabled } Else { "Does Not Exist" }
    TLS12Server_DisabledByDefault = If(KeyExist $TLS12Server.DisabledByDefault) { $TLS12Server.DisabledByDefault } Else { "Does Not Exist" }
    '.Net v2.0' = If(KeyExist $Net20_x86.SchUseStrongCrypto) { $Net20_x86.SchUseStrongCrypto } Else { "Does Not Exist" }
    '.Net v2.0 x64' = If(KeyExist $Net20_x86.SchUseStrongCrypto) { $Net20_x86.SchUseStrongCrypto } Else { "Does Not Exist" }
    '.Net v4.0' = If(KeyExist $Net40_x86.SchUseStrongCrypto) { $Net40_x86.SchUseStrongCrypto } Else { "Does Not Exist" }
    '.Net v4.0 x64' = If(KeyExist $Net40_x64.SchUseStrongCrypto) { $Net40_x64.SchUseStrongCrypto } Else { "Does Not Exist" }
    '.Net Version' = If(KeyExist $NetVersion.Version) { $NetVersion.Version } Else { "Prior to v4" }
}

$SChannel | Export-Csv -NoTypeInformation -Force C:\Windows\Temp\SChannel.csv