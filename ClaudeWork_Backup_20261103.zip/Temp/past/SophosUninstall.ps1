﻿#
# ===================================================================
# Purpose:           Sophos Uninstall and Reboot
# Parameters:        
# Called From:       Manual
# User Account:      
# Author:            Bryan Grider
# Notes:             
#                    
# Revision:
#             Created:           8/24/2021
# ===================================================================
#


<#
.SYNOPSIS
    This script is for removal of Sophos

.DESCRIPTION
    Script remotely uninstalls Sophos.

    SophosZap.exe is required in same directory as this script!

.EXAMPLE
    ./SophosUninstall.ps1 -Path <string>
    ./SophosUninstall.ps1 -Computer <string>
    ./SophosUninstall.ps1 -Path <string> -UseDefaultCredentials
    ./SophosUninstall.ps1 -Computer <string> -UseDefaultCredentials

.PARAMETERS
    -Path 
            Refers to the full path of either a TXT file or CSV file
            Cannot be used in conjunction with -Computer
    
    -Computer
            To run script against a single computer
            Cannot be used in conjunction with -Path
    
    -Credential
            Credentials used to access run remote command
    

.LINK
    N/A
#>


[CmdletBinding(DefaultParameterSetName="Path")]
param
(
    [Parameter(ParameterSetName="Computer")][string]$ComputerName,
    [Parameter(ParameterSetName="Path")][string]$Path = "",
    [pscredential]$Credential,
    [string]$LogFile = "SophosUninstall.log"
)


#region Global
Cls
$Computers = @()
$Error.Clear()


#region Functions
Function GetPath()
{
    Do
    {
        $NewPath = Read-Host "Enter the location of the txt file containing the list of servers"
        If (-not (Test-Path $NewPath -PathType Leaf)) { Write-Host "Unable to access file `'$($NewPath)`'!" }
    }
    While (-not (Test-Path $NewPath -PathType Leaf))
    Return $NewPath
}
#endregion


#region Check Parameters
If ($PSCmdlet.ParameterSetName -eq "Path")
{
    If ([string]::IsNullOrWhiteSpace($Path))
    {
        $Path = GetPath
    }
    ElseIf (-not (Test-Path $Path -PathType Leaf -ErrorAction SilentlyContinue))
    {
        $Path = GetPath
    }
    If ($Path.EndsWith(".txt"))
    {
        $Computers = Get-Content -Path $Path
    }
    else
    {
        $Computers = Import-Csv -Path $Path
    }
}
Else
{
    $Computers += $ComputerName
}

If ($Credential -eq $null)
{
    $Credential = Get-Credential
    If ($Credential -eq $null)
    {
        Write-Output "No credentials provided and are required.  Script will exit!"
        Exit
    }
}
#endregion


#region Main
$Error.Clear()
Start-Transcript -Path $LogFile -Append

# Sophos Uninstall
ForEach ($Computer in $Computers)
{
    If (Test-Connection -Quiet -Count 2 $Computer)
    {
        $DriveLetter = (70..90 | %{$L=[char]$_; if ((gdr).Name -notContains $L) {$L}})[0]
        Write-Host "Connecting $($DriveLetter) drive to `'$($Computer)`'..."
        New-PSDrive -Name $DriveLetter -PSProvider FileSystem -Root \\$Computer\C$\Windows\Temp -Credential $Credential
        Copy-Item -Path SophosZap.exe -Destination "$($DriveLetter):\SophosZap.exe"
        Start-Sleep -Seconds 5
        Write-Host "Uninstalling Sophos on $Computer" -ForegroundColor Yellow
        #Invoke-WmiMethod -Class Win32_Process -Name Create -ComputerName $Computer -Credential $Credential -ArgumentList '"C:\Windows\Temp\SophosZap.exe --confirm"'
	    Invoke-Command -ComputerName $Computer -Credential $Credential -ScriptBlock {
		    c:\Windows\Temp\SophosZap.exe --confirm
	    }
#        Start-Sleep -Seconds 30
        Remove-PSDrive -Name $DriveLetter
    }
}

# Sophos Service Check - No Service means SophosZap was successful and computer can reboot.
$Error.Clear()
$SuccessfulComputers = @()
$FailedComputers = @()
ForEach ($Computer in $Computers)
{
    If (Test-Connection -Quiet -Count 2 $Computer)
    {
        Write-Host "Checking Sophos Service on $Computer" -ForegroundColor Yellow
        #$Results = Get-WmiObject -Class Win32_Service -ComputerName $Computer -Credential $Credential -Filter "Name LIKE 'Sophos Agent'"
        $Results = Invoke-Command -ComputerName $Computer -Authentication Negotiate -Credential $Credential -ScriptBlock { Get-WmiObject -Class Win32_Service -Filter "Name LIKE 'Sophos Agent'" }
        If ($Error)
        {
            $FailedComputers += New-Object psobject -Property @{
                Computer = $Computer
                Error = $Error[0]
            }
            $Error.Clear()
        }
        Else
        {
            If ($Results -eq $null)  #  True if Sophos does not exist (uninstalled)
            {
                $SuccessfulComputers += New-Object psobject -Property @{
                    Computer = $Computer
                }
                Write-Host "Sophos Successfully Uninstalled!"
            }
            Else
            {
                $FailedComputers += New-Object psobject -Property @{
                    Computer = $Computer
                    Error = "Not Uninstalled"
                }
            }
        }
    }
    Write-Host ""
}

# Reboot Computers that no longer Sophos Installed (Uninstall Successful)
$Error.Clear()
$SuccessfulRebootComputers
$FailedRebootComputer = @()
ForEach ($Computer in $SuccessfulComputers)
{
    If (Test-Connection -Quiet -Count 2 $Computer)
    {
        Write-Host "Rebooting server $($Computer)" -ForegroundColor Green
        Restart-Computer -ComputerName $Computer -Force -Credential $Credential
        If ($Error)
        {
            $FailedRebootComputer += New-Object psobject -Property @{
                Computer = $Computer
                Error = $Error[0]
            }
            $Error.Clear()
        }
        Else
        {
            $SuccessfulRebootComputers += $Computer
        }
    }
}

#  Output Sophos Failed
Write-Host "Sophos Failed to uninstall on the following:"
$FailedComputers | ft -AutoSize
$FailedComputers | Select Computer, Error | Export-Csv -NoTypeInformation -Path "SophosFailedUninstall.csv"

#  Output Sophos Successful but Reboot failed
Write-Host "Sophos Uninstalled Successfully but Reboot failed:"
$FailedRebootComputer | ft -AutoSize
$FailedRebootComputer | Select Computer, Error | Export-Csv -NoTypeInformation -Path "SophosFailedReboot.csv"

#  Output Successful
$SuccessfulRebootComputers | ft -AutoSize
$SuccessfulRebootComputers | Select Computer | Export-Csv -NoTypeInformation -Path "SophosUninstallSuccessfully.csv"

#endregion
Stop-Transcript