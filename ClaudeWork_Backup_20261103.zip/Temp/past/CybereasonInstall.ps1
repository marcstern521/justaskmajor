﻿[CmdletBinding(DefaultParameterSetName="Path")]
param
(
    [Parameter(ParameterSetName="Computer")][string]$ComputerName,
    [Parameter(ParameterSetName="Path")][string]$Path = "",
    [string]$PSExec = "C:\PSTools\PsExec64.exe",
    [switch]$ReportOnly = $false,
    [switch]$NoDelete,
    [switch]$InstallOnly,
    [switch]$Uninstall = $false,
    [int]$WaitTime = 5
)

CLS
$Error.Clear()
$OutputFile = "CR_Install_$((Get-Date).ToString("hhmmss")).log"
$ReportFile = "CR_Status_$((Get-Date).ToString("hhmmss")).csv"
$ServiceName = "CybereasonActiveProbe"
$SourceFileUNCPath = "\\corpfs03.ucn.net\dfs-root\NetOps\SystemOperations\Cybereason\installer.exe"
$SourceBatFileUNCPath = "\\corpfs03.ucn.net\dfs-root\NetOps\SystemOperations\Cybereason\CybereasonInstall.bat"
$DestFileName = "installer.exe"
$DestBatFileName = "CybereasonInstall.bat"
$Computers = @()

Function GetPath()
{
    Do
    {
        $NewPath = Read-Host "Enter the location of the txt file containing the list of servers"
        If (-not (Test-Path $NewPath -PathType Leaf)) { Write-Host "Unable to access file `'$($NewPath)`'!" }
    }
    While (-not (Test-Path $NewPath -PathType Leaf))
    Return $NewPath
}

If ($PSCmdlet.ParameterSetName -eq "Path")
{
    If ([string]::IsNullOrWhiteSpace($Path))
    {
        $Path = GetPath
    }
    ElseIf (-not (Test-Path $Path -PathType Leaf -ErrorAction SilentlyContinue))
    {
        $Path = GetPath
    }
    $Computers = Get-Content -Path $Path
}
Else
{
    $Computers += $ComputerName
}

Function Get-Count($Object)
{
    $Count = 0
    If ($Object -ne $null) { $Count = 1 }
    If ($Object.Count -ne $null) { $Count = $Object.Count }
    Return $Count
}

Function ExportServiceStatus($ExportFile, $Systems, $Cred)
{
    $AgentStatus = @()
    $Installed = ""
    $Status = ""

    ForEach ($System in $Systems)
    {
        Write-Host "Checking Cybereason Agent status on $($System)..."
        $Error.Clear()
        If (Test-Connection -Quiet -Count 1 $System)
        {
            #$Service = Get-Service ir_agent -ComputerName $System -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
            $Service = Get-WMIObject Win32_Service -ComputerName $System -Credential $Cred -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | Where Name -eq $ServiceName
            If ($Error -ne $null)
            {
                $Installed = "Error Connecting"
                $Status = "Error Connecting"
            }
            Else
            {
                If ($Service -eq $null)
                {
                    $Installed = "Not Installed"
                    $Status = "Not Installed"
                }
                Else
                {
                    $Installed = $true
                    $Status = $Service.Status 
                    Write-Host "$($Service.DisplayName) installed on $($System).  Status = $($Status)"
                }
            }
        }
        Else
        {
            Write-Host "Unable to connect to $($System)"
            $Installed = "Unable to connect"
            $Status = "Unknown"
        }

        $AgentStatus += New-Object psobject -Property ([ordered]@{
            ComputerName = $System
            Installed = $Installed
            Status = $Status
        })
    }
    Write-Host "Creating export file $($ExportFile)"
    $AgentStatus | Export-Csv -Path $ExportFile -NoTypeInformation
}

$username = 'INUCN\' + $env:USERNAME
$Cred = Get-Credential $username -Message "Admin Credentials for accessing Systems"
Write-Host ""

If (Test-Path $OutputFile) { Remove-Item -Path $OutputFile -Force }
Get-Date | Tee-Object -FilePath $OutputFile

If (-not($ReportOnly))
{
    ForEach ($pc in $Computers)
    {
        If (Test-Connection -Quiet -Count 1 $pc)
        {
            If ($Uninstall)
            {
                "Uninstall Cybereason if installed." | Tee-Object -FilePath $OutputFile -Append | Write-Host
                $Command = "cmd.exe /c for /r `"%programdata%\Package Cache\`" %a in (cybereasonsensor.exe) do if exist %a %a /uninstall /quiet /norestart AP_UNINSTALL_CODE=`"pBWsXcO8I19a`""
                $Result = Invoke-WmiMethod -Class Win32_Process -Name Create -ComputerName $pc -Credential $Cred -ArgumentList $Command
                $Result | Tee-Object -FilePath $OutputFile -Append | Write-Host
                "" | Tee-Object -FilePath $OutputFile -Append | Write-Host
                Start-Sleep -Seconds ($WaitTime * 3)
            }

            $DriveLetter = (70..90 | %{$L=[char]$_; if ((gdr).Name -notContains $L) {$L}})[0]
            $Error.Clear()
            If (-not($InstallOnly))
            {
                "Connecting $($DriveLetter) drive on `'$($pc)`'..." | Tee-Object -FilePath $OutputFile -Append | Write-Host
                New-PSDrive -Name $DriveLetter -PSProvider FileSystem -Root \\$pc\C$\Windows\Temp -Credential $cred  | Tee-Object -FilePath $OutputFile -Append | Write-Host
                If (-not $Error)
                {
                    "Copying Installation files ..." | Tee-Object -FilePath $OutputFile -Append | Write-Host
                    Copy-Item -Path $SourceFileUNCPath -Destination "$($DriveLetter):\$($DestFileName)" -Force -Recurse | Tee-Object -FilePath $OutputFile -Append | Write-Host
                    Copy-Item -Path $SourceBatFileUNCPath -Destination "$($DriveLetter):\$($DestBatFileName)" -Force -Recurse | Tee-Object -FilePath $OutputFile -Append | Write-Host
	                "Waiting $($WaitTime) seconds" | Tee-Object -FilePath $OutputFile -Append | Write-Host
                    Start-Sleep -Seconds $WaitTime
                }
                Else
                {
                    "Error Mapping Drive on $($pc)." | Out-File -FilePath $OutputFile -Append
                }
            }
            "Beginning Installation on $pc" | Tee-Object -FilePath $OutputFile -Append | Write-Host
            $Result = ""
            $ErrorActionPreference = "Stop"
            Try
            {
                "$PSExec -NoBanner \\$pc -h -u $($cred.UserName) -p **Password** `"C:\Windows\Temp\$($DestBatFileName)`"" | Tee-Object -FilePath $OutputFile -Append | Write-Host
                & $PSExec -NoBanner \\$pc -h -u $cred.UserName -p $cred.GetNetworkCredential().Password "C:\Windows\Temp\$($DestBatFileName)" | Out-File -FilePath $OutputFile -Append
            }
            Catch
            {
                "--  Error using PSExec --" | Tee-Object -FilePath $OutputFile -Append | Write-Host
                $Result = $_.Exception
                $Result | Tee-Object -FilePath $OutputFile -Append | Write-Host
            }
            If (-not([string]::IsNullOrWhiteSpace($Result)))
            {
                "Trying WMI to run batch file for D: installation." | Tee-Object -FilePath $OutputFile -Append | Write-Host
                Try
                {
                    $Result = Invoke-WmiMethod -Class Win32_Process -Name Create -ComputerName $pc -Credential $Cred -ArgumentList "C:\Windows\Temp\$($DestBatFileName)"
                    $Result | Tee-Object -FilePath $OutputFile -Append | Write-Host
                }
                Catch
                {
                    "--  Error using WMI --" | Tee-Object -FilePath $OutputFile -Append | Write-Host
                    $Result = $_.Exception
                    $Result | Tee-Object -FilePath $OutputFile -Append | Write-Host
                }
            }
            $ErrorActionPreference = "Continue"

	        "Waiting $($WaitTime) seconds" | Tee-Object -FilePath $OutputFile -Append | Write-Host
            Start-Sleep -Seconds $WaitTime

            If (-not($NoDelete))
            {
                "Cleaning up the mess..." | Tee-Object -FilePath $OutputFile -Append | Write-Host
                Remove-Item -Path "$($DriveLetter):\$($DestFileName)" -Recurse -Force  | Tee-Object -FilePath $OutputFile -Append | Write-Host
                Remove-Item -Path "$($DriveLetter):\$($DestBatFileName)" -Recurse -Force  | Tee-Object -FilePath $OutputFile -Append | Write-Host
            }

            Remove-PSDrive -Name $DriveLetter | Tee-Object -FilePath $OutputFile -Append | Write-Host
        }
        Else
        {
            "Unable to Connect to $($pc)!" | Tee-Object -FilePath $OutputFile -Append | Write-Host
        }
        "" | Tee-Object -FilePath $OutputFile -Append | Write-Host
    }
}

ExportServiceStatus $ReportFile $Computers $Cred
Get-Date | Tee-Object -FilePath $OutputFile -Append