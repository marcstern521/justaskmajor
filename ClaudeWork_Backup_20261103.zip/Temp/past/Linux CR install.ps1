﻿if (!(Get-Module -ListAvailable -Name PoSH-SSH)) {
	Install-Module -Name PoSH-SSH
}

If (!(Get-module PoSH-SSH)) {
	Import-Module PoSH-SSH
}	

#Set Credentials
$username = "patrol"
$pswdFile = read-host -Prompt "Enter SSH Password" -assecurestring | convertfrom-securestring | out-file .\passwd.txt
$password = cat .\passwd.txt | ConvertTo-SecureString
$SSHcred = new-object -typename System.Management.Automation.PSCredential `
             -argumentlist $username, $password

$machines = Get-Content .\linux_servers.txt	 
			 
ForEach ($machine in $machines) {
    New-SSHSession -ComputerName $machine -Credential ($SSHcred) -AcceptKey:$true
	#Copy Files (Rapid7 & Cybereason)
	Set-SCPFolder -LocalFolder ".\Installer\" -RemoteFolder "/tmp/" -ComputerName $machine -Credential ($SSHcred) -AcceptKey:$true
}	
	
$SSHsessions = Get-SSHSession

$container = @()

ForEach ($SSHsession in $SSHsessions) {
	#Install Cybereason Agent (RPM)
	$showinforpm = $(Invoke-SSHCommand -SessionId $SSHsession.SessionID -Command "echo BMCagent1 | sudo -S su -c 'rpm -ivh  cybereason-sensor-19.2.161.0-1.x86_64_niceincontact-prod_niceincontact-prod-r.cybereason.net_443_ACTIVE_NORMAL_rpm.rpm'").Output
	
	#Install Cybereason Agent (Debian)
	$showinfodeb = $(Invoke-SSHCommand -SessionId $SSHsession.SessionID -Command "echo BMCagent1 | sudo -S su -c 'dpkg -i  cybereason-sensor-19.2.161.0-1.x86_64_niceincontact-prod_niceincontact-prod-r.cybereason.net_443_ACTIVE_NORMAL_deb.deb'").Output
	
	#Show Service
	$sysvinit = $(Invoke-SSHCommand -SessionId $SSHsession.SessionID -Command "systemctl | grep -i cyber").Output
	$systemd = $(Invoke-SSHCommand -SessionId $SSHsession.SessionID -Command "systemctl | grep -i cyber").Output
	
	#Output Results
	$container += $SSHsession.Host
	$container += $showinforpm
	$container += $showinfodeb
	$container += $sysvinit
	$container += $systemd
}
$container | Export-Csv .\agent_install_result.csv 
