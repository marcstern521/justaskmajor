﻿[CmdletBinding(DefaultParameterSetName="Path")]
param
(
    [Parameter(ParameterSetName="Computer")][string]$ComputerName,
    [Parameter(ParameterSetName="Path")][string]$Path = "",
    [string]$PSExec = "C:\PSTools\PsExec64.exe",
    [switch]$ReportOnly = $false,
    [switch]$NoDelete,
    [switch]$InstallOnly,
    [int]$WaitTime = 5
)

CLS
$Error.Clear()
$OutputFile = "ir_agent_status_$((Get-Date).ToString("hhmmss")).txt"
$ReportFile = "Rapid7_Status_$((Get-Date).ToString("hhmmss")).csv"
$Computers = @()

Function GetPath()
{
    Do
    {
        $NewPath = Read-Host "Enter the location of the txt file containing the list of servers: "
        If (-not (Test-Path $NewPath -PathType Leaf)) { Write-Host "Unable to access file `'$($NewPath)`'!" }
    }
    While (-not (Test-Path $NewPath -PathType Leaf))
    Return $NewPath
}

If ($PSCmdlet.ParameterSetName -eq "Path")
{
    If ([string]::IsNullOrWhiteSpace($Path))
    {
        $Path = GetPath
    }
    ElseIf (-not (Test-Path $Path -PathType Leaf -ErrorAction SilentlyContinue))
    {
        $Path = GetPath
    }
    $Computers = Get-Content -Path $Path
}
Else
{
    $Computers += $ComputerName
}

Function Get-Count($Object)
{
    $Count = 0
    If ($Object -ne $null) { $Count = 1 }
    If ($Object.Count -ne $null) { $Count = $Object.Count }
    Return $Count
}

Function ExportServiceStatus($ExportFile, $Systems, $Cred)
{
    $AgentStatus = @()
    $Installed = ""
    $Status = ""

    ForEach ($System in $Systems)
    {
        Write-Host "Checking Rapid 7 Agent status on $($System)..."
        $Error.Clear()
        If (Test-Connection -Quiet $System)
        {
            #$Service = Get-Service ir_agent -ComputerName $System -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
            $Service = Get-WMIObject Win32_Service -ComputerName $System -Credential $Cred -Filter { Name Like "ir_agent" } -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
            If ($Error -ne $null)
            {
                $Installed = "Error Connecting"
                $Status = "Error Connecting"
            }
            Else
            {
                If ($Service -eq $null)
                {
                    $Installed = "Not Installed"
                    $Status = "Not Installed"
                }
                Else
                {
                    $Installed = $true
                    $Status = $Service.Status 
                    Write-Host "Rapid 7 Agent installed on $($System).  Status = $($Status)"
                }
            }
        }
        Else
        {
            Write-Host "Unable to connect to $($System)"
            $Installed = "Unable to connect"
            $Status = "Unknown"
        }

        $AgentStatus += New-Object psobject -Property ([ordered]@{
            ComputerName = $System
            Installed = $Installed
            Status = $Status
        })
    }
    Write-Host "Creating export file $($ExportFile)"
    $AgentStatus | Export-Csv -Path $ExportFile -NoTypeInformation
}

$username = 'INUCN\' + $env:USERNAME
$Cred = Get-Credential $username -Message "Admin Credentials for accessing Systems"
Write-Host ""

If (Test-Path $OutputFile) { Remove-Item -Path $OutputFile -Force }
Write-Host "Log File:`t$($OutputFile)"

If (-not($ReportOnly))
{
    ForEach ($pc in $Computers)
    {
        If (Test-Connection -Quiet $pc)
        {
            $DriveLetter = (70..90 | %{$L=[char]$_; if ((gdr).Name -notContains $L) {$L}})[0]
            $Error.Clear()
            If (-not($InstallOnly))
            {
                Write-Host "Connecting $($DriveLetter) drive on `'$($pc)`'..."
                New-PSDrive -Name $DriveLetter -PSProvider FileSystem -Root \\$pc\C$\Windows\Temp -Credential $cred
                If (-not $Error)
                {
                    Write-Host "Copying Installation file ..."
                    Copy-Item -Path "\\corpfs03.ucn.net\dfs-root\NetOps\temp\agentInstaller-x86_64.msi" -Destination "$($DriveLetter):\agentInstaller-x86_64.msi" -Force -Recurse | Tee-Object -FilePath $OutputFile -Append | Write-Host
	                Copy-Item -Path "\\corpfs03.ucn.net\dfs-root\NetOps\temp\r7install.bat" -Destination "$($DriveLetter):\r7install.bat" -Force -Recurse | Tee-Object -FilePath $OutputFile -Append | Write-Host
	                "Waiting $($WaitTime) seconds" | Tee-Object -FilePath $OutputFile -Append | Write-Host
                    Start-Sleep -Seconds $WaitTime
                }
                Else
                {
                    "Error Mapping Drive on $($pc)." | Out-File -FilePath $OutputFile -Append
                }
            }
            "Beginning Installation on $pc" | Tee-Object -FilePath $OutputFile -Append | Write-Host
            $Result = ""
            $ErrorActionPreference = "Stop"
            Try
            {
                "$PSExec -NoBanner \\$pc -h -u $($cred.UserName) -p **Password** `"C:\Windows\Temp\r7install.bat`"" | Tee-Object -FilePath $OutputFile -Append | Write-Host
                & $PSExec -NoBanner \\$pc -h -u $cred.UserName -p $cred.GetNetworkCredential().Password "C:\Windows\Temp\r7install.bat" | Tee-Object -FilePath $OutputFile -Append
            }
            Catch
            {
                $Result = $_.Exception
            }
            If (-not([string]::IsNullOrWhiteSpace($Result)))
            {
                $Result = Invoke-WmiMethod -Class Win32_Process -Name Create -ComputerName $pc -Credential $Cred -ArgumentList "C:\Windows\Temp\r7install.bat"
                $Result | Tee-Object -FilePath $OutputFile -Append | Write-Host
            }
            $ErrorActionPreference = "Continue"

	        "Waiting $($WaitTime) seconds" | Tee-Object -FilePath $OutputFile -Append | Write-Host
            Start-Sleep -Seconds $WaitTime

            If (-not($NoDelete))
            {
                "Cleaning up the mess..." | Tee-Object -FilePath $OutputFile -Append | Write-Host
                Remove-Item -Path "$($DriveLetter):\agentInstaller-x86_64.msi" -Recurse -Force  | Tee-Object -FilePath $OutputFile -Append | Write-Host
	            Remove-Item -Path "$($DriveLetter):\r7install.bat" -Recurse -Force  | Tee-Object -FilePath $OutputFile -Append | Write-Host
                Remove-PSDrive -Name $DriveLetter | Tee-Object -FilePath $OutputFile -Append | Write-Host
            }
        }
        Else
        {
            "Unable to Connect to $($pc)!" | Tee-Object -FilePath $OutputFile -Append | Write-Host
        }
    }
}

ExportServiceStatus $ReportFile $Computers $Cred