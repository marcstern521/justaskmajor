﻿#
# ===================================================================
# Purpose:           Check Registry for TLS 1.0, 1.1, 1.2, SSLv2 & SSLv3
# Parameters:        
# Called From:       Manual
# User Account:      
# Author:            Bryan Grider
# Notes:             
#                    
# Revision:
#             Created:           7/22/2020
# ===================================================================
#


[CmdletBinding(DefaultParameterSetName="Computers")]
param
(
    [Parameter(ParameterSetName="Computers",ValueFromPipeline = $True)]$Computers,
    [Parameter(ParameterSetName="Path",ValueFromPipeline = $True)]$Path,
    [pscredential]$Credential,
    [string]$PSExec = "C:\PSTools\PsExec64.exe",
    [string]$LogFile = "C:\Temp\SChannelVersion.log",
    [string]$ExcelFile = "SChannel.xlsx",
    $FailedFile = "FailedComputers.csv"
)


#region Global
Cls
Import-Module ImportExcel
$ErrorActionPreference = "SilentlyContinue"
$ParamSetName = $PsCmdLet.ParameterSetName
$ScriptStartTime = Get-Date
$WaitTime = 5
$ScriptSourceFile = ".\Export-SChannelSettings.ps1"
$ExportFile = "SChannel.csv"
$Error.Clear()
#endregion


#region Functions
Function Log([string]$Message)
{
    $Message | Out-File -FilePath $LogFile -Append
}

Function LogError($Message)
{
    Log ""
    Log "".PadRight(150,'=')
    Log $Message
    Log "".PadRight(150,'-')
    Log $Error[0]
    Log "".PadRight(150,'=')
    Log ""
    $Error.Clear()
}

Function ParseData($Data)
{
    $ParsedData = @()
    ForEach($Row in $Data)
    {
        $NewData = New-Object psobject -Property @{
            Computer = $Row.Computer
            '.Net Version' = $Row.'.Net Version'
            'SSLv2 Disabled' = ($Row.SSLv2Client_Enabled -eq 0)
            'SSLv3 Disabled' = ($Row.SSLv3Client_Enabled -eq 0)
            'TLS 1.0 Disabled' = ($Row.TLS10Client_Enabled -eq 0)
            'TLS 1.1 Disabled' = ($Row.TLS11Client_Enabled -eq 0)
            'TLS 1.2 Enabled' = If($Row.TLS12 -eq $true) { ($Row.TLS12Client_Enabled -eq 1) } Else { "Reg Key Does Not Exist" }
        }

        $ParsedData += $NewData
    }
    Return $ParsedData
}
#endregion


#region Main
If (Test-Path -Path $LogFile) { Get-ChildItem -Path $LogFile | Remove-Item -Force }
Log "Starting Script at $($ScriptStartTime.ToString())."
Log ""


If (($ParamSetName -eq "Path") -and (-not([string]::IsNullOrWhiteSpace($Path))))
{
    If (Test-Path $Path)
    {
        If ($Path.ToUpper().EndsWith(".CSV"))
        {
            $Computers = Import-Csv $Path | Select -ExpandProperty Name
        }
        Else
        {
            $Computers = Get-Content -Path $Path
        }
    }
    If ($Computers -eq $null)
    {
        Write-Output "No computers to check!  Script will exit."
        Exit
    }
}
Else
{
    If (($ParamSetName -eq "Computers") -and ($Computers -eq $null))
    {
        $Computers = Read-Host -Prompt "Enter either a single computer or a multiple computers separated by a comma."
    }
    If ($Computers -eq $null)
    {
        Write-Output "No computers to check!  Script will exit."
        Exit
    }
}

If ($Credential -eq $null)
{
    $Credential = Get-Credential
    If ($Credential -eq $null)
    {
        Write-Output "No credentials provided and are required.  Script will exit."
        Exit
    }
}

Log "Total Number of computers = $($Computers.Count)"
Log ""

$AllComputers = @()
$FailedComputers = @()
$Count = 1
ForEach ($Computer in $Computers)
{
    Log "Checking Computer ($Computer) - $($Count)/$($Computers.Count)"

    If (Test-Connection -Quiet -Count 1 $Computer)
    {
        Log (Get-PSDrive -PSProvider FileSystem | Select Name, Root | ft -AutoSize | Out-String)
        $DriveLetter = (70..90 | %{$L=[char]$_; if ((gdr).Name -notContains $L) {$L}})[0]
        Log "Connecting $($DriveLetter) drive on `'$($Computer)`'..."
        Log (New-PSDrive -Name $DriveLetter -PSProvider FileSystem -Root \\$Computer\C$\Windows\Temp -Credential $Credential | FT -AutoSize | Out-String)
        If ($Error)
        {
            LogError "Error Mapping Drive on $($Computer) using name, trying IP."
            $IP = [System.Net.Dns]::GetHostAddresses($Computer).IPAddressToString
            Log (New-PSDrive -Name $DriveLetter -PSProvider FileSystem -Root \\$IP\C$\Windows\Temp -Credential $Credential | FT -AutoSize | Out-String)
        }
        If (-not $Error)
        {
            $DestScriptSourceFile = $ScriptSourceFile.Substring($ScriptSourceFile.LastIndexOf('\') + 1)
            Log "Copying Script file from $($ScriptSourceFile) to $($DriveLetter):\$($DestScriptSourceFile)..."
            Log (Copy-Item -Path $ScriptSourceFile -Destination "$($DriveLetter):\$($DestScriptSourceFile)" -Force -Recurse | Out-String)
	        #Log "Waiting $($WaitTime) seconds"
            #Start-Sleep -Seconds $WaitTime
            Log ""
            Log "Running Script on $pc"
        
            $Result = ""
            Try
            {
                Log "Launching PSExec at $($PSExec) to run C:\Windows\Temp\$($DestScriptSourceFile)"
                & $PSExec -NoBanner \\$Computer -h -e -u $Credential.UserName -p $Credential.GetNetworkCredential().Password PowerShell.exe -ExecutionPolicy ByPass -File "C:\Windows\Temp\$($DestScriptSourceFile)"
            }
            Catch
            {
                $Result = $_.Exception
                LogError "Launching PSExec failed."
                If (-not([string]::IsNullOrWhiteSpace($Result))) { Log $Result }
                $FailedComputers += $Computer
            }
            If (-not([string]::IsNullOrWhiteSpace($Result)))
            {
                Log "Trying to use WMI to launch script!"
                Log (Invoke-WmiMethod -Class Win32_Process -Name Create -ComputerName $Computer -Credential $Credential -ArgumentList PowerShell.exe -file "C:\Windows\Temp\$($DestScriptSourceFile)" | Out-String)
            }

            Log "Waiting $($WaitTime) seconds"
            Start-Sleep -Seconds $WaitTime

            If (Test-Path -Path "$($DriveLetter):\$($ExportFile)")
            {
                Log "Getting Export Data"
                $AllComputers += Import-Csv -Path "$($DriveLetter):\$($ExportFile)"
            }
            Else
            {
                Log "Export Data $($DriveLetter):\$($ExportFile) does not exist for computer $($Computer)!"
            }

            #Log "Cleaning up the mess..."
            #Log (Remove-Item -Path "$($DriveLetter):\$($DestScriptSourceFile)" -Recurse -Force)
            #Log (Remove-Item -Path "$($DriveLetter):\$($ExportFile)" -Recurse -Force)
            
            Log "Unmapping drive - $($DriveLetter)"
            Log (Remove-PSDrive -Name $DriveLetter | Out-String)
            Log "Done with $($Computer)."
            Log ""
        }
        Else
        {
            LogError "Error Mapping Drive on $($Computer)."
            $FailedComputers += $Computer
        }
    }
    Else
    {
        Log "Unable to Connect to $($Computer) by IP Address!"
        $FailedComputers += $Computer
    }
    Log ""
    $Count++
}

Log "Exporting $($AllComputers.Count) computer(s) to $($ExcelFile)."
ParseData $AllComputers | Select Computer, '.Net Version', 'SSLv2 Disabled', 'SSLv3 Disabled', 'TLS 1.0 Disabled', 'TLS 1.1 Disabled', 'TLS 1.2 Enabled' | Export-Excel -Path $ExcelFile -WorksheetName "Summary" -AutoSize -AutoFilter -BoldTopRow
$AllComputers | Select Computer, '.Net Version', SSLv2, SSLv2Client_Enabled, SSLv2Client_DisabledByDefault, SSLv2Server_Enabled, SSLv2Server_DisabledByDefault, SSLv3, SSLv3Client_Enabled, SSLv3Client_DisabledByDefault, SSLv3Server_Enabled, SSLv3Server_DisabledByDefault, TLS10, TLS10Client_Enabled, TLS10Client_DisabledByDefault, TLS10Server_Enabled, TLS10Server_DisabledByDefault, TLS11, TLS11Client_Enabled, TLS11Client_DisabledByDefault, TLS11Server_Enabled, TLS11Server_DisabledByDefault, TLS12, TLS12Client_Enabled, TLS12Client_DisabledByDefault, TLS12Server_Enabled, TLS12Server_DisabledByDefault, '.Net v2.0', '.Net v2.0 x64', '.Net v4.0', '.Net v4.0 x64' | Export-Excel -Path $ExcelFile -WorksheetName "RegistryEntries" -AutoSize -AutoFilter -BoldTopRow -MoveToEnd
$FailedComputers | Select Name | Export-Csv -NoTypeInformation -Path $FailedFile
Log ""
Log "Script finished at $(Get-Date)."
#endregion

