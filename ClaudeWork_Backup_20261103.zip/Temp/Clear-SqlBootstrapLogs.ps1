<#
.SYNOPSIS
  Clears old SQL Server "Setup Bootstrap\Log" session folders on ONE server. Nothing else.

.DESCRIPTION
  Only touches the dated session folders under:
      <Program Files>\Microsoft SQL Server\<nnn>\Setup Bootstrap\Log\<yyyymmdd_hhmmss>
  It never touches the rest of Setup Bootstrap (SQLServerxxxx install media, Update Cache, Release),
  and never the Summary*.txt files in the Log root. Those are what SQL patching needs.

  Keeps the newest -KeepNewest session folders per instance version AND anything newer than -KeepDays.
  DRY RUN by default: it lists what it would remove and how much space that frees. Nothing is deleted
  until you add -Execute.

.EXAMPLE
  .\Clear-SqlBootstrapLogs.ps1                       # dry run on this server
  .\Clear-SqlBootstrapLogs.ps1 -Execute -ChangeNumber CHG0000000
  .\Clear-SqlBootstrapLogs.ps1 -ComputerName SERVER01   # dry run on another server over WinRM

.NOTES
  Run from an elevated PowerShell on the server (RDP), or use -ComputerName if WinRM works from where you are.
  Log written to C:\Temp\BootstrapCleanup_<server>_<stamp>.csv on the machine you run it from.
#>
[CmdletBinding()]
param(
    [string]$ComputerName,
    [int]$KeepNewest = 2,
    [int]$KeepDays   = 30,
    [switch]$Execute,
    [string]$ChangeNumber,
    [string]$OutDir = 'C:\Temp'
)
$ErrorActionPreference = 'Stop'

$work = {
    param($KeepNewest, $KeepDays, $Execute)
    $out = @()
    $roots = @()
    foreach ($pf in @($env:ProgramFiles, ${env:ProgramFiles(x86)}) | Where-Object { $_ } | Select-Object -Unique) {
        $sql = Join-Path $pf 'Microsoft SQL Server'
        if (Test-Path -LiteralPath $sql) {
            Get-ChildItem -LiteralPath $sql -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^\d{2,3}$' } | ForEach-Object {
                $log = Join-Path $_.FullName 'Setup Bootstrap\Log'
                if (Test-Path -LiteralPath $log) { $roots += $log }
            }
        }
    }
    $cutoff = (Get-Date).AddDays(-$KeepDays)
    foreach ($root in $roots) {
        # session folders only (yyyyMMdd_HHmmss), never reparse points
        $all = @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
                 Where-Object { $_.Name -match '^\d{8}_\d{6}' -and -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) } |
                 Sort-Object LastWriteTime -Descending)
        $keepSet = @{}
        $all | Select-Object -First $KeepNewest | ForEach-Object { $keepSet[$_.FullName] = 'Kept: newest' }
        foreach ($d in $all) {
            $size = 0
            try { $size = (Get-ChildItem -LiteralPath $d.FullName -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum } catch {}
            if (-not $size) { $size = 0 }
            $action = ''; $result = ''
            if ($keepSet.ContainsKey($d.FullName)) { $action = $keepSet[$d.FullName] }
            elseif ($d.LastWriteTime -gt $cutoff) { $action = "Kept: newer than $KeepDays days" }
            else { $action = 'Remove' }
            if ($action -eq 'Remove') {
                if ($Execute) {
                    # rd /s /q does not follow links, same approach as the fleet cleanup script
                    & cmd.exe /c "rd /s /q `"$($d.FullName)`"" 2>&1 | Out-Null
                    $result = if (Test-Path -LiteralPath $d.FullName) { 'FAILED (in use or access denied)' } else { 'Removed' }
                } else { $result = 'Dry run' }
            } else { $result = 'Not touched' }
            $out += [pscustomobject]@{
                Server = $env:COMPUTERNAME; Folder = $d.FullName; Modified = $d.LastWriteTime.ToString('yyyy-MM-dd HH:mm')
                SizeMB = [math]::Round($size / 1MB, 1); Action = $action; Result = $result
            }
        }
    }
    $freeC = [math]::Round((Get-PSDrive -Name C).Free / 1GB, 2)
    [pscustomobject]@{ Rows = $out; RootsFound = $roots.Count; FreeGB = $freeC }
}

if ($Execute -and -not $ChangeNumber) { throw 'Add -ChangeNumber (the CHG or task number) so the log shows why this was run.' }

if ($ComputerName) { $res = Invoke-Command -ComputerName $ComputerName -ScriptBlock $work -ArgumentList $KeepNewest, $KeepDays, ([bool]$Execute) }
else               { $res = & $work $KeepNewest $KeepDays ([bool]$Execute) }

$srv = if ($ComputerName) { $ComputerName } else { $env:COMPUTERNAME }
Write-Host ''
Write-Host "Server: $srv   SQL 'Setup Bootstrap\Log' folders found: $($res.RootsFound)   C: free now: $($res.FreeGB) GB" -ForegroundColor Cyan
$rows = @($res.Rows)
if (-not $rows.Count) { Write-Host 'Nothing to do: no bootstrap log session folders found.' -ForegroundColor Yellow; return }

$rows | Format-Table Modified, SizeMB, Action, Result, Folder -AutoSize
$rem = @($rows | Where-Object { $_.Action -eq 'Remove' })
$mb  = [math]::Round(($rem | Measure-Object SizeMB -Sum).Sum, 1)
if ($Execute) {
    $ok = @($rem | Where-Object { $_.Result -eq 'Removed' }); $bad = @($rem | Where-Object { $_.Result -like 'FAILED*' })
    Write-Host ("Removed {0} folder(s), {1} MB freed. Failed: {2}. Change: {3}" -f $ok.Count, [math]::Round(($ok | Measure-Object SizeMB -Sum).Sum,1), $bad.Count, $ChangeNumber) -ForegroundColor Green
} else {
    Write-Host ("DRY RUN: would remove {0} folder(s), about {1} MB. Add -Execute -ChangeNumber <number> to do it." -f $rem.Count, $mb) -ForegroundColor Yellow
}
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$csv = Join-Path $OutDir ("BootstrapCleanup_{0}_{1}.csv" -f $srv, (Get-Date -Format 'yyyyMMdd-HHmmss'))
$rows | Export-Csv $csv -NoTypeInformation -Encoding UTF8
Write-Host "Log: $csv"
