<#
.SYNOPSIS
    Collects current CPU and RAM utilization from a list of servers (baseline
    before Cortex XDR install), using the caller's credentials over WinRM.

.DESCRIPTION
    Reads server names from a CSV export (column: Name), prompts once for
    domain credentials, and remotes into each server in the in.lab domain to
    pull live CPU % and memory usage. Results print to screen and export to CSV.

.PARAMETER CsvPath
    Path to the input CSV (e.g. the InfraTools/vCenter export). Must contain a "Name" column.

.PARAMETER Domain
    Domain suffix to append to server names for WinRM. Defaults to "in.lab".

.PARAMETER OutputCsv
    Path to write the results CSV. Defaults to CortexBaseline_<timestamp>.csv in the current folder.

.EXAMPLE
    .\Get-CortexPreInstallBaseline.ps1 -CsvPath .\ExportList__12_.csv
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$CsvPath,

    [string]$Domain = "in.lab",

    [string]$OutputCsv = ".\CortexBaseline_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
)

# Prompt once for creds — reused for every server
$cred = Get-Credential -Message "Enter $Domain credentials"

# Pull server names from the CSV
$servers = Import-Csv -Path $CsvPath | Select-Object -ExpandProperty Name

$results = foreach ($server in $servers) {

    $fqdn = if ($server -like "*.$Domain") { $server } else { "$server.$Domain" }

    Write-Host "Checking $fqdn..." -ForegroundColor Cyan

    if (-not (Test-Connection -ComputerName $fqdn -Count 1 -Quiet)) {
        Write-Warning "$fqdn is unreachable (ping failed) — skipping"
        [PSCustomObject]@{
            Server        = $server
            Status        = "Unreachable"
            CPU_PercentUsed = $null
            Mem_TotalGB   = $null
            Mem_UsedGB    = $null
            Mem_FreeGB    = $null
            Mem_PercentUsed = $null
            Timestamp     = Get-Date
        }
        continue
    }

    try {
        $data = Invoke-Command -ComputerName $fqdn -Credential $cred -ErrorAction Stop -ScriptBlock {
            # Average CPU over 3x 1-second samples for a more stable reading
            $cpuSamples = 1..3 | ForEach-Object {
                (Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples.CookedValue
                Start-Sleep -Seconds 1
            }
            $cpuAvg = [math]::Round(($cpuSamples | Measure-Object -Average).Average, 1)

            $os = Get-CimInstance -ClassName Win32_OperatingSystem
            $totalMemGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
            $freeMemGB  = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
            $usedMemGB  = [math]::Round($totalMemGB - $freeMemGB, 2)
            $memPct     = [math]::Round(($usedMemGB / $totalMemGB) * 100, 1)

            [PSCustomObject]@{
                CPU_PercentUsed = $cpuAvg
                Mem_TotalGB     = $totalMemGB
                Mem_UsedGB      = $usedMemGB
                Mem_FreeGB      = $freeMemGB
                Mem_PercentUsed = $memPct
            }
        }

        [PSCustomObject]@{
            Server          = $server
            Status          = "OK"
            CPU_PercentUsed = $data.CPU_PercentUsed
            Mem_TotalGB     = $data.Mem_TotalGB
            Mem_UsedGB      = $data.Mem_UsedGB
            Mem_FreeGB      = $data.Mem_FreeGB
            Mem_PercentUsed = $data.Mem_PercentUsed
            Timestamp       = Get-Date
        }
    }
    catch {
        Write-Warning "$fqdn failed: $($_.Exception.Message)"
        [PSCustomObject]@{
            Server          = $server
            Status          = "Error: $($_.Exception.Message)"
            CPU_PercentUsed = $null
            Mem_TotalGB     = $null
            Mem_UsedGB      = $null
            Mem_FreeGB      = $null
            Mem_PercentUsed = $null
            Timestamp       = Get-Date
        }
    }
}

$results | Format-Table -AutoSize
$results | Export-Csv -Path $OutputCsv -NoTypeInformation
Write-Host "`nResults saved to $OutputCsv" -ForegroundColor Green
