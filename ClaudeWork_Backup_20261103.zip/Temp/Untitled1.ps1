﻿# ============================================================
# Script 4 - EFT Hop-by-Hop Upgrade - CORRECTED
# Target: ENA-INEFT01.in.lab
# ============================================================

$TargetServer  = 'ENA-INEFT01.in.lab'
$InstallerBase = 'D:\temp'
$ConfigBackup  = 'D:\ProgramData\Globalscape\EFT Server\Server Config'
$LogPath       = "C:\temp\globalscape\upgrade_log_INEFT01_$(Get-Date -Format 'yyyyMMdd').txt"

$Installers = [ordered]@{
    '8.1.0.16'  = 'EFT-nodb_8.1.0.16.exe'
    '8.2.0.46'  = 'EFT-nodb_8.2.0.46.exe'
    '8.2.1.408' = 'EFT-nodb_8.2.1.408.exe'
    '8.3.0.410' = 'EFT-nodb_8.3.0.410.exe'
    '8.3.2.565' = 'EFT-nodb_8.3.2.565.exe'
}

$HopSequence = @('8.1.0.16','8.2.0.46','8.2.1.408','8.3.0.410','8.3.2.565')

# Create log on laptop
New-Item -Path "C:\temp\globalscape" -ItemType Directory -Force | Out-Null
New-Item -Path $LogPath -ItemType File -Force | Out-Null

# --- Helpers ---
function Write-Log {
    param($msg, $color = 'White')
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $msg"
    Write-Host $entry -ForegroundColor $color
    Add-Content -Path $LogPath -Value $entry
}

function Get-EFTVersion {
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        $r = Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall' |
            Get-ItemProperty -EA SilentlyContinue |
            Where-Object { $_.DisplayName -like '*EFT*' } |
            Select-Object -First 1
        $r.DisplayVersion
    }
}

function Get-ServiceStatus {
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        (Get-Service -Name 'EFT Server' -EA SilentlyContinue).Status
    }
}

function Backup-Config {
    param($version)
    $dest = "$ConfigBackup\Backup_pre_$version-$(Get-Date -Format 'yyyyMMdd-HHmm')"
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($src, $dst)
        if (Test-Path $src) {
            Copy-Item $src $dst -Recurse -Force
            Write-Host "  Config backed up to $dst"
        } else {
            Write-Host "  ⚠️ Config path not found: $src - skipping backup"
        }
    } -ArgumentList $ConfigBackup, $dest
}

# --- Start ---
Write-Log "=== EFT Upgrade Started on $TargetServer ===" Cyan

$currentVersion = Get-EFTVersion
Write-Log "Current version: $currentVersion" Yellow
Write-Log "Upgrade path: $currentVersion > $($HopSequence -join ' > ')"

# Confirm
Write-Host "`n⚠️  Ready to upgrade $TargetServer" -ForegroundColor Yellow
Write-Host "   Snapshot confirmed: Pre-Globalscape-Upgrade-2026-04-02" -ForegroundColor Yellow
$confirm = Read-Host "Type YES to begin"
if ($confirm -ne 'YES') { Write-Log "Cancelled by user" Yellow; exit }

# --- Hop Loop ---
foreach ($targetVersion in $HopSequence) {

    if ($currentVersion -ge $targetVersion) {
        Write-Log "Skipping $targetVersion - already on $currentVersion" Yellow
        continue
    }

    Write-Log "--- Hop: $currentVersion > $targetVersion ---" Cyan

    # Backup config
    Write-Log "Backing up config..."
    Backup-Config -version $currentVersion

    # Check installer exists on remote server
    $installer     = $Installers[$targetVersion]
    $installerPath = "$InstallerBase\$installer"

    $exists = Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($p); Test-Path $p
    } -ArgumentList $installerPath

    if (-not $exists) {
        Write-Log "❌ Installer not found on $TargetServer at $installerPath" Red
        Write-Log "   Copy $installer to D:\temp\ on $TargetServer and re-run" Red
        exit
    }

    # Run installer
    Write-Log "Running $installer - this will take a few minutes..."
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        param($path, $logfile)
        Start-Process -FilePath $path -ArgumentList "/S /log $logfile" -Wait
    } -ArgumentList $installerPath, "D:\temp\install_$targetVersion.log"

    # Restart service
    Write-Log "Restarting EFT service..."
    Invoke-Command -ComputerName $TargetServer -Credential $creds -ScriptBlock {
        Restart-Service -Name 'EFT Server' -Force -EA SilentlyContinue
        Start-Sleep -Seconds 15
    }

    # Check service
    $status = Get-ServiceStatus
    Write-Log "Service status: $status"
    if ($status -ne 'Running') {
        Write-Log "❌ Service not running after hop to $targetVersion" Red
        Write-Log "   Check D:\temp\install_$targetVersion.log on $TargetServer" Red
        exit
    }

    # Verify version
    $newVersion = Get-EFTVersion
    Write-Log "Version after hop: $newVersion $(if ($newVersion -eq $targetVersion) {'✅'} else {'⚠️ mismatch - expected ' + $targetVersion})"

    # Manual console check
    Write-Host "`n================================================================" -ForegroundColor Magenta
    Write-Host "  MANUAL STEP - Hop to $targetVersion complete" -ForegroundColor Magenta
    Write-Host "================================================================" -ForegroundColor Magenta
    Write-Host "  1. RDP or open EFT Admin Console on $TargetServer" -ForegroundColor White
    Write-Host "  2. Confirm site shows RUNNING" -ForegroundColor White
    Write-Host "  3. Confirm licensed modules still show Standard License" -ForegroundColor White
    Write-Host "================================================================`n" -ForegroundColor Magenta

    $check = Read-Host "Type OK to continue to next hop, or ABORT to stop"
    if ($check -eq 'ABORT') {
        Write-Log "Aborted by user after hop to $targetVersion" Yellow
        exit
    }

    Write-Log "Console confirmed OK for $targetVersion ✅" Green
    $currentVersion = $newVersion
}

# --- Done ---
Write-Log "=== Upgrade Complete ===" Green
Write-Log "Final version on $TargetServer`: $currentVersion"
Write-Host "`n✅ All hops complete on $TargetServer" -ForegroundColor Green
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Run same script with TargetServer = ENA-INEFT03.in.lab" -ForegroundColor White
Write-Host "  2. Then upgrade both DMZ servers" -ForegroundColor White
Write-Host "  3. Then run Script 5 for cipher config (after approvals)" -ForegroundColor White