﻿<#
.SYNOPSIS
    Runs ProdReadinessCheck-Windows.ps1 against a list of servers and rolls the
    results up into one summary - built for the VA26 MED cluster (5 pairs,
    10 servers) on RITM0108839/SCTASK0157523, but works for any server list.

.DESCRIPTION
    Calls the single-server script once per hostname, writes each server's own
    CSV, then reads those back in to build one rollup CSV with PASS/FAIL/MANUAL
    counts per server so you can see at a glance which of the ten need a look.

    Where to run this from matters more than with the single-server script:
    -ComputerName on the main script uses Invoke-Command (WinRM) for anything
    that isn't the local machine, and a laptop generally won't have that trust
    relationship into Production. Peer servers already inside the same
    cluster/domain are a much better bet. Try running this FROM one of the ten
    MED boxes (RDP into acvaa-26med06, say) targeting all ten, including
    itself - the main script runs locally with no remoting needed for whichever
    one matches $env:COMPUTERNAME. If WinRM between peers is also locked down,
    fall back to RDP'ing into each of the ten individually and running the
    single-server script directly (no -ComputerName) - more clicks, same
    per-server command each time.

.PARAMETER ComputerNames
    List of servers to check. Defaults to the 10 VA26 MED servers from
    SCTASK0157523's build task (acvaa/acvab-26med06 through 10).

.PARAMETER Role
    Passed through to the main script for every server. Default MED.

.PARAMETER ScriptPath
    Path to ProdReadinessCheck-Windows.ps1. Default assumes it's in the same
    folder as this script.

.PARAMETER OutDir
    Folder for per-server CSVs plus the rollup summary CSV. Created if missing.

.PARAMETER AutoPatch
.PARAMETER PatchThresholdDays
    Passed through to the main script if you want the batch to also trigger
    Windows Update on anything stale past the threshold. Off by default -
    same change-control caveat as the single-server script applies here,
    times ten servers.

.EXAMPLE
    .\Invoke-ProdReadinessBatch.ps1

.EXAMPLE
    .\Invoke-ProdReadinessBatch.ps1 -ComputerNames acvaa-26med06,acvab-26med06 -OutDir .\va26-test
#>

[CmdletBinding()]
param(
    [string[]]$ComputerNames = @(
        "acvaa-26med06","acvaa-26med07","acvaa-26med08","acvaa-26med09","acvaa-26med10",
        "acvab-26med06","acvab-26med07","acvab-26med08","acvab-26med09","acvab-26med10"
    ),
    [string]$Role = "MED",
    [string]$ScriptPath = ".\ProdReadinessCheck-Windows.ps1",
    [string]$OutDir = ".\VA26-MED-readiness",
    [switch]$AutoPatch,
    [int]$PatchThresholdDays = 90
)

if (-not (Test-Path $ScriptPath)) {
    Write-Host "Can't find $ScriptPath - run this from the same folder as ProdReadinessCheck-Windows.ps1, or pass -ScriptPath." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $OutDir)) {
    New-Item -ItemType Directory -Path $OutDir | Out-Null
}

$summary = New-Object System.Collections.Generic.List[object]

foreach ($cn in $ComputerNames) {
    Write-Host ""
    Write-Host "========== $cn ==========" -ForegroundColor Cyan

    $csvPath = Join-Path $OutDir "$cn-readiness.csv"

    $scriptParams = @{
        ComputerName  = $cn
        Role          = $Role
        RequestedName = $cn
        OutCsv        = $csvPath
    }
    if ($AutoPatch) {
        $scriptParams.AutoPatch = $true
        $scriptParams.PatchThresholdDays = $PatchThresholdDays
    }

    try {
        & $ScriptPath @scriptParams

        if (Test-Path $csvPath) {
            $rows = Import-Csv $csvPath
            $pass = ($rows | Where-Object Status -eq "PASS").Count
            $fail = ($rows | Where-Object Status -eq "FAIL").Count
            $manual = ($rows | Where-Object Status -eq "MANUAL").Count
            $skip = ($rows | Where-Object Status -eq "SKIP").Count
            $summary.Add([pscustomobject]@{
                Server = $cn; PASS = $pass; FAIL = $fail; MANUAL = $manual; SKIP = $skip; Csv = $csvPath
            })
        } else {
            $summary.Add([pscustomobject]@{
                Server = $cn; PASS = "-"; FAIL = "-"; MANUAL = "-"; SKIP = "-"; Csv = "No CSV written - check output above for errors"
            })
        }
    } catch {
        Write-Host "FAILED to check $cn : $($_.Exception.Message)" -ForegroundColor Red
        $summary.Add([pscustomobject]@{
            Server = $cn; PASS = "-"; FAIL = "-"; MANUAL = "-"; SKIP = "-"; Csv = "ERROR: $($_.Exception.Message)"
        })
    }
}

Write-Host ""
Write-Host "=== Batch Summary: $($ComputerNames.Count) server(s), Role=$Role ===" -ForegroundColor Cyan
$summary | Format-Table -AutoSize

$rollupPath = Join-Path $OutDir "_batch-summary.csv"
$summary | Export-Csv -Path $rollupPath -NoTypeInformation
Write-Host ""
Write-Host "Per-server CSVs and rollup summary written to $OutDir"
Write-Host "If any server shows an ERROR/couldn't-connect line above, that's almost always WinRM trust between wherever this ran and that box - not a finding about the server itself."