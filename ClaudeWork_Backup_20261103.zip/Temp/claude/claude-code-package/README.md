# Claude Code Authentication Setup

## Quick Start

### macOS/Linux

1. Extract the package:
   ```bash
   unzip claude-code-package-*.zip
   cd claude-code-package
   ```

2. Run the installer:
   ```bash
   ./install.sh
   ```

3. Use the AWS profile:
   ```bash
   export AWS_PROFILE=bedrock-aws
   aws sts get-caller-identity
   ```

### Windows

#### Step 1: Download the Package
```powershell
# Use the Invoke-WebRequest command provided by your IT administrator
Invoke-WebRequest -Uri "URL_PROVIDED" -OutFile "claude-code-package.zip"
```

#### Step 2: Extract the Package

**Option A: Using Windows Explorer**
1. Right-click on `claude-code-package.zip`
2. Select "Extract All..."
3. Choose a destination folder
4. Click "Extract"

**Option B: Using PowerShell**
```powershell
# Extract to current directory
Expand-Archive -Path "claude-code-package.zip" -DestinationPath "claude-code-package"

# Navigate to the extracted folder
cd claude-code-package
```

**Option C: Using Command Prompt**
```cmd
# If you have tar available (Windows 10 1803+)
tar -xf claude-code-package.zip

# Or use PowerShell from Command Prompt
powershell -command "Expand-Archive -Path 'claude-code-package.zip' -DestinationPath 'claude-code-package'"

cd claude-code-package
```

#### Step 3: Run the Installer
```cmd
install.bat
```

The installer will:
- Check for AWS CLI installation
- Copy authentication tools to `%USERPROFILE%\claude-code-with-bedrock`
- Configure the AWS profile "bedrock-aws"
- Test the authentication

#### Step 4: Use Claude Code
```cmd
# Set the AWS profile
set AWS_PROFILE=bedrock-aws

# Verify authentication works
aws sts get-caller-identity

# Your browser will open automatically for authentication if needed
```

For PowerShell users:
```powershell
$env:AWS_PROFILE = "bedrock-aws"
aws sts get-caller-identity
```

## What This Does

- Installs the Claude Code authentication tools
- Configures your AWS CLI to use login.microsoftonline.com/7123dabd-0e87-4da9-9cb9-b7ec82011aad/v2.0 for authentication
- Sets up automatic credential refresh via your browser

## Requirements

- Python 3.8 or later
- AWS CLI v2
- pip3

## Troubleshooting

### Validating the OTEL Helper

The OTEL helper requires an active AWS profile to function. You must export `AWS_PROFILE` before running the validation command, otherwise it will fail.

**macOS/Linux (bash/zsh):**
```bash
export AWS_PROFILE=bedrock-aws
~/claude-code-with-bedrock/otel-helper --test
```

**Windows - Command Prompt:**
```cmd
set AWS_PROFILE=bedrock-aws
%USERPROFILE%\claude-code-with-bedrock\otel-helper.exe --test
```

**Windows - PowerShell:**
```powershell
$env:AWS_PROFILE = "bedrock-aws"
& "$env:USERPROFILE\claude-code-with-bedrock\otel-helper.exe" --test
```

### macOS Keychain Access Popup
On first use, macOS will ask for permission to access the keychain. This is normal and required for secure credential storage. Click "Always Allow" to avoid repeated prompts.

### Authentication Issues
If you encounter issues with authentication:
- Ensure you're assigned to the Claude Code application in your identity provider
- Check that port 8400 is available for the callback
- Contact your IT administrator for help

### Authentication Behavior

The system handles authentication automatically:
- Your browser will open when authentication is needed
- Credentials are cached securely to avoid repeated logins
- Bad credentials are automatically cleared and re-authenticated

To manually clear cached credentials (if needed):
```bash
~/claude-code-with-bedrock/credential-process --clear-cache
```

This will force re-authentication on your next AWS command.

### Browser doesn't open
Check that you're not in an SSH session. The browser needs to open on your local machine.

## Changelog

### v8
- Fixed `install.sh` duplicating AWS profile entries in `~/.aws/config` on every upgrade (macOS only). Root cause: BSD `sed` silently failed to remove the old profile section when no blank lines existed between sections. Replaced with portable `awk` approach.

### v7
- Fixed telemetry stopping after credential-process restart. Monitoring file is now always written regardless of credential storage mode, so `otel-proxy.js` can read the token.
- Fixed credential-process deadlock after `--clear-cache` on Windows. Replaced `socket.bind()` with `socket.connect()` for port lock detection to avoid Windows TCP TIME_WAIT conflicts.
- Added two-layer caching to otel-helper to eliminate telemetry UI freezes.

### v6
- Replaced manual 4-step upgrade instructions with smart installer scripts (`install.sh`, `install.bat`).
- Silent token refresh via `offline_access` — no browser popup after initial login.
- OTLP reverse proxy (`otel-proxy.js`) for full-session telemetry beyond the 65-minute token expiry.
- Switched from Nuitka to PyInstaller for Windows builds (fixes Defender false positives).
- Removed PowerShell wrapper — Python `.exe` is the sole Windows wrapper.

## Support

Contact your IT administrator for help.

Configuration Details:
- Organization: login.microsoftonline.com/7123dabd-0e87-4da9-9cb9-b7ec82011aad/v2.0
- Region: us-west-2
- Package Version: 2026-03-10-100700
