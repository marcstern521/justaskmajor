#!/bin/bash
# OTEL Headers Wrapper - reads monitoring token and outputs user attribute headers
# Bypasses otel-helper-bin to avoid JWT expiration triggering browser re-auth
# User attributes (email, name, department) don't change during a session
# Also launches the OTLP proxy for full-session telemetry (token refresh on every request)

PROFILE="${AWS_PROFILE:-bedrock-aws}"
MONITORING_FILE="$HOME/.claude-code-session/${PROFILE}-monitoring.json"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Detect Python command (python3 on Linux/macOS, python on some systems)
PYTHON_CMD="python3"
if ! command -v python3 &>/dev/null; then
    PYTHON_CMD="python"
fi

# ---------------------------------------------------------------------------
# Ensure OTLP proxy is running (Phase 2 — full-session telemetry)
# ---------------------------------------------------------------------------
_read_endpoint_from_settings() {
    # Fallback: read OTEL_COLLECTOR_ENDPOINT from ~/.claude/settings.json
    local settings_file="$HOME/.claude/settings.json"
    if [ -f "$settings_file" ]; then
        $PYTHON_CMD -c "
import json, sys
for enc in ('utf-8-sig', 'utf-16', 'utf-8'):
    try:
        with open(sys.argv[1], encoding=enc) as f:
            print(json.load(f).get('env', {}).get('OTEL_COLLECTOR_ENDPOINT', ''))
        break
    except (UnicodeDecodeError, json.JSONDecodeError):
        continue
" "$settings_file" 2>/dev/null
    fi
}

ensure_proxy_running() {
    local target="${OTEL_COLLECTOR_ENDPOINT:-}"
    if [ -z "$target" ]; then
        target="$(_read_endpoint_from_settings)"
    fi
    if [ -z "$target" ]; then
        return  # No target configured — skip proxy
    fi

    local proxy_script="$SCRIPT_DIR/otel-proxy.js"
    if [ ! -f "$proxy_script" ]; then
        return  # Proxy script not deployed
    fi

    # Check if proxy is already listening
    if curl -s -o /dev/null --connect-timeout 1 http://127.0.0.1:4318/health 2>/dev/null; then
        return  # Already running
    fi

    # Launch proxy as background process
    nohup node "$proxy_script" "$target" 4318 >/dev/null 2>&1 &

    # Brief wait for proxy to bind
    for i in $(seq 1 10); do
        sleep 0.3
        if curl -s -o /dev/null --connect-timeout 1 http://127.0.0.1:4318/health 2>/dev/null; then
            break
        fi
    done
}

ensure_proxy_running

# ---------------------------------------------------------------------------
# Main: read monitoring file, refresh token if needed, output headers
# ---------------------------------------------------------------------------
_exec_fallback() {
    # Fall back to the compiled otel-helper for first auth
    for name in otel-helper.exe otel-helper-bin otel-helper; do
        if [ -x "$SCRIPT_DIR/$name" ] || [ -f "$SCRIPT_DIR/$name" ]; then
            exec "$SCRIPT_DIR/$name" "$@"
        fi
    done
    exit 0
}

if [ ! -f "$MONITORING_FILE" ]; then
    _exec_fallback "$@"
fi

# Use Python3 to decode JWT, refresh if expired, and output headers
export __OTEL_MONITORING_FILE="$MONITORING_FILE"
OUTPUT=$($PYTHON_CMD << 'PYEOF' 2>/dev/null
import os, json, base64, hashlib, sys, time, urllib.request, urllib.parse

def b64url_decode(s):
    s = s + '=' * (4 - len(s) % 4)
    s = s.replace('-', '+').replace('_', '/')
    return base64.b64decode(s).decode('utf-8')

def decode_jwt_payload(token):
    return json.loads(b64url_decode(token.split('.')[1]))

def refresh_id_token(refresh_token, payload):
    iss = payload.get('iss', '')
    aud = payload.get('aud', '')
    if 'microsoftonline.com' in iss:
        base = iss.replace('/v2.0', '')
        token_url = f"{base}/oauth2/v2.0/token"
    elif 'okta.com' in iss:
        token_url = f"{iss}/oauth2/v1/token"
    elif 'auth0.com' in iss:
        token_url = f"{iss}/oauth/token"
    else:
        return None, None
    post_data = urllib.parse.urlencode({
        'grant_type': 'refresh_token',
        'client_id': aud,
        'refresh_token': refresh_token,
        'scope': 'openid profile email offline_access',
    }).encode('utf-8')
    try:
        req = urllib.request.Request(token_url, data=post_data,
            headers={'Content-Type': 'application/x-www-form-urlencoded'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            tokens = json.loads(resp.read().decode('utf-8'))
        new_id = tokens.get('id_token')
        new_refresh = tokens.get('refresh_token', refresh_token)
        return (new_id, new_refresh) if new_id else (None, None)
    except Exception:
        return None, None

try:
    monitoring_file = os.environ.get('__OTEL_MONITORING_FILE', '')
    with open(monitoring_file) as f:
        data = json.load(f)

    token = data['token']
    refresh_token = data.get('refresh_token')
    payload = decode_jwt_payload(token)

    # Check if token is expired (with 60s buffer)
    exp = payload.get('exp', 0)
    now = int(time.time())
    if now >= (exp - 60) and refresh_token:
        new_token, new_refresh = refresh_id_token(refresh_token, payload)
        if new_token:
            token = new_token
            payload = decode_jwt_payload(token)
            data['token'] = new_token
            data['expires'] = payload.get('exp', 0)
            if new_refresh:
                data['refresh_token'] = new_refresh
            try:
                with open(monitoring_file, 'w') as f:
                    json.dump(data, f)
            except Exception:
                pass

    # Extract user info
    email = payload.get('email') or payload.get('preferred_username') or payload.get('mail') or 'unknown@example.com'
    username = payload.get('cognito:username') or payload.get('preferred_username') or email.split('@')[0]

    sub = payload.get('sub', '')
    h = hashlib.sha256(sub.encode()).hexdigest()
    user_id = f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"

    iss = payload.get('iss', '')
    if 'microsoftonline.com' in iss:
        org = 'azure'
    elif 'okta.com' in iss:
        org = 'okta'
    elif 'auth0.com' in iss:
        org = 'auth0'
    else:
        org = 'default'

    headers = {
        "x-user-email": email,
        "x-user-id": user_id,
        "x-user-name": username,
        "x-department": "unspecified",
        "x-team-id": "default-team",
        "x-cost-center": "general",
        "x-organization": org,
        "x-location": "remote",
        "x-role": "user",
        "x-manager": "unassigned"
    }
    # Include Bearer token for ALB JWT validation
    if os.environ.get('OTEL_JWT_AUTH', '').lower() in ('true', '1', 'yes'):
        headers['authorization'] = f'Bearer {token}'
    print(json.dumps(headers))
except Exception:
    sys.exit(1)
PYEOF
)

if [ -z "$OUTPUT" ]; then
    _exec_fallback "$@"
fi

echo "$OUTPUT"
