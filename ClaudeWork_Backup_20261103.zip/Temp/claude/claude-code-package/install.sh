#!/bin/bash
# Claude Code Authentication Installer
# Organization: login.microsoftonline.com/7123dabd-0e87-4da9-9cb9-b7ec82011aad/v2.0
# Generated: 2026-03-06 12:25:17

set -e

echo "======================================"
echo "Claude Code Authentication Installer"
echo "======================================"
echo
echo "Organization: login.microsoftonline.com/7123dabd-0e87-4da9-9cb9-b7ec82011aad/v2.0"
echo


# Check prerequisites
echo "Checking prerequisites..."

if ! command -v aws &> /dev/null; then
    echo "❌ AWS CLI is not installed"
    echo "   Please install from https://aws.amazon.com/cli/"
    exit 1
fi

if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    echo "   Please install Python 3.8 or later"
    exit 1
fi

NODE_AVAILABLE=false
if command -v node &> /dev/null; then
    NODE_AVAILABLE=true
else
    echo "⚠️  Node.js not found. OTEL telemetry proxy will not be available."
    echo "   Telemetry will be limited to ~65 minutes per session."
fi

echo "✓ Prerequisites found"

# Detect platform and architecture
echo
echo "Detecting platform and architecture..."
if [[ "$OSTYPE" == "darwin"* ]]; then
    PLATFORM="macos"
    ARCH=$(uname -m)
    if [[ "$ARCH" == "arm64" ]]; then
        echo "✓ Detected macOS ARM64 (Apple Silicon)"
        BINARY_SUFFIX="macos-arm64"
    else
        echo "✓ Detected macOS Intel"
        BINARY_SUFFIX="macos-intel"
    fi
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    PLATFORM="linux"
    ARCH=$(uname -m)
    if [[ "$ARCH" == "aarch64" ]] || [[ "$ARCH" == "arm64" ]]; then
        echo "✓ Detected Linux ARM64"
        BINARY_SUFFIX="linux-arm64"
    else
        echo "✓ Detected Linux x64"
        BINARY_SUFFIX="linux-x64"
    fi
else
    echo "❌ Unsupported platform: $OSTYPE"
    echo "   This installer supports macOS and Linux only."
    exit 1
fi

# Check if binary for platform exists
CREDENTIAL_BINARY="credential-process-$BINARY_SUFFIX"
OTEL_BINARY="otel-helper-$BINARY_SUFFIX"

if [ ! -f "$CREDENTIAL_BINARY" ]; then
    echo "❌ Binary not found for your platform: $CREDENTIAL_BINARY"
    echo "   Please ensure you have the correct package for your architecture."
    exit 1
fi

# Create directory
echo
echo "Installing authentication tools..."
mkdir -p ~/claude-code-with-bedrock

# Copy appropriate binary
cp "$CREDENTIAL_BINARY" ~/claude-code-with-bedrock/credential-process

# Copy config
cp config.json ~/claude-code-with-bedrock/
chmod +x ~/claude-code-with-bedrock/credential-process

# macOS Keychain Notice
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo
    echo "⚠️  macOS Keychain Access:"
    echo "   On first use, macOS will ask for permission to access the keychain."
    echo "   This is normal and required for secure credential storage."
    echo "   Click 'Always Allow' when prompted."
fi

# Determine if OTEL helper will be available
OTEL_COPIED=false
if [ -f "$OTEL_BINARY" ]; then
    OTEL_COPIED=true
fi

# Copy OTEL helper executable if present
if [ -f "$OTEL_BINARY" ]; then
    echo
    echo "Installing OTEL helper..."
    # Install original as otel-helper-bin (used as fallback by wrapper)
    cp "$OTEL_BINARY" ~/claude-code-with-bedrock/otel-helper-bin
    chmod +x ~/claude-code-with-bedrock/otel-helper-bin
    # Also keep as otel-helper for --test flag
    cp "$OTEL_BINARY" ~/claude-code-with-bedrock/otel-helper
    chmod +x ~/claude-code-with-bedrock/otel-helper
    echo "✓ OTEL helper installed"
fi

# Copy OTEL wrapper script (reads monitoring file directly, avoids re-auth)
if [ -f "otel-helper-wrapper.sh" ]; then
    echo "Installing OTEL wrapper..."
    cp "otel-helper-wrapper.sh" ~/claude-code-with-bedrock/otel-helper-wrapper.sh
    chmod +x ~/claude-code-with-bedrock/otel-helper-wrapper.sh
    echo "✓ OTEL wrapper installed"
fi

# Copy OTEL proxy (Node.js reverse proxy for full-session telemetry)
if [ -f "otel-proxy.js" ]; then
    echo "Installing OTEL proxy..."
    cp "otel-proxy.js" ~/claude-code-with-bedrock/otel-proxy.js
    echo "✓ OTEL proxy installed"
fi

# Add debug info if OTEL helper was installed
if [ -f ~/claude-code-with-bedrock/otel-helper ]; then
    echo "The OTEL helper will extract user attributes from authentication tokens"
    echo "and include them in metrics. To test the helper, run:"
    echo "  ~/claude-code-with-bedrock/otel-helper --test"
fi

# Configure Claude Code settings (JSON merge — preserves user customizations)
if [ -d "claude-settings" ] && [ -f "claude-settings/settings.json" ]; then
    echo
    echo "Configuring Claude Code settings..."
    mkdir -p ~/.claude

    CRED_PATH="$HOME/claude-code-with-bedrock/credential-process"
    OTEL_WRAPPER_PATH="$HOME/claude-code-with-bedrock/otel-helper-wrapper.sh"

    if [ -f ~/.claude/settings.json ]; then
        # Existing settings — JSON merge (update infrastructure, preserve user customizations)
        echo "Existing Claude Code settings found - merging updates..."

        # Create backup
        BACKUP_DATE=$(date +%Y%m%d)
        BACKUP_PATH="$HOME/.claude/settings.json.backup-$BACKUP_DATE"
        echo "Creating backup: $BACKUP_PATH"
        cp ~/.claude/settings.json "$BACKUP_PATH"

        # JSON merge via python3
        python3 << PYEOF
import json, sys

try:
    with open("claude-settings/settings.json") as f:
        template = json.load(f)
    with open("$HOME/.claude/settings.json") as f:
        existing = json.load(f)

    # Ensure env object exists
    if "env" not in existing:
        existing["env"] = {}

    # Infrastructure keys — always update from template
    infra_keys = [
        "CLAUDE_CODE_USE_BEDROCK",
        "CLAUDE_CODE_ENABLE_TELEMETRY",
        "OTEL_METRICS_EXPORTER",
        "OTEL_LOGS_EXPORTER",
        "OTEL_EXPORTER_OTLP_PROTOCOL",
        "OTEL_EXPORTER_OTLP_ENDPOINT",
        "OTEL_COLLECTOR_ENDPOINT",
        "OTEL_JWT_AUTH",
    ]
    for key in infra_keys:
        if key in template.get("env", {}):
            existing["env"][key] = template["env"][key]

    # Default keys — set only if missing (user may have customized)
    default_keys = [
        "AWS_REGION",
        "AWS_PROFILE",
        "ANTHROPIC_MODEL",
        "ANTHROPIC_SMALL_FAST_MODEL",
        "OTEL_RESOURCE_ATTRIBUTES",
    ]
    for key in default_keys:
        if key not in existing["env"] and key in template.get("env", {}):
            existing["env"][key] = template["env"][key]

    # Update paths
    existing["awsAuthRefresh"] = "$CRED_PATH --profile bedrock-aws"
    if "$OTEL_COPIED" == "true":
        existing["otelHeadersHelper"] = "$OTEL_WRAPPER_PATH"

    with open("$HOME/.claude/settings.json", "w") as f:
        json.dump(existing, f, indent=2)
        f.write("\n")

    print("✓ Claude Code settings merged successfully.")
    print("  Infrastructure settings updated, user customizations preserved.")
except Exception as e:
    print(f"⚠️  Settings merge failed: {e}", file=sys.stderr)
    print("  Your existing settings were not modified.", file=sys.stderr)
    print(f"  Backup saved at: $BACKUP_PATH", file=sys.stderr)
    sys.exit(1)
PYEOF
    else
        # No existing settings — fresh install from template
        echo "Installing Claude Code settings..."
        if [ "$OTEL_COPIED" = "true" ]; then
            sed -e "s|__OTEL_HELPER_PATH__|$OTEL_WRAPPER_PATH|g" \
                -e "s|__CREDENTIAL_PROCESS_PATH__|$CRED_PATH|g" \
                "claude-settings/settings.json" > ~/.claude/settings.json
        else
            sed -e '/"otelHeadersHelper"/d' \
                -e "s|__CREDENTIAL_PROCESS_PATH__|$CRED_PATH|g" \
                "claude-settings/settings.json" > ~/.claude/settings.json
        fi
        echo "✓ Claude Code settings configured"
    fi
fi

# Update AWS config
echo
echo "Configuring AWS profiles..."
mkdir -p ~/.aws

# Backup existing AWS config if it exists
if [ -f ~/.aws/config ]; then
    BACKUP_DATE=$(date +%Y%m%d)
    AWS_BACKUP_PATH="$HOME/.aws/config.backup-$BACKUP_DATE"
    echo "Creating backup of AWS config: $AWS_BACKUP_PATH"
    cp ~/.aws/config "$AWS_BACKUP_PATH"
fi

# Read all profiles from config.json
PROFILES=$(python3 -c "import json; profiles = list(json.load(open('config.json')).keys()); print(' '.join(profiles))")

if [ -z "$PROFILES" ]; then
    echo "❌ No profiles found in config.json"
    exit 1
fi

echo "Found profiles: $PROFILES"
echo

# Get region from package settings (for Bedrock calls, not infrastructure)
if [ -f "claude-settings/settings.json" ]; then
    DEFAULT_REGION=$(python3 -c "import json; print(json.load(open('claude-settings/settings.json'))[
    'env']['AWS_REGION'])" 2>/dev/null || echo "us-west-2")
else
    DEFAULT_REGION="us-west-2"
fi

# Configure each profile
for PROFILE_NAME in $PROFILES; do
    echo "Configuring AWS profile: $PROFILE_NAME"

    # Remove old profile if exists (awk handles missing blank lines between sections, works on both macOS and Linux)
    if [ -f ~/.aws/config ]; then
        awk -v target="[profile $PROFILE_NAME]" '
            $0 == target { skip=1; next }
            /^\[/ { skip=0 }
            !skip
        ' ~/.aws/config > ~/.aws/config.tmp && mv ~/.aws/config.tmp ~/.aws/config
    fi

    # Get profile-specific region from config.json
    PROFILE_REGION=$(python3 -c "import json; print(json.load(open('config.json')).get('$PROFILE_NAME',     {}).get('aws_region', '$DEFAULT_REGION'))")

    # Add new profile with --profile flag (cross-platform, no shell required)
    cat >> ~/.aws/config << EOF
[profile $PROFILE_NAME]
credential_process = $HOME/claude-code-with-bedrock/credential-process --profile $PROFILE_NAME
region = $PROFILE_REGION
EOF
    echo "  ✓ Created AWS profile '$PROFILE_NAME'"
done

echo
echo "======================================"
echo "✓ Installation complete!"
echo "======================================"
echo
echo "You can now start Claude Code. A browser window will open once for"
echo "initial login. All subsequent sessions will authenticate silently."
echo
