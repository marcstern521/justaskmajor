@echo off
cd /d "%~dp0"
echo Working directory: %CD%
REM Claude Code Authentication Installer for Windows
REM Organization: login.microsoftonline.com/7123dabd-0e87-4da9-9cb9-b7ec82011aad/v2.0
REM Generated: 2026-03-06 12:25:17

echo ======================================
echo Claude Code Authentication Installer
echo ======================================
echo.
echo Organization: login.microsoftonline.com/7123dabd-0e87-4da9-9cb9-b7ec82011aad/v2.0
echo.

REM Check prerequisites
echo Checking prerequisites...

where aws >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: AWS CLI is not installed
    echo        Please install from https://aws.amazon.com/cli/
    pause
    exit /b 1
)

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo WARNING: Node.js is not installed. OTEL telemetry proxy will not be available.
    echo          Telemetry will be limited to ~65 minutes per session.
    set "NODE_AVAILABLE=false"
) else (
    set "NODE_AVAILABLE=true"
)

echo OK Prerequisites found
echo.

REM Create directory
echo Installing authentication tools...
if not exist "%USERPROFILE%\claude-code-with-bedrock" mkdir "%USERPROFILE%\claude-code-with-bedrock"

REM Copy credential process executable with renamed target
echo Copying credential process...
echo   Source: %CD%\credential-process-windows.exe
echo   Dest:   %USERPROFILE%\claude-code-with-bedrock\credential-process.exe
if not exist "credential-process-windows.exe" (
    echo ERROR: credential-process-windows.exe not found in %CD%
    echo        Make sure all package files are extracted to the same folder as install.bat
    pause
    exit /b 1
)
copy /Y "credential-process-windows.exe" "%USERPROFILE%\claude-code-with-bedrock\credential-process.exe" >nul
if %errorlevel% neq 0 (
    echo ERROR: Failed to copy credential-process-windows.exe
    echo        The file exists but could not be copied. Possible causes:
    echo        - Antivirus software blocked or quarantined the file
    echo        - Insufficient permissions to write to %USERPROFILE%\claude-code-with-bedrock\
    pause
    exit /b 1
)

REM Copy OTEL helper if it exists with renamed target
set "OTEL_COPIED=false"
if exist "otel-helper-windows.exe" (
    echo Copying OTEL helper...
    echo   Source: %CD%\otel-helper-windows.exe
    echo   Dest:   %USERPROFILE%\claude-code-with-bedrock\otel-helper.exe
    copy /Y "otel-helper-windows.exe" "%USERPROFILE%\claude-code-with-bedrock\otel-helper.exe" >nul
    if %errorlevel% neq 0 (
        echo WARNING: Failed to copy otel-helper-windows.exe - telemetry will not be available
    ) else (
        set "OTEL_COPIED=true"
    )
)

REM Copy OTEL wrapper (reads monitoring file directly, avoids re-auth popups)
if exist "otel-helper-wrapper-windows.exe" (
    echo Copying OTEL wrapper...
    echo   Source: %CD%\otel-helper-wrapper-windows.exe
    echo   Dest:   %USERPROFILE%\claude-code-with-bedrock\otel-helper-wrapper.exe
    copy /Y "otel-helper-wrapper-windows.exe" "%USERPROFILE%\claude-code-with-bedrock\otel-helper-wrapper.exe" >nul
    if %errorlevel% neq 0 (
        echo WARNING: Failed to copy otel-helper-wrapper-windows.exe
    ) else (
        set "OTEL_COPIED=true"
    )
)

REM Copy OTEL proxy (Node.js reverse proxy for full-session telemetry)
if exist "otel-proxy.js" (
    echo Copying OTEL proxy...
    echo   Source: %CD%\otel-proxy.js
    echo   Dest:   %USERPROFILE%\claude-code-with-bedrock\otel-proxy.js
    copy /Y "otel-proxy.js" "%USERPROFILE%\claude-code-with-bedrock\otel-proxy.js" >nul
    if %errorlevel% neq 0 (
        echo WARNING: Failed to copy otel-proxy.js - telemetry may be limited to 65 minutes
    )
)

REM Copy configuration
echo Copying configuration...
echo   Source: %CD%\config.json
echo   Dest:   %USERPROFILE%\claude-code-with-bedrock\config.json
if not exist "config.json" (
    echo ERROR: config.json not found in %CD%
    echo        Make sure all package files are extracted to the same folder as install.bat
    pause
    exit /b 1
)
copy /Y "config.json" "%USERPROFILE%\claude-code-with-bedrock\" >nul
if %errorlevel% neq 0 (
    echo ERROR: Failed to copy config.json
    echo        Check permissions on %USERPROFILE%\claude-code-with-bedrock\
    pause
    exit /b 1
)

REM Configure Claude Code settings (JSON merge — preserves user customizations)
setlocal EnableDelayedExpansion

if exist "claude-settings\settings.json" (
    echo.
    echo Configuring Claude Code settings...
    if not exist "%USERPROFILE%\.claude" mkdir "%USERPROFILE%\.claude"

    REM Build paths with forward slashes for JSON
    set "CRED_PATH=%USERPROFILE%\claude-code-with-bedrock\credential-process.exe"
    set "OTEL_PATH=%USERPROFILE%\claude-code-with-bedrock\otel-helper-wrapper.exe"

    if exist "%USERPROFILE%\.claude\settings.json" (
        REM Existing settings found — merge (update infrastructure keys, preserve user customizations)
        echo Existing Claude Code settings found - merging updates...

        REM Create backup
        for /f %%d in ('powershell -NoProfile -Command "Get-Date -Format 'yyyyMMdd'"') do set BACKUP_DATE=%%d
        set "BACKUP_PATH=%USERPROFILE%\.claude\settings.json.backup-!BACKUP_DATE!"
        echo Creating backup: !BACKUP_PATH!
        copy /Y "%USERPROFILE%\.claude\settings.json" "!BACKUP_PATH!" >nul

        REM JSON merge via PowerShell — updates only infrastructure keys
        powershell -NoProfile -Command ^
            "$credPath = '%USERPROFILE%\claude-code-with-bedrock\credential-process.exe'.Replace('\', '/'); " ^
            "$otelPath = '%USERPROFILE%\claude-code-with-bedrock\otel-helper-wrapper.exe'.Replace('\', '/'); " ^
            "$template = Get-Content 'claude-settings\settings.json' -Raw | ConvertFrom-Json; " ^
            "$existing = Get-Content '%USERPROFILE%\.claude\settings.json' -Raw | ConvertFrom-Json; " ^
            "" ^
            "if (-not $existing.PSObject.Properties['env']) { " ^
            "    $existing | Add-Member -NotePropertyName 'env' -NotePropertyValue ([PSCustomObject]@{}) " ^
            "} " ^
            "" ^
            "$infraKeys = @( " ^
            "    'CLAUDE_CODE_USE_BEDROCK', " ^
            "    'CLAUDE_CODE_ENABLE_TELEMETRY', " ^
            "    'OTEL_METRICS_EXPORTER', " ^
            "    'OTEL_LOGS_EXPORTER', " ^
            "    'OTEL_EXPORTER_OTLP_PROTOCOL', " ^
            "    'OTEL_EXPORTER_OTLP_ENDPOINT', " ^
            "    'OTEL_COLLECTOR_ENDPOINT', " ^
            "    'OTEL_JWT_AUTH' " ^
            "); " ^
            "" ^
            "foreach ($key in $infraKeys) { " ^
            "    $val = $template.env.PSObject.Properties[$key]; " ^
            "    if ($val) { " ^
            "        if ($existing.env.PSObject.Properties[$key]) { " ^
            "            $existing.env.$key = $val.Value " ^
            "        } else { " ^
            "            $existing.env | Add-Member -NotePropertyName $key -NotePropertyValue $val.Value " ^
            "        } " ^
            "    } " ^
            "} " ^
            "" ^
            "$defaultKeys = @( " ^
            "    'AWS_REGION', 'AWS_PROFILE', 'ANTHROPIC_MODEL', " ^
            "    'ANTHROPIC_SMALL_FAST_MODEL', 'OTEL_RESOURCE_ATTRIBUTES' " ^
            "); " ^
            "foreach ($key in $defaultKeys) { " ^
            "    if (-not $existing.env.PSObject.Properties[$key]) { " ^
            "        $val = $template.env.PSObject.Properties[$key]; " ^
            "        if ($val) { " ^
            "            $existing.env | Add-Member -NotePropertyName $key -NotePropertyValue $val.Value " ^
            "        } " ^
            "    } " ^
            "} " ^
            "" ^
            "if ($existing.PSObject.Properties['awsAuthRefresh']) { " ^
            "    $existing.awsAuthRefresh = \"$credPath --profile bedrock-aws\" " ^
            "} else { " ^
            "    $existing | Add-Member -NotePropertyName 'awsAuthRefresh' -NotePropertyValue \"$credPath --profile bedrock-aws\" " ^
            "} " ^
            "" ^
            "if ($existing.PSObject.Properties['otelHeadersHelper']) { " ^
            "    $existing.otelHeadersHelper = $otelPath " ^
            "} else { " ^
            "    $existing | Add-Member -NotePropertyName 'otelHeadersHelper' -NotePropertyValue $otelPath " ^
            "} " ^
            "" ^
            "$existing | ConvertTo-Json -Depth 10 | Set-Content '%USERPROFILE%\.claude\settings.json' -Encoding utf8"

        if %errorlevel% equ 0 (
            echo OK: Claude Code settings merged successfully.
            echo     Infrastructure settings updated, user customizations preserved.
        ) else (
            echo WARNING: Settings merge failed. Your existing settings were not modified.
            echo          Backup saved at: !BACKUP_PATH!
        )
    ) else (
        REM No existing settings — fresh install from template
        echo Installing Claude Code settings...

        if "!OTEL_COPIED!"=="true" (
            powershell -NoProfile -Command ^
                "$otel = '%USERPROFILE%\claude-code-with-bedrock\otel-helper-wrapper.exe'.Replace('\', '/'); " ^
                "$cred = '%USERPROFILE%\claude-code-with-bedrock\credential-process.exe'.Replace('\', '/'); " ^
                "(Get-Content 'claude-settings\settings.json') " ^
                "-replace '__OTEL_HELPER_PATH__', $otel " ^
                "-replace '__CREDENTIAL_PROCESS_PATH__', $cred | " ^
                "Set-Content '%USERPROFILE%\.claude\settings.json'"
        ) else (
            powershell -NoProfile -Command ^
                "$cred = '%USERPROFILE%\claude-code-with-bedrock\credential-process.exe'.Replace('\', '/'); " ^
                "(Get-Content 'claude-settings\settings.json') " ^
                "-replace '.*\"otelHeadersHelper\".*', '' " ^
                "-replace '__CREDENTIAL_PROCESS_PATH__', $cred | " ^
                "Set-Content '%USERPROFILE%\.claude\settings.json'"
        )

        if %errorlevel% equ 0 (
            echo OK: Claude Code settings configured.
        ) else (
            echo WARNING: Failed to configure Claude Code settings.
        )
    )
)

REM Configure AWS profiles
echo.
echo Configuring AWS profiles...

REM Backup existing AWS config if it exists
if exist "%USERPROFILE%\.aws\config" (
    for /f %%d in ('powershell -NoProfile -Command "Get-Date -Format 'yyyyMMdd'"') do set BACKUP_DATE=%%d
    set "AWS_BACKUP_PATH=%USERPROFILE%\.aws\config.backup-!BACKUP_DATE!"
    echo Creating backup of AWS config: !AWS_BACKUP_PATH!
    copy /Y "%USERPROFILE%\.aws\config" "!AWS_BACKUP_PATH!" >nul
)

REM Read profiles from config.json using PowerShell
set GET_PROFILE_NAMES=powershell -NoProfile -Command "(Get-Content config.json | ConvertFrom-Json).PSObject.Properties.Name"

for /f "tokens=*" %%p in ('!GET_PROFILE_NAMES!') do (
    echo Configuring AWS profile: %%p

    REM Get profile-specific region
    set "PROFILE_REGION="
    for /f "usebackq tokens=*" %%r in (`powershell -NoProfile -Command "(Get-Content config.json | ConvertFrom-Json).'%%p'.aws_region"`) do set "PROFILE_REGION=%%r"

    REM Set credential process with --profile flag (cross-platform, no wrapper needed)
    aws configure set credential_process "%USERPROFILE%\claude-code-with-bedrock\credential-process.exe --profile %%p" --profile %%p

    REM Set region
    if "!PROFILE_REGION!" neq "" (
        aws configure set region !PROFILE_REGION! --profile %%p
    ) else (
        aws configure set region us-west-2 --profile %%p
    )

    echo    OK Created AWS profile '%%p'
)

endlocal

echo.
echo ======================================
echo Installation complete!
echo ======================================
echo.
echo You can now start Claude Code. A browser window will open once for
echo initial login. All subsequent sessions will authenticate silently.
echo.
pause
