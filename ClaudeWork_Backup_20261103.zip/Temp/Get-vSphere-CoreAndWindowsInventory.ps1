﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidateSet('lab', 'inopslab', 'prod')]
    [string]$Environment,

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = $PWD
)

$ErrorActionPreference = 'Stop'

try {
    Import-Module VCF.PowerCLI -ErrorAction Stop
}
catch {
    try {
        Import-Module VMware.PowerCLI -ErrorAction Stop
    }
    catch {
        throw "PowerCLI module not found. Install VCF.PowerCLI or VMware.PowerCLI first."
    }
}

try {
    Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false -Scope User | Out-Null
}
catch {
    Write-Warning "Could not set PowerCLI certificate handling automatically."
}

function Get-CleanVCenterName {
    param([string]$Server)
    return ($Server -replace '^https?://', '').TrimEnd('/')
}

function Get-OsFamily {
    param([string]$GuestFullName)

    if ([string]::IsNullOrWhiteSpace($GuestFullName)) { return 'Unknown' }
    if ($GuestFullName -match 'Windows') { return 'Windows' }
    if ($GuestFullName -match 'Linux|Ubuntu|CentOS|Red Hat|RHEL|SUSE|Debian|Oracle|Rocky|Alma') { return 'Linux' }
    return 'Other'
}

if (-not $Environment) {
    $Environment = Read-Host "Enter environment (lab, inopslab, prod)"
}

switch ($Environment.ToLower()) {
    'lab' {
        $VCenter = 'eng-vmvce01.in.lab'
        $SuggestedUser = 'in\marc.stern'
    }
    'inopslab' {
        $VCenter = 'oua-vmvce01.inopslab.com'
        $SuggestedUser = 'inopslab\marc.stern'
    }
    'prod' {
        $VCenter = 'lax-vmvce01.inucn.com'
        $SuggestedUser = 'inucn\marc.stern'
    }
    default {
        throw "Unsupported environment: $Environment"
    }
}

$VCenter = Get-CleanVCenterName -Server $VCenter

if (-not (Test-Path $OutputPath)) {
    New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
}

Write-Host ""
Write-Host "Environment    : $Environment" -ForegroundColor Yellow
Write-Host "vCenter        : $VCenter" -ForegroundColor Yellow
Write-Host "Suggested user : $SuggestedUser" -ForegroundColor Yellow
Write-Host "Output path    : $OutputPath" -ForegroundColor Yellow
Write-Host ""

$Credential = Get-Credential -Message "Enter credentials for $Environment ($SuggestedUser)"

try {
    Connect-VIServer -Server $VCenter -Credential $Credential -ErrorAction Stop | Out-Null

    Write-Host "Collecting VM inventory..." -ForegroundColor Cyan
    $allVms = Get-VM
    $allHosts = Get-VMHost

    $hardwareEligibleHosts = $allHosts | Where-Object {
        $_.ConnectionState -in @('Connected', 'Maintenance')
    }

    $hardwareIneligibleHosts = $allHosts | Where-Object {
        $_.ConnectionState -notin @('Connected', 'Maintenance')
    }

    if ($hardwareIneligibleHosts) {
        Write-Warning ("Skipping Get-VMHostHardware for these hosts due to state: " + (($hardwareIneligibleHosts | ForEach-Object {
            "$($_.Name) [$($_.ConnectionState)]"
        }) -join ', '))
    }

    $hostHardware = @()
    if ($hardwareEligibleHosts) {
        $hostHardware = Get-VMHostHardware -VMHost $hardwareEligibleHosts
    }

    $vmReport = foreach ($vm in $allVms) {
        $guestOs = $vm.Guest.OSFullName
        if ([string]::IsNullOrWhiteSpace($guestOs)) {
            $guestOs = $vm.ExtensionData.Config.GuestFullName
        }

        $osFamily = Get-OsFamily -GuestFullName $guestOs

        $ipAddress = $null
        if ($vm.Guest.IPAddress) {
            $ipAddress = ($vm.Guest.IPAddress | Where-Object { $_ -match '\.' } | Select-Object -First 1)
            if (-not $ipAddress) {
                $ipAddress = ($vm.Guest.IPAddress | Select-Object -First 1)
            }
        }

        $dnsName = $vm.Guest.HostName
        if ([string]::IsNullOrWhiteSpace($dnsName)) {
            $dnsName = $vm.ExtensionData.Guest.HostName
        }

        $clusterName = $null
        try { $clusterName = (Get-Cluster -VM $vm -ErrorAction Stop).Name } catch {}

        $datacenterName = $null
        try { $datacenterName = (Get-Datacenter -VM $vm -ErrorAction Stop).Name } catch {}

        [PSCustomObject]@{
            VMName       = $vm.Name
            PowerState   = $vm.PowerState.ToString()
            VCenter      = $VCenter
            Datacenter   = $datacenterName
            Cluster      = $clusterName
            Host         = $vm.VMHost.Name
            GuestOS      = $guestOs
            IPAddress    = $ipAddress
            DNSName      = $dnsName
            CpuCount     = $vm.NumCpu
            RAM_GB       = [math]::Round($vm.MemoryGB, 2)
            ToolsStatus  = $vm.ExtensionData.Guest.ToolsStatus
            ToolsVersion = $vm.ExtensionData.Guest.ToolsVersion
            OSFamily     = $osFamily
            TemplateOrVM = if ($vm.ExtensionData.Config.Template) { 'Template' } else { 'VM' }
            IsWindowsVM  = if (($osFamily -eq 'Windows') -and -not $vm.ExtensionData.Config.Template) { $true } else { $false }
        }
    }

    $windowsVms = $vmReport | Where-Object { $_.IsWindowsVM -eq $true }

    Write-Host "Collecting host/core inventory..." -ForegroundColor Cyan
    $hostReport = foreach ($esxHost in $allHosts) {
        $clusterName = $null
        try { $clusterName = (Get-Cluster -VMHost $esxHost -ErrorAction Stop).Name } catch {}

        $datacenterName = $null
        try { $datacenterName = (Get-Datacenter -VMHost $esxHost -ErrorAction Stop).Name } catch {}

        $mgmtIp = $null
        try {
            $vmk = Get-VMHostNetworkAdapter -VMHost $esxHost -VMKernel |
                Where-Object { $_.ManagementTrafficEnabled } |
                Select-Object -First 1
            if ($vmk) { $mgmtIp = $vmk.IP }
        }
        catch {}

        $dnsName = $null
        try {
            $dnsHost = $esxHost.ExtensionData.Config.Network.DnsConfig.HostName
            $dnsDomain = $esxHost.ExtensionData.Config.Network.DnsConfig.DomainName
            if ($dnsHost -and $dnsDomain) {
                $dnsName = "$dnsHost.$dnsDomain"
            }
            elseif ($dnsHost) {
                $dnsName = $dnsHost
            }
        }
        catch {}

        $hw = $hostHardware | Where-Object { $_.VMHost.Name -eq $esxHost.Name } | Select-Object -First 1

        $cpuPackages = $null
        $coresPerCpu = $null
        $totalCores  = $null
        $logicalCpu  = $null

        if ($hw -and $hw.CpuInfo) {
            $cpuPackages = $hw.CpuInfo.NumCpuPackages
            $totalCores  = $hw.CpuInfo.NumCpuCores
            $logicalCpu  = $hw.CpuInfo.NumCpuThreads

            if ($cpuPackages -and $cpuPackages -gt 0 -and $totalCores -ne $null) {
                $coresPerCpu = [math]::Round(($totalCores / $cpuPackages), 2)
            }
        }
        elseif ($esxHost.ConnectionState -in @('Connected', 'Maintenance')) {
            Write-Warning "No hardware details returned for host $($esxHost.Name) even though host state is $($esxHost.ConnectionState)."
        }

        $windowsOnHost = $windowsVms | Where-Object { $_.Host -eq $esxHost.Name }
        $windowsVmCount = @($windowsOnHost).Count

        [PSCustomObject]@{
            VCenter                = $VCenter
            Datacenter             = $datacenterName
            Cluster                = $clusterName
            ESXiHost               = $esxHost.Name
            ConnectionState        = $esxHost.ConnectionState.ToString()
            ManagementIP           = $mgmtIp
            DNSName                = $dnsName
            ESXiVersion            = $esxHost.Version
            CpuPackages            = $cpuPackages
            CoresPerCpu            = $coresPerCpu
            TotalPhysicalCores     = $totalCores
            TotalLogicalProcessors = $logicalCpu
            RAM_GB                 = [math]::Round($esxHost.MemoryTotalGB, 2)
            WindowsVMCount         = $windowsVmCount
            HasWindowsVM           = if ($windowsVmCount -gt 0) { 'Yes' } else { 'No' }
            HardwareDataAvailable  = if ($hw) { 'Yes' } else { 'No' }
        }
    }

    $timestamp = Get-Date -Format 'yyyy-MM-dd_HHmmss'

    $allVmFile       = Join-Path $OutputPath "VMReport_AllVMs_${Environment}_${timestamp}.csv"
    $windowsVmFile   = Join-Path $OutputPath "WindowsVMReport_${Environment}_${timestamp}.csv"
    $hostCoreFile    = Join-Path $OutputPath "HostCoreReport_AllHosts_${Environment}_${timestamp}.csv"
    $hostWindowsFile = Join-Path $OutputPath "HostCoreReport_WindowsHostsOnly_${Environment}_${timestamp}.csv"

    $vmReport |
        Sort-Object VMName |
        Export-Csv -Path $allVmFile -NoTypeInformation -Encoding UTF8

    $windowsVms |
        Sort-Object VMName |
        Export-Csv -Path $windowsVmFile -NoTypeInformation -Encoding UTF8

    $hostReport |
        Sort-Object ESXiHost |
        Export-Csv -Path $hostCoreFile -NoTypeInformation -Encoding UTF8

    $hostReport |
        Where-Object { $_.HasWindowsVM -eq 'Yes' } |
        Sort-Object ESXiHost |
        Export-Csv -Path $hostWindowsFile -NoTypeInformation -Encoding UTF8

    $totalHosts = @($hostReport).Count
    $windowsHosts = @($hostReport | Where-Object { $_.HasWindowsVM -eq 'Yes' }).Count
    $totalCoresAllHosts = ($hostReport | Measure-Object -Property TotalPhysicalCores -Sum).Sum
    $totalCoresWindowsHosts = (($hostReport | Where-Object { $_.HasWindowsVM -eq 'Yes' }) | Measure-Object -Property TotalPhysicalCores -Sum).Sum
    $totalWindowsVms = @($windowsVms).Count
    $hostsMissingHardware = @($hostReport | Where-Object { $_.HardwareDataAvailable -eq 'No' }).Count

    Write-Host ""
    Write-Host "Done." -ForegroundColor Green
    Write-Host "All VMs file              : $allVmFile" -ForegroundColor Green
    Write-Host "Windows VMs file          : $windowsVmFile" -ForegroundColor Green
    Write-Host "All hosts/core file       : $hostCoreFile" -ForegroundColor Green
    Write-Host "Windows hosts/core file   : $hostWindowsFile" -ForegroundColor Green
    Write-Host ""
    Write-Host "Summary:" -ForegroundColor Cyan
    Write-Host "Total hosts                  : $totalHosts"
    Write-Host "Hosts with Windows VMs       : $windowsHosts"
    Write-Host "Total physical cores (all)   : $totalCoresAllHosts"
    Write-Host "Total cores on Windows hosts : $totalCoresWindowsHosts"
    Write-Host "Windows VM count             : $totalWindowsVms"
    Write-Host "Hosts missing hardware data  : $hostsMissingHardware"

    if ($hostsMissingHardware -gt 0) {
        Write-Warning "One or more hosts were included in the report without core/hardware data. Check the HardwareDataAvailable column in the host CSV."
    }
}
finally {
    Disconnect-VIServer -Server $VCenter -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
}