<#
.SYNOPSIS
    Pulls System, Application, and Windows Update related event log entries
    from the C700 COR/BIT servers around an MI window, for RCA purposes.

.NOTES
    MI 02916074 - C700 split traffic, 10/12/2026
    Incident window (MT): 1:40 PM - 2:03 PM
    Padding +/- 30 min applied below to catch lead-up and tail activity.

    Run this from a box that has WinRM/remote event log access to both servers,
    under an account with remote admin rights on them.
#>

param(
    [string[]]$Servers = @('ata-c700cor01.inucn.com', 'ata-c700bit01.inucn.com'),

    # Incident window - adjust per MI. These are in LOCAL (MT) time;
    # script converts to the server's actual local time for the query.
    [datetime]$StartTime = [datetime]'2026-10-12 13:10:00',
    [datetime]$EndTime   = [datetime]'2026-10-12 14:30:00',

    [string]$OutDir = "$PSScriptRoot\C700_MI02916074_logs",

    [System.Management.Automation.PSCredential]$Credential
)

New-Item -ItemType Directory -Path $OutDir -Force | Out-Null

# Event IDs worth flagging explicitly (reboot/update/service/cluster related)
$WatchIds = @(
    1074,   # User/process initiated restart/shutdown
    1076,   # Shutdown reason provided
    6005, 6006, 6008,  # EventLog service start/stop, unexpected shutdown
    7036,   # Service state change
    7034,   # Service crashed unexpectedly
    41,     # Kernel-Power unexpected reboot
    19, 20, # Windows Update install success/failure
    1001    # BugCheck / Windows Error Reporting
)

foreach ($srv in $Servers) {
    Write-Host "=== $srv ===" -ForegroundColor Cyan
    try {
        $sessionOpt = New-PSSessionOption -IdleTimeout 600000
        $icmParams = @{
            ComputerName  = $srv
            SessionOption = $sessionOpt
            ErrorAction   = 'Stop'
        }
        if ($Credential) { $icmParams['Credential'] = $Credential }

        $results = Invoke-Command @icmParams -ScriptBlock {
            param($start, $end, $watchIds)

            $logs = @('System', 'Application')
            $all = @()

            foreach ($log in $logs) {
                try {
                    $events = Get-WinEvent -FilterHashtable @{
                        LogName   = $log
                        StartTime = $start
                        EndTime   = $end
                    } -ErrorAction SilentlyContinue

                    foreach ($e in $events) {
                        $all += [pscustomobject]@{
                            Server    = $env:COMPUTERNAME
                            Log       = $log
                            TimeCreated = $e.TimeCreated
                            Id        = $e.Id
                            Level     = $e.LevelDisplayName
                            Provider  = $e.ProviderName
                            Flagged   = ($watchIds -contains $e.Id)
                            Message   = ($e.Message -replace "`r`n", ' ' -replace "`n", ' ')
                        }
                    }
                } catch {
                    Write-Warning "Could not read $log on $env:COMPUTERNAME : $_"
                }
            }

            # Windows Update history separately (COM object, not an event log)
            try {
                $session = New-Object -ComObject Microsoft.Update.Session
                $searcher = $session.CreateUpdateSearcher()
                $historyCount = $searcher.GetTotalHistoryCount()
                if ($historyCount -gt 0) {
                    $history = $searcher.QueryHistory(0, $historyCount)
                    foreach ($h in $history) {
                        if ($h.Date -ge $start -and $h.Date -le $end) {
                            $all += [pscustomobject]@{
                                Server      = $env:COMPUTERNAME
                                Log         = 'WindowsUpdate'
                                TimeCreated = $h.Date
                                Id          = $h.ResultCode
                                Level       = 'Update'
                                Provider    = 'WindowsUpdateAgent'
                                Flagged     = $true
                                Message     = $h.Title
                            }
                        }
                    }
                }
            } catch {
                Write-Warning "Could not read WU history on $env:COMPUTERNAME : $_"
            }

            return $all
        } -ArgumentList $StartTime, $EndTime, $WatchIds

        $csvPath = Join-Path $OutDir "$($srv.Split('.')[0])_events.csv"
        $results | Sort-Object TimeCreated | Export-Csv -Path $csvPath -NoTypeInformation
        Write-Host "  -> $($results.Count) events written to $csvPath"

        $flagged = $results | Where-Object { $_.Flagged }
        if ($flagged) {
            Write-Host "  -> FLAGGED events (reboot/update/service/crash):" -ForegroundColor Yellow
            $flagged | Sort-Object TimeCreated | Format-Table TimeCreated, Log, Id, Provider, Message -AutoSize -Wrap
        } else {
            Write-Host "  -> No flagged reboot/update/crash events in window." -ForegroundColor Green
        }

    } catch {
        Write-Host "  -> CONNECTION FAILED - no data collected from $srv" -ForegroundColor Red
        Write-Host "     $($_.Exception.Message)" -ForegroundColor Red
        if ($_.Exception.Message -match 'Access is denied') {
            Write-Host "     Likely cause: your account isn't in Remote Management Users / local Administrators on $srv." -ForegroundColor Yellow
            Write-Host "     This is NOT the same as 'no events found' - nothing was checked." -ForegroundColor Yellow
        }
        continue
    }
}

Write-Host "`nDone. CSVs are in $OutDir" -ForegroundColor Cyan
