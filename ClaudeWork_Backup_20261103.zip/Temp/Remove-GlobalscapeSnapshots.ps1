<#
.SYNOPSIS
  Removes ONLY the Globalscape upgrade snapshots (CHG0204480): 4 pre-upgrade snapshots plus 3 prep snapshots from 10/13 (only if you created them). Dry run by default.
  Needs VMware PowerCLI and a vCenter login (it prompts; credentials are not stored).

.EXAMPLE
  .\Remove-GlobalscapeSnapshots.ps1                                          # lists what it would delete, who made it, how old
  .\Remove-GlobalscapeSnapshots.ps1 -Execute -ChangeNumber CHG0204480
#>
param(
    [string]$Server = 'lax-vmvce01.inucn.com',   # vCenter that holds the sgp/ty6 incdr servers
    [string]$Owner = 'marc.stern',               # the 10/13 snapshots are only removed if vCenter shows this user created them
    [switch]$Execute,
    [string]$ChangeNumber
)
$ErrorActionPreference = 'Stop'
# Exact VM + snapshot name pairs. Anything not on this list is never touched.
$targets = @(
    @{ VM = 'ty6-incdr01'; Snap = 'Pre-Globalscape-Upgrade-2026-10-19' },
    @{ VM = 'ty6-incdr02'; Snap = 'Pre-Globalscape-Upgrade-2026-10-19' },
    @{ VM = 'sgp-incdr01'; Snap = 'Pre-Globalscape-Upgrade-2026-10-19' },
    @{ VM = 'sgp-incdr02'; Snap = 'Pre-Globalscape-Upgrade-2026-10-19' },
    # 10/13 prep snapshots on the same servers: removed only when the creator is confirmed to be $Owner
    @{ VM = 'ty6-incdr01'; Snap = 'ty6-incdr01-snapshot-10/13/26'; CheckOwner = $true },
    @{ VM = 'ty6-incdr02'; Snap = 'ty6-incdr02-snapshot-10/13/26'; CheckOwner = $true },
    @{ VM = 'sgp-incdr01'; Snap = 'sgp-incdr01-snapshot-10/13/26'; CheckOwner = $true }
)
if ($Execute -and -not $ChangeNumber) { throw 'Add -ChangeNumber so the removal is traceable.' }
Import-Module VMware.VimAutomation.Core
Connect-VIServer -Server $Server -Credential (Get-Credential -Message "vCenter login for $Server") | Out-Null

$rows = foreach ($t in $targets) {
    $vm = Get-VM -Name $t.VM -ErrorAction SilentlyContinue
    if (-not $vm) { [pscustomobject]@{ VM = $t.VM; Found = 'VM not on this vCenter'; Created = ''; AgeDays = ''; SizeGB = ''; CreatedBy = ''; Result = 'Skipped' }; continue }
    $snap = Get-Snapshot -VM $vm -Name $t.Snap -ErrorAction SilentlyContinue
    if (-not $snap) { [pscustomobject]@{ VM = $t.VM; Found = 'Snapshot not found'; Created = ''; AgeDays = ''; SizeGB = ''; CreatedBy = ''; Result = 'Skipped' }; continue }
    # who created it (vCenter event log keeps this for a limited time)
    $who = ''
    try { $ev = Get-VIEvent -Entity $vm -Start $snap.Created.AddMinutes(-5) -Finish $snap.Created.AddMinutes(5) -MaxSamples 50 | Where-Object { $_.FullFormattedMessage -match 'snapshot' } | Select-Object -First 1; if ($ev) { $who = $ev.UserName } } catch {}
    $result = 'Dry run'
    $ownerOk = (-not $t.CheckOwner) -or ($who -and $who -match [regex]::Escape($Owner))
    if ($Execute -and -not $ownerOk) { $result = "Skipped: creator is '$who', not $Owner. Confirm with the owner first." }
    elseif ($Execute) {
        try { Remove-Snapshot -Snapshot $snap -Confirm:$false -RunAsync:$false | Out-Null; $result = 'Removed' } catch { $result = "FAILED: $($_.Exception.Message)" }
    }
    [pscustomobject]@{ VM = $t.VM; Found = $snap.Name; Created = $snap.Created.ToString('yyyy-MM-dd HH:mm'); AgeDays = [int]((Get-Date) - $snap.Created).TotalDays; SizeGB = [math]::Round($snap.SizeGB, 1); CreatedBy = $who; Result = $result }
}
$rows | Format-Table -AutoSize
New-Item -ItemType Directory -Force -Path C:\Temp | Out-Null
$csv = "C:\Temp\GlobalscapeSnapshots_$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
$rows | Export-Csv $csv -NoTypeInformation -Encoding UTF8
Write-Host "Log: $csv"
if (-not $Execute) { Write-Host 'DRY RUN only. Add -Execute -ChangeNumber CHG0204480 to remove.' -ForegroundColor Yellow }
Disconnect-VIServer -Confirm:$false | Out-Null
