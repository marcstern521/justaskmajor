﻿<#
.SYNOPSIS
  Try Pleasant Password REST login with several username formats, then search for the terminated users.
  READ-ONLY (login + list users). Deleting is done by you in the web UI.

.EXAMPLE
  .\Check-Pleasant.ps1
  .\Check-Pleasant.ps1 -Server lax-ininf01.inucn.com:10001 -Username marc.stern
  .\Check-Pleasant.ps1 -Username 'INUCN\marc.stern'      # try exactly one format
#>
param(
    [string]$Server = 'dal-insys01.inucn.com:10001',
    [string]$UserCsv = 'C:\Temp\inucn_users_for_pleasant.csv',
    [string]$Username = 'marc.stern',
    [string]$OutDir = 'C:\Temp\TermCheck'
)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }

function Get-ErrBody($err) {
    try {
        $r = $err.Exception.Response
        if ($r) { $sr = New-Object IO.StreamReader($r.GetResponseStream()); return $sr.ReadToEnd() }
    } catch {}
    return $err.Exception.Message
}

$pw = (Read-Host "Pleasant Password for $Username" -AsSecureString)
$plain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($pw))

# username formats to try
$bare = ($Username -split '[\\@]')[-1]; if ($Username -match '@') { $bare = ($Username -split '@')[0] }
$formats = if ($Username -match '[\\@]') { @($Username) } else { @($bare, "INUCN\$bare", "$bare@inucn.com", "$bare@niceincontact.com", "$bare@nice.com") }

$token = $null
foreach ($f in $formats) {
    try {
        $tok = Invoke-RestMethod -Method Post -Uri "https://$Server/OAuth2/Token" -ContentType 'application/x-www-form-urlencoded' `
               -Body @{ grant_type = 'password'; username = $f; password = $plain }
        Write-Host "LOGIN OK with username format: $f" -ForegroundColor Green
        $token = $tok.access_token; break
    } catch {
        Write-Host "  failed ($f): $(Get-ErrBody $_)" -ForegroundColor Yellow
    }
}
if (-not $token) {
    Write-Host "`nNo login worked. Read the messages above:" -ForegroundColor Red
    Write-Host "  invalid_grant / invalid credentials -> wrong account type (try the exact name you use in the web client)"
    Write-Host "  mention of 2FA / verification code   -> account needs MFA; REST login can't do it, use the web UI"
    Write-Host "  unable to connect                    -> server not reachable from here (try the other server / run from a server)"
    return
}

$hdr = @{ Authorization = "Bearer $token" }
$users = $null
foreach ($path in '/api/v5/rest/users', '/api/v5/rest/user') {
    try { $users = @(Invoke-RestMethod -Uri "https://$Server$path" -Headers $hdr); Write-Host "Loaded $($users.Count) Pleasant users via $path"; break }
    catch { Write-Host "  $path failed: $(Get-ErrBody $_)" -ForegroundColor Yellow }
}
if (-not $users) { Write-Host 'Logged in but could not list users (account may lack permission). Use the web UI.' -ForegroundColor Red; return }

$want = Import-Csv $UserCsv
$hits = foreach ($w in $want) {
    $last = ($w.DisplayName -split ' ')[-1]
    foreach ($u in $users) {
        $blob = ($u | ConvertTo-Json -Depth 3 -Compress)
        if ($blob -match [regex]::Escape($w.SamAccountName) -or $blob -match [regex]::Escape($w.DisplayName)) {
            [pscustomobject]@{ Wanted = $w.DisplayName; AD = $w.SamAccountName; PleasantUsername = $u.Username; PleasantName = $u.Name; Email = $u.Email; Id = $u.Id }
        }
    }
}
$out = Join-Path $OutDir ("Pleasant_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
if ($hits) { $hits | Format-Table -AutoSize; $hits | Export-Csv $out -NoTypeInformation; Write-Host "Matches: $(@($hits).Count)  -> $out" -ForegroundColor Green }
else { Write-Host 'No matching Pleasant users found for the list.' -ForegroundColor Green }
Write-Host 'Delete matches in the web UI (Users > Manage). This script does not delete.'