# ============================================================
# GS - Script 2 - VMware Snapshots
# Snapshots the VMs you name BEFORE any changes. VMware only - EC2 servers
# need an EBS snapshot / AMI instead (not covered here).
# Snapshot name matches the runbook rollback step:
#   Pre-Globalscape-Upgrade-<yyyy-MM-dd>
#
# Example:
#   .\GS_2_Snapshot_Servers.ps1 -VMName dal-ineft02,dal-inftp02 -ChangeRef CHG0177747
# ============================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string[]]$VMName,
    [string]$vCenterServer = 'lax-vmvce01.inucn.com',
    [string]$ChangeRef = '',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
Start-GSLog -Name 'snapshot'

$SnapshotName = 'Pre-Globalscape-Upgrade-{0}' -f (Get-Date -Format 'yyyy-MM-dd')
$SnapshotDesc = ('Pre-upgrade snapshot - Globalscape EFT/DMZ upgrade {0}' -f $ChangeRef).Trim()

if (-not (Get-Command Connect-VIServer -ErrorAction SilentlyContinue)) {
    throw 'VMware PowerCLI is not loaded. Run: Import-Module VMware.PowerCLI'
}

# --- Check / connect to vCenter ---
Write-Log '=== Checking vCenter connection ===' Cyan
$connected = $global:DefaultVIServers | Where-Object { $_.Name -eq $vCenterServer -and $_.IsConnected }
if ($connected) {
    Write-Log "Already connected to $vCenterServer as $($connected.User)" Green
} else {
    Write-Log "Connecting to $vCenterServer ..." Yellow
    try {
        $cred = Get-GSCredential $Credential
        Connect-VIServer -Server $vCenterServer -Credential $cred -ErrorAction Stop | Out-Null
        Write-Log "Connected to $vCenterServer" Green
    } catch {
        Write-Log "Failed to connect to vCenter: $_" Red
        Write-Log "Check that $vCenterServer is reachable, the credentials are right, and this is the right vCenter for these VMs" Red
        exit 1
    }
}

# --- Verify VMs ---
Write-Log 'Verifying VMs in vCenter...' Yellow
$found   = @()
$missing = @()
foreach ($n in $VMName) {
    $vm = Get-VM -Name $n -ErrorAction SilentlyContinue
    if ($vm) {
        $found += $vm
        Write-Log ("  {0} - {1}" -f $vm.Name, $vm.PowerState)
    } else {
        $missing += $n
        Write-Log "  $n not found in vCenter - check the VM name (or it is an EC2 server)" Red
    }
}
if ($missing.Count -gt 0) {
    Write-Log "$($missing.Count) VM(s) not found - do not proceed until resolved" Red
    exit 1
}

if (-not (Confirm-Typed "`nAll $($found.Count) VM(s) confirmed. Take snapshots '$SnapshotName'?" 'YES')) {
    Write-Log 'Exiting - no snapshots taken' Yellow
    exit 0
}

# --- Take snapshots ---
Write-Log '=== Taking snapshots ===' Cyan
$allGood = $true
foreach ($vm in $found) {
    $existing = Get-Snapshot -VM $vm -Name $SnapshotName -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Log "  $($vm.Name) - snapshot '$SnapshotName' already exists, leaving it alone" Yellow
        continue
    }
    Write-Log "Snapshotting $($vm.Name)..." Yellow
    try {
        $snap = New-Snapshot -VM $vm -Name $SnapshotName -Description $SnapshotDesc -Memory:$false -Quiesce:$false -Confirm:$false -ErrorAction Stop
        Write-Log "  Done - $($snap.Name) at $($snap.Created)" Green
    } catch {
        Write-Log "  Failed - $_" Red
        $allGood = $false
    }
}

# --- Summary ---
if ($allGood) {
    Write-Log "All snapshots good - safe to proceed. Snapshot name: $SnapshotName" Green
    Write-Log 'Next: GS_3_Push_Installers.ps1' Cyan
} else {
    Write-Log 'One or more snapshots failed - DO NOT proceed until resolved' Red
}
