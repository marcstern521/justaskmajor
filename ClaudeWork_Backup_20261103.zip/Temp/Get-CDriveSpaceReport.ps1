<#
.SYNOPSIS
  READ-ONLY. Scans the C: drive of each server in a list and reports what is using the space:
  C: size/free, every top-level folder, second-level folders (Users\<profile>, Windows\WinSxS, Windows\Temp,
  ProgramData\<x>, Program Files\<x> ...), SQL "Setup Bootstrap" folders, MEMORY.DMP / dumps, page file, hiberfil,
  and any single file over 500 MB. Deletes and changes NOTHING.

.DESCRIPTION
  Mode 1 (fleet):  run from a box that can reach the servers over WinRM (a peer/jump box - NOT your laptop, remoting
                   from the laptop into prod is blocked). Uses Invoke-Command, runs in batches so a stall does not lose
                   everything, scan runs at BelowNormal thread priority, a few servers at a time.
  Mode 2 (single): -Local, run ON one server (RDP / SSM session) for any host the fleet run could not reach.

  Your current Windows login is used. Add -PromptCredential only if you need a different account; the password is
  typed at the prompt and never stored.

  NOTE: WinSxS is measured by adding up file sizes. The component store uses hard links, so the number shown is
  LARGER than what WinSxS really costs on disk. Treat it as "upper bound"; for the real number run
  Dism.exe /Online /Cleanup-Image /AnalyzeComponentStore on that server.

.EXAMPLE
  .\Get-CDriveSpaceReport.ps1 -ServerFile C:\Temp\Servers-CDriveCrawl.txt
  .\Get-CDriveSpaceReport.ps1 -ServerFile .\servers.txt -Suffix incmp.com -ThrottleLimit 5
  .\Get-CDriveSpaceReport.ps1 -Local                     # on one server by itself
#>
param(
    [string]$ServerFile = '.\Servers-CDriveCrawl.txt',
    [string[]]$ComputerName,
    [switch]$Local,
    [string]$Suffix,                 # optional DNS suffix appended to short names, e.g. incmp.com
    [int]$ThrottleLimit = 8,         # servers scanned at the same time
    [int]$BatchSize = 25,            # servers per batch; CSVs are rewritten after every batch
    [double]$MinGB = 0.5,            # folders smaller than this are left out of the detail
    [int]$TimeoutMinutes = 45,       # per-server limit
    [string]$OutDir = 'C:\Temp\CDriveCrawl',
    [switch]$PromptCredential
)
$ErrorActionPreference = 'Continue'

# ---------- what runs on each server (read-only) ----------
$scan = {
    param([double]$MinGB)
    try { [System.Threading.Thread]::CurrentThread.Priority = 'BelowNormal' } catch {}
    $out = New-Object System.Collections.Generic.List[object]
    function Add-Row($kind, $item, $bytes) {
        $gb = [math]::Round($bytes / 1GB, 2)
        $out.Add([pscustomobject]@{ Kind = $kind; Item = $item; GB = $gb })
    }
    $l1 = @{}; $l2 = @{}; $sp = @{}
    $big = New-Object System.Collections.Generic.List[object]
    $total = [double]0
    $stack = New-Object System.Collections.Generic.Stack[System.IO.DirectoryInfo]
    $stack.Push((New-Object System.IO.DirectoryInfo 'C:\'))
    while ($stack.Count) {
        $d = $stack.Pop()
        $rel = $d.FullName.Substring(3).Trim('\')
        $parts = @(); if ($rel) { $parts = $rel.Split('\') }
        $sum = [double]0; $files = @(); $subs = @()
        try { $files = $d.GetFiles() } catch {}
        try { $subs = $d.GetDirectories() } catch {}
        foreach ($f in $files) {
            $len = [double]$f.Length; $sum += $len
            if ($parts.Count -eq 0) { $l1[$f.Name] = [double]$l1[$f.Name] + $len }   # files sitting directly in C:\
            if ($len -ge 500MB) { $big.Add([pscustomobject]@{ Path = $f.FullName; Bytes = $len }) }
        }
        if ($parts.Count -ge 1) {
            $k1 = $parts[0]
            $k2 = if ($parts.Count -ge 2) { $parts[0] + '\' + $parts[1] } else { $parts[0] + '\(files directly in folder)' }
            $l1[$k1] = [double]$l1[$k1] + $sum
            $l2[$k2] = [double]$l2[$k2] + $sum
            if ($rel -like '*Setup Bootstrap*') { $sp['SQL Setup Bootstrap (all)'] = [double]$sp['SQL Setup Bootstrap (all)'] + $sum }
        }
        $total += $sum
        foreach ($s in $subs) {
            if (($s.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq 0) { $stack.Push($s) }
        }
    }
    $di = New-Object System.IO.DriveInfo 'C'
    $used = $di.TotalSize - $di.AvailableFreeSpace
    Add-Row 'Drive' 'C: size' $di.TotalSize
    Add-Row 'Drive' 'C: free' $di.AvailableFreeSpace
    Add-Row 'Drive' 'C: used (per Windows)' $used
    Add-Row 'Drive' 'Seen by this scan' $total
    Add-Row 'Drive' 'Not seen (shadow copies, locked/denied, NTFS metadata)' ([math]::Max(0, $used - $total))
    foreach ($k in $l1.Keys) { if ($l1[$k] -ge ($MinGB * 1GB)) { Add-Row 'L1' $k $l1[$k] } }
    foreach ($k in $l2.Keys) { if ($l2[$k] -ge ($MinGB * 1GB)) { Add-Row 'L2' $k $l2[$k] } }
    foreach ($k in $sp.Keys) { Add-Row 'Special' $k $sp[$k] }
    foreach ($b in ($big | Sort-Object Bytes -Descending | Select-Object -First 15)) { Add-Row 'BigFile' $b.Path $b.Bytes }
    try {
        $pf = Get-WmiObject Win32_PageFileUsage -ErrorAction Stop
        foreach ($p in $pf) { $out.Add([pscustomobject]@{ Kind = 'Info'; Item = ('Page file configured: ' + $p.Name + ' (allocated MB)'); GB = [math]::Round($p.AllocatedBaseSize / 1024, 2) }) }
    } catch {}
    try {
        $rp = Get-WmiObject Win32_Volume -Filter "DriveLetter='C:'" -ErrorAction Stop
        $null = $rp
    } catch {}
    $out
}

# ---------- run ----------
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir -Force | Out-Null }
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$detail = New-Object System.Collections.Generic.List[object]
$failed = New-Object System.Collections.Generic.List[object]

if ($Local) {
    Write-Host "Scanning C: on $env:COMPUTERNAME (read-only)..." -ForegroundColor Cyan
    foreach ($r in (& $scan $MinGB)) {
        $detail.Add([pscustomobject]@{ Server = $env:COMPUTERNAME; Kind = $r.Kind; Item = $r.Item; GB = $r.GB })
    }
} else {
    if ($ComputerName) { $targets = @($ComputerName) }
    else {
        if (-not (Test-Path $ServerFile)) { throw "Server list not found: $ServerFile (use -ServerFile or -ComputerName)" }
        $targets = @(Get-Content $ServerFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') } | Sort-Object -Unique)
    }
    if ($Suffix) { $targets = $targets | ForEach-Object { if ($_ -like '*.*') { $_ } else { "$_.$Suffix" } } }
    Write-Host "$($targets.Count) server(s), $ThrottleLimit at a time, batches of $BatchSize. Read-only." -ForegroundColor Cyan
    $so = New-PSSessionOption -OpenTimeout 30000 -OperationTimeout ($TimeoutMinutes * 60000)
    $cred = $null; if ($PromptCredential) { $cred = Get-Credential -Message 'Account with admin rights on the servers' }
    for ($i = 0; $i -lt $targets.Count; $i += $BatchSize) {
        $chunk = @($targets[$i..([math]::Min($i + $BatchSize, $targets.Count) - 1)])
        Write-Host ("Batch {0}-{1} of {2} ..." -f ($i + 1), ($i + $chunk.Count), $targets.Count) -ForegroundColor DarkCyan
        $remErr = $null
        $splat = @{ ComputerName = $chunk; ScriptBlock = $scan; ArgumentList = @($MinGB); ThrottleLimit = $ThrottleLimit
                    SessionOption = $so; ErrorAction = 'SilentlyContinue'; ErrorVariable = 'remErr' }
        if ($cred) { $splat.Credential = $cred }
        $res = @(Invoke-Command @splat)
        foreach ($r in $res) {
            if ($r.Kind) { $detail.Add([pscustomobject]@{ Server = "$($r.PSComputerName)"; Kind = $r.Kind; Item = $r.Item; GB = $r.GB }) }
        }
        foreach ($e in @($remErr)) {
            $h = if ($e.TargetObject) { "$($e.TargetObject)" } else { '?' }
            $failed.Add([pscustomobject]@{ Server = $h; Reason = ("$($e.Exception.Message)").Split([char]10)[0].Trim() })
        }
        $detail | Export-Csv -NoTypeInformation -Path (Join-Path $OutDir "CDrive_Detail_$stamp.csv")
        if ($failed.Count) { $failed | Export-Csv -NoTypeInformation -Path (Join-Path $OutDir "CDrive_Failed_$stamp.csv") }
    }
}

# ---------- summary ----------
function G($rows, $kind, $item) {
    $r = @($rows | Where-Object { $_.Kind -eq $kind -and $_.Item -eq $item })
    if ($r.Count) { [double]$r[0].GB } else { 0 }
}
$summary = foreach ($g in ($detail | Group-Object Server)) {
    $rows = $g.Group
    $size = G $rows 'Drive' 'C: size'; $free = G $rows 'Drive' 'C: free'
    $top = @($rows | Where-Object Kind -eq 'L1' | Sort-Object GB -Descending | Select-Object -First 3 | ForEach-Object { '{0} {1}GB' -f $_.Item, $_.GB }) -join '; '
    $deep = @($rows | Where-Object Kind -eq 'L2' | Sort-Object GB -Descending | Select-Object -First 1 | ForEach-Object { '{0} {1}GB' -f $_.Item, $_.GB }) -join ''
    [pscustomobject]@{
        Server = $g.Name; SizeGB = $size; FreeGB = $free
        PctFree = if ($size) { [math]::Round(100 * $free / $size, 1) } else { '' }
        Top3Folders = $top; BiggestSubfolder = $deep
        UsersGB = G $rows 'L1' 'Users'
        WinSxS_GB = G $rows 'L2' 'Windows\WinSxS'
        WinTempGB = G $rows 'L2' 'Windows\Temp'
        CTempGB = G $rows 'L1' 'Temp'
        SoftwareDistGB = G $rows 'L2' 'Windows\SoftwareDistribution'
        InstallerGB = G $rows 'L2' 'Windows\Installer'
        SqlBootstrapGB = G $rows 'Special' 'SQL Setup Bootstrap (all)'
        MinidumpGB = G $rows 'L2' 'Windows\Minidump'
        PagefileGB = G $rows 'L1' 'pagefile.sys'
        ProgramDataGB = G $rows 'L1' 'ProgramData'
        WindowsOldGB = G $rows 'L1' 'Windows.old'
        NotSeenGB = G $rows 'Drive' 'Not seen (shadow copies, locked/denied, NTFS metadata)'
        MemoryDmp = (@($rows | Where-Object { $_.Kind -eq 'BigFile' -and $_.Item -like '*MEMORY.DMP' } | ForEach-Object { '{0}GB' -f $_.GB }) -join ',')
    }
}
$summary = @($summary | Sort-Object FreeGB)
$fleet = @($detail | Where-Object { $_.Kind -in 'L2', 'Special' } | Group-Object Item | ForEach-Object {
    [pscustomobject]@{ Item = $_.Name; Servers = $_.Count; TotalGB = [math]::Round(($_.Group | Measure-Object GB -Sum).Sum, 1); MaxGB = ($_.Group | Measure-Object GB -Maximum).Maximum }
} | Sort-Object TotalGB -Descending)

$f1 = Join-Path $OutDir "CDrive_Summary_$stamp.csv"
$f2 = Join-Path $OutDir "CDrive_Detail_$stamp.csv"
$f3 = Join-Path $OutDir "CDrive_FleetTopConsumers_$stamp.csv"
$summary | Export-Csv -NoTypeInformation -Path $f1
$detail | Export-Csv -NoTypeInformation -Path $f2
$fleet | Export-Csv -NoTypeInformation -Path $f3

Write-Host "`nLowest free space first:" -ForegroundColor Cyan
$summary | Select-Object -First 25 | Format-Table Server, SizeGB, FreeGB, PctFree, UsersGB, WinSxS_GB, WinTempGB, CTempGB, SoftwareDistGB, SqlBootstrapGB, MinidumpGB, MemoryDmp -AutoSize
Write-Host "Biggest consumers across all servers (second-level folders):" -ForegroundColor Cyan
$fleet | Select-Object -First 20 | Format-Table -AutoSize
Write-Host ("Scanned: {0} server(s). Failed / not reachable: {1}." -f $summary.Count, $failed.Count) -ForegroundColor Yellow
if ($failed.Count) {
    Write-Host 'Could not reach (run with -Local on these, via RDP or an SSM session):' -ForegroundColor Yellow
    $failed | Sort-Object Server -Unique | Format-Table -AutoSize -Wrap
    $failed | Export-Csv -NoTypeInformation -Path (Join-Path $OutDir "CDrive_Failed_$stamp.csv")
}
Write-Host "`nFiles:`n  $f1`n  $f3`n  $f2" -ForegroundColor Green
