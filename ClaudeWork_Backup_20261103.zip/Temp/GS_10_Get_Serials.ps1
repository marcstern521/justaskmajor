# ============================================================
# GS - Script 10 - Find EFT serial numbers on a server (read-only)
# Searches the places EFT is likely to keep them and lists every serial-looking
# value it finds (14 characters, starts with A, letters + digits, like A93B3E56P4KJJD):
#   1. Registry under GlobalSCAPE / Fortra keys (names and values)
#   2. Registration.db in EFT's data folder (the folder that holds ServerConfig.db)
#   3. With -Deep: the other .db files in that folder too
#
# IMPORTANT
#   * I could not find a Fortra doc saying exactly where EFT 8.x stores serials, so this is
#     a search, not a lookup. It finds the values; it cannot say which module each one is.
#     The Context column shows the text next to the value - use it, or EFT Admin Console >
#     Help > About, which lists each module's serial.
#   * CALIBRATE FIRST: run it on a server whose serials are already on the page
#     (aaa-ineft01). If the five serials on the page show up, the method works.
#   * DMZ Gateway servers (inftp, qmftp) have no serial of their own. The gateway licence is
#     the "DMZ Gateway Module Serial Number" on the paired EFT server, so skip them here.
#
# Example:
#   .\GS_10_Get_Serials.ps1 -Server aaa-ineft01                 # calibration
#   .\GS_10_Get_Serials.ps1                                     # the 5 servers with no serials on the page
#   .\GS_10_Get_Serials.ps1 -Server hy1-incdr01 -Deep
# ============================================================
[CmdletBinding()]
param(
    [string[]]$Server = @('acosa-incdr01', 'hy1-incdr01', 'mb1-incdr01', 'aaa-qweft01', 'afa-qweft01'),
    [switch]$Deep,
    [string]$Domain = 'inucn.com',
    [pscredential]$Credential
)

. "$PSScriptRoot\GS_Common.ps1"
$Credential = Get-GSCredential $Credential
Start-GSLog -Name 'serials'

# Runs ON the server
$scan = {
    param($dataDir, $deep)
    $pattern = '(?<![A-Z0-9])A[A-Z0-9]{13}(?![A-Z0-9])'   # lowercase neighbours allowed: database records have no delimiters
    $found = New-Object System.Collections.Generic.List[object]

    function Add-Hit($source, $where, $value, $context) {
        # needs at least one digit and one letter after the leading A (cuts false positives)
        if ($value.Substring(1) -match '[0-9]' -and $value.Substring(1) -match '[A-Z]') {
            $found.Add([pscustomobject]@{ Source = $source; Where = $where; Value = $value; Context = $context })
        }
    }

    # 1. registry (skipped when this block is tested on non-Windows)
    $runReg = ($null -eq $IsWindows) -or $IsWindows
    if ($runReg) {
        $roots = 'HKLM:\SOFTWARE\GlobalSCAPE', 'HKLM:\SOFTWARE\GlobalSCAPE Inc.', 'HKLM:\SOFTWARE\Globalscape',
                 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE', 'HKLM:\SOFTWARE\WOW6432Node\GlobalSCAPE Inc.',
                 'HKLM:\SOFTWARE\WOW6432Node\Globalscape', 'HKLM:\SOFTWARE\Fortra', 'HKLM:\SOFTWARE\WOW6432Node\Fortra'
        foreach ($root in $roots) {
            if (-not (Test-Path -LiteralPath $root)) { continue }
            $keys = @(Get-Item -LiteralPath $root) + @(Get-ChildItem -LiteralPath $root -Recurse -ErrorAction SilentlyContinue)
            foreach ($k in $keys) {
                foreach ($m in [regex]::Matches($k.PSChildName, $pattern)) { Add-Hit 'Registry' $k.Name $m.Value 'key name' }
                foreach ($vn in $k.GetValueNames()) {
                    $v = $k.GetValue($vn)
                    if ($v -is [byte[]]) { continue }
                    foreach ($m in [regex]::Matches("$vn", $pattern)) { Add-Hit 'Registry' $k.Name $m.Value ('value name: ' + $vn) }
                    foreach ($m in [regex]::Matches((@($v) -join ' '), $pattern)) { Add-Hit 'Registry' $k.Name $m.Value ('value: ' + $vn) }
                }
            }
        }
    }

    # 2/3. database files in the data folder
    if ($dataDir -and (Test-Path -LiteralPath $dataDir)) {
        $files = @(Join-Path $dataDir 'Registration.db')
        if ($deep) { $files += @(Get-ChildItem -LiteralPath $dataDir -Filter '*.db' -File -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName }) }
        foreach ($f in ($files | Select-Object -Unique)) {
            if (-not (Test-Path -LiteralPath $f)) { continue }
            try {
                $fs = [System.IO.File]::Open($f, 'Open', 'Read', 'ReadWrite')   # works even if EFT has it open
                $bytes = New-Object byte[] $fs.Length
                [void]$fs.Read($bytes, 0, $bytes.Length)
                $fs.Close()
            } catch { continue }
            foreach ($enc in @([System.Text.Encoding]::ASCII, [System.Text.Encoding]::Unicode)) {
                $text = $enc.GetString($bytes)
                foreach ($m in [regex]::Matches($text, $pattern)) {
                    $start = [Math]::Max(0, $m.Index - 60)
                    $ctx = ($text.Substring($start, $m.Index - $start) -replace '[^\x20-\x7E]', ' ' -replace '\s+', ' ').Trim()
                    Add-Hit 'File' (Split-Path $f -Leaf) $m.Value $ctx
                }
            }
        }
    }
    $found
}

$all = @()
Write-Log "=== Serial search: $($Server -join ', ') ===" Cyan
foreach ($name in $Server) {
    $fqdn = Resolve-GSHost $name $Domain
    Write-Log "Checking $fqdn" Yellow
    try {
        $s    = New-PSSession -ComputerName $fqdn -Credential $Credential -ErrorAction Stop
        $info = Get-EFTInfo -Session $s
        $data = "$($info.DataDir)"
        if (-not $info.ServiceName) { Write-Log '  No EFT service found on this server' Yellow }
        Write-Log ("  EFT {0} | data folder: {1}" -f $info.Version, $(if ($data) { $data } else { '(not found)' }))
        $hits = @(Invoke-Command -Session $s -ScriptBlock $scan -ArgumentList $data, [bool]$Deep)
        Remove-PSSession $s
    } catch {
        Write-Log "  FAILED - $($_.Exception.Message)" Red
        continue
    }
    $uniq = @($hits | Sort-Object Source, Where, Value -Unique)
    Write-Log "  $($uniq.Count) serial-looking value(s) found" $(if ($uniq.Count) { 'Green' } else { 'Yellow' })
    foreach ($h in $uniq) {
        $all += [pscustomobject]@{ Server = $name; Version = "$($info.Version)"; Source = "$($h.Source)"; Where = "$($h.Where)"; Value = "$($h.Value)"; Context = "$($h.Context)" }
    }
}

if ($all.Count -eq 0) {
    Write-Log 'Nothing found. Read the serials from EFT Admin Console > Help > About on each server.' Yellow
    exit 0
}

$csv = Join-Path $script:WorkDir ('serials_{0}.csv' -f (Get-Date -Format 'yyyyMMdd-HHmm'))
$all | Export-Csv -Path $csv -NoTypeInformation
Write-Host ''
$all | Format-Table Server, Version, Source, Value, Where, Context -AutoSize -Wrap
Write-Log "Saved to $csv" Green
Write-Host "`nNext: confirm which module each serial belongs to (Context column or Help > About), then add them to the page." -ForegroundColor Cyan
