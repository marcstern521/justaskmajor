﻿<#
.SYNOPSIS
  Check for, and remove, the CrowdStrike Falcon sensor on the PO200 perf MED servers (in.lab) from your laptop.
  Built for the CrowdStrike -> Cortex XDR swap. Nothing is removed unless you use -Mode Remove, give a ticket,
  and type RUN.

.DESCRIPTION
  -Mode Check  (default, read-only)  Per server: reachable? OS, free space on C:, CrowdStrike service/version, Cortex service.
  -Mode Remove                       Copies the uninstaller to the server, runs it silently, re-checks, deletes the copy.
                                     Does NOT install Cortex and does NOT reboot.
  Safety rails:
    * Check is the default. Remove needs -Ticket and a typed RUN.
    * Remove does only the FIRST server by default (-First 1) so you can verify one before the rest. Use -First 0 for all.
    * Stops after 2 failures in a row.
    * Skips any server that does not have CrowdStrike, and any that is unreachable.
    * The maintenance token (only needed if uninstall protection is on) is typed at a hidden prompt. It is never
      written to the log, the CSV or the console.

.EXAMPLE
  .\Remove-CrowdStrike.ps1                                   # check all 20, read-only
  .\Remove-CrowdStrike.ps1 -Mode Remove -Ticket CHG0000000   # remove from the first server only
  .\Remove-CrowdStrike.ps1 -Mode Remove -Ticket CHG0000000 -First 0   # then the rest
  .\Remove-CrowdStrike.ps1 -Servers PFORA-200MED21,PFORB-200MED21 -Mode Check

.NOTES
  Uninstaller: the tool Morgan emailed (normally CsUninstallTool.exe), saved on your laptop at -Uninstaller.
  Silent switch is /quiet, plus MAINTENANCE_TOKEN=<token> when uninstall protection is on. If Morgan's tool uses
  other switches, change $UninstallArgs below. Servers must be on (start them in AWS perf first) and WinRM reachable.
  Run from an in.lab-reachable machine. Prompts for an in.lab login (marc.stern@in.lab) unless -Credential is given.
#>
param(
    [string[]]$Servers = @(
        (21..30 | ForEach-Object { "PFORA-200MED$_" }) + (21..30 | ForEach-Object { "PFORB-200MED$_" })
    ),
    [string]$Domain = 'in.lab',
    [ValidateSet('Check', 'Remove')][string]$Mode = 'Check',
    [string]$Uninstaller = 'C:\Temp\CsUninstallTool.exe',
    [string]$Ticket = '',
    [int]$First = 1,
    [pscredential]$Credential,
    [string]$OutDir = 'C:\Temp\TermCheck'
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory $OutDir | Out-Null }
if (-not $Credential) { $Credential = Get-Credential -Message 'in.lab login for the PO200 servers (marc.stern@in.lab)' }
if (-not $Credential) { Write-Warning 'No login given.'; return }

$fqdns = $Servers | ForEach-Object { if ($_ -like '*.*') { $_ } else { "$_.$Domain" } }
$cred = @{ Credential = $Credential }

# What runs on each server (read-only)
$probe = {
    $cs = Get-Service -Name 'CSFalconService' -ErrorAction SilentlyContinue
    $csApp = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*' -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -like '*CrowdStrike*' } | Select-Object -First 1
    $cx = Get-Service -Name 'cyserver' -ErrorAction SilentlyContinue
    $c = Get-PSDrive -Name C -ErrorAction SilentlyContinue
    [pscustomobject]@{
        OS        = (Get-CimInstance Win32_OperatingSystem).Caption
        FreeGB    = [math]::Round($c.Free / 1GB, 1)
        CrowdStrike = if ($cs) { "$($cs.Status)" } else { 'not installed' }
        CsVersion = if ($csApp) { $csApp.DisplayVersion } else { '' }
        Cortex    = if ($cx) { "$($cx.Status)" } else { 'not installed' }
    }
}

function Get-State($fqdn) {
    try {
        $r = Invoke-Command -ComputerName $fqdn @cred -Authentication Negotiate -ScriptBlock $probe -ErrorAction Stop
        [pscustomobject]@{ Server = $fqdn; Reach = 'OK'; OS = $r.OS; FreeGB = $r.FreeGB; CrowdStrike = $r.CrowdStrike; CsVersion = $r.CsVersion; Cortex = $r.Cortex; Detail = '' }
    } catch {
        [pscustomobject]@{ Server = $fqdn; Reach = 'FAILED'; OS = ''; FreeGB = ''; CrowdStrike = ''; CsVersion = ''; Cortex = ''; Detail = $_.Exception.Message.Split("`n")[0].Trim() }
    }
}

# ---- Check pass (always) ----
Write-Host "Checking $($fqdns.Count) servers..." -ForegroundColor Cyan
$state = @()
foreach ($f in $fqdns) {
    $s = Get-State $f
    $state += $s
    $col = if ($s.Reach -eq 'OK') { 'Gray' } else { 'Yellow' }
    Write-Host ("  {0,-34} {1,-7} CrowdStrike: {2,-14} Cortex: {3}" -f $s.Server, $s.Reach, $s.CrowdStrike, $s.Cortex) -ForegroundColor $col
}
$state | Format-Table Server, Reach, OS, FreeGB, CrowdStrike, CsVersion, Cortex, Detail -AutoSize | Out-String -Width 250 | Write-Host
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$state | Export-Csv (Join-Path $OutDir "CrowdStrike_Check_$stamp.csv") -NoTypeInformation
$todo = @($state | Where-Object { $_.Reach -eq 'OK' -and $_.CrowdStrike -ne 'not installed' })
$off = @($state | Where-Object { $_.Reach -ne 'OK' }).Count
Write-Host ("{0} have CrowdStrike, {1} do not, {2} unreachable (start those in AWS perf, then rerun)." -f $todo.Count, (@($state | Where-Object { $_.Reach -eq 'OK' -and $_.CrowdStrike -eq 'not installed' }).Count), $off) -ForegroundColor Cyan
if ($Mode -eq 'Check') { Write-Host 'Check only. Nothing was changed.' -ForegroundColor Green; return }

# ---- Remove pass ----
if (-not $Ticket) { Write-Warning 'Remove needs -Ticket (change or task number). Stopping.'; return }
if (-not (Test-Path $Uninstaller)) { Write-Warning "Uninstaller not found at $Uninstaller. Save the tool from Morgan's email there, or pass -Uninstaller. Stopping."; return }
if (-not $todo.Count) { Write-Host 'Nothing to remove.' -ForegroundColor Green; return }
if ($First -gt 0) { $todo = @($todo | Select-Object -First $First) }
Write-Host "`nAbout to REMOVE CrowdStrike from:" -ForegroundColor Yellow
$todo | ForEach-Object { Write-Host "  $($_.Server)" }
Write-Host "Ticket: $Ticket   Uninstaller: $Uninstaller   (no reboot, no Cortex install)" -ForegroundColor Yellow
if ((Read-Host 'Type RUN to continue') -ne 'RUN') { Write-Host 'Cancelled.'; return }
$sec = Read-Host 'CrowdStrike maintenance token (press Enter if uninstall protection is off)' -AsSecureString
$token = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
$UninstallArgs = '/quiet'
if ($token) { $UninstallArgs += ' MAINTENANCE_TOKEN=' + $token }

$remote = {
    param($exe, $argLine)
    $p = Start-Process -FilePath $exe -ArgumentList $argLine -Wait -PassThru -WindowStyle Hidden
    $p.ExitCode
}
$results = @(); $fails = 0
foreach ($row in $todo) {
    $f = $row.Server
    Write-Host ">> $f" -ForegroundColor Cyan
    $exit = ''; $note = ''; $sess = $null
    try {
        $sess = New-PSSession -ComputerName $f @cred -Authentication Negotiate -ErrorAction Stop
        Invoke-Command -Session $sess -ScriptBlock { if (-not (Test-Path 'C:\Temp')) { New-Item -ItemType Directory 'C:\Temp' | Out-Null } }
        Copy-Item -Path $Uninstaller -Destination 'C:\Temp\CsUninstallTool.exe' -ToSession $sess -Force
        $exit = Invoke-Command -Session $sess -ScriptBlock $remote -ArgumentList 'C:\Temp\CsUninstallTool.exe', $UninstallArgs
        Start-Sleep -Seconds 20
        Invoke-Command -Session $sess -ScriptBlock { Remove-Item 'C:\Temp\CsUninstallTool.exe' -Force -ErrorAction SilentlyContinue }
        Remove-PSSession $sess; $sess = $null
        $after = Get-State $f
        $ok = ($after.Reach -eq 'OK' -and $after.CrowdStrike -eq 'not installed')
        if ($exit -eq 3010) { $note = 'reboot required' }
        if ($ok) { $fails = 0; Write-Host "   removed (exit $exit) $note" -ForegroundColor Green } else { $fails++; $note = ($note + " still present: $($after.CrowdStrike)").Trim(); Write-Warning "$f : exit $exit, CrowdStrike still shows '$($after.CrowdStrike)'. Wrong token or protection on? $note" }
        $results += [pscustomobject]@{ Server = $f; Result = $(if ($ok) { 'REMOVED' } else { 'NOT REMOVED' }); ExitCode = $exit; Note = $note; Ticket = $Ticket }
    } catch {
        $fails++
        $m = $_.Exception.Message.Split("`n")[0].Trim()
        Write-Warning "$f : $m"
        $results += [pscustomobject]@{ Server = $f; Result = 'ERROR'; ExitCode = $exit; Note = $m; Ticket = $Ticket }
        if ($sess) { Remove-PSSession $sess -ErrorAction SilentlyContinue }
    }
    if ($fails -ge 2) { Write-Warning 'Two failures in a row. Stopping so nothing else is touched. Fix the cause, then rerun.'; break }
}
$token = $null
$results | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
$out = Join-Path $OutDir "CrowdStrike_Remove_$stamp.csv"
$results | Export-Csv $out -NoTypeInformation
Write-Host "Report: $out" -ForegroundColor Green
Write-Host 'Next: confirm each server shows no CrowdStrike, then install Cortex from C:\Temp (installer saved by Morgan).' -ForegroundColor Yellow