Claude work backup - 2026-11-03 22:59
Marc Stern / NICE SysOps

What is in here: scripts (.ps1 .sh .py .cmd), runbooks and cheat sheets (.md .docx), Ops Hub app and configs (.json .html),
and the C: drive review workbook/doc. Folder layout mirrors C:\Temp.

Left out on purpose (employee/HR data, logs, secrets): all .csv data files, Okta/HR exports and the Okta review workbook,
Ops Hub data\ and runs\ folders, term/AD run logs, certificates and keys, personal projects.
No credentials are stored in any script (they prompt at run time).

To restore: unzip into C:\Temp. Scripts that were last changed in this session are the versions in the top level.
